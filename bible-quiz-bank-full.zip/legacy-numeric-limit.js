(function(root){
 // Keep source files intact; apply one shared cap across built-in playable pools.
 let remaining=20;const removed=[];
 function cap(list){return (list||[]).filter(q=>{if(!root.BibleReadingCore.numericPrompt(q))return true;if(remaining>0){remaining--;return true;}removed.push(q.id||q.quiz_id||q.question_id);return false;});}
 root.BIBLE_QUIZ_QUESTIONS=cap(root.BIBLE_QUIZ_QUESTIONS);
 root.BIBLE_BOOK_QUIZ_QUESTIONS=cap(root.BIBLE_BOOK_QUIZ_QUESTIONS);
 if(root.BIBLE_GAME_SEED)root.BIBLE_GAME_SEED.quizzes=cap(root.BIBLE_GAME_SEED.quizzes);
 if(root.BIBLE_CHAPTER_QUESTION_BANK)root.BIBLE_CHAPTER_QUESTION_BANK.questions=cap(root.BIBLE_CHAPTER_QUESTION_BANK.questions);
 root.BIBLE_NUMERIC_POLICY={limit:20,retained:20-remaining,removed:removed.length};
})(window);
