(function initGenesisGameData(root) {
  const seed = {
  "content_version": "whole-bible-journey-v1-bank-1189",
  "default_locale": "ko",
  "world_id": "W_OT_PENT",
  "translation_policy": {
    "canonical_locale": "ko",
    "korean_bible_standard": "개역개정",
    "text_storage_rule": "사진/에셋에는 문자를 넣지 않고 모든 제목, 설명, 장절 표시는 텍스트 필드로 렌더링한다.",
    "license_note": "저작권 검수 전에는 성경 본문 전문을 저장하지 않고 장절 참조와 요약 중심으로 표시한다.",
    "review_required_locales": [
      "en",
      "ja",
      "ms",
      "th",
      "km"
    ]
  },
  "protected_terms": {
    "ko": {
      "Esau": "에서",
      "Jacob": "야곱",
      "Joseph": "요셉",
      "Egypt": "애굽",
      "Haran": "하란",
      "Canaan": "가나안",
      "Bethel": "벧엘"
    },
    "en": {
      "Esau": "Esau",
      "Jacob": "Jacob",
      "Joseph": "Joseph",
      "Egypt": "Egypt",
      "Haran": "Haran",
      "Canaan": "Canaan",
      "Bethel": "Bethel"
    }
  },
  "content_manifest": {
    "version": "whole-bible-journey-v1-bank-1189",
    "storage_key": "bibleQuizContentVersion.v1",
    "pack_format": "section/book-stage/chapter-bank-quiz",
    "chapter_bank_version": "whole-bible-chapter-bank-v4-scripture-facts",
    "total_chapter_questions": 1189,
    "total_bank_questions": 2238,
    "randomization": "Each journey stage samples chapter-bank questions at run time.",
    "packs": [
      {
        "section_key": "pentateuch",
        "book_id": "OT-PENT",
        "source": "./genesisGameData.js",
        "question_bank_source": "./bibleChapterQuestionBank.generated.js",
        "status": "active",
        "book_count": 5,
        "chapter_question_count": 187
      },
      {
        "section_key": "history",
        "book_id": "OT-HIST",
        "source": "./genesisGameData.js",
        "question_bank_source": "./bibleChapterQuestionBank.generated.js",
        "status": "active",
        "book_count": 12,
        "chapter_question_count": 249
      },
      {
        "section_key": "wisdom",
        "book_id": "OT-WIS",
        "source": "./genesisGameData.js",
        "question_bank_source": "./bibleChapterQuestionBank.generated.js",
        "status": "active",
        "book_count": 5,
        "chapter_question_count": 243
      },
      {
        "section_key": "majorProphets",
        "book_id": "OT-MAJOR",
        "source": "./genesisGameData.js",
        "question_bank_source": "./bibleChapterQuestionBank.generated.js",
        "status": "active",
        "book_count": 5,
        "chapter_question_count": 183
      },
      {
        "section_key": "minorProphets",
        "book_id": "OT-MINOR",
        "source": "./genesisGameData.js",
        "question_bank_source": "./bibleChapterQuestionBank.generated.js",
        "status": "active",
        "book_count": 12,
        "chapter_question_count": 67
      },
      {
        "section_key": "gospels",
        "book_id": "NT-GOS",
        "source": "./genesisGameData.js",
        "question_bank_source": "./bibleChapterQuestionBank.generated.js",
        "status": "active",
        "book_count": 4,
        "chapter_question_count": 89
      },
      {
        "section_key": "acts",
        "book_id": "NT-ACTS",
        "source": "./genesisGameData.js",
        "question_bank_source": "./bibleChapterQuestionBank.generated.js",
        "status": "active",
        "book_count": 1,
        "chapter_question_count": 28
      },
      {
        "section_key": "pauline",
        "book_id": "NT-PAUL",
        "source": "./genesisGameData.js",
        "question_bank_source": "./bibleChapterQuestionBank.generated.js",
        "status": "active",
        "book_count": 13,
        "chapter_question_count": 87
      },
      {
        "section_key": "general",
        "book_id": "NT-GEN",
        "source": "./genesisGameData.js",
        "question_bank_source": "./bibleChapterQuestionBank.generated.js",
        "status": "active",
        "book_count": 8,
        "chapter_question_count": 34
      },
      {
        "section_key": "prophecy",
        "book_id": "NT-PROP",
        "source": "./genesisGameData.js",
        "question_bank_source": "./bibleChapterQuestionBank.generated.js",
        "status": "active",
        "book_count": 1,
        "chapter_question_count": 22
      }
    ]
  },
  "books": [
    {
      "book_id": "GEN",
      "order_index": 1,
      "testament": "old",
      "section_key": "pentateuch",
      "chapters": 50,
      "title": {
        "ko": "창세기",
        "en": "Genesis",
        "ja": "創世記",
        "ms": "Kejadian",
        "th": "ปฐมกาล",
        "km": "លោកុប្បត្តិ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "창세기 50",
        "en": "Genesis 50",
        "ja": "創世記 50",
        "ms": "Kejadian 50",
        "th": "ปฐมกาล 50",
        "km": "លោកុប្បត្តិ 50"
      }
    },
    {
      "book_id": "EXO",
      "order_index": 2,
      "testament": "old",
      "section_key": "pentateuch",
      "chapters": 40,
      "title": {
        "ko": "출애굽기",
        "en": "Exodus",
        "ja": "出エジプト記",
        "ms": "Keluaran",
        "th": "อพยพ",
        "km": "និក្ខមនំ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "출애굽기 40",
        "en": "Exodus 40",
        "ja": "出エジプト記 40",
        "ms": "Keluaran 40",
        "th": "อพยพ 40",
        "km": "និក្ខមនំ 40"
      }
    },
    {
      "book_id": "LEV",
      "order_index": 3,
      "testament": "old",
      "section_key": "pentateuch",
      "chapters": 27,
      "title": {
        "ko": "레위기",
        "en": "Leviticus",
        "ja": "レビ記",
        "ms": "Imamat",
        "th": "เลวีนิติ",
        "km": "លេវីវិន័យ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "레위기 27",
        "en": "Leviticus 27",
        "ja": "レビ記 27",
        "ms": "Imamat 27",
        "th": "เลวีนิติ 27",
        "km": "លេវីវិន័យ 27"
      }
    },
    {
      "book_id": "NUM",
      "order_index": 4,
      "testament": "old",
      "section_key": "pentateuch",
      "chapters": 36,
      "title": {
        "ko": "민수기",
        "en": "Numbers",
        "ja": "民数記",
        "ms": "Bilangan",
        "th": "กันดารวิถี",
        "km": "ជនគណនា"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "민수기 36",
        "en": "Numbers 36",
        "ja": "民数記 36",
        "ms": "Bilangan 36",
        "th": "กันดารวิถี 36",
        "km": "ជនគណនា 36"
      }
    },
    {
      "book_id": "DEU",
      "order_index": 5,
      "testament": "old",
      "section_key": "pentateuch",
      "chapters": 34,
      "title": {
        "ko": "신명기",
        "en": "Deuteronomy",
        "ja": "申命記",
        "ms": "Ulangan",
        "th": "เฉลยธรรมบัญญัติ",
        "km": "ចោទិយកថា"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "신명기 34",
        "en": "Deuteronomy 34",
        "ja": "申命記 34",
        "ms": "Ulangan 34",
        "th": "เฉลยธรรมบัญญัติ 34",
        "km": "ចោទិយកថា 34"
      }
    },
    {
      "book_id": "JOS",
      "order_index": 6,
      "testament": "old",
      "section_key": "history",
      "chapters": 24,
      "title": {
        "ko": "여호수아",
        "en": "Joshua",
        "ja": "ヨシュア記",
        "ms": "Yosua",
        "th": "โยชูวา",
        "km": "យ៉ូស្វេ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "여호수아 24",
        "en": "Joshua 24",
        "ja": "ヨシュア記 24",
        "ms": "Yosua 24",
        "th": "โยชูวา 24",
        "km": "យ៉ូស្វេ 24"
      }
    },
    {
      "book_id": "JDG",
      "order_index": 7,
      "testament": "old",
      "section_key": "history",
      "chapters": 21,
      "title": {
        "ko": "사사기",
        "en": "Judges",
        "ja": "士師記",
        "ms": "Hakim-hakim",
        "th": "ผู้วินิจฉัย",
        "km": "ពួកចៅហ្វាយ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "사사기 21",
        "en": "Judges 21",
        "ja": "士師記 21",
        "ms": "Hakim-hakim 21",
        "th": "ผู้วินิจฉัย 21",
        "km": "ពួកចៅហ្វាយ 21"
      }
    },
    {
      "book_id": "RUT",
      "order_index": 8,
      "testament": "old",
      "section_key": "history",
      "chapters": 4,
      "title": {
        "ko": "룻기",
        "en": "Ruth",
        "ja": "ルツ記",
        "ms": "Rut",
        "th": "รูธ",
        "km": "នាងរស់"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "룻기 4",
        "en": "Ruth 4",
        "ja": "ルツ記 4",
        "ms": "Rut 4",
        "th": "รูธ 4",
        "km": "នាងរស់ 4"
      }
    },
    {
      "book_id": "1SA",
      "order_index": 9,
      "testament": "old",
      "section_key": "history",
      "chapters": 31,
      "title": {
        "ko": "사무엘상",
        "en": "1 Samuel",
        "ja": "サムエル記上",
        "ms": "1 Samuel",
        "th": "1 ซามูเอล",
        "km": "១ សាំយូអែល"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "사무엘상 31",
        "en": "1 Samuel 31",
        "ja": "サムエル記上 31",
        "ms": "1 Samuel 31",
        "th": "1 ซามูเอล 31",
        "km": "១ សាំយូអែល 31"
      }
    },
    {
      "book_id": "2SA",
      "order_index": 10,
      "testament": "old",
      "section_key": "history",
      "chapters": 24,
      "title": {
        "ko": "사무엘하",
        "en": "2 Samuel",
        "ja": "サムエル記下",
        "ms": "2 Samuel",
        "th": "2 ซามูเอล",
        "km": "២ សាំយូអែល"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "사무엘하 24",
        "en": "2 Samuel 24",
        "ja": "サムエル記下 24",
        "ms": "2 Samuel 24",
        "th": "2 ซามูเอล 24",
        "km": "២ សាំយូអែល 24"
      }
    },
    {
      "book_id": "1KI",
      "order_index": 11,
      "testament": "old",
      "section_key": "history",
      "chapters": 22,
      "title": {
        "ko": "열왕기상",
        "en": "1 Kings",
        "ja": "列王記上",
        "ms": "1 Raja-raja",
        "th": "1 พงศ์กษัตริย์",
        "km": "១ ពង្សាវតារក្សត្រ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "열왕기상 22",
        "en": "1 Kings 22",
        "ja": "列王記上 22",
        "ms": "1 Raja-raja 22",
        "th": "1 พงศ์กษัตริย์ 22",
        "km": "១ ពង្សាវតារក្សត្រ 22"
      }
    },
    {
      "book_id": "2KI",
      "order_index": 12,
      "testament": "old",
      "section_key": "history",
      "chapters": 25,
      "title": {
        "ko": "열왕기하",
        "en": "2 Kings",
        "ja": "列王記下",
        "ms": "2 Raja-raja",
        "th": "2 พงศ์กษัตริย์",
        "km": "២ ពង្សាវតារក្សត្រ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "열왕기하 25",
        "en": "2 Kings 25",
        "ja": "列王記下 25",
        "ms": "2 Raja-raja 25",
        "th": "2 พงศ์กษัตริย์ 25",
        "km": "២ ពង្សាវតារក្សត្រ 25"
      }
    },
    {
      "book_id": "1CH",
      "order_index": 13,
      "testament": "old",
      "section_key": "history",
      "chapters": 29,
      "title": {
        "ko": "역대상",
        "en": "1 Chronicles",
        "ja": "歴代誌上",
        "ms": "1 Tawarikh",
        "th": "1 พงศาวดาร",
        "km": "១ របាក្សត្រ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "역대상 29",
        "en": "1 Chronicles 29",
        "ja": "歴代誌上 29",
        "ms": "1 Tawarikh 29",
        "th": "1 พงศาวดาร 29",
        "km": "១ របាក្សត្រ 29"
      }
    },
    {
      "book_id": "2CH",
      "order_index": 14,
      "testament": "old",
      "section_key": "history",
      "chapters": 36,
      "title": {
        "ko": "역대하",
        "en": "2 Chronicles",
        "ja": "歴代誌下",
        "ms": "2 Tawarikh",
        "th": "2 พงศาวดาร",
        "km": "២ របាក្សត្រ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "역대하 36",
        "en": "2 Chronicles 36",
        "ja": "歴代誌下 36",
        "ms": "2 Tawarikh 36",
        "th": "2 พงศาวดาร 36",
        "km": "២ របាក្សត្រ 36"
      }
    },
    {
      "book_id": "EZR",
      "order_index": 15,
      "testament": "old",
      "section_key": "history",
      "chapters": 10,
      "title": {
        "ko": "에스라",
        "en": "Ezra",
        "ja": "エズラ記",
        "ms": "Ezra",
        "th": "เอสรา",
        "km": "អែសរ៉ា"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "에스라 10",
        "en": "Ezra 10",
        "ja": "エズラ記 10",
        "ms": "Ezra 10",
        "th": "เอสรา 10",
        "km": "អែសរ៉ា 10"
      }
    },
    {
      "book_id": "NEH",
      "order_index": 16,
      "testament": "old",
      "section_key": "history",
      "chapters": 13,
      "title": {
        "ko": "느헤미야",
        "en": "Nehemiah",
        "ja": "ネヘミヤ記",
        "ms": "Nehemia",
        "th": "เนหะมีย์",
        "km": "នេហេមា"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "느헤미야 13",
        "en": "Nehemiah 13",
        "ja": "ネヘミヤ記 13",
        "ms": "Nehemia 13",
        "th": "เนหะมีย์ 13",
        "km": "នេហេមា 13"
      }
    },
    {
      "book_id": "EST",
      "order_index": 17,
      "testament": "old",
      "section_key": "history",
      "chapters": 10,
      "title": {
        "ko": "에스더",
        "en": "Esther",
        "ja": "エステル記",
        "ms": "Ester",
        "th": "เอสเธอร์",
        "km": "អេសធើរ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "에스더 10",
        "en": "Esther 10",
        "ja": "エステル記 10",
        "ms": "Ester 10",
        "th": "เอสเธอร์ 10",
        "km": "អេសធើរ 10"
      }
    },
    {
      "book_id": "JOB",
      "order_index": 18,
      "testament": "old",
      "section_key": "wisdom",
      "chapters": 42,
      "title": {
        "ko": "욥기",
        "en": "Job",
        "ja": "ヨブ記",
        "ms": "Ayub",
        "th": "โยบ",
        "km": "យ៉ូប"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "욥기 42",
        "en": "Job 42",
        "ja": "ヨブ記 42",
        "ms": "Ayub 42",
        "th": "โยบ 42",
        "km": "យ៉ូប 42"
      }
    },
    {
      "book_id": "PSA",
      "order_index": 19,
      "testament": "old",
      "section_key": "wisdom",
      "chapters": 150,
      "title": {
        "ko": "시편",
        "en": "Psalms",
        "ja": "詩篇",
        "ms": "Mazmur",
        "th": "สดุดี",
        "km": "ទំនុកតម្កើង"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "시편 150",
        "en": "Psalms 150",
        "ja": "詩篇 150",
        "ms": "Mazmur 150",
        "th": "สดุดี 150",
        "km": "ទំនុកតម្កើង 150"
      }
    },
    {
      "book_id": "PRO",
      "order_index": 20,
      "testament": "old",
      "section_key": "wisdom",
      "chapters": 31,
      "title": {
        "ko": "잠언",
        "en": "Proverbs",
        "ja": "箴言",
        "ms": "Amsal",
        "th": "สุภาษิต",
        "km": "សុភាសិត"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "잠언 31",
        "en": "Proverbs 31",
        "ja": "箴言 31",
        "ms": "Amsal 31",
        "th": "สุภาษิต 31",
        "km": "សុភាសិត 31"
      }
    },
    {
      "book_id": "ECC",
      "order_index": 21,
      "testament": "old",
      "section_key": "wisdom",
      "chapters": 12,
      "title": {
        "ko": "전도서",
        "en": "Ecclesiastes",
        "ja": "伝道者の書",
        "ms": "Pengkhotbah",
        "th": "ปัญญาจารย์",
        "km": "សាស្ដា"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "전도서 12",
        "en": "Ecclesiastes 12",
        "ja": "伝道者の書 12",
        "ms": "Pengkhotbah 12",
        "th": "ปัญญาจารย์ 12",
        "km": "សាស្ដា 12"
      }
    },
    {
      "book_id": "SNG",
      "order_index": 22,
      "testament": "old",
      "section_key": "wisdom",
      "chapters": 8,
      "title": {
        "ko": "아가",
        "en": "Song of Songs",
        "ja": "雅歌",
        "ms": "Kidung Agung",
        "th": "เพลงซาโลมอน",
        "km": "បទចម្រៀងសាឡូម៉ូន"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "아가 8",
        "en": "Song of Songs 8",
        "ja": "雅歌 8",
        "ms": "Kidung Agung 8",
        "th": "เพลงซาโลมอน 8",
        "km": "បទចម្រៀងសាឡូម៉ូន 8"
      }
    },
    {
      "book_id": "ISA",
      "order_index": 23,
      "testament": "old",
      "section_key": "majorProphets",
      "chapters": 66,
      "title": {
        "ko": "이사야",
        "en": "Isaiah",
        "ja": "イザヤ書",
        "ms": "Yesaya",
        "th": "อิสยาห์",
        "km": "អេសាយ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "이사야 66",
        "en": "Isaiah 66",
        "ja": "イザヤ書 66",
        "ms": "Yesaya 66",
        "th": "อิสยาห์ 66",
        "km": "អេសាយ 66"
      }
    },
    {
      "book_id": "JER",
      "order_index": 24,
      "testament": "old",
      "section_key": "majorProphets",
      "chapters": 52,
      "title": {
        "ko": "예레미야",
        "en": "Jeremiah",
        "ja": "エレミヤ書",
        "ms": "Yeremia",
        "th": "เยเรมีย์",
        "km": "យេរេមា"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "예레미야 52",
        "en": "Jeremiah 52",
        "ja": "エレミヤ書 52",
        "ms": "Yeremia 52",
        "th": "เยเรมีย์ 52",
        "km": "យេរេមា 52"
      }
    },
    {
      "book_id": "LAM",
      "order_index": 25,
      "testament": "old",
      "section_key": "majorProphets",
      "chapters": 5,
      "title": {
        "ko": "예레미야애가",
        "en": "Lamentations",
        "ja": "哀歌",
        "ms": "Ratapan",
        "th": "เพลงคร่ำครวญ",
        "km": "បរិទេវ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "예레미야애가 5",
        "en": "Lamentations 5",
        "ja": "哀歌 5",
        "ms": "Ratapan 5",
        "th": "เพลงคร่ำครวญ 5",
        "km": "បរិទេវ 5"
      }
    },
    {
      "book_id": "EZK",
      "order_index": 26,
      "testament": "old",
      "section_key": "majorProphets",
      "chapters": 48,
      "title": {
        "ko": "에스겔",
        "en": "Ezekiel",
        "ja": "エゼキエル書",
        "ms": "Yehezkiel",
        "th": "เอเสเคียล",
        "km": "អេសេគាល"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "에스겔 48",
        "en": "Ezekiel 48",
        "ja": "エゼキエル書 48",
        "ms": "Yehezkiel 48",
        "th": "เอเสเคียล 48",
        "km": "អេសេគាល 48"
      }
    },
    {
      "book_id": "DAN",
      "order_index": 27,
      "testament": "old",
      "section_key": "majorProphets",
      "chapters": 12,
      "title": {
        "ko": "다니엘",
        "en": "Daniel",
        "ja": "ダニエル書",
        "ms": "Daniel",
        "th": "ดาเนียล",
        "km": "ដានីយ៉ែល"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "다니엘 12",
        "en": "Daniel 12",
        "ja": "ダニエル書 12",
        "ms": "Daniel 12",
        "th": "ดาเนียล 12",
        "km": "ដានីយ៉ែល 12"
      }
    },
    {
      "book_id": "HOS",
      "order_index": 28,
      "testament": "old",
      "section_key": "minorProphets",
      "chapters": 14,
      "title": {
        "ko": "호세아",
        "en": "Hosea",
        "ja": "ホセア書",
        "ms": "Hosea",
        "th": "โฮเชยา",
        "km": "ហូសេ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "호세아 14",
        "en": "Hosea 14",
        "ja": "ホセア書 14",
        "ms": "Hosea 14",
        "th": "โฮเชยา 14",
        "km": "ហូសេ 14"
      }
    },
    {
      "book_id": "JOL",
      "order_index": 29,
      "testament": "old",
      "section_key": "minorProphets",
      "chapters": 3,
      "title": {
        "ko": "요엘",
        "en": "Joel",
        "ja": "ヨエル書",
        "ms": "Yoel",
        "th": "โยเอล",
        "km": "យ៉ូអែល"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "요엘 3",
        "en": "Joel 3",
        "ja": "ヨエル書 3",
        "ms": "Yoel 3",
        "th": "โยเอล 3",
        "km": "យ៉ូអែល 3"
      }
    },
    {
      "book_id": "AMO",
      "order_index": 30,
      "testament": "old",
      "section_key": "minorProphets",
      "chapters": 9,
      "title": {
        "ko": "아모스",
        "en": "Amos",
        "ja": "アモス書",
        "ms": "Amos",
        "th": "อาโมส",
        "km": "អាម៉ុស"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "아모스 9",
        "en": "Amos 9",
        "ja": "アモス書 9",
        "ms": "Amos 9",
        "th": "อาโมส 9",
        "km": "អាម៉ុស 9"
      }
    },
    {
      "book_id": "OBA",
      "order_index": 31,
      "testament": "old",
      "section_key": "minorProphets",
      "chapters": 1,
      "title": {
        "ko": "오바댜",
        "en": "Obadiah",
        "ja": "オバデヤ書",
        "ms": "Obaja",
        "th": "โอบาดีห์",
        "km": "អូបាឌា"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "오바댜 1",
        "en": "Obadiah 1",
        "ja": "オバデヤ書 1",
        "ms": "Obaja 1",
        "th": "โอบาดีห์ 1",
        "km": "អូបាឌា 1"
      }
    },
    {
      "book_id": "JON",
      "order_index": 32,
      "testament": "old",
      "section_key": "minorProphets",
      "chapters": 4,
      "title": {
        "ko": "요나",
        "en": "Jonah",
        "ja": "ヨナ書",
        "ms": "Yunus",
        "th": "โยนาห์",
        "km": "យ៉ូណា"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "요나 4",
        "en": "Jonah 4",
        "ja": "ヨナ書 4",
        "ms": "Yunus 4",
        "th": "โยนาห์ 4",
        "km": "យ៉ូណា 4"
      }
    },
    {
      "book_id": "MIC",
      "order_index": 33,
      "testament": "old",
      "section_key": "minorProphets",
      "chapters": 7,
      "title": {
        "ko": "미가",
        "en": "Micah",
        "ja": "ミカ書",
        "ms": "Mikha",
        "th": "มีคาห์",
        "km": "មីកា"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "미가 7",
        "en": "Micah 7",
        "ja": "ミカ書 7",
        "ms": "Mikha 7",
        "th": "มีคาห์ 7",
        "km": "មីកា 7"
      }
    },
    {
      "book_id": "NAM",
      "order_index": 34,
      "testament": "old",
      "section_key": "minorProphets",
      "chapters": 3,
      "title": {
        "ko": "나훔",
        "en": "Nahum",
        "ja": "ナホム書",
        "ms": "Nahum",
        "th": "นาฮูม",
        "km": "ណាហ៊ុម"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "나훔 3",
        "en": "Nahum 3",
        "ja": "ナホム書 3",
        "ms": "Nahum 3",
        "th": "นาฮูม 3",
        "km": "ណាហ៊ុម 3"
      }
    },
    {
      "book_id": "HAB",
      "order_index": 35,
      "testament": "old",
      "section_key": "minorProphets",
      "chapters": 3,
      "title": {
        "ko": "하박국",
        "en": "Habakkuk",
        "ja": "ハバクク書",
        "ms": "Habakuk",
        "th": "ฮาบากุก",
        "km": "ហាបាគុក"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "하박국 3",
        "en": "Habakkuk 3",
        "ja": "ハバクク書 3",
        "ms": "Habakuk 3",
        "th": "ฮาบากุก 3",
        "km": "ហាបាគុក 3"
      }
    },
    {
      "book_id": "ZEP",
      "order_index": 36,
      "testament": "old",
      "section_key": "minorProphets",
      "chapters": 3,
      "title": {
        "ko": "스바냐",
        "en": "Zephaniah",
        "ja": "ゼパニヤ書",
        "ms": "Zefanya",
        "th": "เศฟันยาห์",
        "km": "សេផានា"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "스바냐 3",
        "en": "Zephaniah 3",
        "ja": "ゼパニヤ書 3",
        "ms": "Zefanya 3",
        "th": "เศฟันยาห์ 3",
        "km": "សេផានា 3"
      }
    },
    {
      "book_id": "HAG",
      "order_index": 37,
      "testament": "old",
      "section_key": "minorProphets",
      "chapters": 2,
      "title": {
        "ko": "학개",
        "en": "Haggai",
        "ja": "ハガイ書",
        "ms": "Hagai",
        "th": "ฮักกัย",
        "km": "ហាកាយ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "학개 2",
        "en": "Haggai 2",
        "ja": "ハガイ書 2",
        "ms": "Hagai 2",
        "th": "ฮักกัย 2",
        "km": "ហាកាយ 2"
      }
    },
    {
      "book_id": "ZEC",
      "order_index": 38,
      "testament": "old",
      "section_key": "minorProphets",
      "chapters": 14,
      "title": {
        "ko": "스가랴",
        "en": "Zechariah",
        "ja": "ゼカリヤ書",
        "ms": "Zakharia",
        "th": "เศคาริยาห์",
        "km": "សាការី"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "스가랴 14",
        "en": "Zechariah 14",
        "ja": "ゼカリヤ書 14",
        "ms": "Zakharia 14",
        "th": "เศคาริยาห์ 14",
        "km": "សាការី 14"
      }
    },
    {
      "book_id": "MAL",
      "order_index": 39,
      "testament": "old",
      "section_key": "minorProphets",
      "chapters": 4,
      "title": {
        "ko": "말라기",
        "en": "Malachi",
        "ja": "マラキ書",
        "ms": "Maleakhi",
        "th": "มาลาคี",
        "km": "ម៉ាឡាគី"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "말라기 4",
        "en": "Malachi 4",
        "ja": "マラキ書 4",
        "ms": "Maleakhi 4",
        "th": "มาลาคี 4",
        "km": "ម៉ាឡាគី 4"
      }
    },
    {
      "book_id": "MAT",
      "order_index": 40,
      "testament": "new",
      "section_key": "gospels",
      "chapters": 28,
      "title": {
        "ko": "마태복음",
        "en": "Matthew",
        "ja": "マタイの福音書",
        "ms": "Matius",
        "th": "มัทธิว",
        "km": "ម៉ាថាយ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "마태복음 28",
        "en": "Matthew 28",
        "ja": "マタイの福音書 28",
        "ms": "Matius 28",
        "th": "มัทธิว 28",
        "km": "ម៉ាថាយ 28"
      }
    },
    {
      "book_id": "MRK",
      "order_index": 41,
      "testament": "new",
      "section_key": "gospels",
      "chapters": 16,
      "title": {
        "ko": "마가복음",
        "en": "Mark",
        "ja": "マルコの福音書",
        "ms": "Markus",
        "th": "มาระโก",
        "km": "ម៉ាកុស"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "마가복음 16",
        "en": "Mark 16",
        "ja": "マルコの福音書 16",
        "ms": "Markus 16",
        "th": "มาระโก 16",
        "km": "ម៉ាកុស 16"
      }
    },
    {
      "book_id": "LUK",
      "order_index": 42,
      "testament": "new",
      "section_key": "gospels",
      "chapters": 24,
      "title": {
        "ko": "누가복음",
        "en": "Luke",
        "ja": "ルカの福音書",
        "ms": "Lukas",
        "th": "ลูกา",
        "km": "លូកា"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "누가복음 24",
        "en": "Luke 24",
        "ja": "ルカの福音書 24",
        "ms": "Lukas 24",
        "th": "ลูกา 24",
        "km": "លូកា 24"
      }
    },
    {
      "book_id": "JHN",
      "order_index": 43,
      "testament": "new",
      "section_key": "gospels",
      "chapters": 21,
      "title": {
        "ko": "요한복음",
        "en": "John",
        "ja": "ヨハネの福音書",
        "ms": "Yohanes",
        "th": "ยอห์น",
        "km": "យ៉ូហាន"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "요한복음 21",
        "en": "John 21",
        "ja": "ヨハネの福音書 21",
        "ms": "Yohanes 21",
        "th": "ยอห์น 21",
        "km": "យ៉ូហាន 21"
      }
    },
    {
      "book_id": "ACT",
      "order_index": 44,
      "testament": "new",
      "section_key": "acts",
      "chapters": 28,
      "title": {
        "ko": "사도행전",
        "en": "Acts",
        "ja": "使徒の働き",
        "ms": "Kisah Para Rasul",
        "th": "กิจการ",
        "km": "កិច្ចការ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "사도행전 28",
        "en": "Acts 28",
        "ja": "使徒の働き 28",
        "ms": "Kisah Para Rasul 28",
        "th": "กิจการ 28",
        "km": "កិច្ចការ 28"
      }
    },
    {
      "book_id": "ROM",
      "order_index": 45,
      "testament": "new",
      "section_key": "pauline",
      "chapters": 16,
      "title": {
        "ko": "로마서",
        "en": "Romans",
        "ja": "ローマ人への手紙",
        "ms": "Roma",
        "th": "โรม",
        "km": "រ៉ូម"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "로마서 16",
        "en": "Romans 16",
        "ja": "ローマ人への手紙 16",
        "ms": "Roma 16",
        "th": "โรม 16",
        "km": "រ៉ូម 16"
      }
    },
    {
      "book_id": "1CO",
      "order_index": 46,
      "testament": "new",
      "section_key": "pauline",
      "chapters": 16,
      "title": {
        "ko": "고린도전서",
        "en": "1 Corinthians",
        "ja": "コリント人への手紙第一",
        "ms": "1 Korintus",
        "th": "1 โครินธ์",
        "km": "១ កូរិនថូស"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "고린도전서 16",
        "en": "1 Corinthians 16",
        "ja": "コリント人への手紙第一 16",
        "ms": "1 Korintus 16",
        "th": "1 โครินธ์ 16",
        "km": "១ កូរិនថូស 16"
      }
    },
    {
      "book_id": "2CO",
      "order_index": 47,
      "testament": "new",
      "section_key": "pauline",
      "chapters": 13,
      "title": {
        "ko": "고린도후서",
        "en": "2 Corinthians",
        "ja": "コリント人への手紙第二",
        "ms": "2 Korintus",
        "th": "2 โครินธ์",
        "km": "២ កូរិនថូស"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "고린도후서 13",
        "en": "2 Corinthians 13",
        "ja": "コリント人への手紙第二 13",
        "ms": "2 Korintus 13",
        "th": "2 โครินธ์ 13",
        "km": "២ កូរិនថូស 13"
      }
    },
    {
      "book_id": "GAL",
      "order_index": 48,
      "testament": "new",
      "section_key": "pauline",
      "chapters": 6,
      "title": {
        "ko": "갈라디아서",
        "en": "Galatians",
        "ja": "ガラテヤ人への手紙",
        "ms": "Galatia",
        "th": "กาลาเทีย",
        "km": "កាឡាទី"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "갈라디아서 6",
        "en": "Galatians 6",
        "ja": "ガラテヤ人への手紙 6",
        "ms": "Galatia 6",
        "th": "กาลาเทีย 6",
        "km": "កាឡាទី 6"
      }
    },
    {
      "book_id": "EPH",
      "order_index": 49,
      "testament": "new",
      "section_key": "pauline",
      "chapters": 6,
      "title": {
        "ko": "에베소서",
        "en": "Ephesians",
        "ja": "エペソ人への手紙",
        "ms": "Efesus",
        "th": "เอเฟซัส",
        "km": "អេភេសូរ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "에베소서 6",
        "en": "Ephesians 6",
        "ja": "エペソ人への手紙 6",
        "ms": "Efesus 6",
        "th": "เอเฟซัส 6",
        "km": "អេភេសូរ 6"
      }
    },
    {
      "book_id": "PHP",
      "order_index": 50,
      "testament": "new",
      "section_key": "pauline",
      "chapters": 4,
      "title": {
        "ko": "빌립보서",
        "en": "Philippians",
        "ja": "ピリピ人への手紙",
        "ms": "Filipi",
        "th": "ฟิลิปปี",
        "km": "ភីលីព"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "빌립보서 4",
        "en": "Philippians 4",
        "ja": "ピリピ人への手紙 4",
        "ms": "Filipi 4",
        "th": "ฟิลิปปี 4",
        "km": "ភីលីព 4"
      }
    },
    {
      "book_id": "COL",
      "order_index": 51,
      "testament": "new",
      "section_key": "pauline",
      "chapters": 4,
      "title": {
        "ko": "골로새서",
        "en": "Colossians",
        "ja": "コロサイ人への手紙",
        "ms": "Kolose",
        "th": "โคโลสี",
        "km": "កូឡុស"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "골로새서 4",
        "en": "Colossians 4",
        "ja": "コロサイ人への手紙 4",
        "ms": "Kolose 4",
        "th": "โคโลสี 4",
        "km": "កូឡុស 4"
      }
    },
    {
      "book_id": "1TH",
      "order_index": 52,
      "testament": "new",
      "section_key": "pauline",
      "chapters": 5,
      "title": {
        "ko": "데살로니가전서",
        "en": "1 Thessalonians",
        "ja": "テサロニケ人への手紙第一",
        "ms": "1 Tesalonika",
        "th": "1 เธสะโลนิกา",
        "km": "១ ថែស្សាឡូនីច"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "데살로니가전서 5",
        "en": "1 Thessalonians 5",
        "ja": "テサロニケ人への手紙第一 5",
        "ms": "1 Tesalonika 5",
        "th": "1 เธสะโลนิกา 5",
        "km": "១ ថែស្សាឡូនីច 5"
      }
    },
    {
      "book_id": "2TH",
      "order_index": 53,
      "testament": "new",
      "section_key": "pauline",
      "chapters": 3,
      "title": {
        "ko": "데살로니가후서",
        "en": "2 Thessalonians",
        "ja": "テサロニケ人への手紙第二",
        "ms": "2 Tesalonika",
        "th": "2 เธสะโลนิกา",
        "km": "២ ថែស្សាឡូនីច"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "데살로니가후서 3",
        "en": "2 Thessalonians 3",
        "ja": "テサロニケ人への手紙第二 3",
        "ms": "2 Tesalonika 3",
        "th": "2 เธสะโลนิกา 3",
        "km": "២ ថែស្សាឡូនីច 3"
      }
    },
    {
      "book_id": "1TI",
      "order_index": 54,
      "testament": "new",
      "section_key": "pauline",
      "chapters": 6,
      "title": {
        "ko": "디모데전서",
        "en": "1 Timothy",
        "ja": "テモテへの手紙第一",
        "ms": "1 Timotius",
        "th": "1 ทิโมธี",
        "km": "១ ធីម៉ូថេ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "디모데전서 6",
        "en": "1 Timothy 6",
        "ja": "テモテへの手紙第一 6",
        "ms": "1 Timotius 6",
        "th": "1 ทิโมธี 6",
        "km": "១ ធីម៉ូថេ 6"
      }
    },
    {
      "book_id": "2TI",
      "order_index": 55,
      "testament": "new",
      "section_key": "pauline",
      "chapters": 4,
      "title": {
        "ko": "디모데후서",
        "en": "2 Timothy",
        "ja": "テモテへの手紙第二",
        "ms": "2 Timotius",
        "th": "2 ทิโมธี",
        "km": "២ ធីម៉ូថេ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "디모데후서 4",
        "en": "2 Timothy 4",
        "ja": "テモテへの手紙第二 4",
        "ms": "2 Timotius 4",
        "th": "2 ทิโมธี 4",
        "km": "២ ធីម៉ូថេ 4"
      }
    },
    {
      "book_id": "TIT",
      "order_index": 56,
      "testament": "new",
      "section_key": "pauline",
      "chapters": 3,
      "title": {
        "ko": "디도서",
        "en": "Titus",
        "ja": "テトスへの手紙",
        "ms": "Titus",
        "th": "ทิตัส",
        "km": "ទីតុស"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "디도서 3",
        "en": "Titus 3",
        "ja": "テトスへの手紙 3",
        "ms": "Titus 3",
        "th": "ทิตัส 3",
        "km": "ទីតុស 3"
      }
    },
    {
      "book_id": "PHM",
      "order_index": 57,
      "testament": "new",
      "section_key": "pauline",
      "chapters": 1,
      "title": {
        "ko": "빌레몬서",
        "en": "Philemon",
        "ja": "ピレモンへの手紙",
        "ms": "Filemon",
        "th": "ฟีเลโมน",
        "km": "ភីលេម៉ូន"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "빌레몬서 1",
        "en": "Philemon 1",
        "ja": "ピレモンへの手紙 1",
        "ms": "Filemon 1",
        "th": "ฟีเลโมน 1",
        "km": "ភីលេម៉ូន 1"
      }
    },
    {
      "book_id": "HEB",
      "order_index": 58,
      "testament": "new",
      "section_key": "general",
      "chapters": 13,
      "title": {
        "ko": "히브리서",
        "en": "Hebrews",
        "ja": "ヘブル人への手紙",
        "ms": "Ibrani",
        "th": "ฮีบรู",
        "km": "ហេព្រើរ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "히브리서 13",
        "en": "Hebrews 13",
        "ja": "ヘブル人への手紙 13",
        "ms": "Ibrani 13",
        "th": "ฮีบรู 13",
        "km": "ហេព្រើរ 13"
      }
    },
    {
      "book_id": "JAS",
      "order_index": 59,
      "testament": "new",
      "section_key": "general",
      "chapters": 5,
      "title": {
        "ko": "야고보서",
        "en": "James",
        "ja": "ヤコブの手紙",
        "ms": "Yakobus",
        "th": "ยากอบ",
        "km": "យ៉ាកុប"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "야고보서 5",
        "en": "James 5",
        "ja": "ヤコブの手紙 5",
        "ms": "Yakobus 5",
        "th": "ยากอบ 5",
        "km": "យ៉ាកុប 5"
      }
    },
    {
      "book_id": "1PE",
      "order_index": 60,
      "testament": "new",
      "section_key": "general",
      "chapters": 5,
      "title": {
        "ko": "베드로전서",
        "en": "1 Peter",
        "ja": "ペテロの手紙第一",
        "ms": "1 Petrus",
        "th": "1 เปโตร",
        "km": "១ ពេត្រុស"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "베드로전서 5",
        "en": "1 Peter 5",
        "ja": "ペテロの手紙第一 5",
        "ms": "1 Petrus 5",
        "th": "1 เปโตร 5",
        "km": "១ ពេត្រុស 5"
      }
    },
    {
      "book_id": "2PE",
      "order_index": 61,
      "testament": "new",
      "section_key": "general",
      "chapters": 3,
      "title": {
        "ko": "베드로후서",
        "en": "2 Peter",
        "ja": "ペテロの手紙第二",
        "ms": "2 Petrus",
        "th": "2 เปโตร",
        "km": "២ ពេត្រុស"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "베드로후서 3",
        "en": "2 Peter 3",
        "ja": "ペテロの手紙第二 3",
        "ms": "2 Petrus 3",
        "th": "2 เปโตร 3",
        "km": "២ ពេត្រុស 3"
      }
    },
    {
      "book_id": "1JN",
      "order_index": 62,
      "testament": "new",
      "section_key": "general",
      "chapters": 5,
      "title": {
        "ko": "요한일서",
        "en": "1 John",
        "ja": "ヨハネの手紙第一",
        "ms": "1 Yohanes",
        "th": "1 ยอห์น",
        "km": "១ យ៉ូហាន"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "요한일서 5",
        "en": "1 John 5",
        "ja": "ヨハネの手紙第一 5",
        "ms": "1 Yohanes 5",
        "th": "1 ยอห์น 5",
        "km": "១ យ៉ូហាន 5"
      }
    },
    {
      "book_id": "2JN",
      "order_index": 63,
      "testament": "new",
      "section_key": "general",
      "chapters": 1,
      "title": {
        "ko": "요한이서",
        "en": "2 John",
        "ja": "ヨハネの手紙第二",
        "ms": "2 Yohanes",
        "th": "2 ยอห์น",
        "km": "២ យ៉ូហាន"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "요한이서 1",
        "en": "2 John 1",
        "ja": "ヨハネの手紙第二 1",
        "ms": "2 Yohanes 1",
        "th": "2 ยอห์น 1",
        "km": "២ យ៉ូហាន 1"
      }
    },
    {
      "book_id": "3JN",
      "order_index": 64,
      "testament": "new",
      "section_key": "general",
      "chapters": 1,
      "title": {
        "ko": "요한삼서",
        "en": "3 John",
        "ja": "ヨハネの手紙第三",
        "ms": "3 Yohanes",
        "th": "3 ยอห์น",
        "km": "៣ យ៉ូហាន"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "요한삼서 1",
        "en": "3 John 1",
        "ja": "ヨハネの手紙第三 1",
        "ms": "3 Yohanes 1",
        "th": "3 ยอห์น 1",
        "km": "៣ យ៉ូហាន 1"
      }
    },
    {
      "book_id": "JUD",
      "order_index": 65,
      "testament": "new",
      "section_key": "general",
      "chapters": 1,
      "title": {
        "ko": "유다서",
        "en": "Jude",
        "ja": "ユダの手紙",
        "ms": "Yudas",
        "th": "ยูดา",
        "km": "យូដាស"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "유다서 1",
        "en": "Jude 1",
        "ja": "ユダの手紙 1",
        "ms": "Yudas 1",
        "th": "ยูดา 1",
        "km": "យូដាស 1"
      }
    },
    {
      "book_id": "REV",
      "order_index": 66,
      "testament": "new",
      "section_key": "prophecy",
      "chapters": 22,
      "title": {
        "ko": "요한계시록",
        "en": "Revelation",
        "ja": "黙示録",
        "ms": "Wahyu",
        "th": "วิวรณ์",
        "km": "វិវរណៈ"
      },
      "status": "active",
      "upgrade_note": {
        "ko": "요한계시록 22",
        "en": "Revelation 22",
        "ja": "黙示録 22",
        "ms": "Wahyu 22",
        "th": "วิวรณ์ 22",
        "km": "វិវរណៈ 22"
      }
    }
  ],
  "worlds": [
    {
      "world_id": "W_OT_PENT",
      "code": "OT-PENT",
      "title": {
        "ko": "구약 1. 모세오경",
        "en": "Old Testament 1. Pentateuch",
        "ja": "旧約1. モーセ五書",
        "ms": "Perjanjian Lama 1. Taurat",
        "th": "พันธสัญญาเดิม 1. โมเสสห้าเล่ม",
        "km": "សញ្ញាចាស់ ១. បញ្ចកណ្ឌ"
      },
      "subtitle": {
        "ko": "창조, 언약, 출애굽, 율법, 광야 여정을 성경 첫 다섯 권으로 따라갑니다.",
        "en": "Follow creation, covenant, Exodus, law, and wilderness through the first five books.",
        "ja": "創造、契約、出エジプト、律法、荒野の旅を最初の五書でたどります。",
        "ms": "Ikuti penciptaan, perjanjian, Keluaran, hukum, dan padang gurun melalui lima kitab pertama.",
        "th": "ติดตามการทรงสร้าง พันธสัญญา อพยพ ธรรมบัญญัติ และถิ่นทุรกันดารผ่านห้าเล่มแรก",
        "km": "ដើរតាមការបង្កើត សម្ពន្ធមេត្រី និក្ខមនំ ក្រឹត្យវិន័យ និងទីរហោស្ថានតាមសៀវភៅប្រាំដំបូង។"
      },
      "bible_range": "구약 1. 모세오경",
      "design_theme_key": "OT-PENT_WORLD_STYLE",
      "background_asset_key": "asset.world.ot-pent"
    },
    {
      "world_id": "W_OT_HIST",
      "code": "OT-HIST",
      "title": {
        "ko": "구약 2. 역사서",
        "en": "Old Testament 2. Historical Books",
        "ja": "旧約2. 歴史書",
        "ms": "Perjanjian Lama 2. Kitab Sejarah",
        "th": "พันธสัญญาเดิม 2. หนังสือประวัติศาสตร์",
        "km": "សញ្ញាចាស់ ២. សៀវភៅប្រវត្តិសាស្ត្រ"
      },
      "subtitle": {
        "ko": "가나안 정착, 사사, 왕국, 포로, 귀환의 흐름을 책별로 걷습니다.",
        "en": "Walk conquest, judges, kingdom, exile, and return book by book.",
        "ja": "カナン定着、士師、王国、捕囚、帰還を各書で歩きます。",
        "ms": "Ikuti penaklukan, hakim-hakim, kerajaan, pembuangan, dan kepulangan mengikut kitab.",
        "th": "เดินผ่านการพิชิต ผู้วินิจฉัย อาณาจักร การเป็นเชลย และการกลับมาตามแต่ละเล่ม",
        "km": "ដើរតាមការចូលកាន់កាប់ ចៅហ្វាយ អាណាចក្រ ការជាប់ជាឈ្លើយ និងការត្រឡប់តាមសៀវភៅនីមួយៗ។"
      },
      "bible_range": "구약 2. 역사서",
      "design_theme_key": "OT-HIST_WORLD_STYLE",
      "background_asset_key": "asset.world.ot-hist"
    },
    {
      "world_id": "W_OT_WIS",
      "code": "OT-WIS",
      "title": {
        "ko": "구약 3. 시가서",
        "en": "Old Testament 3. Wisdom and Poetry",
        "ja": "旧約3. 知恵と詩",
        "ms": "Perjanjian Lama 3. Hikmat dan Puisi",
        "th": "พันธสัญญาเดิม 3. ปัญญาและบทกวี",
        "km": "សញ្ញាចាស់ ៣. ប្រាជ្ញា និងកំណាព្យ"
      },
      "subtitle": {
        "ko": "고난, 찬양, 지혜, 인생의 의미, 사랑의 노래를 묵상합니다.",
        "en": "Reflect on suffering, praise, wisdom, meaning, and love songs.",
        "ja": "苦難、賛美、知恵、人生の意味、愛の歌を黙想します。",
        "ms": "Renungkan penderitaan, pujian, hikmat, makna hidup, dan nyanyian kasih.",
        "th": "ใคร่ครวญความทุกข์ การสรรเสริญ ปัญญา ความหมายชีวิต และบทเพลงรัก",
        "km": "សញ្ជឹងគិតអំពីទុក្ខវេទនា ការសរសើរ ប្រាជ្ញា អត្ថន័យជីវិត និងបទចម្រៀងសេចក្ដីស្រឡាញ់។"
      },
      "bible_range": "구약 3. 시가서",
      "design_theme_key": "OT-WIS_WORLD_STYLE",
      "background_asset_key": "asset.world.ot-wis"
    },
    {
      "world_id": "W_OT_MAJOR",
      "code": "OT-MAJOR",
      "title": {
        "ko": "구약 4. 대선지서",
        "en": "Old Testament 4. Major Prophets",
        "ja": "旧約4. 大預言書",
        "ms": "Perjanjian Lama 4. Nabi-nabi Besar",
        "th": "พันธสัญญาเดิม 4. ผู้เผยพระวจนะใหญ่",
        "km": "សញ្ញាចាស់ ៤. ហោរាធំ"
      },
      "subtitle": {
        "ko": "심판, 회복, 새 언약, 하나님 나라의 소망을 선지서 흐름으로 봅니다.",
        "en": "See judgment, restoration, new covenant, and kingdom hope through the prophets.",
        "ja": "裁き、回復、新しい契約、神の国の希望を預言書で見ます。",
        "ms": "Lihat penghakiman, pemulihan, perjanjian baru, dan harapan kerajaan melalui nabi-nabi.",
        "th": "มองการพิพากษา การฟื้นฟู พันธสัญญาใหม่ และความหวังแห่งอาณาจักรผ่านผู้เผยพระวจนะ",
        "km": "មើលការជំនុំជម្រះ ការស្ដារ សម្ពន្ធមេត្រីថ្មី និងសេចក្ដីសង្ឃឹមនៃនគរតាមហោរា។"
      },
      "bible_range": "구약 4. 대선지서",
      "design_theme_key": "OT-MAJOR_WORLD_STYLE",
      "background_asset_key": "asset.world.ot-major"
    },
    {
      "world_id": "W_OT_MINOR",
      "code": "OT-MINOR",
      "title": {
        "ko": "구약 5. 소선지서",
        "en": "Old Testament 5. Minor Prophets",
        "ja": "旧約5. 小預言書",
        "ms": "Perjanjian Lama 5. Nabi-nabi Kecil",
        "th": "พันธสัญญาเดิม 5. ผู้เผยพระวจนะเล็ก",
        "km": "សញ្ញាចាស់ ៥. ហោរាតូច"
      },
      "subtitle": {
        "ko": "열두 선지자의 회개, 정의, 긍휼, 소망의 메시지를 따라갑니다.",
        "en": "Follow the twelve prophets' calls to repentance, justice, mercy, and hope.",
        "ja": "十二預言者の悔い改め、正義、憐れみ、希望の呼びかけをたどります。",
        "ms": "Ikuti seruan dua belas nabi tentang pertobatan, keadilan, belas kasihan, dan harapan.",
        "th": "ติดตามเสียงเรียกของผู้เผยพระวจนะสิบสองเรื่องการกลับใจ ความยุติธรรม พระเมตตา และความหวัง",
        "km": "ដើរតាមការអំពាវនាវរបស់ហោរា១២អំពីការប្រែចិត្ត យុត្តិធម៌ មេត្តាករុណា និងសង្ឃឹម។"
      },
      "bible_range": "구약 5. 소선지서",
      "design_theme_key": "OT-MINOR_WORLD_STYLE",
      "background_asset_key": "asset.world.ot-minor"
    },
    {
      "world_id": "W_NT_GOS",
      "code": "NT-GOS",
      "title": {
        "ko": "신약 1. 복음서",
        "en": "New Testament 1. Gospels",
        "ja": "新約1. 福音書",
        "ms": "Perjanjian Baru 1. Injil",
        "th": "พันธสัญญาใหม่ 1. พระกิตติคุณ",
        "km": "សញ្ញាថ្មី ១. ដំណឹងល្អ"
      },
      "subtitle": {
        "ko": "예수님의 탄생, 사역, 십자가, 부활을 네 복음서로 따라갑니다.",
        "en": "Follow Jesus' birth, ministry, cross, and resurrection through the four Gospels.",
        "ja": "イエスの誕生、働き、十字架、復活を四福音書でたどります。",
        "ms": "Ikuti kelahiran, pelayanan, salib, dan kebangkitan Yesus melalui empat Injil.",
        "th": "ติดตามการประสูติ พันธกิจ กางเขน และการคืนพระชนม์ของพระเยซูผ่านสี่พระกิตติคุณ",
        "km": "ដើរតាមកំណើត ព័ន្ធកិច្ច ឈើឆ្កាង និងការរស់ឡើងវិញរបស់ព្រះយេស៊ូតាមដំណឹងល្អទាំងបួន។"
      },
      "bible_range": "신약 1. 복음서",
      "design_theme_key": "NT-GOS_WORLD_STYLE",
      "background_asset_key": "asset.world.nt-gos"
    },
    {
      "world_id": "W_NT_ACTS",
      "code": "NT-ACTS",
      "title": {
        "ko": "신약 2. 역사서",
        "en": "New Testament 2. History",
        "ja": "新約2. 歴史書",
        "ms": "Perjanjian Baru 2. Sejarah",
        "th": "พันธสัญญาใหม่ 2. ประวัติศาสตร์",
        "km": "សញ្ញាថ្មី ២. ប្រវត្តិសាស្ត្រ"
      },
      "subtitle": {
        "ko": "사도행전의 성령 강림, 교회 탄생, 선교 확장을 봅니다.",
        "en": "Trace Pentecost, the birth of the church, and mission expansion in Acts.",
        "ja": "使徒の働きで聖霊降臨、教会誕生、宣教拡大を見ます。",
        "ms": "Telusuri Pentakosta, kelahiran gereja, dan pengembangan misi dalam Kisah Para Rasul.",
        "th": "ติดตามวันเพ็นเทคอสต์ การเกิดของคริสตจักร และการขยายพันธกิจในกิจการ",
        "km": "តាមដានបុណ្យថ្ងៃទី៥០ កំណើតព្រះវិហារ និងការពង្រីកបេសកកម្មក្នុងកិច្ចការ។"
      },
      "bible_range": "신약 2. 역사서",
      "design_theme_key": "NT-ACTS_WORLD_STYLE",
      "background_asset_key": "asset.world.nt-acts"
    },
    {
      "world_id": "W_NT_PAUL",
      "code": "NT-PAUL",
      "title": {
        "ko": "신약 3. 바울서신",
        "en": "New Testament 3. Pauline Epistles",
        "ja": "新約3. パウロ書簡",
        "ms": "Perjanjian Baru 3. Surat Paulus",
        "th": "พันธสัญญาใหม่ 3. จดหมายของเปาโล",
        "km": "សញ្ញាថ្មី ៣. សំបុត្ររបស់ប៉ូល"
      },
      "subtitle": {
        "ko": "복음, 교회, 믿음의 삶, 목회 권면을 바울서신으로 배웁니다.",
        "en": "Learn the gospel, church life, faithful living, and pastoral counsel through Paul's letters.",
        "ja": "福音、教会生活、信仰の歩み、牧会的勧めをパウロ書簡で学びます。",
        "ms": "Pelajari Injil, hidup jemaat, kehidupan beriman, dan nasihat pastoral melalui surat Paulus.",
        "th": "เรียนรู้พระกิตติคุณ ชีวิตคริสตจักร ชีวิตแห่งความเชื่อ และคำแนะนำอภิบาลผ่านจดหมายเปาโล",
        "km": "រៀនដំណឹងល្អ ជីវិតព្រះវិហារ ជីវិតជំនឿ និងដំបូន្មានគ្រូគង្វាលតាមសំបុត្រប៉ូល។"
      },
      "bible_range": "신약 3. 바울서신",
      "design_theme_key": "NT-PAUL_WORLD_STYLE",
      "background_asset_key": "asset.world.nt-paul"
    },
    {
      "world_id": "W_NT_GEN",
      "code": "NT-GEN",
      "title": {
        "ko": "신약 4. 공동서신",
        "en": "New Testament 4. General Epistles",
        "ja": "新約4. 公同書簡",
        "ms": "Perjanjian Baru 4. Surat Umum",
        "th": "พันธสัญญาใหม่ 4. จดหมายทั่วไป",
        "km": "សញ្ញាថ្មី ៤. សំបុត្រទូទៅ"
      },
      "subtitle": {
        "ko": "히브리서부터 유다서까지 믿음, 행함, 소망, 진리를 확인합니다.",
        "en": "Review faith, works, hope, and truth from Hebrews to Jude.",
        "ja": "ヘブルからユダまで、信仰、行い、希望、真理を確認します。",
        "ms": "Semak iman, perbuatan, harapan, dan kebenaran dari Ibrani hingga Yudas.",
        "th": "ทบทวนความเชื่อ การประพฤติ ความหวัง และความจริงตั้งแต่ฮีบรูถึงยูดา",
        "km": "រំលឹកជំនឿ ការប្រព្រឹត្ត សង្ឃឹម និងសេចក្ដីពិតពីហេព្រើរដល់យូដាស។"
      },
      "bible_range": "신약 4. 공동서신",
      "design_theme_key": "NT-GEN_WORLD_STYLE",
      "background_asset_key": "asset.world.nt-gen"
    },
    {
      "world_id": "W_NT_PROP",
      "code": "NT-PROP",
      "title": {
        "ko": "신약 5. 예언서",
        "en": "New Testament 5. Prophecy",
        "ja": "新約5. 預言書",
        "ms": "Perjanjian Baru 5. Nubuat",
        "th": "พันธสัญญาใหม่ 5. คำพยากรณ์",
        "km": "សញ្ញាថ្មី ៥. ទំនាយ"
      },
      "subtitle": {
        "ko": "요한계시록의 예배, 인내, 새 창조의 소망을 따라갑니다.",
        "en": "Follow worship, endurance, and new-creation hope in Revelation.",
        "ja": "黙示録の礼拝、忍耐、新しい創造の希望をたどります。",
        "ms": "Ikuti penyembahan, ketekunan, dan harapan ciptaan baru dalam Wahyu.",
        "th": "ติดตามการนมัสการ ความอดทน และความหวังการทรงสร้างใหม่ในวิวรณ์",
        "km": "ដើរតាមការថ្វាយបង្គំ ការអត់ធ្មត់ និងសង្ឃឹមនៃការបង្កើតថ្មីក្នុងវិវរណៈ។"
      },
      "bible_range": "신약 5. 예언서",
      "design_theme_key": "NT-PROP_WORLD_STYLE",
      "background_asset_key": "asset.world.nt-prop"
    }
  ],
  "journey_chapters": [
    {
      "chapter_id": "OT-PENT-C01",
      "book_id": "GEN",
      "section_key": "pentateuch",
      "world_id": "W_OT_PENT",
      "order_index": 1,
      "title": {
        "ko": "에덴·아라랏·바벨 → 느보산",
        "en": "Eden·Ararat·Babel → Mount Nebo",
        "ja": "エデン·アララト·バベル → ネボ山",
        "ms": "Eden·Ararat·Babel → Gunung Nebo",
        "th": "เอเดน·อารารัต·บาเบล → ภูเขาเนโบ",
        "km": "អេដែន·អារ៉ារ៉ាត់·បាបិល → ភ្នំណេបូ"
      },
      "summary": {
        "ko": "에덴·아라랏·바벨 / 고센·홍해·시내산 / 시내산 / 가데스·모압 / 느보산 길을 따라 구약 1. 모세오경 본문 사건을 풉니다.",
        "en": "Follow Eden·Ararat·Babel / Goshen·Red Sea·Sinai / Sinai / Kadesh·Moab / Mount Nebo through Old Testament 1. Pentateuch.",
        "ja": "エデン·アララト·バベル / ゴシェン·紅海·シナイ / シナイ / カデシュ·モアブ / ネボ山の道をたどり、旧約1. モーセ五書の本文出来事を解きます。",
        "ms": "Ikuti laluan Eden·Ararat·Babel / Gosyen·Laut Merah·Sinai / Sinai / Kadesh·Moab / Gunung Nebo dan jawab peristiwa teks Perjanjian Lama 1. Taurat.",
        "th": "ติดตามเส้นทาง เอเดน·อารารัต·บาเบล / โกเชน·ทะเลแดง·ซีนาย / ซีนาย / คาเดช·โมอับ / ภูเขาเนโบ และตอบเหตุการณ์ในเนื้อหาพันธสัญญาเดิม 1. โมเสสห้าเล่ม",
        "km": "តាមដានផ្លូវ អេដែន·អារ៉ារ៉ាត់·បាបិល / កូសែន·សមុទ្រក្រហម·ស៊ីណាយ / ស៊ីណាយ / កាដេស·ម៉ូអាប់ / ភ្នំណេបូ ហើយឆ្លើយព្រឹត្តិការណ៍ក្នុងអត្ថបទសញ្ញាចាស់ ១. បញ្ចកណ្ឌ។"
      },
      "stops": [
        {
          "stage_id": "GEN-001",
          "title": {
            "ko": "에덴 · 아라랏산 · 바벨",
            "en": "Eden · Mount Ararat · Babel",
            "ja": "エデン · アララト山 · バベル",
            "ms": "Eden · Gunung Ararat · Babel",
            "th": "เอเดน · ภูเขาอารารัต · บาเบล",
            "km": "អេដែន · ភ្នំអារ៉ារ៉ាត់ · បាបិល"
          },
          "short_title": {
            "ko": "에덴·아라랏·바벨",
            "en": "Eden·Ararat·Babel",
            "ja": "エデン·アララト·バベル",
            "ms": "Eden·Ararat·Babel",
            "th": "เอเดน·อารารัต·บาเบล",
            "km": "អេដែន·អារ៉ារ៉ាត់·បាបិល"
          },
          "book_title": {
            "ko": "창세기",
            "en": "Genesis",
            "ja": "創世記",
            "ms": "Kejadian",
            "th": "ปฐมกาล",
            "km": "លោកុប្បត្តិ"
          },
          "map_query": "Garden of Eden and Ararat biblical route",
          "map_region": "babylon",
          "map_x": 61.7,
          "map_y": 66.5,
          "route_group": "old-testament",
          "place_names": [
            "에덴 · 아라랏산 · 바벨",
            "Eden · Mount Ararat · Babel",
            "에덴·아라랏·바벨",
            "Eden·Ararat·Babel",
            "エデン · アララト山 · バベル",
            "Eden · Gunung Ararat · Babel",
            "เอเดน · ภูเขาอารารัต · บาเบล",
            "អេដែន · ភ្នំអារ៉ារ៉ាត់ · បាបិល"
          ],
          "reference": "창세기 1-50",
          "references": {
            "ko": "창세기 1-50",
            "en": "Genesis 1-50",
            "ja": "創世記 1-50",
            "ms": "Kejadian 1-50",
            "th": "ปฐมกาล 1-50",
            "km": "លោកុប្បត្តិ 1-50"
          },
          "scene": {
            "ko": "에덴·아라랏·바벨 위치에서 창세기 1-50 본문 사건을 확인합니다.",
            "en": "Eden·Ararat·Babel: read and answer from Genesis 1-50.",
            "ja": "エデン·アララト·バベルの地点で、創世記 1-50の本文出来事を確認します。",
            "ms": "Di lokasi Eden·Ararat·Babel, semak peristiwa teks Kejadian 1-50.",
            "th": "ที่ตำแหน่งเอเดน·อารารัต·บาเบล ให้ตรวจสอบเหตุการณ์ในปฐมกาล 1-50",
            "km": "នៅទីតាំងអេដែន·អារ៉ារ៉ាត់·បាបិល សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងលោកុប្បត្តិ 1-50។"
          },
          "mission": {
            "ko": "에덴 · 아라랏산 · 바벨 여정에서 창세기 50장 본문 문제를 풉니다.",
            "en": "Follow Eden · Mount Ararat · Babel and answer Genesis 50 chapters question bank.",
            "ja": "エデン · アララト山 · バベルの旅で、創世記50章の問題バンクに答えます。",
            "ms": "Ikuti Eden · Gunung Ararat · Babel dan jawab bank soalan Kejadian 50 bab.",
            "th": "ติดตามเส้นทางเอเดน · ภูเขาอารารัต · บาเบลและตอบคลังคำถามจากปฐมกาล 50 บท",
            "km": "តាមដានដំណើរអេដែន · ភ្នំអារ៉ារ៉ាត់ · បាបិល ហើយឆ្លើយធនាគារសំណួរពីលោកុប្បត្តិ 50 ជំពូក។"
          }
        },
        {
          "stage_id": "EXO-001",
          "title": {
            "ko": "고센 · 홍해 · 시내산",
            "en": "Goshen · Red Sea · Mount Sinai",
            "ja": "ゴシェン · 紅海 · シナイ山",
            "ms": "Gosyen · Laut Merah · Gunung Sinai",
            "th": "โกเชน · ทะเลแดง · ภูเขาซีนาย",
            "km": "កូសែន · សមុទ្រក្រហម · ភ្នំស៊ីណាយ"
          },
          "short_title": {
            "ko": "고센·홍해·시내산",
            "en": "Goshen·Red Sea·Sinai",
            "ja": "ゴシェン·紅海·シナイ",
            "ms": "Gosyen·Laut Merah·Sinai",
            "th": "โกเชน·ทะเลแดง·ซีนาย",
            "km": "កូសែន·សមុទ្រក្រហម·ស៊ីណាយ"
          },
          "book_title": {
            "ko": "출애굽기",
            "en": "Exodus",
            "ja": "出エジプト記",
            "ms": "Keluaran",
            "th": "อพยพ",
            "km": "និក្ខមនំ"
          },
          "map_query": "Goshen Egypt to Mount Sinai biblical route",
          "map_region": "goshen",
          "map_x": 25.2,
          "map_y": 75.2,
          "route_group": "old-testament",
          "place_names": [
            "고센 · 홍해 · 시내산",
            "Goshen · Red Sea · Mount Sinai",
            "고센·홍해·시내산",
            "Goshen·Red Sea·Sinai",
            "ゴシェン · 紅海 · シナイ山",
            "Gosyen · Laut Merah · Gunung Sinai",
            "โกเชน · ทะเลแดง · ภูเขาซีนาย",
            "កូសែន · សមុទ្រក្រហម · ភ្នំស៊ីណាយ"
          ],
          "reference": "출애굽기 1-40",
          "references": {
            "ko": "출애굽기 1-40",
            "en": "Exodus 1-40",
            "ja": "出エジプト記 1-40",
            "ms": "Keluaran 1-40",
            "th": "อพยพ 1-40",
            "km": "និក្ខមនំ 1-40"
          },
          "scene": {
            "ko": "고센·홍해·시내산 위치에서 출애굽기 1-40 본문 사건을 확인합니다.",
            "en": "Goshen·Red Sea·Sinai: read and answer from Exodus 1-40.",
            "ja": "ゴシェン·紅海·シナイの地点で、出エジプト記 1-40の本文出来事を確認します。",
            "ms": "Di lokasi Gosyen·Laut Merah·Sinai, semak peristiwa teks Keluaran 1-40.",
            "th": "ที่ตำแหน่งโกเชน·ทะเลแดง·ซีนาย ให้ตรวจสอบเหตุการณ์ในอพยพ 1-40",
            "km": "នៅទីតាំងកូសែន·សមុទ្រក្រហម·ស៊ីណាយ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងនិក្ខមនំ 1-40។"
          },
          "mission": {
            "ko": "고센 · 홍해 · 시내산 여정에서 출애굽기 40장 본문 문제를 풉니다.",
            "en": "Follow Goshen · Red Sea · Mount Sinai and answer Exodus 40 chapters question bank.",
            "ja": "ゴシェン · 紅海 · シナイ山の旅で、出エジプト記40章の問題バンクに答えます。",
            "ms": "Ikuti Gosyen · Laut Merah · Gunung Sinai dan jawab bank soalan Keluaran 40 bab.",
            "th": "ติดตามเส้นทางโกเชน · ทะเลแดง · ภูเขาซีนายและตอบคลังคำถามจากอพยพ 40 บท",
            "km": "តាមដានដំណើរកូសែន · សមុទ្រក្រហម · ភ្នំស៊ីណាយ ហើយឆ្លើយធនាគារសំណួរពីនិក្ខមនំ 40 ជំពូក។"
          }
        },
        {
          "stage_id": "LEV-001",
          "title": {
            "ko": "시내산 회막",
            "en": "The Tent of Meeting at Sinai",
            "ja": "シナイの会見の天幕",
            "ms": "Khemah Pertemuan di Sinai",
            "th": "เต็นท์นัดพบที่ซีนาย",
            "km": "ត្រសាលជំនុំនៅស៊ីណាយ"
          },
          "short_title": {
            "ko": "시내산",
            "en": "Sinai",
            "ja": "シナイ",
            "ms": "Sinai",
            "th": "ซีนาย",
            "km": "ស៊ីណាយ"
          },
          "book_title": {
            "ko": "레위기",
            "en": "Leviticus",
            "ja": "レビ記",
            "ms": "Imamat",
            "th": "เลวีนิติ",
            "km": "លេវីវិន័យ"
          },
          "map_query": "Mount Sinai biblical location",
          "map_region": "sinai",
          "map_x": 31.2,
          "map_y": 86.5,
          "route_group": "old-testament",
          "place_names": [
            "시내산 회막",
            "The Tent of Meeting at Sinai",
            "시내산",
            "Sinai",
            "シナイの会見の天幕",
            "Khemah Pertemuan di Sinai",
            "เต็นท์นัดพบที่ซีนาย",
            "ត្រសាលជំនុំនៅស៊ីណាយ"
          ],
          "reference": "레위기 1-27",
          "references": {
            "ko": "레위기 1-27",
            "en": "Leviticus 1-27",
            "ja": "レビ記 1-27",
            "ms": "Imamat 1-27",
            "th": "เลวีนิติ 1-27",
            "km": "លេវីវិន័យ 1-27"
          },
          "scene": {
            "ko": "시내산 위치에서 레위기 1-27 본문 사건을 확인합니다.",
            "en": "Sinai: read and answer from Leviticus 1-27.",
            "ja": "シナイの地点で、レビ記 1-27の本文出来事を確認します。",
            "ms": "Di lokasi Sinai, semak peristiwa teks Imamat 1-27.",
            "th": "ที่ตำแหน่งซีนาย ให้ตรวจสอบเหตุการณ์ในเลวีนิติ 1-27",
            "km": "នៅទីតាំងស៊ីណាយ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងលេវីវិន័យ 1-27។"
          },
          "mission": {
            "ko": "시내산 회막 여정에서 레위기 27장 본문 문제를 풉니다.",
            "en": "Follow The Tent of Meeting at Sinai and answer Leviticus 27 chapters question bank.",
            "ja": "シナイの会見の天幕の旅で、レビ記27章の問題バンクに答えます。",
            "ms": "Ikuti Khemah Pertemuan di Sinai dan jawab bank soalan Imamat 27 bab.",
            "th": "ติดตามเส้นทางเต็นท์นัดพบที่ซีนายและตอบคลังคำถามจากเลวีนิติ 27 บท",
            "km": "តាមដានដំណើរត្រសាលជំនុំនៅស៊ីណាយ ហើយឆ្លើយធនាគារសំណួរពីលេវីវិន័យ 27 ជំពូក។"
          }
        },
        {
          "stage_id": "NUM-001",
          "title": {
            "ko": "가데스 바네아 · 모압 평지",
            "en": "Kadesh-barnea · Plains of Moab",
            "ja": "カデシュ・バルネア · モアブの平野",
            "ms": "Kadesh-barnea · Dataran Moab",
            "th": "คาเดชบารเนีย · ที่ราบโมอับ",
            "km": "កាដេសបារនេា · វាលទំនាបម៉ូអាប់"
          },
          "short_title": {
            "ko": "가데스·모압",
            "en": "Kadesh·Moab",
            "ja": "カデシュ·モアブ",
            "ms": "Kadesh·Moab",
            "th": "คาเดช·โมอับ",
            "km": "កាដេស·ម៉ូអាប់"
          },
          "book_title": {
            "ko": "민수기",
            "en": "Numbers",
            "ja": "民数記",
            "ms": "Bilangan",
            "th": "กันดารวิถี",
            "km": "ជនគណនា"
          },
          "map_query": "Kadesh Barnea wilderness biblical location",
          "map_region": "kadesh",
          "map_x": 34.5,
          "map_y": 76.5,
          "route_group": "old-testament",
          "place_names": [
            "가데스 바네아 · 모압 평지",
            "Kadesh-barnea · Plains of Moab",
            "가데스·모압",
            "Kadesh·Moab",
            "カデシュ・バルネア · モアブの平野",
            "Kadesh-barnea · Dataran Moab",
            "คาเดชบารเนีย · ที่ราบโมอับ",
            "កាដេសបារនេា · វាលទំនាបម៉ូអាប់"
          ],
          "reference": "민수기 1-36",
          "references": {
            "ko": "민수기 1-36",
            "en": "Numbers 1-36",
            "ja": "民数記 1-36",
            "ms": "Bilangan 1-36",
            "th": "กันดารวิถี 1-36",
            "km": "ជនគណនា 1-36"
          },
          "scene": {
            "ko": "가데스·모압 위치에서 민수기 1-36 본문 사건을 확인합니다.",
            "en": "Kadesh·Moab: read and answer from Numbers 1-36.",
            "ja": "カデシュ·モアブの地点で、民数記 1-36の本文出来事を確認します。",
            "ms": "Di lokasi Kadesh·Moab, semak peristiwa teks Bilangan 1-36.",
            "th": "ที่ตำแหน่งคาเดช·โมอับ ให้ตรวจสอบเหตุการณ์ในกันดารวิถี 1-36",
            "km": "នៅទីតាំងកាដេស·ម៉ូអាប់ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងជនគណនា 1-36។"
          },
          "mission": {
            "ko": "가데스 바네아 · 모압 평지 여정에서 민수기 36장 본문 문제를 풉니다.",
            "en": "Follow Kadesh-barnea · Plains of Moab and answer Numbers 36 chapters question bank.",
            "ja": "カデシュ・バルネア · モアブの平野の旅で、民数記36章の問題バンクに答えます。",
            "ms": "Ikuti Kadesh-barnea · Dataran Moab dan jawab bank soalan Bilangan 36 bab.",
            "th": "ติดตามเส้นทางคาเดชบารเนีย · ที่ราบโมอับและตอบคลังคำถามจากกันดารวิถี 36 บท",
            "km": "តាមដានដំណើរកាដេសបារនេា · វាលទំនាបម៉ូអាប់ ហើយឆ្លើយធនាគារសំណួរពីជនគណនា 36 ជំពូក។"
          }
        },
        {
          "stage_id": "DEU-001",
          "title": {
            "ko": "느보산 · 모압 평지",
            "en": "Mount Nebo · Plains of Moab",
            "ja": "ネボ山 · モアブの平野",
            "ms": "Gunung Nebo · Dataran Moab",
            "th": "ภูเขาเนโบ · ที่ราบโมอับ",
            "km": "ភ្នំណេបូ · វាលទំនាបម៉ូអាប់"
          },
          "short_title": {
            "ko": "느보산",
            "en": "Mount Nebo",
            "ja": "ネボ山",
            "ms": "Gunung Nebo",
            "th": "ภูเขาเนโบ",
            "km": "ភ្នំណេបូ"
          },
          "book_title": {
            "ko": "신명기",
            "en": "Deuteronomy",
            "ja": "申命記",
            "ms": "Ulangan",
            "th": "เฉลยธรรมบัญญัติ",
            "km": "ចោទិយកថា"
          },
          "map_query": "Mount Nebo Jordan biblical location",
          "map_region": "nebo",
          "map_x": 37.6,
          "map_y": 72.4,
          "route_group": "old-testament",
          "place_names": [
            "느보산 · 모압 평지",
            "Mount Nebo · Plains of Moab",
            "느보산",
            "Mount Nebo",
            "ネボ山 · モアブの平野",
            "Gunung Nebo · Dataran Moab",
            "ภูเขาเนโบ · ที่ราบโมอับ",
            "ភ្នំណេបូ · វាលទំនាបម៉ូអាប់"
          ],
          "reference": "신명기 1-34",
          "references": {
            "ko": "신명기 1-34",
            "en": "Deuteronomy 1-34",
            "ja": "申命記 1-34",
            "ms": "Ulangan 1-34",
            "th": "เฉลยธรรมบัญญัติ 1-34",
            "km": "ចោទិយកថា 1-34"
          },
          "scene": {
            "ko": "느보산 위치에서 신명기 1-34 본문 사건을 확인합니다.",
            "en": "Mount Nebo: read and answer from Deuteronomy 1-34.",
            "ja": "ネボ山の地点で、申命記 1-34の本文出来事を確認します。",
            "ms": "Di lokasi Gunung Nebo, semak peristiwa teks Ulangan 1-34.",
            "th": "ที่ตำแหน่งภูเขาเนโบ ให้ตรวจสอบเหตุการณ์ในเฉลยธรรมบัญญัติ 1-34",
            "km": "នៅទីតាំងភ្នំណេបូ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងចោទិយកថា 1-34។"
          },
          "mission": {
            "ko": "느보산 · 모압 평지 여정에서 신명기 34장 본문 문제를 풉니다.",
            "en": "Follow Mount Nebo · Plains of Moab and answer Deuteronomy 34 chapters question bank.",
            "ja": "ネボ山 · モアブの平野の旅で、申命記34章の問題バンクに答えます。",
            "ms": "Ikuti Gunung Nebo · Dataran Moab dan jawab bank soalan Ulangan 34 bab.",
            "th": "ติดตามเส้นทางภูเขาเนโบ · ที่ราบโมอับและตอบคลังคำถามจากเฉลยธรรมบัญญัติ 34 บท",
            "km": "តាមដានដំណើរភ្នំណេបូ · វាលទំនាបម៉ូអាប់ ហើយឆ្លើយធនាគារសំណួរពីចោទិយកថា 34 ជំពូក។"
          }
        }
      ]
    },
    {
      "chapter_id": "OT-HIST-C01",
      "book_id": "JOS",
      "section_key": "history",
      "world_id": "W_OT_HIST",
      "order_index": 11,
      "title": {
        "ko": "요단·여리고 → 헤브론·예루살렘",
        "en": "Jordan·Jericho → Hebron·Jerusalem",
        "ja": "ヨルダン·エリコ → ヘブロン·エルサレム",
        "ms": "Yordan·Yerikho → Hebron·Yerusalem",
        "th": "จอร์แดน·เยรีโค → เฮប្រូន·เยรูซาเล็ม",
        "km": "យ័រដាន់·យេរីខូ → ហេប្រូន·យេរូសាឡឹម"
      },
      "summary": {
        "ko": "요단·여리고 / 이스르엘 / 모압·베들레헴 / 실로·엘라 / 헤브론·예루살렘 길을 따라 구약 2. 역사서 본문 사건을 풉니다.",
        "en": "Follow Jordan·Jericho / Jezreel / Moab·Bethlehem / Shiloh·Elah / Hebron·Jerusalem through Old Testament 2. Historical Books.",
        "ja": "ヨルダン·エリコ / イズレエル / モアブ·ベツレヘム / シロ·エラ / ヘブロン·エルサレムの道をたどり、旧約2. 歴史書の本文出来事を解きます。",
        "ms": "Ikuti laluan Yordan·Yerikho / Yizreel / Moab·Betlehem / Silo·Ela / Hebron·Yerusalem dan jawab peristiwa teks Perjanjian Lama 2. Kitab Sejarah.",
        "th": "ติดตามเส้นทาง จอร์แดน·เยรีโค / ยิสเรเอล / โมอับ·เบธเลเฮม / ชิโลห์·เอลาห์ / เฮប្រូន·เยรูซาเล็ม และตอบเหตุการณ์ในเนื้อหาพันธสัญญาเดิม 2. หนังสือประวัติศาสตร์",
        "km": "តាមដានផ្លូវ យ័រដាន់·យេរីខូ / យីសរេអែល / ម៉ូអាប់·បេថ្លេហិម / ស៊ីឡូ·អេឡា / ហេប្រូន·យេរូសាឡឹម ហើយឆ្លើយព្រឹត្តិការណ៍ក្នុងអត្ថបទសញ្ញាចាស់ ២. សៀវភៅប្រវត្តិសាស្ត្រ។"
      },
      "stops": [
        {
          "stage_id": "JOS-001",
          "title": {
            "ko": "요단강 · 여리고",
            "en": "Jordan River · Jericho",
            "ja": "ヨルダン川 · エリコ",
            "ms": "Sungai Yordan · Yerikho",
            "th": "แม่น้ำจอร์แดน · เยรีโค",
            "km": "ទន្លេយ័រដាន់ · យេរីខូ"
          },
          "short_title": {
            "ko": "요단·여리고",
            "en": "Jordan·Jericho",
            "ja": "ヨルダン·エリコ",
            "ms": "Yordan·Yerikho",
            "th": "จอร์แดน·เยรีโค",
            "km": "យ័រដាន់·យេរីខូ"
          },
          "book_title": {
            "ko": "여호수아",
            "en": "Joshua",
            "ja": "ヨシュア記",
            "ms": "Yosua",
            "th": "โยชูวา",
            "km": "យ៉ូស្វេ"
          },
          "map_query": "Jericho archaeological site biblical Joshua",
          "map_region": "canaan",
          "map_x": 37.2,
          "map_y": 69.2,
          "route_group": "old-testament",
          "place_names": [
            "요단강 · 여리고",
            "Jordan River · Jericho",
            "요단·여리고",
            "Jordan·Jericho",
            "ヨルダン川 · エリコ",
            "Sungai Yordan · Yerikho",
            "แม่น้ำจอร์แดน · เยรีโค",
            "ទន្លេយ័រដាន់ · យេរីខូ"
          ],
          "reference": "여호수아 1-24",
          "references": {
            "ko": "여호수아 1-24",
            "en": "Joshua 1-24",
            "ja": "ヨシュア記 1-24",
            "ms": "Yosua 1-24",
            "th": "โยชูวา 1-24",
            "km": "យ៉ូស្វេ 1-24"
          },
          "scene": {
            "ko": "요단·여리고 위치에서 여호수아 1-24 본문 사건을 확인합니다.",
            "en": "Jordan·Jericho: read and answer from Joshua 1-24.",
            "ja": "ヨルダン·エリコの地点で、ヨシュア記 1-24の本文出来事を確認します。",
            "ms": "Di lokasi Yordan·Yerikho, semak peristiwa teks Yosua 1-24.",
            "th": "ที่ตำแหน่งจอร์แดน·เยรีโค ให้ตรวจสอบเหตุการณ์ในโยชูวา 1-24",
            "km": "នៅទីតាំងយ័រដាន់·យេរីខូ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងយ៉ូស្វេ 1-24។"
          },
          "mission": {
            "ko": "요단강 · 여리고 여정에서 여호수아 24장 본문 문제를 풉니다.",
            "en": "Follow Jordan River · Jericho and answer Joshua 24 chapters question bank.",
            "ja": "ヨルダン川 · エリコの旅で、ヨシュア記24章の問題バンクに答えます。",
            "ms": "Ikuti Sungai Yordan · Yerikho dan jawab bank soalan Yosua 24 bab.",
            "th": "ติดตามเส้นทางแม่น้ำจอร์แดน · เยรีโคและตอบคลังคำถามจากโยชูวา 24 บท",
            "km": "តាមដានដំណើរទន្លេយ័រដាន់ · យេរីខូ ហើយឆ្លើយធនាគារសំណួរពីយ៉ូស្វេ 24 ជំពូក។"
          }
        },
        {
          "stage_id": "JDG-001",
          "title": {
            "ko": "이스르엘 골짜기 · 가나안 산지",
            "en": "Jezreel Valley · Canaan Highlands",
            "ja": "イズレエルの谷 · カナン山地",
            "ms": "Lembah Yizreel · Tanah tinggi Kanaan",
            "th": "หุบเขายิสเรเอล · ที่ราบสูงคานาอัน",
            "km": "ជ្រលងយីសរេអែល · តំបន់ភ្នំកាណាន"
          },
          "short_title": {
            "ko": "이스르엘",
            "en": "Jezreel",
            "ja": "イズレエル",
            "ms": "Yizreel",
            "th": "ยิสเรเอล",
            "km": "យីសរេអែល"
          },
          "book_title": {
            "ko": "사사기",
            "en": "Judges",
            "ja": "士師記",
            "ms": "Hakim-hakim",
            "th": "ผู้วินิจฉัย",
            "km": "ពួកចៅហ្វាយ"
          },
          "map_query": "Valley of Jezreel Israel biblical Judges",
          "map_region": "canaan",
          "map_x": 36.8,
          "map_y": 67.5,
          "route_group": "old-testament",
          "place_names": [
            "이스르엘 골짜기 · 가나안 산지",
            "Jezreel Valley · Canaan Highlands",
            "이스르엘",
            "Jezreel",
            "イズレエルの谷 · カナン山地",
            "Lembah Yizreel · Tanah tinggi Kanaan",
            "หุบเขายิสเรเอล · ที่ราบสูงคานาอัน",
            "ជ្រលងយីសរេអែល · តំបន់ភ្នំកាណាន"
          ],
          "reference": "사사기 1-21",
          "references": {
            "ko": "사사기 1-21",
            "en": "Judges 1-21",
            "ja": "士師記 1-21",
            "ms": "Hakim-hakim 1-21",
            "th": "ผู้วินิจฉัย 1-21",
            "km": "ពួកចៅហ្វាយ 1-21"
          },
          "scene": {
            "ko": "이스르엘 위치에서 사사기 1-21 본문 사건을 확인합니다.",
            "en": "Jezreel: read and answer from Judges 1-21.",
            "ja": "イズレエルの地点で、士師記 1-21の本文出来事を確認します。",
            "ms": "Di lokasi Yizreel, semak peristiwa teks Hakim-hakim 1-21.",
            "th": "ที่ตำแหน่งยิสเรเอล ให้ตรวจสอบเหตุการณ์ในผู้วินิจฉัย 1-21",
            "km": "នៅទីតាំងយីសរេអែល សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងពួកចៅហ្វាយ 1-21។"
          },
          "mission": {
            "ko": "이스르엘 골짜기 · 가나안 산지 여정에서 사사기 21장 본문 문제를 풉니다.",
            "en": "Follow Jezreel Valley · Canaan Highlands and answer Judges 21 chapters question bank.",
            "ja": "イズレエルの谷 · カナン山地の旅で、士師記21章の問題バンクに答えます。",
            "ms": "Ikuti Lembah Yizreel · Tanah tinggi Kanaan dan jawab bank soalan Hakim-hakim 21 bab.",
            "th": "ติดตามเส้นทางหุบเขายิสเรเอล · ที่ราบสูงคานาอันและตอบคลังคำถามจากผู้วินิจฉัย 21 บท",
            "km": "តាមដានដំណើរជ្រលងយីសរេអែល · តំបន់ភ្នំកាណាន ហើយឆ្លើយធនាគារសំណួរពីពួកចៅហ្វាយ 21 ជំពូក។"
          }
        },
        {
          "stage_id": "RUT-001",
          "title": {
            "ko": "모압 · 베들레헴",
            "en": "Moab · Bethlehem",
            "ja": "モアブ · ベツレヘム",
            "ms": "Moab · Betlehem",
            "th": "โมอับ · เบธเลเฮม",
            "km": "ម៉ូអាប់ · បេថ្លេហិម"
          },
          "short_title": {
            "ko": "모압·베들레헴",
            "en": "Moab·Bethlehem",
            "ja": "モアブ·ベツレヘム",
            "ms": "Moab·Betlehem",
            "th": "โมอับ·เบธเลเฮม",
            "km": "ម៉ូអាប់·បេថ្លេហិម"
          },
          "book_title": {
            "ko": "룻기",
            "en": "Ruth",
            "ja": "ルツ記",
            "ms": "Rut",
            "th": "รูธ",
            "km": "នាងរស់"
          },
          "map_query": "Bethlehem Israel Ruth biblical location",
          "map_region": "bethlehem",
          "map_x": 37.1,
          "map_y": 72.2,
          "route_group": "old-testament",
          "place_names": [
            "모압 · 베들레헴",
            "Moab · Bethlehem",
            "모압·베들레헴",
            "Moab·Bethlehem",
            "モアブ · ベツレヘム",
            "Moab · Betlehem",
            "โมอับ · เบธเลเฮม",
            "ម៉ូអាប់ · បេថ្លេហិម"
          ],
          "reference": "룻기 1-4",
          "references": {
            "ko": "룻기 1-4",
            "en": "Ruth 1-4",
            "ja": "ルツ記 1-4",
            "ms": "Rut 1-4",
            "th": "รูธ 1-4",
            "km": "នាងរស់ 1-4"
          },
          "scene": {
            "ko": "모압·베들레헴 위치에서 룻기 1-4 본문 사건을 확인합니다.",
            "en": "Moab·Bethlehem: read and answer from Ruth 1-4.",
            "ja": "モアブ·ベツレヘムの地点で、ルツ記 1-4の本文出来事を確認します。",
            "ms": "Di lokasi Moab·Betlehem, semak peristiwa teks Rut 1-4.",
            "th": "ที่ตำแหน่งโมอับ·เบธเลเฮม ให้ตรวจสอบเหตุการณ์ในรูธ 1-4",
            "km": "នៅទីតាំងម៉ូអាប់·បេថ្លេហិម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងនាងរស់ 1-4។"
          },
          "mission": {
            "ko": "모압 · 베들레헴 여정에서 룻기 4장 본문 문제를 풉니다.",
            "en": "Follow Moab · Bethlehem and answer Ruth 4 chapters question bank.",
            "ja": "モアブ · ベツレヘムの旅で、ルツ記4章の問題バンクに答えます。",
            "ms": "Ikuti Moab · Betlehem dan jawab bank soalan Rut 4 bab.",
            "th": "ติดตามเส้นทางโมอับ · เบธเลเฮมและตอบคลังคำถามจากรูธ 4 บท",
            "km": "តាមដានដំណើរម៉ូអាប់ · បេថ្លេហិម ហើយឆ្លើយធនាគារសំណួរពីនាងរស់ 4 ជំពូក។"
          }
        },
        {
          "stage_id": "1SA-001",
          "title": {
            "ko": "실로 · 엘라 골짜기",
            "en": "Shiloh · Valley of Elah",
            "ja": "シロ · エラの谷",
            "ms": "Silo · Lembah Ela",
            "th": "ชิโลห์ · หุบเขาเอลาห์",
            "km": "ស៊ីឡូ · ជ្រលងអេឡា"
          },
          "short_title": {
            "ko": "실로·엘라",
            "en": "Shiloh·Elah",
            "ja": "シロ·エラ",
            "ms": "Silo·Ela",
            "th": "ชิโลห์·เอลาห์",
            "km": "ស៊ីឡូ·អេឡា"
          },
          "book_title": {
            "ko": "사무엘상",
            "en": "1 Samuel",
            "ja": "サムエル記上",
            "ms": "1 Samuel",
            "th": "1 ซามูเอล",
            "km": "១ សាំយូអែល"
          },
          "map_query": "Valley of Elah Israel David Goliath",
          "map_region": "canaan",
          "map_x": 36.9,
          "map_y": 72,
          "route_group": "old-testament",
          "place_names": [
            "실로 · 엘라 골짜기",
            "Shiloh · Valley of Elah",
            "실로·엘라",
            "Shiloh·Elah",
            "シロ · エラの谷",
            "Silo · Lembah Ela",
            "ชิโลห์ · หุบเขาเอลาห์",
            "ស៊ីឡូ · ជ្រលងអេឡា"
          ],
          "reference": "사무엘상 1-31",
          "references": {
            "ko": "사무엘상 1-31",
            "en": "1 Samuel 1-31",
            "ja": "サムエル記上 1-31",
            "ms": "1 Samuel 1-31",
            "th": "1 ซามูเอล 1-31",
            "km": "១ សាំយូអែល 1-31"
          },
          "scene": {
            "ko": "실로·엘라 위치에서 사무엘상 1-31 본문 사건을 확인합니다.",
            "en": "Shiloh·Elah: read and answer from 1 Samuel 1-31.",
            "ja": "シロ·エラの地点で、サムエル記上 1-31の本文出来事を確認します。",
            "ms": "Di lokasi Silo·Ela, semak peristiwa teks 1 Samuel 1-31.",
            "th": "ที่ตำแหน่งชิโลห์·เอลาห์ ให้ตรวจสอบเหตุการณ์ใน1 ซามูเอล 1-31",
            "km": "នៅទីតាំងស៊ីឡូ·អេឡា សូមពិនិត្យព្រឹត្តិការណ៍ក្នុង១ សាំយូអែល 1-31។"
          },
          "mission": {
            "ko": "실로 · 엘라 골짜기 여정에서 사무엘상 31장 본문 문제를 풉니다.",
            "en": "Follow Shiloh · Valley of Elah and answer 1 Samuel 31 chapters question bank.",
            "ja": "シロ · エラの谷の旅で、サムエル記上31章の問題バンクに答えます。",
            "ms": "Ikuti Silo · Lembah Ela dan jawab bank soalan 1 Samuel 31 bab.",
            "th": "ติดตามเส้นทางชิโลห์ · หุบเขาเอลาห์และตอบคลังคำถามจาก1 ซามูเอล 31 บท",
            "km": "តាមដានដំណើរស៊ីឡូ · ជ្រលងអេឡា ហើយឆ្លើយធនាគារសំណួរពី១ សាំយូអែល 31 ជំពូក។"
          }
        },
        {
          "stage_id": "2SA-001",
          "title": {
            "ko": "헤브론 · 예루살렘",
            "en": "Hebron · Jerusalem",
            "ja": "ヘブロン · エルサレム",
            "ms": "Hebron · Yerusalem",
            "th": "เฮប្រូន · เยรูซาเล็ม",
            "km": "ហេប្រូន · យេរូសាឡឹម"
          },
          "short_title": {
            "ko": "헤브론·예루살렘",
            "en": "Hebron·Jerusalem",
            "ja": "ヘブロン·エルサレム",
            "ms": "Hebron·Yerusalem",
            "th": "เฮប្រូន·เยรูซาเล็ม",
            "km": "ហេប្រូន·យេរូសាឡឹម"
          },
          "book_title": {
            "ko": "사무엘하",
            "en": "2 Samuel",
            "ja": "サムエル記下",
            "ms": "2 Samuel",
            "th": "2 ซามูเอล",
            "km": "២ សាំយូអែល"
          },
          "map_query": "City of David Jerusalem biblical location",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "old-testament",
          "place_names": [
            "헤브론 · 예루살렘",
            "Hebron · Jerusalem",
            "헤브론·예루살렘",
            "Hebron·Jerusalem",
            "ヘブロン · エルサレム",
            "Hebron · Yerusalem",
            "เฮប្រូន · เยรูซาเล็ม",
            "ហេប្រូន · យេរូសាឡឹម"
          ],
          "reference": "사무엘하 1-24",
          "references": {
            "ko": "사무엘하 1-24",
            "en": "2 Samuel 1-24",
            "ja": "サムエル記下 1-24",
            "ms": "2 Samuel 1-24",
            "th": "2 ซามูเอล 1-24",
            "km": "២ សាំយូអែល 1-24"
          },
          "scene": {
            "ko": "헤브론·예루살렘 위치에서 사무엘하 1-24 본문 사건을 확인합니다.",
            "en": "Hebron·Jerusalem: read and answer from 2 Samuel 1-24.",
            "ja": "ヘブロン·エルサレムの地点で、サムエル記下 1-24の本文出来事を確認します。",
            "ms": "Di lokasi Hebron·Yerusalem, semak peristiwa teks 2 Samuel 1-24.",
            "th": "ที่ตำแหน่งเฮប្រូន·เยรูซาเล็ม ให้ตรวจสอบเหตุการณ์ใน2 ซามูเอล 1-24",
            "km": "នៅទីតាំងហេប្រូន·យេរូសាឡឹម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុង២ សាំយូអែល 1-24។"
          },
          "mission": {
            "ko": "헤브론 · 예루살렘 여정에서 사무엘하 24장 본문 문제를 풉니다.",
            "en": "Follow Hebron · Jerusalem and answer 2 Samuel 24 chapters question bank.",
            "ja": "ヘブロン · エルサレムの旅で、サムエル記下24章の問題バンクに答えます。",
            "ms": "Ikuti Hebron · Yerusalem dan jawab bank soalan 2 Samuel 24 bab.",
            "th": "ติดตามเส้นทางเฮប្រូន · เยรูซาเล็มและตอบคลังคำถามจาก2 ซามูเอล 24 บท",
            "km": "តាមដានដំណើរហេប្រូន · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពី២ សាំយូអែល 24 ជំពូក។"
          }
        }
      ]
    },
    {
      "chapter_id": "OT-HIST-C02",
      "book_id": "1KI",
      "section_key": "history",
      "world_id": "W_OT_HIST",
      "order_index": 12,
      "title": {
        "ko": "성전·갈멜산 → 바벨론·예루살렘",
        "en": "Temple·Carmel → Babylon·Jerusalem",
        "ja": "神殿·カルメル → バビロン·エルサレム",
        "ms": "Bait Suci·Karmel → Babilon·Yerusalem",
        "th": "พระวิหาร·คาร์เมล → บาบิโลน·เยรูซาเล็ม",
        "km": "ព្រះវិហារ·កាមែល → បាប៊ីឡូន·យេរូសាឡឹម"
      },
      "summary": {
        "ko": "성전·갈멜산 / 사마리아·예루살렘 / 다윗 성 / 예루살렘 성전 / 바벨론·예루살렘 길을 따라 구약 2. 역사서 본문 사건을 풉니다.",
        "en": "Follow Temple·Carmel / Samaria·Jerusalem / City of David / Jerusalem Temple / Babylon·Jerusalem through Old Testament 2. Historical Books.",
        "ja": "神殿·カルメル / サマリア·エルサレム / ダビデの町 / エルサレム神殿 / バビロン·エルサレムの道をたどり、旧約2. 歴史書の本文出来事を解きます。",
        "ms": "Ikuti laluan Bait Suci·Karmel / Samaria·Yerusalem / Kota Daud / Bait Suci Yerusalem / Babilon·Yerusalem dan jawab peristiwa teks Perjanjian Lama 2. Kitab Sejarah.",
        "th": "ติดตามเส้นทาง พระวิหาร·คาร์เมล / สะมาเรีย·เยรูซาเล็ม / นครดาวิด / พระวิหารเยรูซาเล็ม / บาบิโลน·เยรูซาเล็ม และตอบเหตุการณ์ในเนื้อหาพันธสัญญาเดิม 2. หนังสือประวัติศาสตร์",
        "km": "តាមដានផ្លូវ ព្រះវិហារ·កាមែល / សាម៉ារី·យេរូសាឡឹម / ទីក្រុងដាវីឌ / ព្រះវិហារយេរូសាឡឹម / បាប៊ីឡូន·យេរូសាឡឹម ហើយឆ្លើយព្រឹត្តិការណ៍ក្នុងអត្ថបទសញ្ញាចាស់ ២. សៀវភៅប្រវត្តិសាស្ត្រ។"
      },
      "stops": [
        {
          "stage_id": "1KI-001",
          "title": {
            "ko": "예루살렘 성전 · 갈멜산",
            "en": "Jerusalem Temple · Mount Carmel",
            "ja": "エルサレム神殿 · カルメル山",
            "ms": "Bait Suci Yerusalem · Gunung Karmel",
            "th": "พระวิหารเยรูซาเล็ม · ภูเขาคารเมล",
            "km": "ព្រះវិហារយេរូសាឡឹម · ភ្នំកាមែល"
          },
          "short_title": {
            "ko": "성전·갈멜산",
            "en": "Temple·Carmel",
            "ja": "神殿·カルメル",
            "ms": "Bait Suci·Karmel",
            "th": "พระวิหาร·คาร์เมล",
            "km": "ព្រះវិហារ·កាមែល"
          },
          "book_title": {
            "ko": "열왕기상",
            "en": "1 Kings",
            "ja": "列王記上",
            "ms": "1 Raja-raja",
            "th": "1 พงศ์กษัตริย์",
            "km": "១ ពង្សាវតារក្សត្រ"
          },
          "map_query": "Jerusalem Temple Mount Solomon biblical location",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "old-testament",
          "place_names": [
            "예루살렘 성전 · 갈멜산",
            "Jerusalem Temple · Mount Carmel",
            "성전·갈멜산",
            "Temple·Carmel",
            "エルサレム神殿 · カルメル山",
            "Bait Suci Yerusalem · Gunung Karmel",
            "พระวิหารเยรูซาเล็ม · ภูเขาคารเมล",
            "ព្រះវិហារយេរូសាឡឹម · ភ្នំកាមែល"
          ],
          "reference": "열왕기상 1-22",
          "references": {
            "ko": "열왕기상 1-22",
            "en": "1 Kings 1-22",
            "ja": "列王記上 1-22",
            "ms": "1 Raja-raja 1-22",
            "th": "1 พงศ์กษัตริย์ 1-22",
            "km": "១ ពង្សាវតារក្សត្រ 1-22"
          },
          "scene": {
            "ko": "성전·갈멜산 위치에서 열왕기상 1-22 본문 사건을 확인합니다.",
            "en": "Temple·Carmel: read and answer from 1 Kings 1-22.",
            "ja": "神殿·カルメルの地点で、列王記上 1-22の本文出来事を確認します。",
            "ms": "Di lokasi Bait Suci·Karmel, semak peristiwa teks 1 Raja-raja 1-22.",
            "th": "ที่ตำแหน่งพระวิหาร·คาร์เมล ให้ตรวจสอบเหตุการณ์ใน1 พงศ์กษัตริย์ 1-22",
            "km": "នៅទីតាំងព្រះវិហារ·កាមែល សូមពិនិត្យព្រឹត្តិការណ៍ក្នុង១ ពង្សាវតារក្សត្រ 1-22។"
          },
          "mission": {
            "ko": "예루살렘 성전 · 갈멜산 여정에서 열왕기상 22장 본문 문제를 풉니다.",
            "en": "Follow Jerusalem Temple · Mount Carmel and answer 1 Kings 22 chapters question bank.",
            "ja": "エルサレム神殿 · カルメル山の旅で、列王記上22章の問題バンクに答えます。",
            "ms": "Ikuti Bait Suci Yerusalem · Gunung Karmel dan jawab bank soalan 1 Raja-raja 22 bab.",
            "th": "ติดตามเส้นทางพระวิหารเยรูซาเล็ม · ภูเขาคารเมลและตอบคลังคำถามจาก1 พงศ์กษัตริย์ 22 บท",
            "km": "តាមដានដំណើរព្រះវិហារយេរូសាឡឹម · ភ្នំកាមែល ហើយឆ្លើយធនាគារសំណួរពី១ ពង្សាវតារក្សត្រ 22 ជំពូក។"
          }
        },
        {
          "stage_id": "2KI-001",
          "title": {
            "ko": "사마리아 · 예루살렘",
            "en": "Samaria · Jerusalem",
            "ja": "サマリア · エルサレム",
            "ms": "Samaria · Yerusalem",
            "th": "สะมาเรีย · เยรูซาเล็ม",
            "km": "សាម៉ារី · យេរូសាឡឹម"
          },
          "short_title": {
            "ko": "사마리아·예루살렘",
            "en": "Samaria·Jerusalem",
            "ja": "サマリア·エルサレム",
            "ms": "Samaria·Yerusalem",
            "th": "สะมาเรีย·เยรูซาเล็ม",
            "km": "សាម៉ារី·យេរូសាឡឹម"
          },
          "book_title": {
            "ko": "열왕기하",
            "en": "2 Kings",
            "ja": "列王記下",
            "ms": "2 Raja-raja",
            "th": "2 พงศ์กษัตริย์",
            "km": "២ ពង្សាវតារក្សត្រ"
          },
          "map_query": "Samaria and Jerusalem biblical kings",
          "map_region": "samaria",
          "map_x": 36.5,
          "map_y": 67.3,
          "route_group": "old-testament",
          "place_names": [
            "사마리아 · 예루살렘",
            "Samaria · Jerusalem",
            "사마리아·예루살렘",
            "Samaria·Jerusalem",
            "サマリア · エルサレム",
            "Samaria · Yerusalem",
            "สะมาเรีย · เยรูซาเล็ม",
            "សាម៉ារី · យេរូសាឡឹម"
          ],
          "reference": "열왕기하 1-25",
          "references": {
            "ko": "열왕기하 1-25",
            "en": "2 Kings 1-25",
            "ja": "列王記下 1-25",
            "ms": "2 Raja-raja 1-25",
            "th": "2 พงศ์กษัตริย์ 1-25",
            "km": "២ ពង្សាវតារក្សត្រ 1-25"
          },
          "scene": {
            "ko": "사마리아·예루살렘 위치에서 열왕기하 1-25 본문 사건을 확인합니다.",
            "en": "Samaria·Jerusalem: read and answer from 2 Kings 1-25.",
            "ja": "サマリア·エルサレムの地点で、列王記下 1-25の本文出来事を確認します。",
            "ms": "Di lokasi Samaria·Yerusalem, semak peristiwa teks 2 Raja-raja 1-25.",
            "th": "ที่ตำแหน่งสะมาเรีย·เยรูซาเล็ม ให้ตรวจสอบเหตุการณ์ใน2 พงศ์กษัตริย์ 1-25",
            "km": "នៅទីតាំងសាម៉ារី·យេរូសាឡឹម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុង២ ពង្សាវតារក្សត្រ 1-25។"
          },
          "mission": {
            "ko": "사마리아 · 예루살렘 여정에서 열왕기하 25장 본문 문제를 풉니다.",
            "en": "Follow Samaria · Jerusalem and answer 2 Kings 25 chapters question bank.",
            "ja": "サマリア · エルサレムの旅で、列王記下25章の問題バンクに答えます。",
            "ms": "Ikuti Samaria · Yerusalem dan jawab bank soalan 2 Raja-raja 25 bab.",
            "th": "ติดตามเส้นทางสะมาเรีย · เยรูซาเล็มและตอบคลังคำถามจาก2 พงศ์กษัตริย์ 25 บท",
            "km": "តាមដានដំណើរសាម៉ារី · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពី២ ពង្សាវតារក្សត្រ 25 ជំពូក។"
          }
        },
        {
          "stage_id": "1CH-001",
          "title": {
            "ko": "예루살렘 다윗 성",
            "en": "City of David, Jerusalem",
            "ja": "ダビデの町, エルサレム",
            "ms": "Kota Daud, Yerusalem",
            "th": "นครดาวิด, เยรูซาเล็ม",
            "km": "ទីក្រុងដាវីឌ, យេរូសាឡឹម"
          },
          "short_title": {
            "ko": "다윗 성",
            "en": "City of David",
            "ja": "ダビデの町",
            "ms": "Kota Daud",
            "th": "นครดาวิด",
            "km": "ទីក្រុងដាវីឌ"
          },
          "book_title": {
            "ko": "역대상",
            "en": "1 Chronicles",
            "ja": "歴代誌上",
            "ms": "1 Tawarikh",
            "th": "1 พงศาวดาร",
            "km": "១ របាក្សត្រ"
          },
          "map_query": "Jerusalem City of David biblical Chronicles",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "old-testament",
          "place_names": [
            "예루살렘 다윗 성",
            "City of David, Jerusalem",
            "다윗 성",
            "City of David",
            "ダビデの町, エルサレム",
            "Kota Daud, Yerusalem",
            "นครดาวิด, เยรูซาเล็ม",
            "ទីក្រុងដាវីឌ, យេរូសាឡឹម"
          ],
          "reference": "역대상 1-29",
          "references": {
            "ko": "역대상 1-29",
            "en": "1 Chronicles 1-29",
            "ja": "歴代誌上 1-29",
            "ms": "1 Tawarikh 1-29",
            "th": "1 พงศาวดาร 1-29",
            "km": "១ របាក្សត្រ 1-29"
          },
          "scene": {
            "ko": "다윗 성 위치에서 역대상 1-29 본문 사건을 확인합니다.",
            "en": "City of David: read and answer from 1 Chronicles 1-29.",
            "ja": "ダビデの町の地点で、歴代誌上 1-29の本文出来事を確認します。",
            "ms": "Di lokasi Kota Daud, semak peristiwa teks 1 Tawarikh 1-29.",
            "th": "ที่ตำแหน่งนครดาวิด ให้ตรวจสอบเหตุการณ์ใน1 พงศาวดาร 1-29",
            "km": "នៅទីតាំងទីក្រុងដាវីឌ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុង១ របាក្សត្រ 1-29។"
          },
          "mission": {
            "ko": "예루살렘 다윗 성 여정에서 역대상 29장 본문 문제를 풉니다.",
            "en": "Follow City of David, Jerusalem and answer 1 Chronicles 29 chapters question bank.",
            "ja": "ダビデの町, エルサレムの旅で、歴代誌上29章の問題バンクに答えます。",
            "ms": "Ikuti Kota Daud, Yerusalem dan jawab bank soalan 1 Tawarikh 29 bab.",
            "th": "ติดตามเส้นทางนครดาวิด, เยรูซาเล็มและตอบคลังคำถามจาก1 พงศาวดาร 29 บท",
            "km": "តាមដានដំណើរទីក្រុងដាវីឌ, យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពី១ របាក្សត្រ 29 ជំពូក។"
          }
        },
        {
          "stage_id": "2CH-001",
          "title": {
            "ko": "예루살렘 성전",
            "en": "Jerusalem Temple",
            "ja": "エルサレム神殿",
            "ms": "Bait Suci Yerusalem",
            "th": "พระวิหารเยรูซาเล็ม",
            "km": "ព្រះវិហារយេរូសាឡឹម"
          },
          "short_title": {
            "ko": "예루살렘 성전",
            "en": "Jerusalem Temple",
            "ja": "エルサレム神殿",
            "ms": "Bait Suci Yerusalem",
            "th": "พระวิหารเยรูซาเล็ม",
            "km": "ព្រះវិហារយេរូសាឡឹម"
          },
          "book_title": {
            "ko": "역대하",
            "en": "2 Chronicles",
            "ja": "歴代誌下",
            "ms": "2 Tawarikh",
            "th": "2 พงศาวดาร",
            "km": "២ របាក្សត្រ"
          },
          "map_query": "Jerusalem Temple Mount biblical Chronicles",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "old-testament",
          "place_names": [
            "예루살렘 성전",
            "Jerusalem Temple",
            "예루살렘 성전",
            "Jerusalem Temple",
            "エルサレム神殿",
            "Bait Suci Yerusalem",
            "พระวิหารเยรูซาเล็ม",
            "ព្រះវិហារយេរូសាឡឹម"
          ],
          "reference": "역대하 1-36",
          "references": {
            "ko": "역대하 1-36",
            "en": "2 Chronicles 1-36",
            "ja": "歴代誌下 1-36",
            "ms": "2 Tawarikh 1-36",
            "th": "2 พงศาวดาร 1-36",
            "km": "២ របាក្សត្រ 1-36"
          },
          "scene": {
            "ko": "예루살렘 성전 위치에서 역대하 1-36 본문 사건을 확인합니다.",
            "en": "Jerusalem Temple: read and answer from 2 Chronicles 1-36.",
            "ja": "エルサレム神殿の地点で、歴代誌下 1-36の本文出来事を確認します。",
            "ms": "Di lokasi Bait Suci Yerusalem, semak peristiwa teks 2 Tawarikh 1-36.",
            "th": "ที่ตำแหน่งพระวิหารเยรูซาเล็ม ให้ตรวจสอบเหตุการณ์ใน2 พงศาวดาร 1-36",
            "km": "នៅទីតាំងព្រះវិហារយេរូសាឡឹម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុង២ របាក្សត្រ 1-36។"
          },
          "mission": {
            "ko": "예루살렘 성전 여정에서 역대하 36장 본문 문제를 풉니다.",
            "en": "Follow Jerusalem Temple and answer 2 Chronicles 36 chapters question bank.",
            "ja": "エルサレム神殿の旅で、歴代誌下36章の問題バンクに答えます。",
            "ms": "Ikuti Bait Suci Yerusalem dan jawab bank soalan 2 Tawarikh 36 bab.",
            "th": "ติดตามเส้นทางพระวิหารเยรูซาเล็มและตอบคลังคำถามจาก2 พงศาวดาร 36 บท",
            "km": "តាមដានដំណើរព្រះវិហារយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពី២ របាក្សត្រ 36 ជំពូក។"
          }
        },
        {
          "stage_id": "EZR-001",
          "title": {
            "ko": "바벨론 · 예루살렘",
            "en": "Babylon · Jerusalem",
            "ja": "バビロン · エルサレム",
            "ms": "Babilon · Yerusalem",
            "th": "บาบิโลน · เยรูซาเล็ม",
            "km": "បាប៊ីឡូន · យេរូសាឡឹម"
          },
          "short_title": {
            "ko": "바벨론·예루살렘",
            "en": "Babylon·Jerusalem",
            "ja": "バビロン·エルサレム",
            "ms": "Babilon·Yerusalem",
            "th": "บาบิโลน·เยรูซาเล็ม",
            "km": "បាប៊ីឡូន·យេរូសាឡឹម"
          },
          "book_title": {
            "ko": "에스라",
            "en": "Ezra",
            "ja": "エズラ記",
            "ms": "Ezra",
            "th": "เอสรา",
            "km": "អែសរ៉ា"
          },
          "map_query": "Jerusalem Second Temple Ezra biblical location",
          "map_region": "babylon",
          "map_x": 61.7,
          "map_y": 66.5,
          "route_group": "old-testament",
          "place_names": [
            "바벨론 · 예루살렘",
            "Babylon · Jerusalem",
            "바벨론·예루살렘",
            "Babylon·Jerusalem",
            "バビロン · エルサレム",
            "Babilon · Yerusalem",
            "บาบิโลน · เยรูซาเล็ม",
            "បាប៊ីឡូន · យេរូសាឡឹម"
          ],
          "reference": "에스라 1-10",
          "references": {
            "ko": "에스라 1-10",
            "en": "Ezra 1-10",
            "ja": "エズラ記 1-10",
            "ms": "Ezra 1-10",
            "th": "เอสรา 1-10",
            "km": "អែសរ៉ា 1-10"
          },
          "scene": {
            "ko": "바벨론·예루살렘 위치에서 에스라 1-10 본문 사건을 확인합니다.",
            "en": "Babylon·Jerusalem: read and answer from Ezra 1-10.",
            "ja": "バビロン·エルサレムの地点で、エズラ記 1-10の本文出来事を確認します。",
            "ms": "Di lokasi Babilon·Yerusalem, semak peristiwa teks Ezra 1-10.",
            "th": "ที่ตำแหน่งบาบิโลน·เยรูซาเล็ม ให้ตรวจสอบเหตุการณ์ในเอสรา 1-10",
            "km": "នៅទីតាំងបាប៊ីឡូន·យេរូសាឡឹម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងអែសរ៉ា 1-10។"
          },
          "mission": {
            "ko": "바벨론 · 예루살렘 여정에서 에스라 10장 본문 문제를 풉니다.",
            "en": "Follow Babylon · Jerusalem and answer Ezra 10 chapters question bank.",
            "ja": "バビロン · エルサレムの旅で、エズラ記10章の問題バンクに答えます。",
            "ms": "Ikuti Babilon · Yerusalem dan jawab bank soalan Ezra 10 bab.",
            "th": "ติดตามเส้นทางบาบิโลน · เยรูซาเล็มและตอบคลังคำถามจากเอสรา 10 บท",
            "km": "តាមដានដំណើរបាប៊ីឡូន · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីអែសរ៉ា 10 ជំពូក។"
          }
        }
      ]
    },
    {
      "chapter_id": "OT-HIST-C03",
      "book_id": "NEH",
      "section_key": "history",
      "world_id": "W_OT_HIST",
      "order_index": 13,
      "title": {
        "ko": "수산·성벽 → 모압·베들레헴+",
        "en": "Susa·Walls → Moab·Bethlehem+",
        "ja": "スサ·城壁 → モアブ·ベツレヘム+",
        "ms": "Susan·Tembok → Moab·Betlehem+",
        "th": "สุสา·กำแพง → โมอับ·เบธเลเฮม+",
        "km": "ស៊ូសា·កំពែង → ម៉ូអាប់·បេថ្លេហិម+"
      },
      "summary": {
        "ko": "수산·성벽 / 수산 / 요단·여리고+ / 이스르엘+ / 모압·베들레헴+ 길을 따라 구약 2. 역사서 본문 사건을 풉니다.",
        "en": "Follow Susa·Walls / Susa / Jordan·Jericho+ / Jezreel+ / Moab·Bethlehem+ through Old Testament 2. Historical Books.",
        "ja": "スサ·城壁 / スサ / ヨルダン·エリコ+ / イズレエル+ / モアブ·ベツレヘム+の道をたどり、旧約2. 歴史書の本文出来事を解きます。",
        "ms": "Ikuti laluan Susan·Tembok / Susan / Yordan·Yerikho+ / Yizreel+ / Moab·Betlehem+ dan jawab peristiwa teks Perjanjian Lama 2. Kitab Sejarah.",
        "th": "ติดตามเส้นทาง สุสา·กำแพง / สุสา / จอร์แดน·เยรีโค+ / ยิสเรเอล+ / โมอับ·เบธเลเฮม+ และตอบเหตุการณ์ในเนื้อหาพันธสัญญาเดิม 2. หนังสือประวัติศาสตร์",
        "km": "តាមដានផ្លូវ ស៊ូសា·កំពែង / ស៊ូសា / យ័រដាន់·យេរីខូ+ / យីសរេអែល+ / ម៉ូអាប់·បេថ្លេហិម+ ហើយឆ្លើយព្រឹត្តិការណ៍ក្នុងអត្ថបទសញ្ញាចាស់ ២. សៀវភៅប្រវត្តិសាស្ត្រ។"
      },
      "stops": [
        {
          "stage_id": "NEH-001",
          "title": {
            "ko": "수산궁 · 예루살렘 성벽",
            "en": "Susa Palace · Jerusalem Walls",
            "ja": "スサ宮殿 · エルサレム城壁",
            "ms": "Istana Susann · Tembok Yerusalem",
            "th": "พระราชวังสุสา · กำแพงเยรูซาเล็ม",
            "km": "រាជវាំងស៊ូសា · កំពែងយេរូសាឡឹម"
          },
          "short_title": {
            "ko": "수산·성벽",
            "en": "Susa·Walls",
            "ja": "スサ·城壁",
            "ms": "Susan·Tembok",
            "th": "สุสา·กำแพง",
            "km": "ស៊ូសា·កំពែង"
          },
          "book_title": {
            "ko": "느헤미야",
            "en": "Nehemiah",
            "ja": "ネヘミヤ記",
            "ms": "Nehemia",
            "th": "เนหะมีย์",
            "km": "នេហេមា"
          },
          "map_query": "Jerusalem walls Nehemiah biblical location",
          "map_region": "susa",
          "map_x": 78,
          "map_y": 67.2,
          "route_group": "old-testament",
          "place_names": [
            "수산궁 · 예루살렘 성벽",
            "Susa Palace · Jerusalem Walls",
            "수산·성벽",
            "Susa·Walls",
            "スサ宮殿 · エルサレム城壁",
            "Istana Susann · Tembok Yerusalem",
            "พระราชวังสุสา · กำแพงเยรูซาเล็ม",
            "រាជវាំងស៊ូសា · កំពែងយេរូសាឡឹម"
          ],
          "reference": "느헤미야 1-13",
          "references": {
            "ko": "느헤미야 1-13",
            "en": "Nehemiah 1-13",
            "ja": "ネヘミヤ記 1-13",
            "ms": "Nehemia 1-13",
            "th": "เนหะมีย์ 1-13",
            "km": "នេហេមា 1-13"
          },
          "scene": {
            "ko": "수산·성벽 위치에서 느헤미야 1-13 본문 사건을 확인합니다.",
            "en": "Susa·Walls: read and answer from Nehemiah 1-13.",
            "ja": "スサ·城壁の地点で、ネヘミヤ記 1-13の本文出来事を確認します。",
            "ms": "Di lokasi Susan·Tembok, semak peristiwa teks Nehemia 1-13.",
            "th": "ที่ตำแหน่งสุสา·กำแพง ให้ตรวจสอบเหตุการณ์ในเนหะมีย์ 1-13",
            "km": "នៅទីតាំងស៊ូសា·កំពែង សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងនេហេមា 1-13។"
          },
          "mission": {
            "ko": "수산궁 · 예루살렘 성벽 여정에서 느헤미야 13장 본문 문제를 풉니다.",
            "en": "Follow Susa Palace · Jerusalem Walls and answer Nehemiah 13 chapters question bank.",
            "ja": "スサ宮殿 · エルサレム城壁の旅で、ネヘミヤ記13章の問題バンクに答えます。",
            "ms": "Ikuti Istana Susann · Tembok Yerusalem dan jawab bank soalan Nehemia 13 bab.",
            "th": "ติดตามเส้นทางพระราชวังสุสา · กำแพงเยรูซาเล็มและตอบคลังคำถามจากเนหะมีย์ 13 บท",
            "km": "តាមដានដំណើររាជវាំងស៊ូសា · កំពែងយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីនេហេមា 13 ជំពូក។"
          }
        },
        {
          "stage_id": "EST-001",
          "title": {
            "ko": "수산궁",
            "en": "Susa Palace",
            "ja": "スサ宮殿",
            "ms": "Istana Susan",
            "th": "พระราชวังสุสา",
            "km": "រាជវាំងស៊ូសា"
          },
          "short_title": {
            "ko": "수산",
            "en": "Susa",
            "ja": "スサ",
            "ms": "Susan",
            "th": "สุสา",
            "km": "ស៊ូសា"
          },
          "book_title": {
            "ko": "에스더",
            "en": "Esther",
            "ja": "エステル記",
            "ms": "Ester",
            "th": "เอสเธอร์",
            "km": "អេសធើរ"
          },
          "map_query": "Susa Iran Esther biblical location",
          "map_region": "susa",
          "map_x": 78,
          "map_y": 67.2,
          "route_group": "old-testament",
          "place_names": [
            "수산궁",
            "Susa Palace",
            "수산",
            "Susa",
            "スサ宮殿",
            "Istana Susan",
            "พระราชวังสุสา",
            "រាជវាំងស៊ូសា"
          ],
          "reference": "에스더 1-10",
          "references": {
            "ko": "에스더 1-10",
            "en": "Esther 1-10",
            "ja": "エステル記 1-10",
            "ms": "Ester 1-10",
            "th": "เอสเธอร์ 1-10",
            "km": "អេសធើរ 1-10"
          },
          "scene": {
            "ko": "수산 위치에서 에스더 1-10 본문 사건을 확인합니다.",
            "en": "Susa: read and answer from Esther 1-10.",
            "ja": "スサの地点で、エステル記 1-10の本文出来事を確認します。",
            "ms": "Di lokasi Susan, semak peristiwa teks Ester 1-10.",
            "th": "ที่ตำแหน่งสุสา ให้ตรวจสอบเหตุการณ์ในเอสเธอร์ 1-10",
            "km": "នៅទីតាំងស៊ូសា សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងអេសធើរ 1-10។"
          },
          "mission": {
            "ko": "수산궁 여정에서 에스더 10장 본문 문제를 풉니다.",
            "en": "Follow Susa Palace and answer Esther 10 chapters question bank.",
            "ja": "スサ宮殿の旅で、エステル記10章の問題バンクに答えます。",
            "ms": "Ikuti Istana Susan dan jawab bank soalan Ester 10 bab.",
            "th": "ติดตามเส้นทางพระราชวังสุสาและตอบคลังคำถามจากเอสเธอร์ 10 บท",
            "km": "តាមដានដំណើររាជវាំងស៊ូសា ហើយឆ្លើយធនាគារសំណួរពីអេសធើរ 10 ជំពូក។"
          }
        },
        {
          "stage_id": "JOS-REVIEW-13",
          "title": {
            "ko": "요단강 · 여리고 복습",
            "en": "Jordan River · Jericho Review",
            "ja": "ヨルダン川 · エリコ 復習",
            "ms": "Sungai Yordan · Yerikho Ulang kaji",
            "th": "แม่น้ำจอร์แดน · เยรีโค ทบทวน",
            "km": "ទន្លេយ័រដាន់ · យេរីខូ រំលឹក"
          },
          "short_title": {
            "ko": "요단·여리고+",
            "en": "Jordan·Jericho+",
            "ja": "ヨルダン·エリコ+",
            "ms": "Yordan·Yerikho+",
            "th": "จอร์แดน·เยรีโค+",
            "km": "យ័រដាន់·យេរីខូ+"
          },
          "book_title": {
            "ko": "여호수아",
            "en": "Joshua",
            "ja": "ヨシュア記",
            "ms": "Yosua",
            "th": "โยชูวา",
            "km": "យ៉ូស្វេ"
          },
          "map_query": "Jericho archaeological site biblical Joshua review",
          "map_region": "canaan",
          "map_x": 37.2,
          "map_y": 69.2,
          "route_group": "old-testament",
          "place_names": [
            "요단강 · 여리고",
            "Jordan River · Jericho",
            "요단·여리고",
            "Jordan·Jericho",
            "ヨルダン川 · エリコ",
            "Sungai Yordan · Yerikho",
            "แม่น้ำจอร์แดน · เยรีโค",
            "ទន្លេយ័រដាន់ · យេរីខូ"
          ],
          "reference": "여호수아 1-24",
          "references": {
            "ko": "여호수아 1-24",
            "en": "Joshua 1-24",
            "ja": "ヨシュア記 1-24",
            "ms": "Yosua 1-24",
            "th": "โยชูวา 1-24",
            "km": "យ៉ូស្វេ 1-24"
          },
          "scene": {
            "ko": "요단·여리고+ 위치에서 여호수아 1-24 본문 사건을 확인합니다.",
            "en": "Jordan·Jericho+: read and answer from Joshua 1-24.",
            "ja": "ヨルダン·エリコ+の地点で、ヨシュア記 1-24の本文出来事を確認します。",
            "ms": "Di lokasi Yordan·Yerikho+, semak peristiwa teks Yosua 1-24.",
            "th": "ที่ตำแหน่งจอร์แดน·เยรีโค+ ให้ตรวจสอบเหตุการณ์ในโยชูวา 1-24",
            "km": "នៅទីតាំងយ័រដាន់·យេរីខូ+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងយ៉ូស្វេ 1-24។"
          },
          "mission": {
            "ko": "요단강 · 여리고 길에서 여호수아 주요 사건을 다시 확인합니다.",
            "en": "Review the main Joshua events along Jordan River · Jericho.",
            "ja": "ヨルダン川 · エリコの道で、ヨシュア記の主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama Yosua di sepanjang Sungai Yordan · Yerikho.",
            "th": "ทบทวนเหตุการณ์สำคัญของโยชูวาตามเส้นทางแม่น้ำจอร์แดน · เยรีโค",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃយ៉ូស្វេ តាមផ្លូវទន្លេយ័រដាន់ · យេរីខូ។"
          }
        },
        {
          "stage_id": "JDG-REVIEW-14",
          "title": {
            "ko": "이스르엘 골짜기 · 가나안 산지 복습",
            "en": "Jezreel Valley · Canaan Highlands Review",
            "ja": "イズレエルの谷 · カナン山地 復習",
            "ms": "Lembah Yizreel · Tanah tinggi Kanaan Ulang kaji",
            "th": "หุบเขายิสเรเอล · ที่ราบสูงคานาอัน ทบทวน",
            "km": "ជ្រលងយីសរេអែល · តំបន់ភ្នំកាណាន រំលឹក"
          },
          "short_title": {
            "ko": "이스르엘+",
            "en": "Jezreel+",
            "ja": "イズレエル+",
            "ms": "Yizreel+",
            "th": "ยิสเรเอล+",
            "km": "យីសរេអែល+"
          },
          "book_title": {
            "ko": "사사기",
            "en": "Judges",
            "ja": "士師記",
            "ms": "Hakim-hakim",
            "th": "ผู้วินิจฉัย",
            "km": "ពួកចៅហ្វាយ"
          },
          "map_query": "Valley of Jezreel Israel biblical Judges review",
          "map_region": "canaan",
          "map_x": 36.8,
          "map_y": 67.5,
          "route_group": "old-testament",
          "place_names": [
            "이스르엘 골짜기 · 가나안 산지",
            "Jezreel Valley · Canaan Highlands",
            "이스르엘",
            "Jezreel",
            "イズレエルの谷 · カナン山地",
            "Lembah Yizreel · Tanah tinggi Kanaan",
            "หุบเขายิสเรเอล · ที่ราบสูงคานาอัน",
            "ជ្រលងយីសរេអែល · តំបន់ភ្នំកាណាន"
          ],
          "reference": "사사기 1-21",
          "references": {
            "ko": "사사기 1-21",
            "en": "Judges 1-21",
            "ja": "士師記 1-21",
            "ms": "Hakim-hakim 1-21",
            "th": "ผู้วินิจฉัย 1-21",
            "km": "ពួកចៅហ្វាយ 1-21"
          },
          "scene": {
            "ko": "이스르엘+ 위치에서 사사기 1-21 본문 사건을 확인합니다.",
            "en": "Jezreel+: read and answer from Judges 1-21.",
            "ja": "イズレエル+の地点で、士師記 1-21の本文出来事を確認します。",
            "ms": "Di lokasi Yizreel+, semak peristiwa teks Hakim-hakim 1-21.",
            "th": "ที่ตำแหน่งยิสเรเอล+ ให้ตรวจสอบเหตุการณ์ในผู้วินิจฉัย 1-21",
            "km": "នៅទីតាំងយីសរេអែល+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងពួកចៅហ្វាយ 1-21។"
          },
          "mission": {
            "ko": "이스르엘 골짜기 · 가나안 산지 길에서 사사기 주요 사건을 다시 확인합니다.",
            "en": "Review the main Judges events along Jezreel Valley · Canaan Highlands.",
            "ja": "イズレエルの谷 · カナン山地の道で、士師記の主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama Hakim-hakim di sepanjang Lembah Yizreel · Tanah tinggi Kanaan.",
            "th": "ทบทวนเหตุการณ์สำคัญของผู้วินิจฉัยตามเส้นทางหุบเขายิสเรเอล · ที่ราบสูงคานาอัน",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃពួកចៅហ្វាយ តាមផ្លូវជ្រលងយីសរេអែល · តំបន់ភ្នំកាណាន។"
          }
        },
        {
          "stage_id": "RUT-REVIEW-15",
          "title": {
            "ko": "모압 · 베들레헴 복습",
            "en": "Moab · Bethlehem Review",
            "ja": "モアブ · ベツレヘム 復習",
            "ms": "Moab · Betlehem Ulang kaji",
            "th": "โมอับ · เบธเลเฮม ทบทวน",
            "km": "ម៉ូអាប់ · បេថ្លេហិម រំលឹក"
          },
          "short_title": {
            "ko": "모압·베들레헴+",
            "en": "Moab·Bethlehem+",
            "ja": "モアブ·ベツレヘム+",
            "ms": "Moab·Betlehem+",
            "th": "โมอับ·เบธเลเฮม+",
            "km": "ម៉ូអាប់·បេថ្លេហិម+"
          },
          "book_title": {
            "ko": "룻기",
            "en": "Ruth",
            "ja": "ルツ記",
            "ms": "Rut",
            "th": "รูธ",
            "km": "នាងរស់"
          },
          "map_query": "Bethlehem Israel Ruth biblical location review",
          "map_region": "bethlehem",
          "map_x": 37.1,
          "map_y": 72.2,
          "route_group": "old-testament",
          "place_names": [
            "모압 · 베들레헴",
            "Moab · Bethlehem",
            "모압·베들레헴",
            "Moab·Bethlehem",
            "モアブ · ベツレヘム",
            "Moab · Betlehem",
            "โมอับ · เบธเลเฮม",
            "ម៉ូអាប់ · បេថ្លេហិម"
          ],
          "reference": "룻기 1-4",
          "references": {
            "ko": "룻기 1-4",
            "en": "Ruth 1-4",
            "ja": "ルツ記 1-4",
            "ms": "Rut 1-4",
            "th": "รูธ 1-4",
            "km": "នាងរស់ 1-4"
          },
          "scene": {
            "ko": "모압·베들레헴+ 위치에서 룻기 1-4 본문 사건을 확인합니다.",
            "en": "Moab·Bethlehem+: read and answer from Ruth 1-4.",
            "ja": "モアブ·ベツレヘム+の地点で、ルツ記 1-4の本文出来事を確認します。",
            "ms": "Di lokasi Moab·Betlehem+, semak peristiwa teks Rut 1-4.",
            "th": "ที่ตำแหน่งโมอับ·เบธเลเฮม+ ให้ตรวจสอบเหตุการณ์ในรูธ 1-4",
            "km": "នៅទីតាំងម៉ូអាប់·បេថ្លេហិម+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងនាងរស់ 1-4។"
          },
          "mission": {
            "ko": "모압 · 베들레헴 길에서 룻기 주요 사건을 다시 확인합니다.",
            "en": "Review the main Ruth events along Moab · Bethlehem.",
            "ja": "モアブ · ベツレヘムの道で、ルツ記の主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama Rut di sepanjang Moab · Betlehem.",
            "th": "ทบทวนเหตุการณ์สำคัญของรูธตามเส้นทางโมอับ · เบธเลเฮม",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃនាងរស់ តាមផ្លូវម៉ូអាប់ · បេថ្លេហិម។"
          }
        }
      ]
    },
    {
      "chapter_id": "OT-WIS-C01",
      "book_id": "JOB",
      "section_key": "wisdom",
      "world_id": "W_OT_WIS",
      "order_index": 21,
      "title": {
        "ko": "우스 → 예루살렘·레바논",
        "en": "Uz → Jerusalem·Lebanon",
        "ja": "ウツ → エルサレム·レバノン",
        "ms": "Us → Yerusalem·Lebanon",
        "th": "อูส → เยรูซาเล็ม·เลบานอน",
        "km": "អ៊ូស → យេរូសាឡឹម·លីបង់"
      },
      "summary": {
        "ko": "우스 / 시온 / 예루살렘 / 예루살렘 / 예루살렘·레바논 길을 따라 구약 3. 시가서 본문 사건을 풉니다.",
        "en": "Follow Uz / Zion / Jerusalem / Jerusalem / Jerusalem·Lebanon through Old Testament 3. Wisdom and Poetry.",
        "ja": "ウツ / シオン / エルサレム / エルサレム / エルサレム·レバノンの道をたどり、旧約3. 知恵と詩の本文出来事を解きます。",
        "ms": "Ikuti laluan Us / Sion / Yerusalem / Yerusalem / Yerusalem·Lebanon dan jawab peristiwa teks Perjanjian Lama 3. Hikmat dan Puisi.",
        "th": "ติดตามเส้นทาง อูส / ศิโยน / เยรูซาเล็ม / เยรูซาเล็ม / เยรูซาเล็ม·เลบานอน และตอบเหตุการณ์ในเนื้อหาพันธสัญญาเดิม 3. ปัญญาและบทกวี",
        "km": "តាមដានផ្លូវ អ៊ូស / ស៊ីយ៉ូន / យេរូសាឡឹម / យេរូសាឡឹម / យេរូសាឡឹម·លីបង់ ហើយឆ្លើយព្រឹត្តិការណ៍ក្នុងអត្ថបទសញ្ញាចាស់ ៣. ប្រាជ្ញា និងកំណាព្យ។"
      },
      "stops": [
        {
          "stage_id": "JOB-001",
          "title": {
            "ko": "우스 땅",
            "en": "Land of Uz",
            "ja": "ウツの地",
            "ms": "Tanah Us",
            "th": "แผ่นดินอูส",
            "km": "ស្រុកអ៊ូស"
          },
          "short_title": {
            "ko": "우스",
            "en": "Uz",
            "ja": "ウツ",
            "ms": "Us",
            "th": "อูส",
            "km": "អ៊ូស"
          },
          "book_title": {
            "ko": "욥기",
            "en": "Job",
            "ja": "ヨブ記",
            "ms": "Ayub",
            "th": "โยบ",
            "km": "យ៉ូប"
          },
          "map_query": "Uz Edom biblical Job location",
          "map_region": "edom",
          "map_x": 36.5,
          "map_y": 79.5,
          "route_group": "old-testament",
          "place_names": [
            "우스 땅",
            "Land of Uz",
            "우스",
            "Uz",
            "ウツの地",
            "Tanah Us",
            "แผ่นดินอูส",
            "ស្រុកអ៊ូស"
          ],
          "reference": "욥기 1-42",
          "references": {
            "ko": "욥기 1-42",
            "en": "Job 1-42",
            "ja": "ヨブ記 1-42",
            "ms": "Ayub 1-42",
            "th": "โยบ 1-42",
            "km": "យ៉ូប 1-42"
          },
          "scene": {
            "ko": "우스 위치에서 욥기 1-42 본문 사건을 확인합니다.",
            "en": "Uz: read and answer from Job 1-42.",
            "ja": "ウツの地点で、ヨブ記 1-42の本文出来事を確認します。",
            "ms": "Di lokasi Us, semak peristiwa teks Ayub 1-42.",
            "th": "ที่ตำแหน่งอูส ให้ตรวจสอบเหตุการณ์ในโยบ 1-42",
            "km": "នៅទីតាំងអ៊ូស សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងយ៉ូប 1-42។"
          },
          "mission": {
            "ko": "우스 땅 여정에서 욥기 42장 본문 문제를 풉니다.",
            "en": "Follow Land of Uz and answer Job 42 chapters question bank.",
            "ja": "ウツの地の旅で、ヨブ記42章の問題バンクに答えます。",
            "ms": "Ikuti Tanah Us dan jawab bank soalan Ayub 42 bab.",
            "th": "ติดตามเส้นทางแผ่นดินอูสและตอบคลังคำถามจากโยบ 42 บท",
            "km": "តាមដានដំណើរស្រុកអ៊ូស ហើយឆ្លើយធនាគារសំណួរពីយ៉ូប 42 ជំពូក។"
          }
        },
        {
          "stage_id": "PSA-001",
          "title": {
            "ko": "시온 · 예루살렘",
            "en": "Zion · Jerusalem",
            "ja": "シオン · エルサレム",
            "ms": "Sion · Yerusalem",
            "th": "ศิโยน · เยรูซาเล็ม",
            "km": "ស៊ីយ៉ូន · យេរូសាឡឹម"
          },
          "short_title": {
            "ko": "시온",
            "en": "Zion",
            "ja": "シオン",
            "ms": "Sion",
            "th": "ศิโยน",
            "km": "ស៊ីយ៉ូន"
          },
          "book_title": {
            "ko": "시편",
            "en": "Psalms",
            "ja": "詩篇",
            "ms": "Mazmur",
            "th": "สดุดี",
            "km": "ទំនុកតម្កើង"
          },
          "map_query": "Jerusalem Psalms biblical worship",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "old-testament",
          "place_names": [
            "시온 · 예루살렘",
            "Zion · Jerusalem",
            "시온",
            "Zion",
            "シオン · エルサレム",
            "Sion · Yerusalem",
            "ศิโยน · เยรูซาเล็ม",
            "ស៊ីយ៉ូន · យេរូសាឡឹម"
          ],
          "reference": "시편 1-150",
          "references": {
            "ko": "시편 1-150",
            "en": "Psalms 1-150",
            "ja": "詩篇 1-150",
            "ms": "Mazmur 1-150",
            "th": "สดุดี 1-150",
            "km": "ទំនុកតម្កើង 1-150"
          },
          "scene": {
            "ko": "시온 위치에서 시편 1-150 본문 사건을 확인합니다.",
            "en": "Zion: read and answer from Psalms 1-150.",
            "ja": "シオンの地点で、詩篇 1-150の本文出来事を確認します。",
            "ms": "Di lokasi Sion, semak peristiwa teks Mazmur 1-150.",
            "th": "ที่ตำแหน่งศิโยน ให้ตรวจสอบเหตุการณ์ในสดุดี 1-150",
            "km": "នៅទីតាំងស៊ីយ៉ូន សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងទំនុកតម្កើង 1-150។"
          },
          "mission": {
            "ko": "시온 · 예루살렘 여정에서 시편 150장 본문 문제를 풉니다.",
            "en": "Follow Zion · Jerusalem and answer Psalms 150 chapters question bank.",
            "ja": "シオン · エルサレムの旅で、詩篇150章の問題バンクに答えます。",
            "ms": "Ikuti Sion · Yerusalem dan jawab bank soalan Mazmur 150 bab.",
            "th": "ติดตามเส้นทางศิโยน · เยรูซาเล็มและตอบคลังคำถามจากสดุดี 150 บท",
            "km": "តាមដានដំណើរស៊ីយ៉ូន · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីទំនុកតម្កើង 150 ជំពូក។"
          }
        },
        {
          "stage_id": "PRO-001",
          "title": {
            "ko": "예루살렘 왕궁",
            "en": "Royal Court of Jerusalem",
            "ja": "エルサレム王宮",
            "ms": "Istana Diraja Yerusalem",
            "th": "ราชสำนักเยรูซาเล็ม",
            "km": "រាជវាំងយេរូសាឡឹម"
          },
          "short_title": {
            "ko": "예루살렘",
            "en": "Jerusalem",
            "ja": "エルサレム",
            "ms": "Yerusalem",
            "th": "เยรูซาเล็ม",
            "km": "យេរូសាឡឹម"
          },
          "book_title": {
            "ko": "잠언",
            "en": "Proverbs",
            "ja": "箴言",
            "ms": "Amsal",
            "th": "สุภาษิต",
            "km": "សុភាសិត"
          },
          "map_query": "Jerusalem Solomon Proverbs biblical location",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "old-testament",
          "place_names": [
            "예루살렘 왕궁",
            "Royal Court of Jerusalem",
            "예루살렘",
            "Jerusalem",
            "エルサレム王宮",
            "Istana Diraja Yerusalem",
            "ราชสำนักเยรูซาเล็ม",
            "រាជវាំងយេរូសាឡឹម"
          ],
          "reference": "잠언 1-31",
          "references": {
            "ko": "잠언 1-31",
            "en": "Proverbs 1-31",
            "ja": "箴言 1-31",
            "ms": "Amsal 1-31",
            "th": "สุภาษิต 1-31",
            "km": "សុភាសិត 1-31"
          },
          "scene": {
            "ko": "예루살렘 위치에서 잠언 1-31 본문 사건을 확인합니다.",
            "en": "Jerusalem: read and answer from Proverbs 1-31.",
            "ja": "エルサレムの地点で、箴言 1-31の本文出来事を確認します。",
            "ms": "Di lokasi Yerusalem, semak peristiwa teks Amsal 1-31.",
            "th": "ที่ตำแหน่งเยรูซาเล็ม ให้ตรวจสอบเหตุการณ์ในสุภาษิต 1-31",
            "km": "នៅទីតាំងយេរូសាឡឹម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងសុភាសិត 1-31។"
          },
          "mission": {
            "ko": "예루살렘 왕궁 여정에서 잠언 31장 본문 문제를 풉니다.",
            "en": "Follow Royal Court of Jerusalem and answer Proverbs 31 chapters question bank.",
            "ja": "エルサレム王宮の旅で、箴言31章の問題バンクに答えます。",
            "ms": "Ikuti Istana Diraja Yerusalem dan jawab bank soalan Amsal 31 bab.",
            "th": "ติดตามเส้นทางราชสำนักเยรูซาเล็มและตอบคลังคำถามจากสุภาษิต 31 บท",
            "km": "តាមដានដំណើររាជវាំងយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីសុភាសិត 31 ជំពូក។"
          }
        },
        {
          "stage_id": "ECC-001",
          "title": {
            "ko": "예루살렘 집회",
            "en": "Assembly in Jerusalem",
            "ja": "エルサレムの集会",
            "ms": "Perhimpunan di Yerusalem",
            "th": "ที่ชุมนุมในเยรูซาเล็ม",
            "km": "ការជួបជុំនៅយេរូសាឡឹម"
          },
          "short_title": {
            "ko": "예루살렘",
            "en": "Jerusalem",
            "ja": "エルサレム",
            "ms": "Yerusalem",
            "th": "เยรูซาเล็ม",
            "km": "យេរូសាឡឹម"
          },
          "book_title": {
            "ko": "전도서",
            "en": "Ecclesiastes",
            "ja": "伝道者の書",
            "ms": "Pengkhotbah",
            "th": "ปัญญาจารย์",
            "km": "សាស្ដា"
          },
          "map_query": "Jerusalem Ecclesiastes Solomon biblical location",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "old-testament",
          "place_names": [
            "예루살렘 집회",
            "Assembly in Jerusalem",
            "예루살렘",
            "Jerusalem",
            "エルサレムの集会",
            "Perhimpunan di Yerusalem",
            "ที่ชุมนุมในเยรูซาเล็ม",
            "ការជួបជុំនៅយេរូសាឡឹម"
          ],
          "reference": "전도서 1-12",
          "references": {
            "ko": "전도서 1-12",
            "en": "Ecclesiastes 1-12",
            "ja": "伝道者の書 1-12",
            "ms": "Pengkhotbah 1-12",
            "th": "ปัญญาจารย์ 1-12",
            "km": "សាស្ដា 1-12"
          },
          "scene": {
            "ko": "예루살렘 위치에서 전도서 1-12 본문 사건을 확인합니다.",
            "en": "Jerusalem: read and answer from Ecclesiastes 1-12.",
            "ja": "エルサレムの地点で、伝道者の書 1-12の本文出来事を確認します。",
            "ms": "Di lokasi Yerusalem, semak peristiwa teks Pengkhotbah 1-12.",
            "th": "ที่ตำแหน่งเยรูซาเล็ม ให้ตรวจสอบเหตุการณ์ในปัญญาจารย์ 1-12",
            "km": "នៅទីតាំងយេរូសាឡឹម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងសាស្ដា 1-12។"
          },
          "mission": {
            "ko": "예루살렘 집회 여정에서 전도서 12장 본문 문제를 풉니다.",
            "en": "Follow Assembly in Jerusalem and answer Ecclesiastes 12 chapters question bank.",
            "ja": "エルサレムの集会の旅で、伝道者の書12章の問題バンクに答えます。",
            "ms": "Ikuti Perhimpunan di Yerusalem dan jawab bank soalan Pengkhotbah 12 bab.",
            "th": "ติดตามเส้นทางที่ชุมนุมในเยรูซาเล็มและตอบคลังคำถามจากปัญญาจารย์ 12 บท",
            "km": "តាមដានដំណើរការជួបជុំនៅយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីសាស្ដា 12 ជំពូក។"
          }
        },
        {
          "stage_id": "SNG-001",
          "title": {
            "ko": "예루살렘 · 레바논",
            "en": "Jerusalem · Lebanon",
            "ja": "エルサレム · レバノン",
            "ms": "Yerusalem · Lebanon",
            "th": "เยรูซาเล็ม · เลบานอน",
            "km": "យេរូសាឡឹម · លីបង់"
          },
          "short_title": {
            "ko": "예루살렘·레바논",
            "en": "Jerusalem·Lebanon",
            "ja": "エルサレム·レバノン",
            "ms": "Yerusalem·Lebanon",
            "th": "เยรูซาเล็ม·เลบานอน",
            "km": "យេរូសាឡឹម·លីបង់"
          },
          "book_title": {
            "ko": "아가",
            "en": "Song of Songs",
            "ja": "雅歌",
            "ms": "Kidung Agung",
            "th": "เพลงซาโลมอน",
            "km": "បទចម្រៀងសាឡូម៉ូន"
          },
          "map_query": "Jerusalem Song of Songs biblical location",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "old-testament",
          "place_names": [
            "예루살렘 · 레바논",
            "Jerusalem · Lebanon",
            "예루살렘·레바논",
            "Jerusalem·Lebanon",
            "エルサレム · レバノン",
            "Yerusalem · Lebanon",
            "เยรูซาเล็ม · เลบานอน",
            "យេរូសាឡឹម · លីបង់"
          ],
          "reference": "아가 1-8",
          "references": {
            "ko": "아가 1-8",
            "en": "Song of Songs 1-8",
            "ja": "雅歌 1-8",
            "ms": "Kidung Agung 1-8",
            "th": "เพลงซาโลมอน 1-8",
            "km": "បទចម្រៀងសាឡូម៉ូន 1-8"
          },
          "scene": {
            "ko": "예루살렘·레바논 위치에서 아가 1-8 본문 사건을 확인합니다.",
            "en": "Jerusalem·Lebanon: read and answer from Song of Songs 1-8.",
            "ja": "エルサレム·レバノンの地点で、雅歌 1-8の本文出来事を確認します。",
            "ms": "Di lokasi Yerusalem·Lebanon, semak peristiwa teks Kidung Agung 1-8.",
            "th": "ที่ตำแหน่งเยรูซาเล็ม·เลบานอน ให้ตรวจสอบเหตุการณ์ในเพลงซาโลมอน 1-8",
            "km": "នៅទីតាំងយេរូសាឡឹម·លីបង់ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងបទចម្រៀងសាឡូម៉ូន 1-8។"
          },
          "mission": {
            "ko": "예루살렘 · 레바논 여정에서 아가 8장 본문 문제를 풉니다.",
            "en": "Follow Jerusalem · Lebanon and answer Song of Songs 8 chapters question bank.",
            "ja": "エルサレム · レバノンの旅で、雅歌8章の問題バンクに答えます。",
            "ms": "Ikuti Yerusalem · Lebanon dan jawab bank soalan Kidung Agung 8 bab.",
            "th": "ติดตามเส้นทางเยรูซาเล็ม · เลบานอนและตอบคลังคำถามจากเพลงซาโลมอน 8 บท",
            "km": "តាមដានដំណើរយេរូសាឡឹម · លីបង់ ហើយឆ្លើយធនាគារសំណួរពីបទចម្រៀងសាឡូម៉ូន 8 ជំពូក។"
          }
        }
      ]
    },
    {
      "chapter_id": "OT-MAJOR-C01",
      "book_id": "ISA",
      "section_key": "majorProphets",
      "world_id": "W_OT_MAJOR",
      "order_index": 31,
      "title": {
        "ko": "시온 → 바벨론·수산",
        "en": "Zion → Babylon·Susa",
        "ja": "シオン → バビロン·スサ",
        "ms": "Sion → Babilon·Susan",
        "th": "ศิโยน → บาบิโลน·สุสา",
        "km": "ស៊ីយ៉ូន → បាប៊ីឡូន·ស៊ូសា"
      },
      "summary": {
        "ko": "시온 / 아나돗·예루살렘 / 예루살렘 폐허 / 그발·바벨론 / 바벨론·수산 길을 따라 구약 4. 대선지서 본문 사건을 풉니다.",
        "en": "Follow Zion / Anathoth·Jerusalem / Jerusalem Ruins / Chebar·Babylon / Babylon·Susa through Old Testament 4. Major Prophets.",
        "ja": "シオン / アナトテ·エルサレム / エルサレムの廃虚 / ケバル·バビロン / バビロン·スサの道をたどり、旧約4. 大預言書の本文出来事を解きます。",
        "ms": "Ikuti laluan Sion / Anatot·Yerusalem / Reruntuhan Yerusalem / Kebar·Babilon / Babilon·Susan dan jawab peristiwa teks Perjanjian Lama 4. Nabi-nabi Besar.",
        "th": "ติดตามเส้นทาง ศิโยน / อานาโธท·เยรูซาเล็ม / ซากกรุงเยรูซาเล็ม / เคบาร์·บาบิโลน / บาบิโลน·สุสา และตอบเหตุการณ์ในเนื้อหาพันธสัญญาเดิม 4. ผู้เผยพระวจนะใหญ่",
        "km": "តាមដានផ្លូវ ស៊ីយ៉ូន / អាណាថោត·យេរូសាឡឹម / គំនរបាក់បែកយេរូសាឡឹម / ខេបារ·បាប៊ីឡូន / បាប៊ីឡូន·ស៊ូសា ហើយឆ្លើយព្រឹត្តិការណ៍ក្នុងអត្ថបទសញ្ញាចាស់ ៤. ហោរាធំ។"
      },
      "stops": [
        {
          "stage_id": "ISA-001",
          "title": {
            "ko": "시온 · 예루살렘",
            "en": "Zion · Jerusalem",
            "ja": "シオン · エルサレム",
            "ms": "Sion · Yerusalem",
            "th": "ศิโยน · เยรูซาเล็ม",
            "km": "ស៊ីយ៉ូន · យេរូសាឡឹម"
          },
          "short_title": {
            "ko": "시온",
            "en": "Zion",
            "ja": "シオン",
            "ms": "Sion",
            "th": "ศิโยน",
            "km": "ស៊ីយ៉ូន"
          },
          "book_title": {
            "ko": "이사야",
            "en": "Isaiah",
            "ja": "イザヤ書",
            "ms": "Yesaya",
            "th": "อิสยาห์",
            "km": "អេសាយ"
          },
          "map_query": "Jerusalem Isaiah biblical prophet location",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "prophets",
          "place_names": [
            "시온 · 예루살렘",
            "Zion · Jerusalem",
            "시온",
            "Zion",
            "シオン · エルサレム",
            "Sion · Yerusalem",
            "ศิโยน · เยรูซาเล็ม",
            "ស៊ីយ៉ូន · យេរូសាឡឹម"
          ],
          "reference": "이사야 1-66",
          "references": {
            "ko": "이사야 1-66",
            "en": "Isaiah 1-66",
            "ja": "イザヤ書 1-66",
            "ms": "Yesaya 1-66",
            "th": "อิสยาห์ 1-66",
            "km": "អេសាយ 1-66"
          },
          "scene": {
            "ko": "시온 위치에서 이사야 1-66 본문 사건을 확인합니다.",
            "en": "Zion: read and answer from Isaiah 1-66.",
            "ja": "シオンの地点で、イザヤ書 1-66の本文出来事を確認します。",
            "ms": "Di lokasi Sion, semak peristiwa teks Yesaya 1-66.",
            "th": "ที่ตำแหน่งศิโยน ให้ตรวจสอบเหตุการณ์ในอิสยาห์ 1-66",
            "km": "នៅទីតាំងស៊ីយ៉ូន សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងអេសាយ 1-66។"
          },
          "mission": {
            "ko": "시온 · 예루살렘 여정에서 이사야 66장 본문 문제를 풉니다.",
            "en": "Follow Zion · Jerusalem and answer Isaiah 66 chapters question bank.",
            "ja": "シオン · エルサレムの旅で、イザヤ書66章の問題バンクに答えます。",
            "ms": "Ikuti Sion · Yerusalem dan jawab bank soalan Yesaya 66 bab.",
            "th": "ติดตามเส้นทางศิโยน · เยรูซาเล็มและตอบคลังคำถามจากอิสยาห์ 66 บท",
            "km": "តាមដានដំណើរស៊ីយ៉ូន · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីអេសាយ 66 ជំពូក។"
          }
        },
        {
          "stage_id": "JER-001",
          "title": {
            "ko": "아나돗 · 예루살렘",
            "en": "Anathoth · Jerusalem",
            "ja": "アナトテ · エルサレム",
            "ms": "Anatot · Yerusalem",
            "th": "อานาโธท · เยรูซาเล็ม",
            "km": "អាណាថោត · យេរូសាឡឹម"
          },
          "short_title": {
            "ko": "아나돗·예루살렘",
            "en": "Anathoth·Jerusalem",
            "ja": "アナトテ·エルサレム",
            "ms": "Anatot·Yerusalem",
            "th": "อานาโธท·เยรูซาเล็ม",
            "km": "អាណាថោត·យេរូសាឡឹម"
          },
          "book_title": {
            "ko": "예레미야",
            "en": "Jeremiah",
            "ja": "エレミヤ書",
            "ms": "Yeremia",
            "th": "เยเรมีย์",
            "km": "យេរេមា"
          },
          "map_query": "Jerusalem Jeremiah biblical prophet location",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "prophets",
          "place_names": [
            "아나돗 · 예루살렘",
            "Anathoth · Jerusalem",
            "아나돗·예루살렘",
            "Anathoth·Jerusalem",
            "アナトテ · エルサレム",
            "Anatot · Yerusalem",
            "อานาโธท · เยรูซาเล็ม",
            "អាណាថោត · យេរូសាឡឹម"
          ],
          "reference": "예레미야 1-52",
          "references": {
            "ko": "예레미야 1-52",
            "en": "Jeremiah 1-52",
            "ja": "エレミヤ書 1-52",
            "ms": "Yeremia 1-52",
            "th": "เยเรมีย์ 1-52",
            "km": "យេរេមា 1-52"
          },
          "scene": {
            "ko": "아나돗·예루살렘 위치에서 예레미야 1-52 본문 사건을 확인합니다.",
            "en": "Anathoth·Jerusalem: read and answer from Jeremiah 1-52.",
            "ja": "アナトテ·エルサレムの地点で、エレミヤ書 1-52の本文出来事を確認します。",
            "ms": "Di lokasi Anatot·Yerusalem, semak peristiwa teks Yeremia 1-52.",
            "th": "ที่ตำแหน่งอานาโธท·เยรูซาเล็ม ให้ตรวจสอบเหตุการณ์ในเยเรมีย์ 1-52",
            "km": "នៅទីតាំងអាណាថោត·យេរូសាឡឹម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងយេរេមា 1-52។"
          },
          "mission": {
            "ko": "아나돗 · 예루살렘 여정에서 예레미야 52장 본문 문제를 풉니다.",
            "en": "Follow Anathoth · Jerusalem and answer Jeremiah 52 chapters question bank.",
            "ja": "アナトテ · エルサレムの旅で、エレミヤ書52章の問題バンクに答えます。",
            "ms": "Ikuti Anatot · Yerusalem dan jawab bank soalan Yeremia 52 bab.",
            "th": "ติดตามเส้นทางอานาโธท · เยรูซาเล็มและตอบคลังคำถามจากเยเรมีย์ 52 บท",
            "km": "តាមដានដំណើរអាណាថោត · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីយេរេមា 52 ជំពូក។"
          }
        },
        {
          "stage_id": "LAM-001",
          "title": {
            "ko": "예루살렘 폐허",
            "en": "Ruins of Jerusalem",
            "ja": "エルサレムの廃虚",
            "ms": "Reruntuhan Yerusalem",
            "th": "ซากกรุงเยรูซาเล็ม",
            "km": "គំនរបាក់បែកយេរូសាឡឹម"
          },
          "short_title": {
            "ko": "예루살렘 폐허",
            "en": "Jerusalem Ruins",
            "ja": "エルサレムの廃虚",
            "ms": "Reruntuhan Yerusalem",
            "th": "ซากกรุงเยรูซาเล็ม",
            "km": "គំនរបាក់បែកយេរូសាឡឹម"
          },
          "book_title": {
            "ko": "예레미야애가",
            "en": "Lamentations",
            "ja": "哀歌",
            "ms": "Ratapan",
            "th": "เพลงคร่ำครวญ",
            "km": "បរិទេវ"
          },
          "map_query": "Jerusalem destruction Lamentations biblical location",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "prophets",
          "place_names": [
            "예루살렘 폐허",
            "Ruins of Jerusalem",
            "예루살렘 폐허",
            "Jerusalem Ruins",
            "エルサレムの廃虚",
            "Reruntuhan Yerusalem",
            "ซากกรุงเยรูซาเล็ม",
            "គំនរបាក់បែកយេរូសាឡឹម"
          ],
          "reference": "예레미야애가 1-5",
          "references": {
            "ko": "예레미야애가 1-5",
            "en": "Lamentations 1-5",
            "ja": "哀歌 1-5",
            "ms": "Ratapan 1-5",
            "th": "เพลงคร่ำครวญ 1-5",
            "km": "បរិទេវ 1-5"
          },
          "scene": {
            "ko": "예루살렘 폐허 위치에서 예레미야애가 1-5 본문 사건을 확인합니다.",
            "en": "Jerusalem Ruins: read and answer from Lamentations 1-5.",
            "ja": "エルサレムの廃虚の地点で、哀歌 1-5の本文出来事を確認します。",
            "ms": "Di lokasi Reruntuhan Yerusalem, semak peristiwa teks Ratapan 1-5.",
            "th": "ที่ตำแหน่งซากกรุงเยรูซาเล็ม ให้ตรวจสอบเหตุการณ์ในเพลงคร่ำครวญ 1-5",
            "km": "នៅទីតាំងគំនរបាក់បែកយេរូសាឡឹម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងបរិទេវ 1-5។"
          },
          "mission": {
            "ko": "예루살렘 폐허 여정에서 예레미야애가 5장 본문 문제를 풉니다.",
            "en": "Follow Ruins of Jerusalem and answer Lamentations 5 chapters question bank.",
            "ja": "エルサレムの廃虚の旅で、哀歌5章の問題バンクに答えます。",
            "ms": "Ikuti Reruntuhan Yerusalem dan jawab bank soalan Ratapan 5 bab.",
            "th": "ติดตามเส้นทางซากกรุงเยรูซาเล็มและตอบคลังคำถามจากเพลงคร่ำครวญ 5 บท",
            "km": "តាមដានដំណើរគំនរបាក់បែកយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីបរិទេវ 5 ជំពូក។"
          }
        },
        {
          "stage_id": "EZK-001",
          "title": {
            "ko": "그발 강가 · 바벨론",
            "en": "Chebar Canal · Babylon",
            "ja": "ケバル川 · バビロン",
            "ms": "Terusan Kebar · Babilon",
            "th": "คลองเคบาร์ · บาบิโลน",
            "km": "ប្រឡាយខេបារ · បាប៊ីឡូន"
          },
          "short_title": {
            "ko": "그발·바벨론",
            "en": "Chebar·Babylon",
            "ja": "ケバル·バビロン",
            "ms": "Kebar·Babilon",
            "th": "เคบาร์·บาบิโลน",
            "km": "ខេបារ·បាប៊ីឡូន"
          },
          "book_title": {
            "ko": "에스겔",
            "en": "Ezekiel",
            "ja": "エゼキエル書",
            "ms": "Yehezkiel",
            "th": "เอเสเคียล",
            "km": "អេសេគាល"
          },
          "map_query": "Chebar canal Babylon Ezekiel biblical location",
          "map_region": "babylon",
          "map_x": 62.5,
          "map_y": 66.2,
          "route_group": "prophets",
          "place_names": [
            "그발 강가 · 바벨론",
            "Chebar Canal · Babylon",
            "그발·바벨론",
            "Chebar·Babylon",
            "ケバル川 · バビロン",
            "Terusan Kebar · Babilon",
            "คลองเคบาร์ · บาบิโลน",
            "ប្រឡាយខេបារ · បាប៊ីឡូន"
          ],
          "reference": "에스겔 1-48",
          "references": {
            "ko": "에스겔 1-48",
            "en": "Ezekiel 1-48",
            "ja": "エゼキエル書 1-48",
            "ms": "Yehezkiel 1-48",
            "th": "เอเสเคียล 1-48",
            "km": "អេសេគាល 1-48"
          },
          "scene": {
            "ko": "그발·바벨론 위치에서 에스겔 1-48 본문 사건을 확인합니다.",
            "en": "Chebar·Babylon: read and answer from Ezekiel 1-48.",
            "ja": "ケバル·バビロンの地点で、エゼキエル書 1-48の本文出来事を確認します。",
            "ms": "Di lokasi Kebar·Babilon, semak peristiwa teks Yehezkiel 1-48.",
            "th": "ที่ตำแหน่งเคบาร์·บาบิโลน ให้ตรวจสอบเหตุการณ์ในเอเสเคียล 1-48",
            "km": "នៅទីតាំងខេបារ·បាប៊ីឡូន សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងអេសេគាល 1-48។"
          },
          "mission": {
            "ko": "그발 강가 · 바벨론 여정에서 에스겔 48장 본문 문제를 풉니다.",
            "en": "Follow Chebar Canal · Babylon and answer Ezekiel 48 chapters question bank.",
            "ja": "ケバル川 · バビロンの旅で、エゼキエル書48章の問題バンクに答えます。",
            "ms": "Ikuti Terusan Kebar · Babilon dan jawab bank soalan Yehezkiel 48 bab.",
            "th": "ติดตามเส้นทางคลองเคบาร์ · บาบิโลนและตอบคลังคำถามจากเอเสเคียล 48 บท",
            "km": "តាមដានដំណើរប្រឡាយខេបារ · បាប៊ីឡូន ហើយឆ្លើយធនាគារសំណួរពីអេសេគាល 48 ជំពូក។"
          }
        },
        {
          "stage_id": "DAN-001",
          "title": {
            "ko": "바벨론 · 수산",
            "en": "Babylon · Susa",
            "ja": "バビロン · スサ",
            "ms": "Babilon · Susan",
            "th": "บาบิโลน · สุสา",
            "km": "បាប៊ីឡូន · ស៊ូសា"
          },
          "short_title": {
            "ko": "바벨론·수산",
            "en": "Babylon·Susa",
            "ja": "バビロン·スサ",
            "ms": "Babilon·Susan",
            "th": "บาบิโลน·สุสา",
            "km": "បាប៊ីឡូន·ស៊ូសា"
          },
          "book_title": {
            "ko": "다니엘",
            "en": "Daniel",
            "ja": "ダニエル書",
            "ms": "Daniel",
            "th": "ดาเนียล",
            "km": "ដានីយ៉ែល"
          },
          "map_query": "Babylon Iraq Daniel biblical location",
          "map_region": "babylon",
          "map_x": 61.7,
          "map_y": 66.5,
          "route_group": "prophets",
          "place_names": [
            "바벨론 · 수산",
            "Babylon · Susa",
            "바벨론·수산",
            "Babylon·Susa",
            "バビロン · スサ",
            "Babilon · Susan",
            "บาบิโลน · สุสา",
            "បាប៊ីឡូន · ស៊ូសា"
          ],
          "reference": "다니엘 1-12",
          "references": {
            "ko": "다니엘 1-12",
            "en": "Daniel 1-12",
            "ja": "ダニエル書 1-12",
            "ms": "Daniel 1-12",
            "th": "ดาเนียล 1-12",
            "km": "ដានីយ៉ែល 1-12"
          },
          "scene": {
            "ko": "바벨론·수산 위치에서 다니엘 1-12 본문 사건을 확인합니다.",
            "en": "Babylon·Susa: read and answer from Daniel 1-12.",
            "ja": "バビロン·スサの地点で、ダニエル書 1-12の本文出来事を確認します。",
            "ms": "Di lokasi Babilon·Susan, semak peristiwa teks Daniel 1-12.",
            "th": "ที่ตำแหน่งบาบิโลน·สุสา ให้ตรวจสอบเหตุการณ์ในดาเนียล 1-12",
            "km": "នៅទីតាំងបាប៊ីឡូន·ស៊ូសា សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងដានីយ៉ែល 1-12។"
          },
          "mission": {
            "ko": "바벨론 · 수산 여정에서 다니엘 12장 본문 문제를 풉니다.",
            "en": "Follow Babylon · Susa and answer Daniel 12 chapters question bank.",
            "ja": "バビロン · スサの旅で、ダニエル書12章の問題バンクに答えます。",
            "ms": "Ikuti Babilon · Susan dan jawab bank soalan Daniel 12 bab.",
            "th": "ติดตามเส้นทางบาบิโลน · สุสาและตอบคลังคำถามจากดาเนียล 12 บท",
            "km": "តាមដានដំណើរបាប៊ីឡូន · ស៊ូសា ហើយឆ្លើយធនាគារសំណួរពីដានីយ៉ែល 12 ជំពូក។"
          }
        }
      ]
    },
    {
      "chapter_id": "OT-MINOR-C01",
      "book_id": "HOS",
      "section_key": "minorProphets",
      "world_id": "W_OT_MINOR",
      "order_index": 41,
      "title": {
        "ko": "사마리아·이스르엘 → 욥바·니느웨",
        "en": "Samaria·Jezreel → Joppa·Nineveh",
        "ja": "サマリア·イズレエル → ヨッパ·ニネベ",
        "ms": "Samaria·Yizreel → Yope·Niniwe",
        "th": "สะมาเรีย·ยิสเรเอล → ยัฟฟา·นีนะเวห์",
        "km": "សាម៉ារី·យីសរេអែល → យ៉ុបប៉ា·នីនីវេ"
      },
      "summary": {
        "ko": "사마리아·이스르엘 / 시온 / 드고아·벧엘 / 에돔 / 욥바·니느웨 길을 따라 구약 5. 소선지서 본문 사건을 풉니다.",
        "en": "Follow Samaria·Jezreel / Zion / Tekoa·Bethel / Edom / Joppa·Nineveh through Old Testament 5. Minor Prophets.",
        "ja": "サマリア·イズレエル / シオン / テコア·ベテル / エドム / ヨッパ·ニネベの道をたどり、旧約5. 小預言書の本文出来事を解きます。",
        "ms": "Ikuti laluan Samaria·Yizreel / Sion / Tekoa·Betel / Edom / Yope·Niniwe dan jawab peristiwa teks Perjanjian Lama 5. Nabi-nabi Kecil.",
        "th": "ติดตามเส้นทาง สะมาเรีย·ยิสเรเอล / ศิโยน / เทโคอา·เบธเอล / เอโดม / ยัฟฟา·นีนะเวห์ และตอบเหตุการณ์ในเนื้อหาพันธสัญญาเดิม 5. ผู้เผยพระวจนะเล็ก",
        "km": "តាមដានផ្លូវ សាម៉ារី·យីសរេអែល / ស៊ីយ៉ូន / តេកូអា·បេតអែល / អេដុម / យ៉ុបប៉ា·នីនីវេ ហើយឆ្លើយព្រឹត្តិការណ៍ក្នុងអត្ថបទសញ្ញាចាស់ ៥. ហោរាតូច។"
      },
      "stops": [
        {
          "stage_id": "HOS-001",
          "title": {
            "ko": "사마리아 · 이스르엘",
            "en": "Samaria · Jezreel",
            "ja": "サマリア · イズレエル",
            "ms": "Samaria · Yizreel",
            "th": "สะมาเรีย · ยิสเรเอล",
            "km": "សាម៉ារី · យីសរេអែល"
          },
          "short_title": {
            "ko": "사마리아·이스르엘",
            "en": "Samaria·Jezreel",
            "ja": "サマリア·イズレエル",
            "ms": "Samaria·Yizreel",
            "th": "สะมาเรีย·ยิสเรเอล",
            "km": "សាម៉ារី·យីសរេអែល"
          },
          "book_title": {
            "ko": "호세아",
            "en": "Hosea",
            "ja": "ホセア書",
            "ms": "Hosea",
            "th": "โฮเชยา",
            "km": "ហូសេ"
          },
          "map_query": "Samaria northern kingdom Hosea biblical location",
          "map_region": "samaria",
          "map_x": 36.5,
          "map_y": 67.3,
          "route_group": "prophets",
          "place_names": [
            "사마리아 · 이스르엘",
            "Samaria · Jezreel",
            "사마리아·이스르엘",
            "Samaria·Jezreel",
            "サマリア · イズレエル",
            "Samaria · Yizreel",
            "สะมาเรีย · ยิสเรเอล",
            "សាម៉ារី · យីសរេអែល"
          ],
          "reference": "호세아 1-14",
          "references": {
            "ko": "호세아 1-14",
            "en": "Hosea 1-14",
            "ja": "ホセア書 1-14",
            "ms": "Hosea 1-14",
            "th": "โฮเชยา 1-14",
            "km": "ហូសេ 1-14"
          },
          "scene": {
            "ko": "사마리아·이스르엘 위치에서 호세아 1-14 본문 사건을 확인합니다.",
            "en": "Samaria·Jezreel: read and answer from Hosea 1-14.",
            "ja": "サマリア·イズレエルの地点で、ホセア書 1-14の本文出来事を確認します。",
            "ms": "Di lokasi Samaria·Yizreel, semak peristiwa teks Hosea 1-14.",
            "th": "ที่ตำแหน่งสะมาเรีย·ยิสเรเอล ให้ตรวจสอบเหตุการณ์ในโฮเชยา 1-14",
            "km": "នៅទីតាំងសាម៉ារី·យីសរេអែល សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងហូសេ 1-14។"
          },
          "mission": {
            "ko": "사마리아 · 이스르엘 여정에서 호세아 14장 본문 문제를 풉니다.",
            "en": "Follow Samaria · Jezreel and answer Hosea 14 chapters question bank.",
            "ja": "サマリア · イズレエルの旅で、ホセア書14章の問題バンクに答えます。",
            "ms": "Ikuti Samaria · Yizreel dan jawab bank soalan Hosea 14 bab.",
            "th": "ติดตามเส้นทางสะมาเรีย · ยิสเรเอลและตอบคลังคำถามจากโฮเชยา 14 บท",
            "km": "តាមដានដំណើរសាម៉ារី · យីសរេអែល ហើយឆ្លើយធនាគារសំណួរពីហូសេ 14 ជំពូក។"
          }
        },
        {
          "stage_id": "JOL-001",
          "title": {
            "ko": "시온 · 예루살렘",
            "en": "Zion · Jerusalem",
            "ja": "シオン · エルサレム",
            "ms": "Sion · Yerusalem",
            "th": "ศิโยน · เยรูซาเล็ม",
            "km": "ស៊ីយ៉ូន · យេរូសាឡឹម"
          },
          "short_title": {
            "ko": "시온",
            "en": "Zion",
            "ja": "シオン",
            "ms": "Sion",
            "th": "ศิโยน",
            "km": "ស៊ីយ៉ូន"
          },
          "book_title": {
            "ko": "요엘",
            "en": "Joel",
            "ja": "ヨエル書",
            "ms": "Yoel",
            "th": "โยเอล",
            "km": "យ៉ូអែល"
          },
          "map_query": "Jerusalem Joel biblical prophet location",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "prophets",
          "place_names": [
            "시온 · 예루살렘",
            "Zion · Jerusalem",
            "시온",
            "Zion",
            "シオン · エルサレム",
            "Sion · Yerusalem",
            "ศิโยน · เยรูซาเล็ม",
            "ស៊ីយ៉ូន · យេរូសាឡឹម"
          ],
          "reference": "요엘 1-3",
          "references": {
            "ko": "요엘 1-3",
            "en": "Joel 1-3",
            "ja": "ヨエル書 1-3",
            "ms": "Yoel 1-3",
            "th": "โยเอล 1-3",
            "km": "យ៉ូអែល 1-3"
          },
          "scene": {
            "ko": "시온 위치에서 요엘 1-3 본문 사건을 확인합니다.",
            "en": "Zion: read and answer from Joel 1-3.",
            "ja": "シオンの地点で、ヨエル書 1-3の本文出来事を確認します。",
            "ms": "Di lokasi Sion, semak peristiwa teks Yoel 1-3.",
            "th": "ที่ตำแหน่งศิโยน ให้ตรวจสอบเหตุการณ์ในโยเอล 1-3",
            "km": "នៅទីតាំងស៊ីយ៉ូន សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងយ៉ូអែល 1-3។"
          },
          "mission": {
            "ko": "시온 · 예루살렘 여정에서 요엘 3장 본문 문제를 풉니다.",
            "en": "Follow Zion · Jerusalem and answer Joel 3 chapters question bank.",
            "ja": "シオン · エルサレムの旅で、ヨエル書3章の問題バンクに答えます。",
            "ms": "Ikuti Sion · Yerusalem dan jawab bank soalan Yoel 3 bab.",
            "th": "ติดตามเส้นทางศิโยน · เยรูซาเล็มและตอบคลังคำถามจากโยเอล 3 บท",
            "km": "តាមដានដំណើរស៊ីយ៉ូន · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីយ៉ូអែល 3 ជំពូក។"
          }
        },
        {
          "stage_id": "AMO-001",
          "title": {
            "ko": "드고아 · 벧엘",
            "en": "Tekoa · Bethel",
            "ja": "テコア · ベテル",
            "ms": "Tekoa · Betel",
            "th": "เทโคอา · เบธเอล",
            "km": "តេកូអា · បេតអែល"
          },
          "short_title": {
            "ko": "드고아·벧엘",
            "en": "Tekoa·Bethel",
            "ja": "テコア·ベテル",
            "ms": "Tekoa·Betel",
            "th": "เทโคอา·เบธเอล",
            "km": "តេកូអា·បេតអែល"
          },
          "book_title": {
            "ko": "아모스",
            "en": "Amos",
            "ja": "アモス書",
            "ms": "Amos",
            "th": "อาโมส",
            "km": "អាម៉ុស"
          },
          "map_query": "Tekoa Israel Amos biblical location",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "prophets",
          "place_names": [
            "드고아 · 벧엘",
            "Tekoa · Bethel",
            "드고아·벧엘",
            "Tekoa·Bethel",
            "テコア · ベテル",
            "Tekoa · Betel",
            "เทโคอา · เบธเอล",
            "តេកូអា · បេតអែល"
          ],
          "reference": "아모스 1-9",
          "references": {
            "ko": "아모스 1-9",
            "en": "Amos 1-9",
            "ja": "アモス書 1-9",
            "ms": "Amos 1-9",
            "th": "อาโมส 1-9",
            "km": "អាម៉ុស 1-9"
          },
          "scene": {
            "ko": "드고아·벧엘 위치에서 아모스 1-9 본문 사건을 확인합니다.",
            "en": "Tekoa·Bethel: read and answer from Amos 1-9.",
            "ja": "テコア·ベテルの地点で、アモス書 1-9の本文出来事を確認します。",
            "ms": "Di lokasi Tekoa·Betel, semak peristiwa teks Amos 1-9.",
            "th": "ที่ตำแหน่งเทโคอา·เบธเอล ให้ตรวจสอบเหตุการณ์ในอาโมส 1-9",
            "km": "នៅទីតាំងតេកូអា·បេតអែល សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងអាម៉ុស 1-9។"
          },
          "mission": {
            "ko": "드고아 · 벧엘 여정에서 아모스 9장 본문 문제를 풉니다.",
            "en": "Follow Tekoa · Bethel and answer Amos 9 chapters question bank.",
            "ja": "テコア · ベテルの旅で、アモス書9章の問題バンクに答えます。",
            "ms": "Ikuti Tekoa · Betel dan jawab bank soalan Amos 9 bab.",
            "th": "ติดตามเส้นทางเทโคอา · เบธเอลและตอบคลังคำถามจากอาโมส 9 บท",
            "km": "តាមដានដំណើរតេកូអា · បេតអែល ហើយឆ្លើយធនាគារសំណួរពីអាម៉ុស 9 ជំពូក។"
          }
        },
        {
          "stage_id": "OBA-001",
          "title": {
            "ko": "에돔 산지",
            "en": "Mountains of Edom",
            "ja": "エドム山地",
            "ms": "Pergunungan Edom",
            "th": "ภูเขาเอโดม",
            "km": "តំបន់ភ្នំអេដុម"
          },
          "short_title": {
            "ko": "에돔",
            "en": "Edom",
            "ja": "エドム",
            "ms": "Edom",
            "th": "เอโดม",
            "km": "អេដុម"
          },
          "book_title": {
            "ko": "오바댜",
            "en": "Obadiah",
            "ja": "オバデヤ書",
            "ms": "Obaja",
            "th": "โอบาดีห์",
            "km": "អូបាឌា"
          },
          "map_query": "Edom biblical location Obadiah",
          "map_region": "edom",
          "map_x": 36.5,
          "map_y": 79.5,
          "route_group": "prophets",
          "place_names": [
            "에돔 산지",
            "Mountains of Edom",
            "에돔",
            "Edom",
            "エドム山地",
            "Pergunungan Edom",
            "ภูเขาเอโดม",
            "តំបន់ភ្នំអេដុម"
          ],
          "reference": "오바댜 1",
          "references": {
            "ko": "오바댜 1",
            "en": "Obadiah 1",
            "ja": "オバデヤ書 1",
            "ms": "Obaja 1",
            "th": "โอบาดีห์ 1",
            "km": "អូបាឌា 1"
          },
          "scene": {
            "ko": "에돔 위치에서 오바댜 1 본문 사건을 확인합니다.",
            "en": "Edom: read and answer from Obadiah 1.",
            "ja": "エドムの地点で、オバデヤ書 1の本文出来事を確認します。",
            "ms": "Di lokasi Edom, semak peristiwa teks Obaja 1.",
            "th": "ที่ตำแหน่งเอโดม ให้ตรวจสอบเหตุการณ์ในโอบาดีห์ 1",
            "km": "នៅទីតាំងអេដុម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងអូបាឌា 1។"
          },
          "mission": {
            "ko": "에돔 산지 여정에서 오바댜 1장 본문 문제를 풉니다.",
            "en": "Follow Mountains of Edom and answer Obadiah 1 chapters question bank.",
            "ja": "エドム山地の旅で、オバデヤ書1章の問題バンクに答えます。",
            "ms": "Ikuti Pergunungan Edom dan jawab bank soalan Obaja 1 bab.",
            "th": "ติดตามเส้นทางภูเขาเอโดมและตอบคลังคำถามจากโอบาดีห์ 1 บท",
            "km": "តាមដានដំណើរតំបន់ភ្នំអេដុម ហើយឆ្លើយធនាគារសំណួរពីអូបាឌា 1 ជំពូក។"
          }
        },
        {
          "stage_id": "JON-001",
          "title": {
            "ko": "욥바 · 니느웨",
            "en": "Joppa · Nineveh",
            "ja": "ヨッパ · ニネベ",
            "ms": "Yope · Niniwe",
            "th": "ยัฟฟา · นีนะเวห์",
            "km": "យ៉ុបប៉ា · នីនីវេ"
          },
          "short_title": {
            "ko": "욥바·니느웨",
            "en": "Joppa·Nineveh",
            "ja": "ヨッパ·ニネベ",
            "ms": "Yope·Niniwe",
            "th": "ยัฟฟา·นีนะเวห์",
            "km": "យ៉ុបប៉ា·នីនីវេ"
          },
          "book_title": {
            "ko": "요나",
            "en": "Jonah",
            "ja": "ヨナ書",
            "ms": "Yunus",
            "th": "โยนาห์",
            "km": "យ៉ូណា"
          },
          "map_query": "Nineveh Iraq Jonah biblical location",
          "map_region": "nineveh",
          "map_x": 60.5,
          "map_y": 39.4,
          "route_group": "prophets",
          "place_names": [
            "욥바 · 니느웨",
            "Joppa · Nineveh",
            "욥바·니느웨",
            "Joppa·Nineveh",
            "ヨッパ · ニネベ",
            "Yope · Niniwe",
            "ยัฟฟา · นีนะเวห์",
            "យ៉ុបប៉ា · នីនីវេ"
          ],
          "reference": "요나 1-4",
          "references": {
            "ko": "요나 1-4",
            "en": "Jonah 1-4",
            "ja": "ヨナ書 1-4",
            "ms": "Yunus 1-4",
            "th": "โยนาห์ 1-4",
            "km": "យ៉ូណា 1-4"
          },
          "scene": {
            "ko": "욥바·니느웨 위치에서 요나 1-4 본문 사건을 확인합니다.",
            "en": "Joppa·Nineveh: read and answer from Jonah 1-4.",
            "ja": "ヨッパ·ニネベの地点で、ヨナ書 1-4の本文出来事を確認します。",
            "ms": "Di lokasi Yope·Niniwe, semak peristiwa teks Yunus 1-4.",
            "th": "ที่ตำแหน่งยัฟฟา·นีนะเวห์ ให้ตรวจสอบเหตุการณ์ในโยนาห์ 1-4",
            "km": "នៅទីតាំងយ៉ុបប៉ា·នីនីវេ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងយ៉ូណា 1-4។"
          },
          "mission": {
            "ko": "욥바 · 니느웨 여정에서 요나 4장 본문 문제를 풉니다.",
            "en": "Follow Joppa · Nineveh and answer Jonah 4 chapters question bank.",
            "ja": "ヨッパ · ニネベの旅で、ヨナ書4章の問題バンクに答えます。",
            "ms": "Ikuti Yope · Niniwe dan jawab bank soalan Yunus 4 bab.",
            "th": "ติดตามเส้นทางยัฟฟา · นีนะเวห์และตอบคลังคำถามจากโยนาห์ 4 บท",
            "km": "តាមដានដំណើរយ៉ុបប៉ា · នីនីវេ ហើយឆ្លើយធនាគារសំណួរពីយ៉ូណា 4 ជំពូក។"
          }
        }
      ]
    },
    {
      "chapter_id": "OT-MINOR-C02",
      "book_id": "MIC",
      "section_key": "minorProphets",
      "world_id": "W_OT_MINOR",
      "order_index": 42,
      "title": {
        "ko": "모레셋 → 성전터",
        "en": "Moresheth → Temple Site",
        "ja": "モレシェト → 神殿跡",
        "ms": "Moresyet → Tapak Bait Suci",
        "th": "โมเรเชท → สถานที่พระวิหาร",
        "km": "មូរេសែត → ទីតាំងព្រះវិហារ"
      },
      "summary": {
        "ko": "모레셋 / 니느웨 / 파수대 / 예루살렘 / 성전터 길을 따라 구약 5. 소선지서 본문 사건을 풉니다.",
        "en": "Follow Moresheth / Nineveh / Watchpost / Jerusalem / Temple Site through Old Testament 5. Minor Prophets.",
        "ja": "モレシェト / ニネベ / 見張り場 / エルサレム / 神殿跡の道をたどり、旧約5. 小預言書の本文出来事を解きます。",
        "ms": "Ikuti laluan Moresyet / Niniwe / Tempat berjaga / Yerusalem / Tapak Bait Suci dan jawab peristiwa teks Perjanjian Lama 5. Nabi-nabi Kecil.",
        "th": "ติดตามเส้นทาง โมเรเชท / นีนะเวห์ / ป้อมยาม / เยรูซาเล็ม / สถานที่พระวิหาร และตอบเหตุการณ์ในเนื้อหาพันธสัญญาเดิม 5. ผู้เผยพระวจนะเล็ก",
        "km": "តាមដានផ្លូវ មូរេសែត / នីនីវេ / កន្លែងយាម / យេរូសាឡឹម / ទីតាំងព្រះវិហារ ហើយឆ្លើយព្រឹត្តិការណ៍ក្នុងអត្ថបទសញ្ញាចាស់ ៥. ហោរាតូច។"
      },
      "stops": [
        {
          "stage_id": "MIC-001",
          "title": {
            "ko": "모레셋 · 예루살렘",
            "en": "Moresheth · Jerusalem",
            "ja": "モレシェト · エルサレム",
            "ms": "Moresyet · Yerusalem",
            "th": "โมเรเชท · เยรูซาเล็ม",
            "km": "មូរេសែត · យេរូសាឡឹម"
          },
          "short_title": {
            "ko": "모레셋",
            "en": "Moresheth",
            "ja": "モレシェト",
            "ms": "Moresyet",
            "th": "โมเรเชท",
            "km": "មូរេសែត"
          },
          "book_title": {
            "ko": "미가",
            "en": "Micah",
            "ja": "ミカ書",
            "ms": "Mikha",
            "th": "มีคาห์",
            "km": "មីកា"
          },
          "map_query": "Moresheth Gath Micah biblical location",
          "map_region": "canaan",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "prophets",
          "place_names": [
            "모레셋 · 예루살렘",
            "Moresheth · Jerusalem",
            "모레셋",
            "Moresheth",
            "モレシェト · エルサレム",
            "Moresyet · Yerusalem",
            "โมเรเชท · เยรูซาเล็ม",
            "មូរេសែត · យេរូសាឡឹម"
          ],
          "reference": "미가 1-7",
          "references": {
            "ko": "미가 1-7",
            "en": "Micah 1-7",
            "ja": "ミカ書 1-7",
            "ms": "Mikha 1-7",
            "th": "มีคาห์ 1-7",
            "km": "មីកា 1-7"
          },
          "scene": {
            "ko": "모레셋 위치에서 미가 1-7 본문 사건을 확인합니다.",
            "en": "Moresheth: read and answer from Micah 1-7.",
            "ja": "モレシェトの地点で、ミカ書 1-7の本文出来事を確認します。",
            "ms": "Di lokasi Moresyet, semak peristiwa teks Mikha 1-7.",
            "th": "ที่ตำแหน่งโมเรเชท ให้ตรวจสอบเหตุการณ์ในมีคาห์ 1-7",
            "km": "នៅទីតាំងមូរេសែត សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងមីកា 1-7។"
          },
          "mission": {
            "ko": "모레셋 · 예루살렘 여정에서 미가 7장 본문 문제를 풉니다.",
            "en": "Follow Moresheth · Jerusalem and answer Micah 7 chapters question bank.",
            "ja": "モレシェト · エルサレムの旅で、ミカ書7章の問題バンクに答えます。",
            "ms": "Ikuti Moresyet · Yerusalem dan jawab bank soalan Mikha 7 bab.",
            "th": "ติดตามเส้นทางโมเรเชท · เยรูซาเล็มและตอบคลังคำถามจากมีคาห์ 7 บท",
            "km": "តាមដានដំណើរមូរេសែត · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីមីកា 7 ជំពូក។"
          }
        },
        {
          "stage_id": "NAM-001",
          "title": {
            "ko": "니느웨",
            "en": "Nineveh",
            "ja": "ニネベ",
            "ms": "Niniwe",
            "th": "นีนะเวห์",
            "km": "នីនីវេ"
          },
          "short_title": {
            "ko": "니느웨",
            "en": "Nineveh",
            "ja": "ニネベ",
            "ms": "Niniwe",
            "th": "นีนะเวห์",
            "km": "នីនីវេ"
          },
          "book_title": {
            "ko": "나훔",
            "en": "Nahum",
            "ja": "ナホム書",
            "ms": "Nahum",
            "th": "นาฮูม",
            "km": "ណាហ៊ុម"
          },
          "map_query": "Nineveh Iraq Nahum biblical location",
          "map_region": "nineveh",
          "map_x": 60.5,
          "map_y": 39.4,
          "route_group": "prophets",
          "place_names": [
            "니느웨",
            "Nineveh",
            "니느웨",
            "Nineveh",
            "ニネベ",
            "Niniwe",
            "นีนะเวห์",
            "នីនីវេ"
          ],
          "reference": "나훔 1-3",
          "references": {
            "ko": "나훔 1-3",
            "en": "Nahum 1-3",
            "ja": "ナホム書 1-3",
            "ms": "Nahum 1-3",
            "th": "นาฮูม 1-3",
            "km": "ណាហ៊ុម 1-3"
          },
          "scene": {
            "ko": "니느웨 위치에서 나훔 1-3 본문 사건을 확인합니다.",
            "en": "Nineveh: read and answer from Nahum 1-3.",
            "ja": "ニネベの地点で、ナホム書 1-3の本文出来事を確認します。",
            "ms": "Di lokasi Niniwe, semak peristiwa teks Nahum 1-3.",
            "th": "ที่ตำแหน่งนีนะเวห์ ให้ตรวจสอบเหตุการณ์ในนาฮูม 1-3",
            "km": "នៅទីតាំងនីនីវេ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងណាហ៊ុម 1-3។"
          },
          "mission": {
            "ko": "니느웨 여정에서 나훔 3장 본문 문제를 풉니다.",
            "en": "Follow Nineveh and answer Nahum 3 chapters question bank.",
            "ja": "ニネベの旅で、ナホム書3章の問題バンクに答えます。",
            "ms": "Ikuti Niniwe dan jawab bank soalan Nahum 3 bab.",
            "th": "ติดตามเส้นทางนีนะเวห์และตอบคลังคำถามจากนาฮูม 3 บท",
            "km": "តាមដានដំណើរនីនីវេ ហើយឆ្លើយធនាគារសំណួរពីណាហ៊ុម 3 ជំពូក។"
          }
        },
        {
          "stage_id": "HAB-001",
          "title": {
            "ko": "예루살렘 파수대",
            "en": "Jerusalem Watchpost",
            "ja": "エルサレムの見張り場",
            "ms": "Tempat berjaga Yerusalem",
            "th": "ป้อมยามเยรูซาเล็ม",
            "km": "កន្លែងយាមនៅយេរូសាឡឹម"
          },
          "short_title": {
            "ko": "파수대",
            "en": "Watchpost",
            "ja": "見張り場",
            "ms": "Tempat berjaga",
            "th": "ป้อมยาม",
            "km": "កន្លែងយាម"
          },
          "book_title": {
            "ko": "하박국",
            "en": "Habakkuk",
            "ja": "ハバクク書",
            "ms": "Habakuk",
            "th": "ฮาบากุก",
            "km": "ហាបាគុក"
          },
          "map_query": "Judah Jerusalem Habakkuk biblical location",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "prophets",
          "place_names": [
            "예루살렘 파수대",
            "Jerusalem Watchpost",
            "파수대",
            "Watchpost",
            "エルサレムの見張り場",
            "Tempat berjaga Yerusalem",
            "ป้อมยามเยรูซาเล็ม",
            "កន្លែងយាមនៅយេរូសាឡឹម"
          ],
          "reference": "하박국 1-3",
          "references": {
            "ko": "하박국 1-3",
            "en": "Habakkuk 1-3",
            "ja": "ハバクク書 1-3",
            "ms": "Habakuk 1-3",
            "th": "ฮาบากุก 1-3",
            "km": "ហាបាគុក 1-3"
          },
          "scene": {
            "ko": "파수대 위치에서 하박국 1-3 본문 사건을 확인합니다.",
            "en": "Watchpost: read and answer from Habakkuk 1-3.",
            "ja": "見張り場の地点で、ハバクク書 1-3の本文出来事を確認します。",
            "ms": "Di lokasi Tempat berjaga, semak peristiwa teks Habakuk 1-3.",
            "th": "ที่ตำแหน่งป้อมยาม ให้ตรวจสอบเหตุการณ์ในฮาบากุก 1-3",
            "km": "នៅទីតាំងកន្លែងយាម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងហាបាគុក 1-3។"
          },
          "mission": {
            "ko": "예루살렘 파수대 여정에서 하박국 3장 본문 문제를 풉니다.",
            "en": "Follow Jerusalem Watchpost and answer Habakkuk 3 chapters question bank.",
            "ja": "エルサレムの見張り場の旅で、ハバクク書3章の問題バンクに答えます。",
            "ms": "Ikuti Tempat berjaga Yerusalem dan jawab bank soalan Habakuk 3 bab.",
            "th": "ติดตามเส้นทางป้อมยามเยรูซาเล็มและตอบคลังคำถามจากฮาบากุก 3 บท",
            "km": "តាមដានដំណើរកន្លែងយាមនៅយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីហាបាគុក 3 ជំពូក។"
          }
        },
        {
          "stage_id": "ZEP-001",
          "title": {
            "ko": "예루살렘",
            "en": "Jerusalem",
            "ja": "エルサレム",
            "ms": "Yerusalem",
            "th": "เยรูซาเล็ม",
            "km": "យេរូសាឡឹម"
          },
          "short_title": {
            "ko": "예루살렘",
            "en": "Jerusalem",
            "ja": "エルサレム",
            "ms": "Yerusalem",
            "th": "เยรูซาเล็ม",
            "km": "យេរូសាឡឹម"
          },
          "book_title": {
            "ko": "스바냐",
            "en": "Zephaniah",
            "ja": "ゼパニヤ書",
            "ms": "Zefanya",
            "th": "เศฟันยาห์",
            "km": "សេផានា"
          },
          "map_query": "Jerusalem Zephaniah biblical prophet location",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "prophets",
          "place_names": [
            "예루살렘",
            "Jerusalem",
            "예루살렘",
            "Jerusalem",
            "エルサレム",
            "Yerusalem",
            "เยรูซาเล็ม",
            "យេរូសាឡឹម"
          ],
          "reference": "스바냐 1-3",
          "references": {
            "ko": "스바냐 1-3",
            "en": "Zephaniah 1-3",
            "ja": "ゼパニヤ書 1-3",
            "ms": "Zefanya 1-3",
            "th": "เศฟันยาห์ 1-3",
            "km": "សេផានា 1-3"
          },
          "scene": {
            "ko": "예루살렘 위치에서 스바냐 1-3 본문 사건을 확인합니다.",
            "en": "Jerusalem: read and answer from Zephaniah 1-3.",
            "ja": "エルサレムの地点で、ゼパニヤ書 1-3の本文出来事を確認します。",
            "ms": "Di lokasi Yerusalem, semak peristiwa teks Zefanya 1-3.",
            "th": "ที่ตำแหน่งเยรูซาเล็ม ให้ตรวจสอบเหตุการณ์ในเศฟันยาห์ 1-3",
            "km": "នៅទីតាំងយេរូសាឡឹម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងសេផានា 1-3។"
          },
          "mission": {
            "ko": "예루살렘 여정에서 스바냐 3장 본문 문제를 풉니다.",
            "en": "Follow Jerusalem and answer Zephaniah 3 chapters question bank.",
            "ja": "エルサレムの旅で、ゼパニヤ書3章の問題バンクに答えます。",
            "ms": "Ikuti Yerusalem dan jawab bank soalan Zefanya 3 bab.",
            "th": "ติดตามเส้นทางเยรูซาเล็มและตอบคลังคำถามจากเศฟันยาห์ 3 บท",
            "km": "តាមដានដំណើរយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីសេផានា 3 ជំពូក។"
          }
        },
        {
          "stage_id": "HAG-001",
          "title": {
            "ko": "예루살렘 성전터",
            "en": "Jerusalem Temple Site",
            "ja": "エルサレム神殿跡",
            "ms": "Tapak Bait Suci Yerusalem",
            "th": "สถานที่พระวิหารเยรูซาเล็ม",
            "km": "ទីតាំងព្រះវិហារយេរូសាឡឹម"
          },
          "short_title": {
            "ko": "성전터",
            "en": "Temple Site",
            "ja": "神殿跡",
            "ms": "Tapak Bait Suci",
            "th": "สถานที่พระวิหาร",
            "km": "ទីតាំងព្រះវិហារ"
          },
          "book_title": {
            "ko": "학개",
            "en": "Haggai",
            "ja": "ハガイ書",
            "ms": "Hagai",
            "th": "ฮักกัย",
            "km": "ហាកាយ"
          },
          "map_query": "Jerusalem Second Temple Haggai biblical location",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "prophets",
          "place_names": [
            "예루살렘 성전터",
            "Jerusalem Temple Site",
            "성전터",
            "Temple Site",
            "エルサレム神殿跡",
            "Tapak Bait Suci Yerusalem",
            "สถานที่พระวิหารเยรูซาเล็ม",
            "ទីតាំងព្រះវិហារយេរូសាឡឹម"
          ],
          "reference": "학개 1-2",
          "references": {
            "ko": "학개 1-2",
            "en": "Haggai 1-2",
            "ja": "ハガイ書 1-2",
            "ms": "Hagai 1-2",
            "th": "ฮักกัย 1-2",
            "km": "ហាកាយ 1-2"
          },
          "scene": {
            "ko": "성전터 위치에서 학개 1-2 본문 사건을 확인합니다.",
            "en": "Temple Site: read and answer from Haggai 1-2.",
            "ja": "神殿跡の地点で、ハガイ書 1-2の本文出来事を確認します。",
            "ms": "Di lokasi Tapak Bait Suci, semak peristiwa teks Hagai 1-2.",
            "th": "ที่ตำแหน่งสถานที่พระวิหาร ให้ตรวจสอบเหตุการณ์ในฮักกัย 1-2",
            "km": "នៅទីតាំងទីតាំងព្រះវិហារ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងហាកាយ 1-2។"
          },
          "mission": {
            "ko": "예루살렘 성전터 여정에서 학개 2장 본문 문제를 풉니다.",
            "en": "Follow Jerusalem Temple Site and answer Haggai 2 chapters question bank.",
            "ja": "エルサレム神殿跡の旅で、ハガイ書2章の問題バンクに答えます。",
            "ms": "Ikuti Tapak Bait Suci Yerusalem dan jawab bank soalan Hagai 2 bab.",
            "th": "ติดตามเส้นทางสถานที่พระวิหารเยรูซาเล็มและตอบคลังคำถามจากฮักกัย 2 บท",
            "km": "តាមដានដំណើរទីតាំងព្រះវិហារយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីហាកាយ 2 ជំពូក។"
          }
        }
      ]
    },
    {
      "chapter_id": "OT-MINOR-C03",
      "book_id": "ZEC",
      "section_key": "minorProphets",
      "world_id": "W_OT_MINOR",
      "order_index": 43,
      "title": {
        "ko": "성전터 → 드고아·벧엘+",
        "en": "Temple Site → Tekoa·Bethel+",
        "ja": "神殿跡 → テコア·ベテル+",
        "ms": "Tapak Bait Suci → Tekoa·Betel+",
        "th": "สถานที่พระวิหาร → เทโคอา·เบธเอล+",
        "km": "ទីតាំងព្រះវិហារ → តេកូអា·បេតអែល+"
      },
      "summary": {
        "ko": "성전터 / 성전 / 사마리아·이스르엘+ / 시온+ / 드고아·벧엘+ 길을 따라 구약 5. 소선지서 본문 사건을 풉니다.",
        "en": "Follow Temple Site / Temple / Samaria·Jezreel+ / Zion+ / Tekoa·Bethel+ through Old Testament 5. Minor Prophets.",
        "ja": "神殿跡 / 神殿 / サマリア·イズレエル+ / シオン+ / テコア·ベテル+の道をたどり、旧約5. 小預言書の本文出来事を解きます。",
        "ms": "Ikuti laluan Tapak Bait Suci / Bait Suci / Samaria·Yizreel+ / Sion+ / Tekoa·Betel+ dan jawab peristiwa teks Perjanjian Lama 5. Nabi-nabi Kecil.",
        "th": "ติดตามเส้นทาง สถานที่พระวิหาร / พระวิหาร / สะมาเรีย·ยิสเรเอล+ / ศิโยน+ / เทโคอา·เบธเอล+ และตอบเหตุการณ์ในเนื้อหาพันธสัญญาเดิม 5. ผู้เผยพระวจนะเล็ก",
        "km": "តាមដានផ្លូវ ទីតាំងព្រះវិហារ / ព្រះវិហារ / សាម៉ារី·យីសរេអែល+ / ស៊ីយ៉ូន+ / តេកូអា·បេតអែល+ ហើយឆ្លើយព្រឹត្តិការណ៍ក្នុងអត្ថបទសញ្ញាចាស់ ៥. ហោរាតូច។"
      },
      "stops": [
        {
          "stage_id": "ZEC-001",
          "title": {
            "ko": "예루살렘 성전터",
            "en": "Jerusalem Temple Site",
            "ja": "エルサレム神殿跡",
            "ms": "Tapak Bait Suci Yerusalem",
            "th": "สถานที่พระวิหารเยรูซาเล็ม",
            "km": "ទីតាំងព្រះវិហារយេរូសាឡឹម"
          },
          "short_title": {
            "ko": "성전터",
            "en": "Temple Site",
            "ja": "神殿跡",
            "ms": "Tapak Bait Suci",
            "th": "สถานที่พระวิหาร",
            "km": "ទីតាំងព្រះវិហារ"
          },
          "book_title": {
            "ko": "스가랴",
            "en": "Zechariah",
            "ja": "ゼカリヤ書",
            "ms": "Zakharia",
            "th": "เศคาริยาห์",
            "km": "សាការី"
          },
          "map_query": "Jerusalem Zechariah biblical prophet location",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "prophets",
          "place_names": [
            "예루살렘 성전터",
            "Jerusalem Temple Site",
            "성전터",
            "Temple Site",
            "エルサレム神殿跡",
            "Tapak Bait Suci Yerusalem",
            "สถานที่พระวิหารเยรูซาเล็ม",
            "ទីតាំងព្រះវិហារយេរូសាឡឹម"
          ],
          "reference": "스가랴 1-14",
          "references": {
            "ko": "스가랴 1-14",
            "en": "Zechariah 1-14",
            "ja": "ゼカリヤ書 1-14",
            "ms": "Zakharia 1-14",
            "th": "เศคาริยาห์ 1-14",
            "km": "សាការី 1-14"
          },
          "scene": {
            "ko": "성전터 위치에서 스가랴 1-14 본문 사건을 확인합니다.",
            "en": "Temple Site: read and answer from Zechariah 1-14.",
            "ja": "神殿跡の地点で、ゼカリヤ書 1-14の本文出来事を確認します。",
            "ms": "Di lokasi Tapak Bait Suci, semak peristiwa teks Zakharia 1-14.",
            "th": "ที่ตำแหน่งสถานที่พระวิหาร ให้ตรวจสอบเหตุการณ์ในเศคาริยาห์ 1-14",
            "km": "នៅទីតាំងទីតាំងព្រះវិហារ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងសាការី 1-14។"
          },
          "mission": {
            "ko": "예루살렘 성전터 여정에서 스가랴 14장 본문 문제를 풉니다.",
            "en": "Follow Jerusalem Temple Site and answer Zechariah 14 chapters question bank.",
            "ja": "エルサレム神殿跡の旅で、ゼカリヤ書14章の問題バンクに答えます。",
            "ms": "Ikuti Tapak Bait Suci Yerusalem dan jawab bank soalan Zakharia 14 bab.",
            "th": "ติดตามเส้นทางสถานที่พระวิหารเยรูซาเล็มและตอบคลังคำถามจากเศคาริยาห์ 14 บท",
            "km": "តាមដានដំណើរទីតាំងព្រះវិហារយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីសាការី 14 ជំពូក។"
          }
        },
        {
          "stage_id": "MAL-001",
          "title": {
            "ko": "예루살렘 성전",
            "en": "Jerusalem Temple",
            "ja": "エルサレム神殿",
            "ms": "Bait Suci Yerusalem",
            "th": "พระวิหารเยรูซาเล็ม",
            "km": "ព្រះវិហារយេរូសាឡឹម"
          },
          "short_title": {
            "ko": "성전",
            "en": "Temple",
            "ja": "神殿",
            "ms": "Bait Suci",
            "th": "พระวิหาร",
            "km": "ព្រះវិហារ"
          },
          "book_title": {
            "ko": "말라기",
            "en": "Malachi",
            "ja": "マラキ書",
            "ms": "Maleakhi",
            "th": "มาลาคี",
            "km": "ម៉ាឡាគី"
          },
          "map_query": "Jerusalem Second Temple Malachi biblical location",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "prophets",
          "place_names": [
            "예루살렘 성전",
            "Jerusalem Temple",
            "성전",
            "Temple",
            "エルサレム神殿",
            "Bait Suci Yerusalem",
            "พระวิหารเยรูซาเล็ม",
            "ព្រះវិហារយេរូសាឡឹម"
          ],
          "reference": "말라기 1-4",
          "references": {
            "ko": "말라기 1-4",
            "en": "Malachi 1-4",
            "ja": "マラキ書 1-4",
            "ms": "Maleakhi 1-4",
            "th": "มาลาคี 1-4",
            "km": "ម៉ាឡាគី 1-4"
          },
          "scene": {
            "ko": "성전 위치에서 말라기 1-4 본문 사건을 확인합니다.",
            "en": "Temple: read and answer from Malachi 1-4.",
            "ja": "神殿の地点で、マラキ書 1-4の本文出来事を確認します。",
            "ms": "Di lokasi Bait Suci, semak peristiwa teks Maleakhi 1-4.",
            "th": "ที่ตำแหน่งพระวิหาร ให้ตรวจสอบเหตุการณ์ในมาลาคี 1-4",
            "km": "នៅទីតាំងព្រះវិហារ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងម៉ាឡាគី 1-4។"
          },
          "mission": {
            "ko": "예루살렘 성전 여정에서 말라기 4장 본문 문제를 풉니다.",
            "en": "Follow Jerusalem Temple and answer Malachi 4 chapters question bank.",
            "ja": "エルサレム神殿の旅で、マラキ書4章の問題バンクに答えます。",
            "ms": "Ikuti Bait Suci Yerusalem dan jawab bank soalan Maleakhi 4 bab.",
            "th": "ติดตามเส้นทางพระวิหารเยรูซาเล็มและตอบคลังคำถามจากมาลาคี 4 บท",
            "km": "តាមដានដំណើរព្រះវិហារយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីម៉ាឡាគី 4 ជំពូក។"
          }
        },
        {
          "stage_id": "HOS-REVIEW-13",
          "title": {
            "ko": "사마리아 · 이스르엘 복습",
            "en": "Samaria · Jezreel Review",
            "ja": "サマリア · イズレエル 復習",
            "ms": "Samaria · Yizreel Ulang kaji",
            "th": "สะมาเรีย · ยิสเรเอล ทบทวน",
            "km": "សាម៉ារី · យីសរេអែល រំលឹក"
          },
          "short_title": {
            "ko": "사마리아·이스르엘+",
            "en": "Samaria·Jezreel+",
            "ja": "サマリア·イズレエル+",
            "ms": "Samaria·Yizreel+",
            "th": "สะมาเรีย·ยิสเรเอล+",
            "km": "សាម៉ារី·យីសរេអែល+"
          },
          "book_title": {
            "ko": "호세아",
            "en": "Hosea",
            "ja": "ホセア書",
            "ms": "Hosea",
            "th": "โฮเชยา",
            "km": "ហូសេ"
          },
          "map_query": "Samaria northern kingdom Hosea biblical location review",
          "map_region": "samaria",
          "map_x": 36.5,
          "map_y": 67.3,
          "route_group": "prophets",
          "place_names": [
            "사마리아 · 이스르엘",
            "Samaria · Jezreel",
            "사마리아·이스르엘",
            "Samaria·Jezreel",
            "サマリア · イズレエル",
            "Samaria · Yizreel",
            "สะมาเรีย · ยิสเรเอล",
            "សាម៉ារី · យីសរេអែល"
          ],
          "reference": "호세아 1-14",
          "references": {
            "ko": "호세아 1-14",
            "en": "Hosea 1-14",
            "ja": "ホセア書 1-14",
            "ms": "Hosea 1-14",
            "th": "โฮเชยา 1-14",
            "km": "ហូសេ 1-14"
          },
          "scene": {
            "ko": "사마리아·이스르엘+ 위치에서 호세아 1-14 본문 사건을 확인합니다.",
            "en": "Samaria·Jezreel+: read and answer from Hosea 1-14.",
            "ja": "サマリア·イズレエル+の地点で、ホセア書 1-14の本文出来事を確認します。",
            "ms": "Di lokasi Samaria·Yizreel+, semak peristiwa teks Hosea 1-14.",
            "th": "ที่ตำแหน่งสะมาเรีย·ยิสเรเอล+ ให้ตรวจสอบเหตุการณ์ในโฮเชยา 1-14",
            "km": "នៅទីតាំងសាម៉ារី·យីសរេអែល+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងហូសេ 1-14។"
          },
          "mission": {
            "ko": "사마리아 · 이스르엘 길에서 호세아 주요 사건을 다시 확인합니다.",
            "en": "Review the main Hosea events along Samaria · Jezreel.",
            "ja": "サマリア · イズレエルの道で、ホセア書の主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama Hosea di sepanjang Samaria · Yizreel.",
            "th": "ทบทวนเหตุการณ์สำคัญของโฮเชยาตามเส้นทางสะมาเรีย · ยิสเรเอล",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃហូសេ តាមផ្លូវសាម៉ារី · យីសរេអែល។"
          }
        },
        {
          "stage_id": "JOL-REVIEW-14",
          "title": {
            "ko": "시온 · 예루살렘 복습",
            "en": "Zion · Jerusalem Review",
            "ja": "シオン · エルサレム 復習",
            "ms": "Sion · Yerusalem Ulang kaji",
            "th": "ศิโยน · เยรูซาเล็ม ทบทวน",
            "km": "ស៊ីយ៉ូន · យេរូសាឡឹម រំលឹក"
          },
          "short_title": {
            "ko": "시온+",
            "en": "Zion+",
            "ja": "シオン+",
            "ms": "Sion+",
            "th": "ศิโยน+",
            "km": "ស៊ីយ៉ូន+"
          },
          "book_title": {
            "ko": "요엘",
            "en": "Joel",
            "ja": "ヨエル書",
            "ms": "Yoel",
            "th": "โยเอล",
            "km": "យ៉ូអែល"
          },
          "map_query": "Jerusalem Joel biblical prophet location review",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "prophets",
          "place_names": [
            "시온 · 예루살렘",
            "Zion · Jerusalem",
            "시온",
            "Zion",
            "シオン · エルサレム",
            "Sion · Yerusalem",
            "ศิโยน · เยรูซาเล็ม",
            "ស៊ីយ៉ូន · យេរូសាឡឹម"
          ],
          "reference": "요엘 1-3",
          "references": {
            "ko": "요엘 1-3",
            "en": "Joel 1-3",
            "ja": "ヨエル書 1-3",
            "ms": "Yoel 1-3",
            "th": "โยเอล 1-3",
            "km": "យ៉ូអែល 1-3"
          },
          "scene": {
            "ko": "시온+ 위치에서 요엘 1-3 본문 사건을 확인합니다.",
            "en": "Zion+: read and answer from Joel 1-3.",
            "ja": "シオン+の地点で、ヨエル書 1-3の本文出来事を確認します。",
            "ms": "Di lokasi Sion+, semak peristiwa teks Yoel 1-3.",
            "th": "ที่ตำแหน่งศิโยน+ ให้ตรวจสอบเหตุการณ์ในโยเอล 1-3",
            "km": "នៅទីតាំងស៊ីយ៉ូន+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងយ៉ូអែល 1-3។"
          },
          "mission": {
            "ko": "시온 · 예루살렘 길에서 요엘 주요 사건을 다시 확인합니다.",
            "en": "Review the main Joel events along Zion · Jerusalem.",
            "ja": "シオン · エルサレムの道で、ヨエル書の主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama Yoel di sepanjang Sion · Yerusalem.",
            "th": "ทบทวนเหตุการณ์สำคัญของโยเอลตามเส้นทางศิโยน · เยรูซาเล็ม",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃយ៉ូអែល តាមផ្លូវស៊ីយ៉ូន · យេរូសាឡឹម។"
          }
        },
        {
          "stage_id": "AMO-REVIEW-15",
          "title": {
            "ko": "드고아 · 벧엘 복습",
            "en": "Tekoa · Bethel Review",
            "ja": "テコア · ベテル 復習",
            "ms": "Tekoa · Betel Ulang kaji",
            "th": "เทโคอา · เบธเอล ทบทวน",
            "km": "តេកូអា · បេតអែល រំលឹក"
          },
          "short_title": {
            "ko": "드고아·벧엘+",
            "en": "Tekoa·Bethel+",
            "ja": "テコア·ベテル+",
            "ms": "Tekoa·Betel+",
            "th": "เทโคอา·เบธเอล+",
            "km": "តេកូអា·បេតអែល+"
          },
          "book_title": {
            "ko": "아모스",
            "en": "Amos",
            "ja": "アモス書",
            "ms": "Amos",
            "th": "อาโมส",
            "km": "អាម៉ុស"
          },
          "map_query": "Tekoa Israel Amos biblical location review",
          "map_region": "jerusalem",
          "map_x": 37.2,
          "map_y": 70.2,
          "route_group": "prophets",
          "place_names": [
            "드고아 · 벧엘",
            "Tekoa · Bethel",
            "드고아·벧엘",
            "Tekoa·Bethel",
            "テコア · ベテル",
            "Tekoa · Betel",
            "เทโคอา · เบธเอล",
            "តេកូអា · បេតអែល"
          ],
          "reference": "아모스 1-9",
          "references": {
            "ko": "아모스 1-9",
            "en": "Amos 1-9",
            "ja": "アモス書 1-9",
            "ms": "Amos 1-9",
            "th": "อาโมส 1-9",
            "km": "អាម៉ុស 1-9"
          },
          "scene": {
            "ko": "드고아·벧엘+ 위치에서 아모스 1-9 본문 사건을 확인합니다.",
            "en": "Tekoa·Bethel+: read and answer from Amos 1-9.",
            "ja": "テコア·ベテル+の地点で、アモス書 1-9の本文出来事を確認します。",
            "ms": "Di lokasi Tekoa·Betel+, semak peristiwa teks Amos 1-9.",
            "th": "ที่ตำแหน่งเทโคอา·เบธเอล+ ให้ตรวจสอบเหตุการณ์ในอาโมส 1-9",
            "km": "នៅទីតាំងតេកូអា·បេតអែល+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងអាម៉ុស 1-9។"
          },
          "mission": {
            "ko": "드고아 · 벧엘 길에서 아모스 주요 사건을 다시 확인합니다.",
            "en": "Review the main Amos events along Tekoa · Bethel.",
            "ja": "テコア · ベテルの道で、アモス書の主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama Amos di sepanjang Tekoa · Betel.",
            "th": "ทบทวนเหตุการณ์สำคัญของอาโมสตามเส้นทางเทโคอา · เบธเอล",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃអាម៉ុស តាមផ្លូវតេកូអា · បេតអែល។"
          }
        }
      ]
    },
    {
      "chapter_id": "NT-GOS-C01",
      "book_id": "MAT",
      "section_key": "gospels",
      "world_id": "W_NT_GOS",
      "order_index": 51,
      "title": {
        "ko": "베들레헴·갈릴리 → 베들레헴·갈릴리+",
        "en": "Bethlehem·Galilee → Bethlehem·Galilee+",
        "ja": "ベツレヘム·ガリラヤ → ベツレヘム·ガリラヤ+",
        "ms": "Betlehem·Galilea → Betlehem·Galilea+",
        "th": "เบธเลเฮม·กาลิลี → เบธเลเฮม·กาลิลี+",
        "km": "បេថ្លេហិម·កាលីឡេ → បេថ្លេហិម·កាលីឡេ+"
      },
      "summary": {
        "ko": "베들레헴·갈릴리 / 갈릴리·가버나움 / 나사렛·베들레헴 / 갈릴리·예루살렘 / 베들레헴·갈릴리+ 길을 따라 신약 1. 복음서 본문 사건을 풉니다.",
        "en": "Follow Bethlehem·Galilee / Galilee·Capernaum / Nazareth·Bethlehem / Galilee·Jerusalem / Bethlehem·Galilee+ through New Testament 1. Gospels.",
        "ja": "ベツレヘム·ガリラヤ / ガリラヤ·カペナウム / ナザレ·ベツレヘム / ガリラヤ·エルサレム / ベツレヘム·ガリラヤ+の道をたどり、新約1. 福音書の本文出来事を解きます。",
        "ms": "Ikuti laluan Betlehem·Galilea / Galilea·Kapernaum / Nazaret·Betlehem / Galilea·Yerusalem / Betlehem·Galilea+ dan jawab peristiwa teks Perjanjian Baru 1. Injil.",
        "th": "ติดตามเส้นทาง เบธเลเฮม·กาลิลี / กาลิลี·คาเปอรนาอุม / นาซาเร็ธ·เบธเลเฮม / กาลิลี·เยรูซาเล็ม / เบธเลเฮม·กาลิลี+ และตอบเหตุการณ์ในเนื้อหาพันธสัญญาใหม่ 1. พระกิตติคุณ",
        "km": "តាមដានផ្លូវ បេថ្លេហិម·កាលីឡេ / កាលីឡេ·កាពើណិម / ណាសារ៉ែត·បេថ្លេហិម / កាលីឡេ·យេរូសាឡឹម / បេថ្លេហិម·កាលីឡេ+ ហើយឆ្លើយព្រឹត្តិការណ៍ក្នុងអត្ថបទសញ្ញាថ្មី ១. ដំណឹងល្អ។"
      },
      "stops": [
        {
          "stage_id": "MAT-001",
          "title": {
            "ko": "베들레헴 · 갈릴리 · 예루살렘",
            "en": "Bethlehem · Galilee · Jerusalem",
            "ja": "ベツレヘム · ガリラヤ · エルサレム",
            "ms": "Betlehem · Galilea · Yerusalem",
            "th": "เบธเลเฮม · กาลิลี · เยรูซาเล็ม",
            "km": "បេថ្លេហិម · កាលីឡេ · យេរូសាឡឹម"
          },
          "short_title": {
            "ko": "베들레헴·갈릴리",
            "en": "Bethlehem·Galilee",
            "ja": "ベツレヘム·ガリラヤ",
            "ms": "Betlehem·Galilea",
            "th": "เบธเลเฮม·กาลิลี",
            "km": "បេថ្លេហិម·កាលីឡេ"
          },
          "book_title": {
            "ko": "마태복음",
            "en": "Matthew",
            "ja": "マタイの福音書",
            "ms": "Matius",
            "th": "มัทธิว",
            "km": "ម៉ាថាយ"
          },
          "map_query": "Bethlehem Galilee Jerusalem Jesus biblical route",
          "map_region": "bethlehem",
          "map_x": 47.4,
          "map_y": 70.5,
          "route_group": "new-testament",
          "place_names": [
            "베들레헴 · 갈릴리 · 예루살렘",
            "Bethlehem · Galilee · Jerusalem",
            "베들레헴·갈릴리",
            "Bethlehem·Galilee",
            "ベツレヘム · ガリラヤ · エルサレム",
            "Betlehem · Galilea · Yerusalem",
            "เบธเลเฮม · กาลิลี · เยรูซาเล็ม",
            "បេថ្លេហិម · កាលីឡេ · យេរូសាឡឹម"
          ],
          "reference": "마태복음 1-28",
          "references": {
            "ko": "마태복음 1-28",
            "en": "Matthew 1-28",
            "ja": "マタイの福音書 1-28",
            "ms": "Matius 1-28",
            "th": "มัทธิว 1-28",
            "km": "ម៉ាថាយ 1-28"
          },
          "scene": {
            "ko": "베들레헴·갈릴리 위치에서 마태복음 1-28 본문 사건을 확인합니다.",
            "en": "Bethlehem·Galilee: read and answer from Matthew 1-28.",
            "ja": "ベツレヘム·ガリラヤの地点で、マタイの福音書 1-28の本文出来事を確認します。",
            "ms": "Di lokasi Betlehem·Galilea, semak peristiwa teks Matius 1-28.",
            "th": "ที่ตำแหน่งเบธเลเฮม·กาลิลี ให้ตรวจสอบเหตุการณ์ในมัทธิว 1-28",
            "km": "នៅទីតាំងបេថ្លេហិម·កាលីឡេ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងម៉ាថាយ 1-28។"
          },
          "mission": {
            "ko": "베들레헴 · 갈릴리 · 예루살렘 여정에서 마태복음 28장 본문 문제를 풉니다.",
            "en": "Follow Bethlehem · Galilee · Jerusalem and answer Matthew 28 chapters question bank.",
            "ja": "ベツレヘム · ガリラヤ · エルサレムの旅で、マタイの福音書28章の問題バンクに答えます。",
            "ms": "Ikuti Betlehem · Galilea · Yerusalem dan jawab bank soalan Matius 28 bab.",
            "th": "ติดตามเส้นทางเบธเลเฮม · กาลิลี · เยรูซาเล็มและตอบคลังคำถามจากมัทธิว 28 บท",
            "km": "តាមដានដំណើរបេថ្លេហិម · កាលីឡេ · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីម៉ាថាយ 28 ជំពូក។"
          }
        },
        {
          "stage_id": "MRK-001",
          "title": {
            "ko": "갈릴리 · 가버나움",
            "en": "Galilee · Capernaum",
            "ja": "ガリラヤ · カペナウム",
            "ms": "Galilea · Kapernaum",
            "th": "กาลิลี · คาเปอรนาอุม",
            "km": "កាលីឡេ · កាពើណិម"
          },
          "short_title": {
            "ko": "갈릴리·가버나움",
            "en": "Galilee·Capernaum",
            "ja": "ガリラヤ·カペナウム",
            "ms": "Galilea·Kapernaum",
            "th": "กาลิลี·คาเปอรนาอุม",
            "km": "កាលីឡេ·កាពើណិម"
          },
          "book_title": {
            "ko": "마가복음",
            "en": "Mark",
            "ja": "マルコの福音書",
            "ms": "Markus",
            "th": "มาระโก",
            "km": "ម៉ាកុស"
          },
          "map_query": "Capernaum Galilee Mark Gospel biblical location",
          "map_region": "galilee",
          "map_x": 51.8,
          "map_y": 37,
          "route_group": "new-testament",
          "place_names": [
            "갈릴리 · 가버나움",
            "Galilee · Capernaum",
            "갈릴리·가버나움",
            "Galilee·Capernaum",
            "ガリラヤ · カペナウム",
            "Galilea · Kapernaum",
            "กาลิลี · คาเปอรนาอุม",
            "កាលីឡេ · កាពើណិម"
          ],
          "reference": "마가복음 1-16",
          "references": {
            "ko": "마가복음 1-16",
            "en": "Mark 1-16",
            "ja": "マルコの福音書 1-16",
            "ms": "Markus 1-16",
            "th": "มาระโก 1-16",
            "km": "ម៉ាកុស 1-16"
          },
          "scene": {
            "ko": "갈릴리·가버나움 위치에서 마가복음 1-16 본문 사건을 확인합니다.",
            "en": "Galilee·Capernaum: read and answer from Mark 1-16.",
            "ja": "ガリラヤ·カペナウムの地点で、マルコの福音書 1-16の本文出来事を確認します。",
            "ms": "Di lokasi Galilea·Kapernaum, semak peristiwa teks Markus 1-16.",
            "th": "ที่ตำแหน่งกาลิลี·คาเปอรนาอุม ให้ตรวจสอบเหตุการณ์ในมาระโก 1-16",
            "km": "នៅទីតាំងកាលីឡេ·កាពើណិម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងម៉ាកុស 1-16។"
          },
          "mission": {
            "ko": "갈릴리 · 가버나움 여정에서 마가복음 16장 본문 문제를 풉니다.",
            "en": "Follow Galilee · Capernaum and answer Mark 16 chapters question bank.",
            "ja": "ガリラヤ · カペナウムの旅で、マルコの福音書16章の問題バンクに答えます。",
            "ms": "Ikuti Galilea · Kapernaum dan jawab bank soalan Markus 16 bab.",
            "th": "ติดตามเส้นทางกาลิลี · คาเปอรนาอุมและตอบคลังคำถามจากมาระโก 16 บท",
            "km": "តាមដានដំណើរកាលីឡេ · កាពើណិម ហើយឆ្លើយធនាគារសំណួរពីម៉ាកុស 16 ជំពូក។"
          }
        },
        {
          "stage_id": "LUK-001",
          "title": {
            "ko": "나사렛 · 베들레헴 · 예루살렘",
            "en": "Nazareth · Bethlehem · Jerusalem",
            "ja": "ナザレ · ベツレヘム · エルサレム",
            "ms": "Nazaret · Betlehem · Yerusalem",
            "th": "นาซาเร็ธ · เบธเลเฮม · เยรูซาเล็ม",
            "km": "ណាសារ៉ែត · បេថ្លេហិម · យេរូសាឡឹម"
          },
          "short_title": {
            "ko": "나사렛·베들레헴",
            "en": "Nazareth·Bethlehem",
            "ja": "ナザレ·ベツレヘム",
            "ms": "Nazaret·Betlehem",
            "th": "นาซาเร็ธ·เบธเลเฮม",
            "km": "ណាសារ៉ែត·បេថ្លេហិម"
          },
          "book_title": {
            "ko": "누가복음",
            "en": "Luke",
            "ja": "ルカの福音書",
            "ms": "Lukas",
            "th": "ลูกา",
            "km": "លូកា"
          },
          "map_query": "Nazareth Bethlehem Jerusalem Luke biblical route",
          "map_region": "galilee",
          "map_x": 52.2,
          "map_y": 39.2,
          "route_group": "new-testament",
          "place_names": [
            "나사렛 · 베들레헴 · 예루살렘",
            "Nazareth · Bethlehem · Jerusalem",
            "나사렛·베들레헴",
            "Nazareth·Bethlehem",
            "ナザレ · ベツレヘム · エルサレム",
            "Nazaret · Betlehem · Yerusalem",
            "นาซาเร็ธ · เบธเลเฮม · เยรูซาเล็ม",
            "ណាសារ៉ែត · បេថ្លេហិម · យេរូសាឡឹម"
          ],
          "reference": "누가복음 1-24",
          "references": {
            "ko": "누가복음 1-24",
            "en": "Luke 1-24",
            "ja": "ルカの福音書 1-24",
            "ms": "Lukas 1-24",
            "th": "ลูกา 1-24",
            "km": "លូកា 1-24"
          },
          "scene": {
            "ko": "나사렛·베들레헴 위치에서 누가복음 1-24 본문 사건을 확인합니다.",
            "en": "Nazareth·Bethlehem: read and answer from Luke 1-24.",
            "ja": "ナザレ·ベツレヘムの地点で、ルカの福音書 1-24の本文出来事を確認します。",
            "ms": "Di lokasi Nazaret·Betlehem, semak peristiwa teks Lukas 1-24.",
            "th": "ที่ตำแหน่งนาซาเร็ธ·เบธเลเฮม ให้ตรวจสอบเหตุการณ์ในลูกา 1-24",
            "km": "នៅទីតាំងណាសារ៉ែត·បេថ្លេហិម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងលូកា 1-24។"
          },
          "mission": {
            "ko": "나사렛 · 베들레헴 · 예루살렘 여정에서 누가복음 24장 본문 문제를 풉니다.",
            "en": "Follow Nazareth · Bethlehem · Jerusalem and answer Luke 24 chapters question bank.",
            "ja": "ナザレ · ベツレヘム · エルサレムの旅で、ルカの福音書24章の問題バンクに答えます。",
            "ms": "Ikuti Nazaret · Betlehem · Yerusalem dan jawab bank soalan Lukas 24 bab.",
            "th": "ติดตามเส้นทางนาซาเร็ธ · เบธเลเฮม · เยรูซาเล็มและตอบคลังคำถามจากลูกา 24 บท",
            "km": "តាមដានដំណើរណាសារ៉ែត · បេថ្លេហិម · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីលូកា 24 ជំពូក។"
          }
        },
        {
          "stage_id": "JHN-001",
          "title": {
            "ko": "갈릴리 · 예루살렘",
            "en": "Galilee · Jerusalem",
            "ja": "ガリラヤ · エルサレム",
            "ms": "Galilea · Yerusalem",
            "th": "กาลิลี · เยรูซาเล็ม",
            "km": "កាលីឡេ · យេរូសាឡឹម"
          },
          "short_title": {
            "ko": "갈릴리·예루살렘",
            "en": "Galilee·Jerusalem",
            "ja": "ガリラヤ·エルサレム",
            "ms": "Galilea·Yerusalem",
            "th": "กาลิลี·เยรูซาเล็ม",
            "km": "កាលីឡេ·យេរូសាឡឹម"
          },
          "book_title": {
            "ko": "요한복음",
            "en": "John",
            "ja": "ヨハネの福音書",
            "ms": "Yohanes",
            "th": "ยอห์น",
            "km": "យ៉ូហាន"
          },
          "map_query": "Jerusalem and Galilee John Gospel biblical route",
          "map_region": "jerusalem",
          "map_x": 47.2,
          "map_y": 69.2,
          "route_group": "new-testament",
          "place_names": [
            "갈릴리 · 예루살렘",
            "Galilee · Jerusalem",
            "갈릴리·예루살렘",
            "Galilee·Jerusalem",
            "ガリラヤ · エルサレム",
            "Galilea · Yerusalem",
            "กาลิลี · เยรูซาเล็ม",
            "កាលីឡេ · យេរូសាឡឹម"
          ],
          "reference": "요한복음 1-21",
          "references": {
            "ko": "요한복음 1-21",
            "en": "John 1-21",
            "ja": "ヨハネの福音書 1-21",
            "ms": "Yohanes 1-21",
            "th": "ยอห์น 1-21",
            "km": "យ៉ូហាន 1-21"
          },
          "scene": {
            "ko": "갈릴리·예루살렘 위치에서 요한복음 1-21 본문 사건을 확인합니다.",
            "en": "Galilee·Jerusalem: read and answer from John 1-21.",
            "ja": "ガリラヤ·エルサレムの地点で、ヨハネの福音書 1-21の本文出来事を確認します。",
            "ms": "Di lokasi Galilea·Yerusalem, semak peristiwa teks Yohanes 1-21.",
            "th": "ที่ตำแหน่งกาลิลี·เยรูซาเล็ม ให้ตรวจสอบเหตุการณ์ในยอห์น 1-21",
            "km": "នៅទីតាំងកាលីឡេ·យេរូសាឡឹម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងយ៉ូហាន 1-21។"
          },
          "mission": {
            "ko": "갈릴리 · 예루살렘 여정에서 요한복음 21장 본문 문제를 풉니다.",
            "en": "Follow Galilee · Jerusalem and answer John 21 chapters question bank.",
            "ja": "ガリラヤ · エルサレムの旅で、ヨハネの福音書21章の問題バンクに答えます。",
            "ms": "Ikuti Galilea · Yerusalem dan jawab bank soalan Yohanes 21 bab.",
            "th": "ติดตามเส้นทางกาลิลี · เยรูซาเล็มและตอบคลังคำถามจากยอห์น 21 บท",
            "km": "តាមដានដំណើរកាលីឡេ · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីយ៉ូហាន 21 ជំពូក។"
          }
        },
        {
          "stage_id": "MAT-REVIEW-05",
          "title": {
            "ko": "베들레헴 · 갈릴리 · 예루살렘 복습",
            "en": "Bethlehem · Galilee · Jerusalem Review",
            "ja": "ベツレヘム · ガリラヤ · エルサレム 復習",
            "ms": "Betlehem · Galilea · Yerusalem Ulang kaji",
            "th": "เบธเลเฮม · กาลิลี · เยรูซาเล็ม ทบทวน",
            "km": "បេថ្លេហិម · កាលីឡេ · យេរូសាឡឹម រំលឹក"
          },
          "short_title": {
            "ko": "베들레헴·갈릴리+",
            "en": "Bethlehem·Galilee+",
            "ja": "ベツレヘム·ガリラヤ+",
            "ms": "Betlehem·Galilea+",
            "th": "เบธเลเฮม·กาลิลี+",
            "km": "បេថ្លេហិម·កាលីឡេ+"
          },
          "book_title": {
            "ko": "마태복음",
            "en": "Matthew",
            "ja": "マタイの福音書",
            "ms": "Matius",
            "th": "มัทธิว",
            "km": "ម៉ាថាយ"
          },
          "map_query": "Bethlehem Galilee Jerusalem Jesus biblical route review",
          "map_region": "bethlehem",
          "map_x": 47.4,
          "map_y": 70.5,
          "route_group": "new-testament",
          "place_names": [
            "베들레헴 · 갈릴리 · 예루살렘",
            "Bethlehem · Galilee · Jerusalem",
            "베들레헴·갈릴리",
            "Bethlehem·Galilee",
            "ベツレヘム · ガリラヤ · エルサレム",
            "Betlehem · Galilea · Yerusalem",
            "เบธเลเฮม · กาลิลี · เยรูซาเล็ม",
            "បេថ្លេហិម · កាលីឡេ · យេរូសាឡឹម"
          ],
          "reference": "마태복음 1-28",
          "references": {
            "ko": "마태복음 1-28",
            "en": "Matthew 1-28",
            "ja": "マタイの福音書 1-28",
            "ms": "Matius 1-28",
            "th": "มัทธิว 1-28",
            "km": "ម៉ាថាយ 1-28"
          },
          "scene": {
            "ko": "베들레헴·갈릴리+ 위치에서 마태복음 1-28 본문 사건을 확인합니다.",
            "en": "Bethlehem·Galilee+: read and answer from Matthew 1-28.",
            "ja": "ベツレヘム·ガリラヤ+の地点で、マタイの福音書 1-28の本文出来事を確認します。",
            "ms": "Di lokasi Betlehem·Galilea+, semak peristiwa teks Matius 1-28.",
            "th": "ที่ตำแหน่งเบธเลเฮม·กาลิลี+ ให้ตรวจสอบเหตุการณ์ในมัทธิว 1-28",
            "km": "នៅទីតាំងបេថ្លេហិម·កាលីឡេ+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងម៉ាថាយ 1-28។"
          },
          "mission": {
            "ko": "베들레헴 · 갈릴리 · 예루살렘 길에서 마태복음 주요 사건을 다시 확인합니다.",
            "en": "Review the main Matthew events along Bethlehem · Galilee · Jerusalem.",
            "ja": "ベツレヘム · ガリラヤ · エルサレムの道で、マタイの福音書の主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama Matius di sepanjang Betlehem · Galilea · Yerusalem.",
            "th": "ทบทวนเหตุการณ์สำคัญของมัทธิวตามเส้นทางเบธเลเฮม · กาลิลี · เยรูซาเล็ม",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃម៉ាថាយ តាមផ្លូវបេថ្លេហិម · កាលីឡេ · យេរូសាឡឹម។"
          }
        }
      ]
    },
    {
      "chapter_id": "NT-ACTS-C01",
      "book_id": "ACT",
      "section_key": "acts",
      "world_id": "W_NT_ACTS",
      "order_index": 61,
      "title": {
        "ko": "예루살렘·안디옥·로마 → 예루살렘·안디옥·로마+",
        "en": "Jerusalem·Antioch·Rome → Jerusalem·Antioch·Rome+",
        "ja": "エルサレム·アンティオキア·ローマ → エルサレム·アンティオキア·ローマ+",
        "ms": "Yerusalem·Antiokhia·Roma → Yerusalem·Antiokhia·Roma+",
        "th": "เยรูซาเล็ม·อันทิโอก·โรม → เยรูซาเล็ม·อันทิโอก·โรม+",
        "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម → យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+"
      },
      "summary": {
        "ko": "예루살렘·안디옥·로마 / 예루살렘·안디옥·로마+ / 예루살렘·안디옥·로마+ / 예루살렘·안디옥·로마+ / 예루살렘·안디옥·로마+ 길을 따라 신약 2. 역사서 본문 사건을 풉니다.",
        "en": "Follow Jerusalem·Antioch·Rome / Jerusalem·Antioch·Rome+ / Jerusalem·Antioch·Rome+ / Jerusalem·Antioch·Rome+ / Jerusalem·Antioch·Rome+ through New Testament 2. History.",
        "ja": "エルサレム·アンティオキア·ローマ / エルサレム·アンティオキア·ローマ+ / エルサレム·アンティオキア·ローマ+ / エルサレム·アンティオキア·ローマ+ / エルサレム·アンティオキア·ローマ+の道をたどり、新約2. 歴史書の本文出来事を解きます。",
        "ms": "Ikuti laluan Yerusalem·Antiokhia·Roma / Yerusalem·Antiokhia·Roma+ / Yerusalem·Antiokhia·Roma+ / Yerusalem·Antiokhia·Roma+ / Yerusalem·Antiokhia·Roma+ dan jawab peristiwa teks Perjanjian Baru 2. Sejarah.",
        "th": "ติดตามเส้นทาง เยรูซาเล็ม·อันทิโอก·โรม / เยรูซาเล็ม·อันทิโอก·โรม+ / เยรูซาเล็ม·อันทิโอก·โรม+ / เยรูซาเล็ม·อันทิโอก·โรม+ / เยรูซาเล็ม·อันทิโอก·โรม+ และตอบเหตุการณ์ในเนื้อหาพันธสัญญาใหม่ 2. ประวัติศาสตร์",
        "km": "តាមដានផ្លូវ យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម / យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+ / យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+ / យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+ / យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+ ហើយឆ្លើយព្រឹត្តិការណ៍ក្នុងអត្ថបទសញ្ញាថ្មី ២. ប្រវត្តិសាស្ត្រ។"
      },
      "stops": [
        {
          "stage_id": "ACT-001",
          "title": {
            "ko": "예루살렘 · 안디옥 · 로마",
            "en": "Jerusalem · Antioch · Rome",
            "ja": "エルサレム · アンティオキア · ローマ",
            "ms": "Yerusalem · Antiokhia · Roma",
            "th": "เยรูซาเล็ม · อันทิโอก · โรม",
            "km": "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម"
          },
          "short_title": {
            "ko": "예루살렘·안디옥·로마",
            "en": "Jerusalem·Antioch·Rome",
            "ja": "エルサレム·アンティオキア·ローマ",
            "ms": "Yerusalem·Antiokhia·Roma",
            "th": "เยรูซาเล็ม·อันทิโอก·โรม",
            "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម"
          },
          "book_title": {
            "ko": "사도행전",
            "en": "Acts",
            "ja": "使徒の働き",
            "ms": "Kisah Para Rasul",
            "th": "กิจการ",
            "km": "កិច្ចការ"
          },
          "map_query": "Jerusalem Antioch Rome Acts mission route",
          "map_region": "antioch",
          "map_x": 78.5,
          "map_y": 43.5,
          "route_group": "letters",
          "place_names": [
            "예루살렘 · 안디옥 · 로마",
            "Jerusalem · Antioch · Rome",
            "예루살렘·안디옥·로마",
            "Jerusalem·Antioch·Rome",
            "エルサレム · アンティオキア · ローマ",
            "Yerusalem · Antiokhia · Roma",
            "เยรูซาเล็ม · อันทิโอก · โรม",
            "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម"
          ],
          "reference": "사도행전 1-28",
          "references": {
            "ko": "사도행전 1-28",
            "en": "Acts 1-28",
            "ja": "使徒の働き 1-28",
            "ms": "Kisah Para Rasul 1-28",
            "th": "กิจการ 1-28",
            "km": "កិច្ចការ 1-28"
          },
          "scene": {
            "ko": "예루살렘·안디옥·로마 위치에서 사도행전 1-28 본문 사건을 확인합니다.",
            "en": "Jerusalem·Antioch·Rome: read and answer from Acts 1-28.",
            "ja": "エルサレム·アンティオキア·ローマの地点で、使徒の働き 1-28の本文出来事を確認します。",
            "ms": "Di lokasi Yerusalem·Antiokhia·Roma, semak peristiwa teks Kisah Para Rasul 1-28.",
            "th": "ที่ตำแหน่งเยรูซาเล็ม·อันทิโอก·โรม ให้ตรวจสอบเหตุการณ์ในกิจการ 1-28",
            "km": "នៅទីតាំងយេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងកិច្ចការ 1-28។"
          },
          "mission": {
            "ko": "예루살렘 · 안디옥 · 로마 여정에서 사도행전 28장 본문 문제를 풉니다.",
            "en": "Follow Jerusalem · Antioch · Rome and answer Acts 28 chapters question bank.",
            "ja": "エルサレム · アンティオキア · ローマの旅で、使徒の働き28章の問題バンクに答えます。",
            "ms": "Ikuti Yerusalem · Antiokhia · Roma dan jawab bank soalan Kisah Para Rasul 28 bab.",
            "th": "ติดตามเส้นทางเยรูซาเล็ม · อันทิโอก · โรมและตอบคลังคำถามจากกิจการ 28 บท",
            "km": "តាមដានដំណើរយេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម ហើយឆ្លើយធនាគារសំណួរពីកិច្ចការ 28 ជំពូក។"
          }
        },
        {
          "stage_id": "ACT-REVIEW-02",
          "title": {
            "ko": "예루살렘 · 안디옥 · 로마 복습",
            "en": "Jerusalem · Antioch · Rome Review",
            "ja": "エルサレム · アンティオキア · ローマ 復習",
            "ms": "Yerusalem · Antiokhia · Roma Ulang kaji",
            "th": "เยรูซาเล็ม · อันทิโอก · โรม ทบทวน",
            "km": "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម រំលឹក"
          },
          "short_title": {
            "ko": "예루살렘·안디옥·로마+",
            "en": "Jerusalem·Antioch·Rome+",
            "ja": "エルサレム·アンティオキア·ローマ+",
            "ms": "Yerusalem·Antiokhia·Roma+",
            "th": "เยรูซาเล็ม·อันทิโอก·โรม+",
            "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+"
          },
          "book_title": {
            "ko": "사도행전",
            "en": "Acts",
            "ja": "使徒の働き",
            "ms": "Kisah Para Rasul",
            "th": "กิจการ",
            "km": "កិច្ចការ"
          },
          "map_query": "Jerusalem Antioch Rome Acts mission route review",
          "map_region": "antioch",
          "map_x": 78.5,
          "map_y": 43.5,
          "route_group": "letters",
          "place_names": [
            "예루살렘 · 안디옥 · 로마",
            "Jerusalem · Antioch · Rome",
            "예루살렘·안디옥·로마",
            "Jerusalem·Antioch·Rome",
            "エルサレム · アンティオキア · ローマ",
            "Yerusalem · Antiokhia · Roma",
            "เยรูซาเล็ม · อันทิโอก · โรม",
            "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម"
          ],
          "reference": "사도행전 1-28",
          "references": {
            "ko": "사도행전 1-28",
            "en": "Acts 1-28",
            "ja": "使徒の働き 1-28",
            "ms": "Kisah Para Rasul 1-28",
            "th": "กิจการ 1-28",
            "km": "កិច្ចការ 1-28"
          },
          "scene": {
            "ko": "예루살렘·안디옥·로마+ 위치에서 사도행전 1-28 본문 사건을 확인합니다.",
            "en": "Jerusalem·Antioch·Rome+: read and answer from Acts 1-28.",
            "ja": "エルサレム·アンティオキア·ローマ+の地点で、使徒の働き 1-28の本文出来事を確認します。",
            "ms": "Di lokasi Yerusalem·Antiokhia·Roma+, semak peristiwa teks Kisah Para Rasul 1-28.",
            "th": "ที่ตำแหน่งเยรูซาเล็ม·อันทิโอก·โรม+ ให้ตรวจสอบเหตุการณ์ในกิจการ 1-28",
            "km": "នៅទីតាំងយេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងកិច្ចការ 1-28។"
          },
          "mission": {
            "ko": "예루살렘 · 안디옥 · 로마 길에서 사도행전 주요 사건을 다시 확인합니다.",
            "en": "Review the main Acts events along Jerusalem · Antioch · Rome.",
            "ja": "エルサレム · アンティオキア · ローマの道で、使徒の働きの主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama Kisah Para Rasul di sepanjang Yerusalem · Antiokhia · Roma.",
            "th": "ทบทวนเหตุการณ์สำคัญของกิจการตามเส้นทางเยรูซาเล็ม · อันทิโอก · โรม",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃកិច្ចការ តាមផ្លូវយេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម។"
          }
        },
        {
          "stage_id": "ACT-REVIEW-03",
          "title": {
            "ko": "예루살렘 · 안디옥 · 로마 복습",
            "en": "Jerusalem · Antioch · Rome Review",
            "ja": "エルサレム · アンティオキア · ローマ 復習",
            "ms": "Yerusalem · Antiokhia · Roma Ulang kaji",
            "th": "เยรูซาเล็ม · อันทิโอก · โรม ทบทวน",
            "km": "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម រំលឹក"
          },
          "short_title": {
            "ko": "예루살렘·안디옥·로마+",
            "en": "Jerusalem·Antioch·Rome+",
            "ja": "エルサレム·アンティオキア·ローマ+",
            "ms": "Yerusalem·Antiokhia·Roma+",
            "th": "เยรูซาเล็ม·อันทิโอก·โรม+",
            "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+"
          },
          "book_title": {
            "ko": "사도행전",
            "en": "Acts",
            "ja": "使徒の働き",
            "ms": "Kisah Para Rasul",
            "th": "กิจการ",
            "km": "កិច្ចការ"
          },
          "map_query": "Jerusalem Antioch Rome Acts mission route review",
          "map_region": "antioch",
          "map_x": 78.5,
          "map_y": 43.5,
          "route_group": "letters",
          "place_names": [
            "예루살렘 · 안디옥 · 로마",
            "Jerusalem · Antioch · Rome",
            "예루살렘·안디옥·로마",
            "Jerusalem·Antioch·Rome",
            "エルサレム · アンティオキア · ローマ",
            "Yerusalem · Antiokhia · Roma",
            "เยรูซาเล็ม · อันทิโอก · โรม",
            "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម"
          ],
          "reference": "사도행전 1-28",
          "references": {
            "ko": "사도행전 1-28",
            "en": "Acts 1-28",
            "ja": "使徒の働き 1-28",
            "ms": "Kisah Para Rasul 1-28",
            "th": "กิจการ 1-28",
            "km": "កិច្ចការ 1-28"
          },
          "scene": {
            "ko": "예루살렘·안디옥·로마+ 위치에서 사도행전 1-28 본문 사건을 확인합니다.",
            "en": "Jerusalem·Antioch·Rome+: read and answer from Acts 1-28.",
            "ja": "エルサレム·アンティオキア·ローマ+の地点で、使徒の働き 1-28の本文出来事を確認します。",
            "ms": "Di lokasi Yerusalem·Antiokhia·Roma+, semak peristiwa teks Kisah Para Rasul 1-28.",
            "th": "ที่ตำแหน่งเยรูซาเล็ม·อันทิโอก·โรม+ ให้ตรวจสอบเหตุการณ์ในกิจการ 1-28",
            "km": "នៅទីតាំងយេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងកិច្ចការ 1-28។"
          },
          "mission": {
            "ko": "예루살렘 · 안디옥 · 로마 길에서 사도행전 주요 사건을 다시 확인합니다.",
            "en": "Review the main Acts events along Jerusalem · Antioch · Rome.",
            "ja": "エルサレム · アンティオキア · ローマの道で、使徒の働きの主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama Kisah Para Rasul di sepanjang Yerusalem · Antiokhia · Roma.",
            "th": "ทบทวนเหตุการณ์สำคัญของกิจการตามเส้นทางเยรูซาเล็ม · อันทิโอก · โรม",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃកិច្ចការ តាមផ្លូវយេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម។"
          }
        },
        {
          "stage_id": "ACT-REVIEW-04",
          "title": {
            "ko": "예루살렘 · 안디옥 · 로마 복습",
            "en": "Jerusalem · Antioch · Rome Review",
            "ja": "エルサレム · アンティオキア · ローマ 復習",
            "ms": "Yerusalem · Antiokhia · Roma Ulang kaji",
            "th": "เยรูซาเล็ม · อันทิโอก · โรม ทบทวน",
            "km": "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម រំលឹក"
          },
          "short_title": {
            "ko": "예루살렘·안디옥·로마+",
            "en": "Jerusalem·Antioch·Rome+",
            "ja": "エルサレム·アンティオキア·ローマ+",
            "ms": "Yerusalem·Antiokhia·Roma+",
            "th": "เยรูซาเล็ม·อันทิโอก·โรม+",
            "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+"
          },
          "book_title": {
            "ko": "사도행전",
            "en": "Acts",
            "ja": "使徒の働き",
            "ms": "Kisah Para Rasul",
            "th": "กิจการ",
            "km": "កិច្ចការ"
          },
          "map_query": "Jerusalem Antioch Rome Acts mission route review",
          "map_region": "antioch",
          "map_x": 78.5,
          "map_y": 43.5,
          "route_group": "letters",
          "place_names": [
            "예루살렘 · 안디옥 · 로마",
            "Jerusalem · Antioch · Rome",
            "예루살렘·안디옥·로마",
            "Jerusalem·Antioch·Rome",
            "エルサレム · アンティオキア · ローマ",
            "Yerusalem · Antiokhia · Roma",
            "เยรูซาเล็ม · อันทิโอก · โรม",
            "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម"
          ],
          "reference": "사도행전 1-28",
          "references": {
            "ko": "사도행전 1-28",
            "en": "Acts 1-28",
            "ja": "使徒の働き 1-28",
            "ms": "Kisah Para Rasul 1-28",
            "th": "กิจการ 1-28",
            "km": "កិច្ចការ 1-28"
          },
          "scene": {
            "ko": "예루살렘·안디옥·로마+ 위치에서 사도행전 1-28 본문 사건을 확인합니다.",
            "en": "Jerusalem·Antioch·Rome+: read and answer from Acts 1-28.",
            "ja": "エルサレム·アンティオキア·ローマ+の地点で、使徒の働き 1-28の本文出来事を確認します。",
            "ms": "Di lokasi Yerusalem·Antiokhia·Roma+, semak peristiwa teks Kisah Para Rasul 1-28.",
            "th": "ที่ตำแหน่งเยรูซาเล็ม·อันทิโอก·โรม+ ให้ตรวจสอบเหตุการณ์ในกิจการ 1-28",
            "km": "នៅទីតាំងយេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងកិច្ចការ 1-28។"
          },
          "mission": {
            "ko": "예루살렘 · 안디옥 · 로마 길에서 사도행전 주요 사건을 다시 확인합니다.",
            "en": "Review the main Acts events along Jerusalem · Antioch · Rome.",
            "ja": "エルサレム · アンティオキア · ローマの道で、使徒の働きの主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama Kisah Para Rasul di sepanjang Yerusalem · Antiokhia · Roma.",
            "th": "ทบทวนเหตุการณ์สำคัญของกิจการตามเส้นทางเยรูซาเล็ม · อันทิโอก · โรม",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃកិច្ចការ តាមផ្លូវយេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម។"
          }
        },
        {
          "stage_id": "ACT-REVIEW-05",
          "title": {
            "ko": "예루살렘 · 안디옥 · 로마 복습",
            "en": "Jerusalem · Antioch · Rome Review",
            "ja": "エルサレム · アンティオキア · ローマ 復習",
            "ms": "Yerusalem · Antiokhia · Roma Ulang kaji",
            "th": "เยรูซาเล็ม · อันทิโอก · โรม ทบทวน",
            "km": "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម រំលឹក"
          },
          "short_title": {
            "ko": "예루살렘·안디옥·로마+",
            "en": "Jerusalem·Antioch·Rome+",
            "ja": "エルサレム·アンティオキア·ローマ+",
            "ms": "Yerusalem·Antiokhia·Roma+",
            "th": "เยรูซาเล็ม·อันทิโอก·โรม+",
            "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+"
          },
          "book_title": {
            "ko": "사도행전",
            "en": "Acts",
            "ja": "使徒の働き",
            "ms": "Kisah Para Rasul",
            "th": "กิจการ",
            "km": "កិច្ចការ"
          },
          "map_query": "Jerusalem Antioch Rome Acts mission route review",
          "map_region": "antioch",
          "map_x": 78.5,
          "map_y": 43.5,
          "route_group": "letters",
          "place_names": [
            "예루살렘 · 안디옥 · 로마",
            "Jerusalem · Antioch · Rome",
            "예루살렘·안디옥·로마",
            "Jerusalem·Antioch·Rome",
            "エルサレム · アンティオキア · ローマ",
            "Yerusalem · Antiokhia · Roma",
            "เยรูซาเล็ม · อันทิโอก · โรม",
            "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម"
          ],
          "reference": "사도행전 1-28",
          "references": {
            "ko": "사도행전 1-28",
            "en": "Acts 1-28",
            "ja": "使徒の働き 1-28",
            "ms": "Kisah Para Rasul 1-28",
            "th": "กิจการ 1-28",
            "km": "កិច្ចការ 1-28"
          },
          "scene": {
            "ko": "예루살렘·안디옥·로마+ 위치에서 사도행전 1-28 본문 사건을 확인합니다.",
            "en": "Jerusalem·Antioch·Rome+: read and answer from Acts 1-28.",
            "ja": "エルサレム·アンティオキア·ローマ+の地点で、使徒の働き 1-28の本文出来事を確認します。",
            "ms": "Di lokasi Yerusalem·Antiokhia·Roma+, semak peristiwa teks Kisah Para Rasul 1-28.",
            "th": "ที่ตำแหน่งเยรูซาเล็ม·อันทิโอก·โรม+ ให้ตรวจสอบเหตุการณ์ในกิจการ 1-28",
            "km": "នៅទីតាំងយេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងកិច្ចការ 1-28។"
          },
          "mission": {
            "ko": "예루살렘 · 안디옥 · 로마 길에서 사도행전 주요 사건을 다시 확인합니다.",
            "en": "Review the main Acts events along Jerusalem · Antioch · Rome.",
            "ja": "エルサレム · アンティオキア · ローマの道で、使徒の働きの主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama Kisah Para Rasul di sepanjang Yerusalem · Antiokhia · Roma.",
            "th": "ทบทวนเหตุการณ์สำคัญของกิจการตามเส้นทางเยรูซาเล็ม · อันทิโอก · โรม",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃកិច្ចការ តាមផ្លូវយេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម។"
          }
        }
      ]
    },
    {
      "chapter_id": "NT-PAUL-C01",
      "book_id": "ROM",
      "section_key": "pauline",
      "world_id": "W_NT_PAUL",
      "order_index": 71,
      "title": {
        "ko": "로마 → 에베소",
        "en": "Rome → Ephesus",
        "ja": "ローマ → エフェソ",
        "ms": "Roma → Efesus",
        "th": "โรม → เอเฟซัส",
        "km": "រ៉ូម → អេភេសូរ"
      },
      "summary": {
        "ko": "로마 / 고린도 / 고린도·마게도냐 / 갈라디아 / 에베소 길을 따라 신약 3. 바울서신 본문 사건을 풉니다.",
        "en": "Follow Rome / Corinth / Corinth·Macedonia / Galatia / Ephesus through New Testament 3. Pauline Epistles.",
        "ja": "ローマ / コリント / コリント·マケドニア / ガラテヤ / エフェソの道をたどり、新約3. パウロ書簡の本文出来事を解きます。",
        "ms": "Ikuti laluan Roma / Korintus / Korintus·Makedonia / Galatia / Efesus dan jawab peristiwa teks Perjanjian Baru 3. Surat Paulus.",
        "th": "ติดตามเส้นทาง โรม / โครินธ์ / โครินธ์·มาซิโดเนีย / กาลาเทีย / เอเฟซัส และตอบเหตุการณ์ในเนื้อหาพันธสัญญาใหม่ 3. จดหมายของเปาโล",
        "km": "តាមដានផ្លូវ រ៉ូម / កូរិនថូស / កូរិនថូស·ម៉ាសេដូនៀ / កាឡាទី / អេភេសូរ ហើយឆ្លើយព្រឹត្តិការណ៍ក្នុងអត្ថបទសញ្ញាថ្មី ៣. សំបុត្ររបស់ប៉ូល។"
      },
      "stops": [
        {
          "stage_id": "ROM-001",
          "title": {
            "ko": "로마",
            "en": "Rome",
            "ja": "ローマ",
            "ms": "Roma",
            "th": "โรม",
            "km": "រ៉ូម"
          },
          "short_title": {
            "ko": "로마",
            "en": "Rome",
            "ja": "ローマ",
            "ms": "Roma",
            "th": "โรม",
            "km": "រ៉ូម"
          },
          "book_title": {
            "ko": "로마서",
            "en": "Romans",
            "ja": "ローマ人への手紙",
            "ms": "Roma",
            "th": "โรม",
            "km": "រ៉ូម"
          },
          "map_query": "Rome Italy Romans biblical letter location",
          "map_region": "rome",
          "map_x": 13.8,
          "map_y": 9.6,
          "route_group": "letters",
          "place_names": [
            "로마",
            "Rome",
            "로마",
            "Rome",
            "ローマ",
            "Roma",
            "โรม",
            "រ៉ូម"
          ],
          "reference": "로마서 1-16",
          "references": {
            "ko": "로마서 1-16",
            "en": "Romans 1-16",
            "ja": "ローマ人への手紙 1-16",
            "ms": "Roma 1-16",
            "th": "โรม 1-16",
            "km": "រ៉ូម 1-16"
          },
          "scene": {
            "ko": "로마 위치에서 로마서 1-16 본문 사건을 확인합니다.",
            "en": "Rome: read and answer from Romans 1-16.",
            "ja": "ローマの地点で、ローマ人への手紙 1-16の本文出来事を確認します。",
            "ms": "Di lokasi Roma, semak peristiwa teks Roma 1-16.",
            "th": "ที่ตำแหน่งโรม ให้ตรวจสอบเหตุการณ์ในโรม 1-16",
            "km": "នៅទីតាំងរ៉ូម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងរ៉ូម 1-16។"
          },
          "mission": {
            "ko": "로마 여정에서 로마서 16장 본문 문제를 풉니다.",
            "en": "Follow Rome and answer Romans 16 chapters question bank.",
            "ja": "ローマの旅で、ローマ人への手紙16章の問題バンクに答えます。",
            "ms": "Ikuti Roma dan jawab bank soalan Roma 16 bab.",
            "th": "ติดตามเส้นทางโรมและตอบคลังคำถามจากโรม 16 บท",
            "km": "តាមដានដំណើររ៉ូម ហើយឆ្លើយធនាគារសំណួរពីរ៉ូម 16 ជំពូក។"
          }
        },
        {
          "stage_id": "1CO-001",
          "title": {
            "ko": "고린도",
            "en": "Corinth",
            "ja": "コリント",
            "ms": "Korintus",
            "th": "โครินธ์",
            "km": "កូរិនថូស"
          },
          "short_title": {
            "ko": "고린도",
            "en": "Corinth",
            "ja": "コリント",
            "ms": "Korintus",
            "th": "โครินธ์",
            "km": "កូរិនថូស"
          },
          "book_title": {
            "ko": "고린도전서",
            "en": "1 Corinthians",
            "ja": "コリント人への手紙第一",
            "ms": "1 Korintus",
            "th": "1 โครินธ์",
            "km": "១ កូរិនថូស"
          },
          "map_query": "Corinth Greece biblical location",
          "map_region": "corinth",
          "map_x": 39.1,
          "map_y": 39.2,
          "route_group": "letters",
          "place_names": [
            "고린도",
            "Corinth",
            "고린도",
            "Corinth",
            "コリント",
            "Korintus",
            "โครินธ์",
            "កូរិនថូស"
          ],
          "reference": "고린도전서 1-16",
          "references": {
            "ko": "고린도전서 1-16",
            "en": "1 Corinthians 1-16",
            "ja": "コリント人への手紙第一 1-16",
            "ms": "1 Korintus 1-16",
            "th": "1 โครินธ์ 1-16",
            "km": "១ កូរិនថូស 1-16"
          },
          "scene": {
            "ko": "고린도 위치에서 고린도전서 1-16 본문 사건을 확인합니다.",
            "en": "Corinth: read and answer from 1 Corinthians 1-16.",
            "ja": "コリントの地点で、コリント人への手紙第一 1-16の本文出来事を確認します。",
            "ms": "Di lokasi Korintus, semak peristiwa teks 1 Korintus 1-16.",
            "th": "ที่ตำแหน่งโครินธ์ ให้ตรวจสอบเหตุการณ์ใน1 โครินธ์ 1-16",
            "km": "នៅទីតាំងកូរិនថូស សូមពិនិត្យព្រឹត្តិការណ៍ក្នុង១ កូរិនថូស 1-16។"
          },
          "mission": {
            "ko": "고린도 여정에서 고린도전서 16장 본문 문제를 풉니다.",
            "en": "Follow Corinth and answer 1 Corinthians 16 chapters question bank.",
            "ja": "コリントの旅で、コリント人への手紙第一16章の問題バンクに答えます。",
            "ms": "Ikuti Korintus dan jawab bank soalan 1 Korintus 16 bab.",
            "th": "ติดตามเส้นทางโครินธ์และตอบคลังคำถามจาก1 โครินธ์ 16 บท",
            "km": "តាមដានដំណើរកូរិនថូស ហើយឆ្លើយធនាគារសំណួរពី១ កូរិនថូស 16 ជំពូក។"
          }
        },
        {
          "stage_id": "2CO-001",
          "title": {
            "ko": "고린도 · 마게도냐",
            "en": "Corinth · Macedonia",
            "ja": "コリント · マケドニア",
            "ms": "Korintus · Makedonia",
            "th": "โครินธ์ · มาซิโดเนีย",
            "km": "កូរិនថូស · ម៉ាសេដូនៀ"
          },
          "short_title": {
            "ko": "고린도·마게도냐",
            "en": "Corinth·Macedonia",
            "ja": "コリント·マケドニア",
            "ms": "Korintus·Makedonia",
            "th": "โครินธ์·มาซิโดเนีย",
            "km": "កូរិនថូស·ម៉ាសេដូនៀ"
          },
          "book_title": {
            "ko": "고린도후서",
            "en": "2 Corinthians",
            "ja": "コリント人への手紙第二",
            "ms": "2 Korintus",
            "th": "2 โครินธ์",
            "km": "២ កូរិនថូស"
          },
          "map_query": "Corinth Greece biblical location",
          "map_region": "corinth",
          "map_x": 39.1,
          "map_y": 39.2,
          "route_group": "letters",
          "place_names": [
            "고린도 · 마게도냐",
            "Corinth · Macedonia",
            "고린도·마게도냐",
            "Corinth·Macedonia",
            "コリント · マケドニア",
            "Korintus · Makedonia",
            "โครินธ์ · มาซิโดเนีย",
            "កូរិនថូស · ម៉ាសេដូនៀ"
          ],
          "reference": "고린도후서 1-13",
          "references": {
            "ko": "고린도후서 1-13",
            "en": "2 Corinthians 1-13",
            "ja": "コリント人への手紙第二 1-13",
            "ms": "2 Korintus 1-13",
            "th": "2 โครินธ์ 1-13",
            "km": "២ កូរិនថូស 1-13"
          },
          "scene": {
            "ko": "고린도·마게도냐 위치에서 고린도후서 1-13 본문 사건을 확인합니다.",
            "en": "Corinth·Macedonia: read and answer from 2 Corinthians 1-13.",
            "ja": "コリント·マケドニアの地点で、コリント人への手紙第二 1-13の本文出来事を確認します。",
            "ms": "Di lokasi Korintus·Makedonia, semak peristiwa teks 2 Korintus 1-13.",
            "th": "ที่ตำแหน่งโครินธ์·มาซิโดเนีย ให้ตรวจสอบเหตุการณ์ใน2 โครินธ์ 1-13",
            "km": "នៅទីតាំងកូរិនថូស·ម៉ាសេដូនៀ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុង២ កូរិនថូស 1-13។"
          },
          "mission": {
            "ko": "고린도 · 마게도냐 여정에서 고린도후서 13장 본문 문제를 풉니다.",
            "en": "Follow Corinth · Macedonia and answer 2 Corinthians 13 chapters question bank.",
            "ja": "コリント · マケドニアの旅で、コリント人への手紙第二13章の問題バンクに答えます。",
            "ms": "Ikuti Korintus · Makedonia dan jawab bank soalan 2 Korintus 13 bab.",
            "th": "ติดตามเส้นทางโครินธ์ · มาซิโดเนียและตอบคลังคำถามจาก2 โครินธ์ 13 บท",
            "km": "តាមដានដំណើរកូរិនថូស · ម៉ាសេដូនៀ ហើយឆ្លើយធនាគារសំណួរពី២ កូរិនថូស 13 ជំពូក។"
          }
        },
        {
          "stage_id": "GAL-001",
          "title": {
            "ko": "갈라디아",
            "en": "Galatia",
            "ja": "ガラテヤ",
            "ms": "Galatia",
            "th": "กาลาเทีย",
            "km": "កាឡាទី"
          },
          "short_title": {
            "ko": "갈라디아",
            "en": "Galatia",
            "ja": "ガラテヤ",
            "ms": "Galatia",
            "th": "กาลาเทีย",
            "km": "កាឡាទី"
          },
          "book_title": {
            "ko": "갈라디아서",
            "en": "Galatians",
            "ja": "ガラテヤ人への手紙",
            "ms": "Galatia",
            "th": "กาลาเทีย",
            "km": "កាឡាទី"
          },
          "map_query": "Galatia Asia Minor biblical region",
          "map_region": "asia-minor",
          "map_x": 63.8,
          "map_y": 32.2,
          "route_group": "letters",
          "place_names": [
            "갈라디아",
            "Galatia",
            "갈라디아",
            "Galatia",
            "ガラテヤ",
            "Galatia",
            "กาลาเทีย",
            "កាឡាទី"
          ],
          "reference": "갈라디아서 1-6",
          "references": {
            "ko": "갈라디아서 1-6",
            "en": "Galatians 1-6",
            "ja": "ガラテヤ人への手紙 1-6",
            "ms": "Galatia 1-6",
            "th": "กาลาเทีย 1-6",
            "km": "កាឡាទី 1-6"
          },
          "scene": {
            "ko": "갈라디아 위치에서 갈라디아서 1-6 본문 사건을 확인합니다.",
            "en": "Galatia: read and answer from Galatians 1-6.",
            "ja": "ガラテヤの地点で、ガラテヤ人への手紙 1-6の本文出来事を確認します。",
            "ms": "Di lokasi Galatia, semak peristiwa teks Galatia 1-6.",
            "th": "ที่ตำแหน่งกาลาเทีย ให้ตรวจสอบเหตุการณ์ในกาลาเทีย 1-6",
            "km": "នៅទីតាំងកាឡាទី សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងកាឡាទី 1-6។"
          },
          "mission": {
            "ko": "갈라디아 여정에서 갈라디아서 6장 본문 문제를 풉니다.",
            "en": "Follow Galatia and answer Galatians 6 chapters question bank.",
            "ja": "ガラテヤの旅で、ガラテヤ人への手紙6章の問題バンクに答えます。",
            "ms": "Ikuti Galatia dan jawab bank soalan Galatia 6 bab.",
            "th": "ติดตามเส้นทางกาลาเทียและตอบคลังคำถามจากกาลาเทีย 6 บท",
            "km": "តាមដានដំណើរកាឡាទី ហើយឆ្លើយធនាគារសំណួរពីកាឡាទី 6 ជំពូក។"
          }
        },
        {
          "stage_id": "EPH-001",
          "title": {
            "ko": "에베소",
            "en": "Ephesus",
            "ja": "エフェソ",
            "ms": "Efesus",
            "th": "เอเฟซัส",
            "km": "អេភេសូរ"
          },
          "short_title": {
            "ko": "에베소",
            "en": "Ephesus",
            "ja": "エフェソ",
            "ms": "Efesus",
            "th": "เอเฟซัส",
            "km": "អេភេសូរ"
          },
          "book_title": {
            "ko": "에베소서",
            "en": "Ephesians",
            "ja": "エペソ人への手紙",
            "ms": "Efesus",
            "th": "เอเฟซัส",
            "km": "អេភេសូរ"
          },
          "map_query": "Ephesus Turkey biblical location",
          "map_region": "asia-minor",
          "map_x": 51.5,
          "map_y": 37.8,
          "route_group": "letters",
          "place_names": [
            "에베소",
            "Ephesus",
            "에베소",
            "Ephesus",
            "エフェソ",
            "Efesus",
            "เอเฟซัส",
            "អេភេសូរ"
          ],
          "reference": "에베소서 1-6",
          "references": {
            "ko": "에베소서 1-6",
            "en": "Ephesians 1-6",
            "ja": "エペソ人への手紙 1-6",
            "ms": "Efesus 1-6",
            "th": "เอเฟซัส 1-6",
            "km": "អេភេសូរ 1-6"
          },
          "scene": {
            "ko": "에베소 위치에서 에베소서 1-6 본문 사건을 확인합니다.",
            "en": "Ephesus: read and answer from Ephesians 1-6.",
            "ja": "エフェソの地点で、エペソ人への手紙 1-6の本文出来事を確認します。",
            "ms": "Di lokasi Efesus, semak peristiwa teks Efesus 1-6.",
            "th": "ที่ตำแหน่งเอเฟซัส ให้ตรวจสอบเหตุการณ์ในเอเฟซัส 1-6",
            "km": "នៅទីតាំងអេភេសូរ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងអេភេសូរ 1-6។"
          },
          "mission": {
            "ko": "에베소 여정에서 에베소서 6장 본문 문제를 풉니다.",
            "en": "Follow Ephesus and answer Ephesians 6 chapters question bank.",
            "ja": "エフェソの旅で、エペソ人への手紙6章の問題バンクに答えます。",
            "ms": "Ikuti Efesus dan jawab bank soalan Efesus 6 bab.",
            "th": "ติดตามเส้นทางเอเฟซัสและตอบคลังคำถามจากเอเฟซัส 6 บท",
            "km": "តាមដានដំណើរអេភេសូរ ហើយឆ្លើយធនាគារសំណួរពីអេភេសូរ 6 ជំពូក។"
          }
        }
      ]
    },
    {
      "chapter_id": "NT-PAUL-C02",
      "book_id": "PHP",
      "section_key": "pauline",
      "world_id": "W_NT_PAUL",
      "order_index": 72,
      "title": {
        "ko": "빌립보 → 에베소",
        "en": "Philippi → Ephesus",
        "ja": "フィリピ → エフェソ",
        "ms": "Filipi → Efesus",
        "th": "ฟีลิปปี → เอเฟซัส",
        "km": "ភីលីព → អេភេសូរ"
      },
      "summary": {
        "ko": "빌립보 / 골로새 / 데살로니가 / 데살로니가 / 에베소 길을 따라 신약 3. 바울서신 본문 사건을 풉니다.",
        "en": "Follow Philippi / Colossae / Thessalonica / Thessalonica / Ephesus through New Testament 3. Pauline Epistles.",
        "ja": "フィリピ / コロサイ / テサロニケ / テサロニケ / エフェソの道をたどり、新約3. パウロ書簡の本文出来事を解きます。",
        "ms": "Ikuti laluan Filipi / Kolose / Tesalonika / Tesalonika / Efesus dan jawab peristiwa teks Perjanjian Baru 3. Surat Paulus.",
        "th": "ติดตามเส้นทาง ฟีลิปปี / โคโลสี / เธสะโลนิกา / เธสะโลนิกา / เอเฟซัส และตอบเหตุการณ์ในเนื้อหาพันธสัญญาใหม่ 3. จดหมายของเปาโล",
        "km": "តាមដានផ្លូវ ភីលីព / កូល៉ុស / ថេស្សាឡូនិក / ថេស្សាឡូនិក / អេភេសូរ ហើយឆ្លើយព្រឹត្តិការណ៍ក្នុងអត្ថបទសញ្ញាថ្មី ៣. សំបុត្ររបស់ប៉ូល។"
      },
      "stops": [
        {
          "stage_id": "PHP-001",
          "title": {
            "ko": "빌립보",
            "en": "Philippi",
            "ja": "フィリピ",
            "ms": "Filipi",
            "th": "ฟีลิปปี",
            "km": "ភីលីព"
          },
          "short_title": {
            "ko": "빌립보",
            "en": "Philippi",
            "ja": "フィリピ",
            "ms": "Filipi",
            "th": "ฟีลิปปี",
            "km": "ភីលីព"
          },
          "book_title": {
            "ko": "빌립보서",
            "en": "Philippians",
            "ja": "ピリピ人への手紙",
            "ms": "Filipi",
            "th": "ฟิลิปปี",
            "km": "ភីលីព"
          },
          "map_query": "Philippi Greece biblical location",
          "map_region": "macedonia",
          "map_x": 37.4,
          "map_y": 19.2,
          "route_group": "letters",
          "place_names": [
            "빌립보",
            "Philippi",
            "빌립보",
            "Philippi",
            "フィリピ",
            "Filipi",
            "ฟีลิปปี",
            "ភីលីព"
          ],
          "reference": "빌립보서 1-4",
          "references": {
            "ko": "빌립보서 1-4",
            "en": "Philippians 1-4",
            "ja": "ピリピ人への手紙 1-4",
            "ms": "Filipi 1-4",
            "th": "ฟิลิปปี 1-4",
            "km": "ភីលីព 1-4"
          },
          "scene": {
            "ko": "빌립보 위치에서 빌립보서 1-4 본문 사건을 확인합니다.",
            "en": "Philippi: read and answer from Philippians 1-4.",
            "ja": "フィリピの地点で、ピリピ人への手紙 1-4の本文出来事を確認します。",
            "ms": "Di lokasi Filipi, semak peristiwa teks Filipi 1-4.",
            "th": "ที่ตำแหน่งฟีลิปปี ให้ตรวจสอบเหตุการณ์ในฟิลิปปี 1-4",
            "km": "នៅទីតាំងភីលីព សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងភីលីព 1-4។"
          },
          "mission": {
            "ko": "빌립보 여정에서 빌립보서 4장 본문 문제를 풉니다.",
            "en": "Follow Philippi and answer Philippians 4 chapters question bank.",
            "ja": "フィリピの旅で、ピリピ人への手紙4章の問題バンクに答えます。",
            "ms": "Ikuti Filipi dan jawab bank soalan Filipi 4 bab.",
            "th": "ติดตามเส้นทางฟีลิปปีและตอบคลังคำถามจากฟิลิปปี 4 บท",
            "km": "តាមដានដំណើរភីលីព ហើយឆ្លើយធនាគារសំណួរពីភីលីព 4 ជំពូក។"
          }
        },
        {
          "stage_id": "COL-001",
          "title": {
            "ko": "골로새",
            "en": "Colossae",
            "ja": "コロサイ",
            "ms": "Kolose",
            "th": "โคโลสี",
            "km": "កូល៉ុស"
          },
          "short_title": {
            "ko": "골로새",
            "en": "Colossae",
            "ja": "コロサイ",
            "ms": "Kolose",
            "th": "โคโลสี",
            "km": "កូល៉ុស"
          },
          "book_title": {
            "ko": "골로새서",
            "en": "Colossians",
            "ja": "コロサイ人への手紙",
            "ms": "Kolose",
            "th": "โคโลสี",
            "km": "កូឡុស"
          },
          "map_query": "Colossae Turkey biblical location",
          "map_region": "asia-minor",
          "map_x": 59.8,
          "map_y": 39.2,
          "route_group": "letters",
          "place_names": [
            "골로새",
            "Colossae",
            "골로새",
            "Colossae",
            "コロサイ",
            "Kolose",
            "โคโลสี",
            "កូល៉ុស"
          ],
          "reference": "골로새서 1-4",
          "references": {
            "ko": "골로새서 1-4",
            "en": "Colossians 1-4",
            "ja": "コロサイ人への手紙 1-4",
            "ms": "Kolose 1-4",
            "th": "โคโลสี 1-4",
            "km": "កូឡុស 1-4"
          },
          "scene": {
            "ko": "골로새 위치에서 골로새서 1-4 본문 사건을 확인합니다.",
            "en": "Colossae: read and answer from Colossians 1-4.",
            "ja": "コロサイの地点で、コロサイ人への手紙 1-4の本文出来事を確認します。",
            "ms": "Di lokasi Kolose, semak peristiwa teks Kolose 1-4.",
            "th": "ที่ตำแหน่งโคโลสี ให้ตรวจสอบเหตุการณ์ในโคโลสี 1-4",
            "km": "នៅទីតាំងកូល៉ុស សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងកូឡុស 1-4។"
          },
          "mission": {
            "ko": "골로새 여정에서 골로새서 4장 본문 문제를 풉니다.",
            "en": "Follow Colossae and answer Colossians 4 chapters question bank.",
            "ja": "コロサイの旅で、コロサイ人への手紙4章の問題バンクに答えます。",
            "ms": "Ikuti Kolose dan jawab bank soalan Kolose 4 bab.",
            "th": "ติดตามเส้นทางโคโลสีและตอบคลังคำถามจากโคโลสี 4 บท",
            "km": "តាមដានដំណើរកូល៉ុស ហើយឆ្លើយធនាគារសំណួរពីកូឡុស 4 ជំពូក។"
          }
        },
        {
          "stage_id": "1TH-001",
          "title": {
            "ko": "데살로니가",
            "en": "Thessalonica",
            "ja": "テサロニケ",
            "ms": "Tesalonika",
            "th": "เธสะโลนิกา",
            "km": "ថេស្សាឡូនិក"
          },
          "short_title": {
            "ko": "데살로니가",
            "en": "Thessalonica",
            "ja": "テサロニケ",
            "ms": "Tesalonika",
            "th": "เธสะโลนิกา",
            "km": "ថេស្សាឡូនិក"
          },
          "book_title": {
            "ko": "데살로니가전서",
            "en": "1 Thessalonians",
            "ja": "テサロニケ人への手紙第一",
            "ms": "1 Tesalonika",
            "th": "1 เธสะโลนิกา",
            "km": "១ ថែស្សាឡូនីច"
          },
          "map_query": "Thessalonica Greece biblical location",
          "map_region": "macedonia",
          "map_x": 36.5,
          "map_y": 23.1,
          "route_group": "letters",
          "place_names": [
            "데살로니가",
            "Thessalonica",
            "데살로니가",
            "Thessalonica",
            "テサロニケ",
            "Tesalonika",
            "เธสะโลนิกา",
            "ថេស្សាឡូនិក"
          ],
          "reference": "데살로니가전서 1-5",
          "references": {
            "ko": "데살로니가전서 1-5",
            "en": "1 Thessalonians 1-5",
            "ja": "テサロニケ人への手紙第一 1-5",
            "ms": "1 Tesalonika 1-5",
            "th": "1 เธสะโลนิกา 1-5",
            "km": "១ ថែស្សាឡូនីច 1-5"
          },
          "scene": {
            "ko": "데살로니가 위치에서 데살로니가전서 1-5 본문 사건을 확인합니다.",
            "en": "Thessalonica: read and answer from 1 Thessalonians 1-5.",
            "ja": "テサロニケの地点で、テサロニケ人への手紙第一 1-5の本文出来事を確認します。",
            "ms": "Di lokasi Tesalonika, semak peristiwa teks 1 Tesalonika 1-5.",
            "th": "ที่ตำแหน่งเธสะโลนิกา ให้ตรวจสอบเหตุการณ์ใน1 เธสะโลนิกา 1-5",
            "km": "នៅទីតាំងថេស្សាឡូនិក សូមពិនិត្យព្រឹត្តិការណ៍ក្នុង១ ថែស្សាឡូនីច 1-5។"
          },
          "mission": {
            "ko": "데살로니가 여정에서 데살로니가전서 5장 본문 문제를 풉니다.",
            "en": "Follow Thessalonica and answer 1 Thessalonians 5 chapters question bank.",
            "ja": "テサロニケの旅で、テサロニケ人への手紙第一5章の問題バンクに答えます。",
            "ms": "Ikuti Tesalonika dan jawab bank soalan 1 Tesalonika 5 bab.",
            "th": "ติดตามเส้นทางเธสะโลนิกาและตอบคลังคำถามจาก1 เธสะโลนิกา 5 บท",
            "km": "តាមដានដំណើរថេស្សាឡូនិក ហើយឆ្លើយធនាគារសំណួរពី១ ថែស្សាឡូនីច 5 ជំពូក។"
          }
        },
        {
          "stage_id": "2TH-001",
          "title": {
            "ko": "데살로니가",
            "en": "Thessalonica",
            "ja": "テサロニケ",
            "ms": "Tesalonika",
            "th": "เธสะโลนิกา",
            "km": "ថេស្សាឡូនិក"
          },
          "short_title": {
            "ko": "데살로니가",
            "en": "Thessalonica",
            "ja": "テサロニケ",
            "ms": "Tesalonika",
            "th": "เธสะโลนิกา",
            "km": "ថេស្សាឡូនិក"
          },
          "book_title": {
            "ko": "데살로니가후서",
            "en": "2 Thessalonians",
            "ja": "テサロニケ人への手紙第二",
            "ms": "2 Tesalonika",
            "th": "2 เธสะโลนิกา",
            "km": "២ ថែស្សាឡូនីច"
          },
          "map_query": "Thessalonica Greece biblical location",
          "map_region": "macedonia",
          "map_x": 36.5,
          "map_y": 23.1,
          "route_group": "letters",
          "place_names": [
            "데살로니가",
            "Thessalonica",
            "데살로니가",
            "Thessalonica",
            "テサロニケ",
            "Tesalonika",
            "เธสะโลนิกา",
            "ថេស្សាឡូនិក"
          ],
          "reference": "데살로니가후서 1-3",
          "references": {
            "ko": "데살로니가후서 1-3",
            "en": "2 Thessalonians 1-3",
            "ja": "テサロニケ人への手紙第二 1-3",
            "ms": "2 Tesalonika 1-3",
            "th": "2 เธสะโลนิกา 1-3",
            "km": "២ ថែស្សាឡូនីច 1-3"
          },
          "scene": {
            "ko": "데살로니가 위치에서 데살로니가후서 1-3 본문 사건을 확인합니다.",
            "en": "Thessalonica: read and answer from 2 Thessalonians 1-3.",
            "ja": "テサロニケの地点で、テサロニケ人への手紙第二 1-3の本文出来事を確認します。",
            "ms": "Di lokasi Tesalonika, semak peristiwa teks 2 Tesalonika 1-3.",
            "th": "ที่ตำแหน่งเธสะโลนิกา ให้ตรวจสอบเหตุการณ์ใน2 เธสะโลนิกา 1-3",
            "km": "នៅទីតាំងថេស្សាឡូនិក សូមពិនិត្យព្រឹត្តិការណ៍ក្នុង២ ថែស្សាឡូនីច 1-3។"
          },
          "mission": {
            "ko": "데살로니가 여정에서 데살로니가후서 3장 본문 문제를 풉니다.",
            "en": "Follow Thessalonica and answer 2 Thessalonians 3 chapters question bank.",
            "ja": "テサロニケの旅で、テサロニケ人への手紙第二3章の問題バンクに答えます。",
            "ms": "Ikuti Tesalonika dan jawab bank soalan 2 Tesalonika 3 bab.",
            "th": "ติดตามเส้นทางเธสะโลนิกาและตอบคลังคำถามจาก2 เธสะโลนิกา 3 บท",
            "km": "តាមដានដំណើរថេស្សាឡូនិក ហើយឆ្លើយធនាគារសំណួរពី២ ថែស្សាឡូនីច 3 ជំពូក។"
          }
        },
        {
          "stage_id": "1TI-001",
          "title": {
            "ko": "에베소",
            "en": "Ephesus",
            "ja": "エフェソ",
            "ms": "Efesus",
            "th": "เอเฟซัส",
            "km": "អេភេសូរ"
          },
          "short_title": {
            "ko": "에베소",
            "en": "Ephesus",
            "ja": "エフェソ",
            "ms": "Efesus",
            "th": "เอเฟซัส",
            "km": "អេភេសូរ"
          },
          "book_title": {
            "ko": "디모데전서",
            "en": "1 Timothy",
            "ja": "テモテへの手紙第一",
            "ms": "1 Timotius",
            "th": "1 ทิโมธี",
            "km": "១ ធីម៉ូថេ"
          },
          "map_query": "Ephesus Timothy biblical location",
          "map_region": "asia-minor",
          "map_x": 51.5,
          "map_y": 37.8,
          "route_group": "letters",
          "place_names": [
            "에베소",
            "Ephesus",
            "에베소",
            "Ephesus",
            "エフェソ",
            "Efesus",
            "เอเฟซัส",
            "អេភេសូរ"
          ],
          "reference": "디모데전서 1-6",
          "references": {
            "ko": "디모데전서 1-6",
            "en": "1 Timothy 1-6",
            "ja": "テモテへの手紙第一 1-6",
            "ms": "1 Timotius 1-6",
            "th": "1 ทิโมธี 1-6",
            "km": "១ ធីម៉ូថេ 1-6"
          },
          "scene": {
            "ko": "에베소 위치에서 디모데전서 1-6 본문 사건을 확인합니다.",
            "en": "Ephesus: read and answer from 1 Timothy 1-6.",
            "ja": "エフェソの地点で、テモテへの手紙第一 1-6の本文出来事を確認します。",
            "ms": "Di lokasi Efesus, semak peristiwa teks 1 Timotius 1-6.",
            "th": "ที่ตำแหน่งเอเฟซัส ให้ตรวจสอบเหตุการณ์ใน1 ทิโมธี 1-6",
            "km": "នៅទីតាំងអេភេសូរ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុង១ ធីម៉ូថេ 1-6។"
          },
          "mission": {
            "ko": "에베소 여정에서 디모데전서 6장 본문 문제를 풉니다.",
            "en": "Follow Ephesus and answer 1 Timothy 6 chapters question bank.",
            "ja": "エフェソの旅で、テモテへの手紙第一6章の問題バンクに答えます。",
            "ms": "Ikuti Efesus dan jawab bank soalan 1 Timotius 6 bab.",
            "th": "ติดตามเส้นทางเอเฟซัสและตอบคลังคำถามจาก1 ทิโมธี 6 บท",
            "km": "តាមដានដំណើរអេភេសូរ ហើយឆ្លើយធនាគារសំណួរពី១ ធីម៉ូថេ 6 ជំពូក។"
          }
        }
      ]
    },
    {
      "chapter_id": "NT-PAUL-C03",
      "book_id": "2TI",
      "section_key": "pauline",
      "world_id": "W_NT_PAUL",
      "order_index": 73,
      "title": {
        "ko": "로마 감옥 → 고린도+",
        "en": "Rome Prison → Corinth+",
        "ja": "ローマの獄 → コリント+",
        "ms": "Penjara Roma → Korintus+",
        "th": "คุกในโรม → โครินธ์+",
        "km": "គុកនៅរ៉ូម → កូរិនថូស+"
      },
      "summary": {
        "ko": "로마 감옥 / 그레데 / 골로새 / 로마+ / 고린도+ 길을 따라 신약 3. 바울서신 본문 사건을 풉니다.",
        "en": "Follow Rome Prison / Crete / Colossae / Rome+ / Corinth+ through New Testament 3. Pauline Epistles.",
        "ja": "ローマの獄 / クレタ / コロサイ / ローマ+ / コリント+の道をたどり、新約3. パウロ書簡の本文出来事を解きます。",
        "ms": "Ikuti laluan Penjara Roma / Kreta / Kolose / Roma+ / Korintus+ dan jawab peristiwa teks Perjanjian Baru 3. Surat Paulus.",
        "th": "ติดตามเส้นทาง คุกในโรม / เกาะครีต / โคโลสี / โรม+ / โครินธ์+ และตอบเหตุการณ์ในเนื้อหาพันธสัญญาใหม่ 3. จดหมายของเปาโล",
        "km": "តាមដានផ្លូវ គុកនៅរ៉ូម / ក្រេត / កូល៉ុស / រ៉ូម+ / កូរិនថូស+ ហើយឆ្លើយព្រឹត្តិការណ៍ក្នុងអត្ថបទសញ្ញាថ្មី ៣. សំបុត្ររបស់ប៉ូល។"
      },
      "stops": [
        {
          "stage_id": "2TI-001",
          "title": {
            "ko": "로마 감옥",
            "en": "Prison in Rome",
            "ja": "ローマの獄",
            "ms": "Penjara Roma",
            "th": "คุกในโรม",
            "km": "គុកនៅរ៉ូម"
          },
          "short_title": {
            "ko": "로마 감옥",
            "en": "Rome Prison",
            "ja": "ローマの獄",
            "ms": "Penjara Roma",
            "th": "คุกในโรม",
            "km": "គុកនៅរ៉ូម"
          },
          "book_title": {
            "ko": "디모데후서",
            "en": "2 Timothy",
            "ja": "テモテへの手紙第二",
            "ms": "2 Timotius",
            "th": "2 ทิโมธี",
            "km": "២ ធីម៉ូថេ"
          },
          "map_query": "Rome Italy Paul Timothy biblical location",
          "map_region": "rome",
          "map_x": 13.8,
          "map_y": 9.6,
          "route_group": "letters",
          "place_names": [
            "로마 감옥",
            "Prison in Rome",
            "로마 감옥",
            "Rome Prison",
            "ローマの獄",
            "Penjara Roma",
            "คุกในโรม",
            "គុកនៅរ៉ូម"
          ],
          "reference": "디모데후서 1-4",
          "references": {
            "ko": "디모데후서 1-4",
            "en": "2 Timothy 1-4",
            "ja": "テモテへの手紙第二 1-4",
            "ms": "2 Timotius 1-4",
            "th": "2 ทิโมธี 1-4",
            "km": "២ ធីម៉ូថេ 1-4"
          },
          "scene": {
            "ko": "로마 감옥 위치에서 디모데후서 1-4 본문 사건을 확인합니다.",
            "en": "Rome Prison: read and answer from 2 Timothy 1-4.",
            "ja": "ローマの獄の地点で、テモテへの手紙第二 1-4の本文出来事を確認します。",
            "ms": "Di lokasi Penjara Roma, semak peristiwa teks 2 Timotius 1-4.",
            "th": "ที่ตำแหน่งคุกในโรม ให้ตรวจสอบเหตุการณ์ใน2 ทิโมธี 1-4",
            "km": "នៅទីតាំងគុកនៅរ៉ូម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុង២ ធីម៉ូថេ 1-4។"
          },
          "mission": {
            "ko": "로마 감옥 여정에서 디모데후서 4장 본문 문제를 풉니다.",
            "en": "Follow Prison in Rome and answer 2 Timothy 4 chapters question bank.",
            "ja": "ローマの獄の旅で、テモテへの手紙第二4章の問題バンクに答えます。",
            "ms": "Ikuti Penjara Roma dan jawab bank soalan 2 Timotius 4 bab.",
            "th": "ติดตามเส้นทางคุกในโรมและตอบคลังคำถามจาก2 ทิโมธี 4 บท",
            "km": "តាមដានដំណើរគុកនៅរ៉ូម ហើយឆ្លើយធនាគារសំណួរពី២ ធីម៉ូថេ 4 ជំពូក។"
          }
        },
        {
          "stage_id": "TIT-001",
          "title": {
            "ko": "그레데",
            "en": "Crete",
            "ja": "クレタ",
            "ms": "Kreta",
            "th": "เกาะครีต",
            "km": "ក្រេត"
          },
          "short_title": {
            "ko": "그레데",
            "en": "Crete",
            "ja": "クレタ",
            "ms": "Kreta",
            "th": "เกาะครีต",
            "km": "ក្រេត"
          },
          "book_title": {
            "ko": "디도서",
            "en": "Titus",
            "ja": "テトスへの手紙",
            "ms": "Titus",
            "th": "ทิตัส",
            "km": "ទីតុស"
          },
          "map_query": "Crete Titus biblical location",
          "map_region": "crete",
          "map_x": 43.5,
          "map_y": 56.2,
          "route_group": "letters",
          "place_names": [
            "그레데",
            "Crete",
            "그레데",
            "Crete",
            "クレタ",
            "Kreta",
            "เกาะครีต",
            "ក្រេត"
          ],
          "reference": "디도서 1-3",
          "references": {
            "ko": "디도서 1-3",
            "en": "Titus 1-3",
            "ja": "テトスへの手紙 1-3",
            "ms": "Titus 1-3",
            "th": "ทิตัส 1-3",
            "km": "ទីតុស 1-3"
          },
          "scene": {
            "ko": "그레데 위치에서 디도서 1-3 본문 사건을 확인합니다.",
            "en": "Crete: read and answer from Titus 1-3.",
            "ja": "クレタの地点で、テトスへの手紙 1-3の本文出来事を確認します。",
            "ms": "Di lokasi Kreta, semak peristiwa teks Titus 1-3.",
            "th": "ที่ตำแหน่งเกาะครีต ให้ตรวจสอบเหตุการณ์ในทิตัส 1-3",
            "km": "នៅទីតាំងក្រេត សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងទីតុស 1-3។"
          },
          "mission": {
            "ko": "그레데 여정에서 디도서 3장 본문 문제를 풉니다.",
            "en": "Follow Crete and answer Titus 3 chapters question bank.",
            "ja": "クレタの旅で、テトスへの手紙3章の問題バンクに答えます。",
            "ms": "Ikuti Kreta dan jawab bank soalan Titus 3 bab.",
            "th": "ติดตามเส้นทางเกาะครีตและตอบคลังคำถามจากทิตัส 3 บท",
            "km": "តាមដានដំណើរក្រេត ហើយឆ្លើយធនាគារសំណួរពីទីតុស 3 ជំពូក។"
          }
        },
        {
          "stage_id": "PHM-001",
          "title": {
            "ko": "골로새",
            "en": "Colossae",
            "ja": "コロサイ",
            "ms": "Kolose",
            "th": "โคโลสี",
            "km": "កូល៉ុស"
          },
          "short_title": {
            "ko": "골로새",
            "en": "Colossae",
            "ja": "コロサイ",
            "ms": "Kolose",
            "th": "โคโลสี",
            "km": "កូល៉ុស"
          },
          "book_title": {
            "ko": "빌레몬서",
            "en": "Philemon",
            "ja": "ピレモンへの手紙",
            "ms": "Filemon",
            "th": "ฟีเลโมน",
            "km": "ភីលេម៉ូន"
          },
          "map_query": "Colossae Philemon biblical location",
          "map_region": "asia-minor",
          "map_x": 59.8,
          "map_y": 39.2,
          "route_group": "letters",
          "place_names": [
            "골로새",
            "Colossae",
            "골로새",
            "Colossae",
            "コロサイ",
            "Kolose",
            "โคโลสี",
            "កូល៉ុស"
          ],
          "reference": "빌레몬서 1",
          "references": {
            "ko": "빌레몬서 1",
            "en": "Philemon 1",
            "ja": "ピレモンへの手紙 1",
            "ms": "Filemon 1",
            "th": "ฟีเลโมน 1",
            "km": "ភីលេម៉ូន 1"
          },
          "scene": {
            "ko": "골로새 위치에서 빌레몬서 1 본문 사건을 확인합니다.",
            "en": "Colossae: read and answer from Philemon 1.",
            "ja": "コロサイの地点で、ピレモンへの手紙 1の本文出来事を確認します。",
            "ms": "Di lokasi Kolose, semak peristiwa teks Filemon 1.",
            "th": "ที่ตำแหน่งโคโลสี ให้ตรวจสอบเหตุการณ์ในฟีเลโมน 1",
            "km": "នៅទីតាំងកូល៉ុស សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងភីលេម៉ូន 1។"
          },
          "mission": {
            "ko": "골로새 여정에서 빌레몬서 1장 본문 문제를 풉니다.",
            "en": "Follow Colossae and answer Philemon 1 chapters question bank.",
            "ja": "コロサイの旅で、ピレモンへの手紙1章の問題バンクに答えます。",
            "ms": "Ikuti Kolose dan jawab bank soalan Filemon 1 bab.",
            "th": "ติดตามเส้นทางโคโลสีและตอบคลังคำถามจากฟีเลโมน 1 บท",
            "km": "តាមដានដំណើរកូល៉ុស ហើយឆ្លើយធនាគារសំណួរពីភីលេម៉ូន 1 ជំពូក។"
          }
        },
        {
          "stage_id": "ROM-REVIEW-14",
          "title": {
            "ko": "로마 복습",
            "en": "Rome Review",
            "ja": "ローマ 復習",
            "ms": "Roma Ulang kaji",
            "th": "โรม ทบทวน",
            "km": "រ៉ូម រំលឹក"
          },
          "short_title": {
            "ko": "로마+",
            "en": "Rome+",
            "ja": "ローマ+",
            "ms": "Roma+",
            "th": "โรม+",
            "km": "រ៉ូម+"
          },
          "book_title": {
            "ko": "로마서",
            "en": "Romans",
            "ja": "ローマ人への手紙",
            "ms": "Roma",
            "th": "โรม",
            "km": "រ៉ូម"
          },
          "map_query": "Rome Italy Romans biblical letter location review",
          "map_region": "rome",
          "map_x": 13.8,
          "map_y": 9.6,
          "route_group": "letters",
          "place_names": [
            "로마",
            "Rome",
            "로마",
            "Rome",
            "ローマ",
            "Roma",
            "โรม",
            "រ៉ូម"
          ],
          "reference": "로마서 1-16",
          "references": {
            "ko": "로마서 1-16",
            "en": "Romans 1-16",
            "ja": "ローマ人への手紙 1-16",
            "ms": "Roma 1-16",
            "th": "โรม 1-16",
            "km": "រ៉ូម 1-16"
          },
          "scene": {
            "ko": "로마+ 위치에서 로마서 1-16 본문 사건을 확인합니다.",
            "en": "Rome+: read and answer from Romans 1-16.",
            "ja": "ローマ+の地点で、ローマ人への手紙 1-16の本文出来事を確認します。",
            "ms": "Di lokasi Roma+, semak peristiwa teks Roma 1-16.",
            "th": "ที่ตำแหน่งโรม+ ให้ตรวจสอบเหตุการณ์ในโรม 1-16",
            "km": "នៅទីតាំងរ៉ូម+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងរ៉ូម 1-16។"
          },
          "mission": {
            "ko": "로마 길에서 로마서 주요 사건을 다시 확인합니다.",
            "en": "Review the main Romans events along Rome.",
            "ja": "ローマの道で、ローマ人への手紙の主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama Roma di sepanjang Roma.",
            "th": "ทบทวนเหตุการณ์สำคัญของโรมตามเส้นทางโรม",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃរ៉ូម តាមផ្លូវរ៉ូម។"
          }
        },
        {
          "stage_id": "1CO-REVIEW-15",
          "title": {
            "ko": "고린도 복습",
            "en": "Corinth Review",
            "ja": "コリント 復習",
            "ms": "Korintus Ulang kaji",
            "th": "โครินธ์ ทบทวน",
            "km": "កូរិនថូស រំលឹក"
          },
          "short_title": {
            "ko": "고린도+",
            "en": "Corinth+",
            "ja": "コリント+",
            "ms": "Korintus+",
            "th": "โครินธ์+",
            "km": "កូរិនថូស+"
          },
          "book_title": {
            "ko": "고린도전서",
            "en": "1 Corinthians",
            "ja": "コリント人への手紙第一",
            "ms": "1 Korintus",
            "th": "1 โครินธ์",
            "km": "១ កូរិនថូស"
          },
          "map_query": "Corinth Greece biblical location review",
          "map_region": "corinth",
          "map_x": 39.1,
          "map_y": 39.2,
          "route_group": "letters",
          "place_names": [
            "고린도",
            "Corinth",
            "고린도",
            "Corinth",
            "コリント",
            "Korintus",
            "โครินธ์",
            "កូរិនថូស"
          ],
          "reference": "고린도전서 1-16",
          "references": {
            "ko": "고린도전서 1-16",
            "en": "1 Corinthians 1-16",
            "ja": "コリント人への手紙第一 1-16",
            "ms": "1 Korintus 1-16",
            "th": "1 โครินธ์ 1-16",
            "km": "១ កូរិនថូស 1-16"
          },
          "scene": {
            "ko": "고린도+ 위치에서 고린도전서 1-16 본문 사건을 확인합니다.",
            "en": "Corinth+: read and answer from 1 Corinthians 1-16.",
            "ja": "コリント+の地点で、コリント人への手紙第一 1-16の本文出来事を確認します。",
            "ms": "Di lokasi Korintus+, semak peristiwa teks 1 Korintus 1-16.",
            "th": "ที่ตำแหน่งโครินธ์+ ให้ตรวจสอบเหตุการณ์ใน1 โครินธ์ 1-16",
            "km": "នៅទីតាំងកូរិនថូស+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុង១ កូរិនថូស 1-16។"
          },
          "mission": {
            "ko": "고린도 길에서 고린도전서 주요 사건을 다시 확인합니다.",
            "en": "Review the main 1 Corinthians events along Corinth.",
            "ja": "コリントの道で、コリント人への手紙第一の主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama 1 Korintus di sepanjang Korintus.",
            "th": "ทบทวนเหตุการณ์สำคัญของ1 โครินธ์ตามเส้นทางโครินธ์",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃ១ កូរិនថូស តាមផ្លូវកូរិនថូស។"
          }
        }
      ]
    },
    {
      "chapter_id": "NT-GEN-C01",
      "book_id": "HEB",
      "section_key": "general",
      "world_id": "W_NT_GEN",
      "order_index": 81,
      "title": {
        "ko": "성전 그림자 → 에베소·소아시아",
        "en": "Temple Pattern → Ephesus·Asia Minor",
        "ja": "神殿の型 → エフェソ·小アジア",
        "ms": "Pola Bait Suci → Efesus·Asia Kecil",
        "th": "แบบอย่างพระวิหาร → เอเฟซัส·เอเชียน้อย",
        "km": "គំរូព្រះវិហារ → អេភេសូរ·អាស៊ីតូច"
      },
      "summary": {
        "ko": "성전 그림자 / 흩어진 지파 / 소아시아 / 소아시아 / 에베소·소아시아 길을 따라 신약 4. 공동서신 본문 사건을 풉니다.",
        "en": "Follow Temple Pattern / Scattered Tribes / Asia Minor / Asia Minor / Ephesus·Asia Minor through New Testament 4. General Epistles.",
        "ja": "神殿の型 / 散らされた部族 / 小アジア / 小アジア / エフェソ·小アジアの道をたどり、新約4. 公同書簡の本文出来事を解きます。",
        "ms": "Ikuti laluan Pola Bait Suci / Suku yang terserak / Asia Kecil / Asia Kecil / Efesus·Asia Kecil dan jawab peristiwa teks Perjanjian Baru 4. Surat Umum.",
        "th": "ติดตามเส้นทาง แบบอย่างพระวิหาร / เผ่าที่กระจัดกระจาย / เอเชียน้อย / เอเชียน้อย / เอเฟซัส·เอเชียน้อย และตอบเหตุการณ์ในเนื้อหาพันธสัญญาใหม่ 4. จดหมายทั่วไป",
        "km": "តាមដានផ្លូវ គំរូព្រះវិហារ / កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ / អាស៊ីតូច / អាស៊ីតូច / អេភេសូរ·អាស៊ីតូច ហើយឆ្លើយព្រឹត្តិការណ៍ក្នុងអត្ថបទសញ្ញាថ្មី ៤. សំបុត្រទូទៅ។"
      },
      "stops": [
        {
          "stage_id": "HEB-001",
          "title": {
            "ko": "예루살렘 성전 그림자",
            "en": "Jerusalem Temple Pattern",
            "ja": "エルサレム神殿の型",
            "ms": "Pola Bait Suci Yerusalem",
            "th": "แบบอย่างพระวิหารเยรูซาเล็ม",
            "km": "គំរូព្រះវិហារយេរូសាឡឹម"
          },
          "short_title": {
            "ko": "성전 그림자",
            "en": "Temple Pattern",
            "ja": "神殿の型",
            "ms": "Pola Bait Suci",
            "th": "แบบอย่างพระวิหาร",
            "km": "គំរូព្រះវិហារ"
          },
          "book_title": {
            "ko": "히브리서",
            "en": "Hebrews",
            "ja": "ヘブル人への手紙",
            "ms": "Ibrani",
            "th": "ฮีบรู",
            "km": "ហេព្រើរ"
          },
          "map_query": "Jerusalem Hebrews biblical worship context",
          "map_region": "jerusalem",
          "map_x": 78,
          "map_y": 71,
          "route_group": "letters",
          "place_names": [
            "예루살렘 성전 그림자",
            "Jerusalem Temple Pattern",
            "성전 그림자",
            "Temple Pattern",
            "エルサレム神殿の型",
            "Pola Bait Suci Yerusalem",
            "แบบอย่างพระวิหารเยรูซาเล็ม",
            "គំរូព្រះវិហារយេរូសាឡឹម"
          ],
          "reference": "히브리서 1-13",
          "references": {
            "ko": "히브리서 1-13",
            "en": "Hebrews 1-13",
            "ja": "ヘブル人への手紙 1-13",
            "ms": "Ibrani 1-13",
            "th": "ฮีบรู 1-13",
            "km": "ហេព្រើរ 1-13"
          },
          "scene": {
            "ko": "성전 그림자 위치에서 히브리서 1-13 본문 사건을 확인합니다.",
            "en": "Temple Pattern: read and answer from Hebrews 1-13.",
            "ja": "神殿の型の地点で、ヘブル人への手紙 1-13の本文出来事を確認します。",
            "ms": "Di lokasi Pola Bait Suci, semak peristiwa teks Ibrani 1-13.",
            "th": "ที่ตำแหน่งแบบอย่างพระวิหาร ให้ตรวจสอบเหตุการณ์ในฮีบรู 1-13",
            "km": "នៅទីតាំងគំរូព្រះវិហារ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងហេព្រើរ 1-13។"
          },
          "mission": {
            "ko": "예루살렘 성전 그림자 여정에서 히브리서 13장 본문 문제를 풉니다.",
            "en": "Follow Jerusalem Temple Pattern and answer Hebrews 13 chapters question bank.",
            "ja": "エルサレム神殿の型の旅で、ヘブル人への手紙13章の問題バンクに答えます。",
            "ms": "Ikuti Pola Bait Suci Yerusalem dan jawab bank soalan Ibrani 13 bab.",
            "th": "ติดตามเส้นทางแบบอย่างพระวิหารเยรูซาเล็มและตอบคลังคำถามจากฮีบรู 13 บท",
            "km": "តាមដានដំណើរគំរូព្រះវិហារយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីហេព្រើរ 13 ជំពូក។"
          }
        },
        {
          "stage_id": "JAS-001",
          "title": {
            "ko": "예루살렘 · 흩어진 지파",
            "en": "Jerusalem · Scattered Tribes",
            "ja": "エルサレム · 散らされた部族",
            "ms": "Yerusalem · Suku yang terserak",
            "th": "เยรูซาเล็ม · เผ่าที่กระจัดกระจาย",
            "km": "យេរូសាឡឹម · កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ"
          },
          "short_title": {
            "ko": "흩어진 지파",
            "en": "Scattered Tribes",
            "ja": "散らされた部族",
            "ms": "Suku yang terserak",
            "th": "เผ่าที่กระจัดกระจาย",
            "km": "កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ"
          },
          "book_title": {
            "ko": "야고보서",
            "en": "James",
            "ja": "ヤコブの手紙",
            "ms": "Yakobus",
            "th": "ยากอบ",
            "km": "យ៉ាកុប"
          },
          "map_query": "Jerusalem James biblical location",
          "map_region": "jerusalem",
          "map_x": 78,
          "map_y": 71,
          "route_group": "letters",
          "place_names": [
            "예루살렘 · 흩어진 지파",
            "Jerusalem · Scattered Tribes",
            "흩어진 지파",
            "Scattered Tribes",
            "エルサレム · 散らされた部族",
            "Yerusalem · Suku yang terserak",
            "เยรูซาเล็ม · เผ่าที่กระจัดกระจาย",
            "យេរូសាឡឹម · កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ"
          ],
          "reference": "야고보서 1-5",
          "references": {
            "ko": "야고보서 1-5",
            "en": "James 1-5",
            "ja": "ヤコブの手紙 1-5",
            "ms": "Yakobus 1-5",
            "th": "ยากอบ 1-5",
            "km": "យ៉ាកុប 1-5"
          },
          "scene": {
            "ko": "흩어진 지파 위치에서 야고보서 1-5 본문 사건을 확인합니다.",
            "en": "Scattered Tribes: read and answer from James 1-5.",
            "ja": "散らされた部族の地点で、ヤコブの手紙 1-5の本文出来事を確認します。",
            "ms": "Di lokasi Suku yang terserak, semak peristiwa teks Yakobus 1-5.",
            "th": "ที่ตำแหน่งเผ่าที่กระจัดกระจาย ให้ตรวจสอบเหตุการณ์ในยากอบ 1-5",
            "km": "នៅទីតាំងកុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងយ៉ាកុប 1-5។"
          },
          "mission": {
            "ko": "예루살렘 · 흩어진 지파 여정에서 야고보서 5장 본문 문제를 풉니다.",
            "en": "Follow Jerusalem · Scattered Tribes and answer James 5 chapters question bank.",
            "ja": "エルサレム · 散らされた部族の旅で、ヤコブの手紙5章の問題バンクに答えます。",
            "ms": "Ikuti Yerusalem · Suku yang terserak dan jawab bank soalan Yakobus 5 bab.",
            "th": "ติดตามเส้นทางเยรูซาเล็ม · เผ่าที่กระจัดกระจายและตอบคลังคำถามจากยากอบ 5 บท",
            "km": "តាមដានដំណើរយេរូសាឡឹម · កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ ហើយឆ្លើយធនាគារសំណួរពីយ៉ាកុប 5 ជំពូក។"
          }
        },
        {
          "stage_id": "1PE-001",
          "title": {
            "ko": "소아시아 흩어진 성도",
            "en": "Scattered Believers in Asia Minor",
            "ja": "小アジアに散らされた信徒",
            "ms": "Orang percaya yang terserak di Asia Kecil",
            "th": "ผู้เชื่อที่กระจัดกระจายในเอเชียน้อย",
            "km": "អ្នកជឿដែលខ្ចាត់ខ្ចាយនៅអាស៊ីតូច"
          },
          "short_title": {
            "ko": "소아시아",
            "en": "Asia Minor",
            "ja": "小アジア",
            "ms": "Asia Kecil",
            "th": "เอเชียน้อย",
            "km": "អាស៊ីតូច"
          },
          "book_title": {
            "ko": "베드로전서",
            "en": "1 Peter",
            "ja": "ペテロの手紙第一",
            "ms": "1 Petrus",
            "th": "1 เปโตร",
            "km": "១ ពេត្រុស"
          },
          "map_query": "Asia Minor 1 Peter biblical recipients",
          "map_region": "asia-minor",
          "map_x": 63.8,
          "map_y": 32.2,
          "route_group": "letters",
          "place_names": [
            "소아시아 흩어진 성도",
            "Scattered Believers in Asia Minor",
            "소아시아",
            "Asia Minor",
            "小アジアに散らされた信徒",
            "Orang percaya yang terserak di Asia Kecil",
            "ผู้เชื่อที่กระจัดกระจายในเอเชียน้อย",
            "អ្នកជឿដែលខ្ចាត់ខ្ចាយនៅអាស៊ីតូច"
          ],
          "reference": "베드로전서 1-5",
          "references": {
            "ko": "베드로전서 1-5",
            "en": "1 Peter 1-5",
            "ja": "ペテロの手紙第一 1-5",
            "ms": "1 Petrus 1-5",
            "th": "1 เปโตร 1-5",
            "km": "១ ពេត្រុស 1-5"
          },
          "scene": {
            "ko": "소아시아 위치에서 베드로전서 1-5 본문 사건을 확인합니다.",
            "en": "Asia Minor: read and answer from 1 Peter 1-5.",
            "ja": "小アジアの地点で、ペテロの手紙第一 1-5の本文出来事を確認します。",
            "ms": "Di lokasi Asia Kecil, semak peristiwa teks 1 Petrus 1-5.",
            "th": "ที่ตำแหน่งเอเชียน้อย ให้ตรวจสอบเหตุการณ์ใน1 เปโตร 1-5",
            "km": "នៅទីតាំងអាស៊ីតូច សូមពិនិត្យព្រឹត្តិការណ៍ក្នុង១ ពេត្រុស 1-5។"
          },
          "mission": {
            "ko": "소아시아 흩어진 성도 여정에서 베드로전서 5장 본문 문제를 풉니다.",
            "en": "Follow Scattered Believers in Asia Minor and answer 1 Peter 5 chapters question bank.",
            "ja": "小アジアに散らされた信徒の旅で、ペテロの手紙第一5章の問題バンクに答えます。",
            "ms": "Ikuti Orang percaya yang terserak di Asia Kecil dan jawab bank soalan 1 Petrus 5 bab.",
            "th": "ติดตามเส้นทางผู้เชื่อที่กระจัดกระจายในเอเชียน้อยและตอบคลังคำถามจาก1 เปโตร 5 บท",
            "km": "តាមដានដំណើរអ្នកជឿដែលខ្ចាត់ខ្ចាយនៅអាស៊ីតូច ហើយឆ្លើយធនាគារសំណួរពី១ ពេត្រុស 5 ជំពូក។"
          }
        },
        {
          "stage_id": "2PE-001",
          "title": {
            "ko": "소아시아 교회",
            "en": "Churches in Asia Minor",
            "ja": "小アジアの教会",
            "ms": "Jemaat di Asia Kecil",
            "th": "คริสตจักรในเอเชียน้อย",
            "km": "ពួកជំនុំនៅអាស៊ីតូច"
          },
          "short_title": {
            "ko": "소아시아",
            "en": "Asia Minor",
            "ja": "小アジア",
            "ms": "Asia Kecil",
            "th": "เอเชียน้อย",
            "km": "អាស៊ីតូច"
          },
          "book_title": {
            "ko": "베드로후서",
            "en": "2 Peter",
            "ja": "ペテロの手紙第二",
            "ms": "2 Petrus",
            "th": "2 เปโตร",
            "km": "២ ពេត្រុស"
          },
          "map_query": "Asia Minor 2 Peter biblical recipients",
          "map_region": "asia-minor",
          "map_x": 63.8,
          "map_y": 32.2,
          "route_group": "letters",
          "place_names": [
            "소아시아 교회",
            "Churches in Asia Minor",
            "소아시아",
            "Asia Minor",
            "小アジアの教会",
            "Jemaat di Asia Kecil",
            "คริสตจักรในเอเชียน้อย",
            "ពួកជំនុំនៅអាស៊ីតូច"
          ],
          "reference": "베드로후서 1-3",
          "references": {
            "ko": "베드로후서 1-3",
            "en": "2 Peter 1-3",
            "ja": "ペテロの手紙第二 1-3",
            "ms": "2 Petrus 1-3",
            "th": "2 เปโตร 1-3",
            "km": "២ ពេត្រុស 1-3"
          },
          "scene": {
            "ko": "소아시아 위치에서 베드로후서 1-3 본문 사건을 확인합니다.",
            "en": "Asia Minor: read and answer from 2 Peter 1-3.",
            "ja": "小アジアの地点で、ペテロの手紙第二 1-3の本文出来事を確認します。",
            "ms": "Di lokasi Asia Kecil, semak peristiwa teks 2 Petrus 1-3.",
            "th": "ที่ตำแหน่งเอเชียน้อย ให้ตรวจสอบเหตุการณ์ใน2 เปโตร 1-3",
            "km": "នៅទីតាំងអាស៊ីតូច សូមពិនិត្យព្រឹត្តិការណ៍ក្នុង២ ពេត្រុស 1-3។"
          },
          "mission": {
            "ko": "소아시아 교회 여정에서 베드로후서 3장 본문 문제를 풉니다.",
            "en": "Follow Churches in Asia Minor and answer 2 Peter 3 chapters question bank.",
            "ja": "小アジアの教会の旅で、ペテロの手紙第二3章の問題バンクに答えます。",
            "ms": "Ikuti Jemaat di Asia Kecil dan jawab bank soalan 2 Petrus 3 bab.",
            "th": "ติดตามเส้นทางคริสตจักรในเอเชียน้อยและตอบคลังคำถามจาก2 เปโตร 3 บท",
            "km": "តាមដានដំណើរពួកជំនុំនៅអាស៊ីតូច ហើយឆ្លើយធនាគារសំណួរពី២ ពេត្រុស 3 ជំពូក។"
          }
        },
        {
          "stage_id": "1JN-001",
          "title": {
            "ko": "에베소 · 소아시아",
            "en": "Ephesus · Asia Minor",
            "ja": "エフェソ · 小アジア",
            "ms": "Efesus · Asia Kecil",
            "th": "เอเฟซัส · เอเชียน้อย",
            "km": "អេភេសូរ · អាស៊ីតូច"
          },
          "short_title": {
            "ko": "에베소·소아시아",
            "en": "Ephesus·Asia Minor",
            "ja": "エフェソ·小アジア",
            "ms": "Efesus·Asia Kecil",
            "th": "เอเฟซัส·เอเชียน้อย",
            "km": "អេភេសូរ·អាស៊ីតូច"
          },
          "book_title": {
            "ko": "요한일서",
            "en": "1 John",
            "ja": "ヨハネの手紙第一",
            "ms": "1 Yohanes",
            "th": "1 ยอห์น",
            "km": "១ យ៉ូហាន"
          },
          "map_query": "Ephesus Asia Minor 1 John biblical tradition",
          "map_region": "asia-minor",
          "map_x": 51.5,
          "map_y": 37.8,
          "route_group": "letters",
          "place_names": [
            "에베소 · 소아시아",
            "Ephesus · Asia Minor",
            "에베소·소아시아",
            "Ephesus·Asia Minor",
            "エフェソ · 小アジア",
            "Efesus · Asia Kecil",
            "เอเฟซัส · เอเชียน้อย",
            "អេភេសូរ · អាស៊ីតូច"
          ],
          "reference": "요한일서 1-5",
          "references": {
            "ko": "요한일서 1-5",
            "en": "1 John 1-5",
            "ja": "ヨハネの手紙第一 1-5",
            "ms": "1 Yohanes 1-5",
            "th": "1 ยอห์น 1-5",
            "km": "១ យ៉ូហាន 1-5"
          },
          "scene": {
            "ko": "에베소·소아시아 위치에서 요한일서 1-5 본문 사건을 확인합니다.",
            "en": "Ephesus·Asia Minor: read and answer from 1 John 1-5.",
            "ja": "エフェソ·小アジアの地点で、ヨハネの手紙第一 1-5の本文出来事を確認します。",
            "ms": "Di lokasi Efesus·Asia Kecil, semak peristiwa teks 1 Yohanes 1-5.",
            "th": "ที่ตำแหน่งเอเฟซัส·เอเชียน้อย ให้ตรวจสอบเหตุการณ์ใน1 ยอห์น 1-5",
            "km": "នៅទីតាំងអេភេសូរ·អាស៊ីតូច សូមពិនិត្យព្រឹត្តិការណ៍ក្នុង១ យ៉ូហាន 1-5។"
          },
          "mission": {
            "ko": "에베소 · 소아시아 여정에서 요한일서 5장 본문 문제를 풉니다.",
            "en": "Follow Ephesus · Asia Minor and answer 1 John 5 chapters question bank.",
            "ja": "エフェソ · 小アジアの旅で、ヨハネの手紙第一5章の問題バンクに答えます。",
            "ms": "Ikuti Efesus · Asia Kecil dan jawab bank soalan 1 Yohanes 5 bab.",
            "th": "ติดตามเส้นทางเอเฟซัส · เอเชียน้อยและตอบคลังคำถามจาก1 ยอห์น 5 บท",
            "km": "តាមដានដំណើរអេភេសូរ · អាស៊ីតូច ហើយឆ្លើយធនាគារសំណួរពី១ យ៉ូហាន 5 ជំពូក។"
          }
        }
      ]
    },
    {
      "chapter_id": "NT-GEN-C02",
      "book_id": "2JN",
      "section_key": "general",
      "world_id": "W_NT_GEN",
      "order_index": 82,
      "title": {
        "ko": "소아시아 → 흩어진 지파+",
        "en": "Asia Minor → Scattered Tribes+",
        "ja": "小アジア → 散らされた部族+",
        "ms": "Asia Kecil → Suku yang terserak+",
        "th": "เอเชียน้อย → เผ่าที่กระจัดกระจาย+",
        "km": "អាស៊ីតូច → កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ+"
      },
      "summary": {
        "ko": "소아시아 / 소아시아 / 예루살렘 공동체 / 성전 그림자+ / 흩어진 지파+ 길을 따라 신약 4. 공동서신 본문 사건을 풉니다.",
        "en": "Follow Asia Minor / Asia Minor / Jerusalem Community / Temple Pattern+ / Scattered Tribes+ through New Testament 4. General Epistles.",
        "ja": "小アジア / 小アジア / エルサレム共同体 / 神殿の型+ / 散らされた部族+の道をたどり、新約4. 公同書簡の本文出来事を解きます。",
        "ms": "Ikuti laluan Asia Kecil / Asia Kecil / Komuniti Yerusalem / Pola Bait Suci+ / Suku yang terserak+ dan jawab peristiwa teks Perjanjian Baru 4. Surat Umum.",
        "th": "ติดตามเส้นทาง เอเชียน้อย / เอเชียน้อย / ชุมชนเยรูซาเล็ม / แบบอย่างพระวิหาร+ / เผ่าที่กระจัดกระจาย+ และตอบเหตุการณ์ในเนื้อหาพันธสัญญาใหม่ 4. จดหมายทั่วไป",
        "km": "តាមដានផ្លូវ អាស៊ីតូច / អាស៊ីតូច / សហគមន៍យេរូសាឡឹម / គំរូព្រះវិហារ+ / កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ+ ហើយឆ្លើយព្រឹត្តិការណ៍ក្នុងអត្ថបទសញ្ញាថ្មី ៤. សំបុត្រទូទៅ។"
      },
      "stops": [
        {
          "stage_id": "2JN-001",
          "title": {
            "ko": "소아시아 교회",
            "en": "Churches in Asia Minor",
            "ja": "小アジアの教会",
            "ms": "Jemaat di Asia Kecil",
            "th": "คริสตจักรในเอเชียน้อย",
            "km": "ពួកជំនុំនៅអាស៊ីតូច"
          },
          "short_title": {
            "ko": "소아시아",
            "en": "Asia Minor",
            "ja": "小アジア",
            "ms": "Asia Kecil",
            "th": "เอเชียน้อย",
            "km": "អាស៊ីតូច"
          },
          "book_title": {
            "ko": "요한이서",
            "en": "2 John",
            "ja": "ヨハネの手紙第二",
            "ms": "2 Yohanes",
            "th": "2 ยอห์น",
            "km": "២ យ៉ូហាន"
          },
          "map_query": "Ephesus Asia Minor 2 John biblical tradition",
          "map_region": "asia-minor",
          "map_x": 51.5,
          "map_y": 37.8,
          "route_group": "letters",
          "place_names": [
            "소아시아 교회",
            "Churches in Asia Minor",
            "소아시아",
            "Asia Minor",
            "小アジアの教会",
            "Jemaat di Asia Kecil",
            "คริสตจักรในเอเชียน้อย",
            "ពួកជំនុំនៅអាស៊ីតូច"
          ],
          "reference": "요한이서 1",
          "references": {
            "ko": "요한이서 1",
            "en": "2 John 1",
            "ja": "ヨハネの手紙第二 1",
            "ms": "2 Yohanes 1",
            "th": "2 ยอห์น 1",
            "km": "២ យ៉ូហាន 1"
          },
          "scene": {
            "ko": "소아시아 위치에서 요한이서 1 본문 사건을 확인합니다.",
            "en": "Asia Minor: read and answer from 2 John 1.",
            "ja": "小アジアの地点で、ヨハネの手紙第二 1の本文出来事を確認します。",
            "ms": "Di lokasi Asia Kecil, semak peristiwa teks 2 Yohanes 1.",
            "th": "ที่ตำแหน่งเอเชียน้อย ให้ตรวจสอบเหตุการณ์ใน2 ยอห์น 1",
            "km": "នៅទីតាំងអាស៊ីតូច សូមពិនិត្យព្រឹត្តិការណ៍ក្នុង២ យ៉ូហាន 1។"
          },
          "mission": {
            "ko": "소아시아 교회 여정에서 요한이서 1장 본문 문제를 풉니다.",
            "en": "Follow Churches in Asia Minor and answer 2 John 1 chapters question bank.",
            "ja": "小アジアの教会の旅で、ヨハネの手紙第二1章の問題バンクに答えます。",
            "ms": "Ikuti Jemaat di Asia Kecil dan jawab bank soalan 2 Yohanes 1 bab.",
            "th": "ติดตามเส้นทางคริสตจักรในเอเชียน้อยและตอบคลังคำถามจาก2 ยอห์น 1 บท",
            "km": "តាមដានដំណើរពួកជំនុំនៅអាស៊ីតូច ហើយឆ្លើយធនាគារសំណួរពី២ យ៉ូហាន 1 ជំពូក។"
          }
        },
        {
          "stage_id": "3JN-001",
          "title": {
            "ko": "소아시아 교회",
            "en": "Churches in Asia Minor",
            "ja": "小アジアの教会",
            "ms": "Jemaat di Asia Kecil",
            "th": "คริสตจักรในเอเชียน้อย",
            "km": "ពួកជំនុំនៅអាស៊ីតូច"
          },
          "short_title": {
            "ko": "소아시아",
            "en": "Asia Minor",
            "ja": "小アジア",
            "ms": "Asia Kecil",
            "th": "เอเชียน้อย",
            "km": "អាស៊ីតូច"
          },
          "book_title": {
            "ko": "요한삼서",
            "en": "3 John",
            "ja": "ヨハネの手紙第三",
            "ms": "3 Yohanes",
            "th": "3 ยอห์น",
            "km": "៣ យ៉ូហាន"
          },
          "map_query": "Ephesus Asia Minor 3 John biblical tradition",
          "map_region": "asia-minor",
          "map_x": 51.5,
          "map_y": 37.8,
          "route_group": "letters",
          "place_names": [
            "소아시아 교회",
            "Churches in Asia Minor",
            "소아시아",
            "Asia Minor",
            "小アジアの教会",
            "Jemaat di Asia Kecil",
            "คริสตจักรในเอเชียน้อย",
            "ពួកជំនុំនៅអាស៊ីតូច"
          ],
          "reference": "요한삼서 1",
          "references": {
            "ko": "요한삼서 1",
            "en": "3 John 1",
            "ja": "ヨハネの手紙第三 1",
            "ms": "3 Yohanes 1",
            "th": "3 ยอห์น 1",
            "km": "៣ យ៉ូហាន 1"
          },
          "scene": {
            "ko": "소아시아 위치에서 요한삼서 1 본문 사건을 확인합니다.",
            "en": "Asia Minor: read and answer from 3 John 1.",
            "ja": "小アジアの地点で、ヨハネの手紙第三 1の本文出来事を確認します。",
            "ms": "Di lokasi Asia Kecil, semak peristiwa teks 3 Yohanes 1.",
            "th": "ที่ตำแหน่งเอเชียน้อย ให้ตรวจสอบเหตุการณ์ใน3 ยอห์น 1",
            "km": "នៅទីតាំងអាស៊ីតូច សូមពិនិត្យព្រឹត្តិការណ៍ក្នុង៣ យ៉ូហាន 1។"
          },
          "mission": {
            "ko": "소아시아 교회 여정에서 요한삼서 1장 본문 문제를 풉니다.",
            "en": "Follow Churches in Asia Minor and answer 3 John 1 chapters question bank.",
            "ja": "小アジアの教会の旅で、ヨハネの手紙第三1章の問題バンクに答えます。",
            "ms": "Ikuti Jemaat di Asia Kecil dan jawab bank soalan 3 Yohanes 1 bab.",
            "th": "ติดตามเส้นทางคริสตจักรในเอเชียน้อยและตอบคลังคำถามจาก3 ยอห์น 1 บท",
            "km": "តាមដានដំណើរពួកជំនុំនៅអាស៊ីតូច ហើយឆ្លើយធនាគារសំណួរពី៣ យ៉ូហាន 1 ជំពូក។"
          }
        },
        {
          "stage_id": "JUD-001",
          "title": {
            "ko": "예루살렘 형제 공동체",
            "en": "Jerusalem Brotherly Community",
            "ja": "エルサレムの兄弟共同体",
            "ms": "Komuniti saudara Yerusalem",
            "th": "ชุมชนพี่น้องเยรูซาเล็ม",
            "km": "សហគមន៍បងប្អូនយេរូសាឡឹម"
          },
          "short_title": {
            "ko": "예루살렘 공동체",
            "en": "Jerusalem Community",
            "ja": "エルサレム共同体",
            "ms": "Komuniti Yerusalem",
            "th": "ชุมชนเยรูซาเล็ม",
            "km": "សហគមន៍យេរូសាឡឹម"
          },
          "book_title": {
            "ko": "유다서",
            "en": "Jude",
            "ja": "ユダの手紙",
            "ms": "Yudas",
            "th": "ยูดา",
            "km": "យូដាស"
          },
          "map_query": "Jerusalem Jude biblical location",
          "map_region": "jerusalem",
          "map_x": 78,
          "map_y": 71,
          "route_group": "letters",
          "place_names": [
            "예루살렘 형제 공동체",
            "Jerusalem Brotherly Community",
            "예루살렘 공동체",
            "Jerusalem Community",
            "エルサレムの兄弟共同体",
            "Komuniti saudara Yerusalem",
            "ชุมชนพี่น้องเยรูซาเล็ม",
            "សហគមន៍បងប្អូនយេរូសាឡឹម"
          ],
          "reference": "유다서 1",
          "references": {
            "ko": "유다서 1",
            "en": "Jude 1",
            "ja": "ユダの手紙 1",
            "ms": "Yudas 1",
            "th": "ยูดา 1",
            "km": "យូដាស 1"
          },
          "scene": {
            "ko": "예루살렘 공동체 위치에서 유다서 1 본문 사건을 확인합니다.",
            "en": "Jerusalem Community: read and answer from Jude 1.",
            "ja": "エルサレム共同体の地点で、ユダの手紙 1の本文出来事を確認します。",
            "ms": "Di lokasi Komuniti Yerusalem, semak peristiwa teks Yudas 1.",
            "th": "ที่ตำแหน่งชุมชนเยรูซาเล็ม ให้ตรวจสอบเหตุการณ์ในยูดา 1",
            "km": "នៅទីតាំងសហគមន៍យេរូសាឡឹម សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងយូដាស 1។"
          },
          "mission": {
            "ko": "예루살렘 형제 공동체 여정에서 유다서 1장 본문 문제를 풉니다.",
            "en": "Follow Jerusalem Brotherly Community and answer Jude 1 chapters question bank.",
            "ja": "エルサレムの兄弟共同体の旅で、ユダの手紙1章の問題バンクに答えます。",
            "ms": "Ikuti Komuniti saudara Yerusalem dan jawab bank soalan Yudas 1 bab.",
            "th": "ติดตามเส้นทางชุมชนพี่น้องเยรูซาเล็มและตอบคลังคำถามจากยูดา 1 บท",
            "km": "តាមដានដំណើរសហគមន៍បងប្អូនយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីយូដាស 1 ជំពូក។"
          }
        },
        {
          "stage_id": "HEB-REVIEW-09",
          "title": {
            "ko": "예루살렘 성전 그림자 복습",
            "en": "Jerusalem Temple Pattern Review",
            "ja": "エルサレム神殿の型 復習",
            "ms": "Pola Bait Suci Yerusalem Ulang kaji",
            "th": "แบบอย่างพระวิหารเยรูซาเล็ม ทบทวน",
            "km": "គំរូព្រះវិហារយេរូសាឡឹម រំលឹក"
          },
          "short_title": {
            "ko": "성전 그림자+",
            "en": "Temple Pattern+",
            "ja": "神殿の型+",
            "ms": "Pola Bait Suci+",
            "th": "แบบอย่างพระวิหาร+",
            "km": "គំរូព្រះវិហារ+"
          },
          "book_title": {
            "ko": "히브리서",
            "en": "Hebrews",
            "ja": "ヘブル人への手紙",
            "ms": "Ibrani",
            "th": "ฮีบรู",
            "km": "ហេព្រើរ"
          },
          "map_query": "Jerusalem Hebrews biblical worship context review",
          "map_region": "jerusalem",
          "map_x": 78,
          "map_y": 71,
          "route_group": "letters",
          "place_names": [
            "예루살렘 성전 그림자",
            "Jerusalem Temple Pattern",
            "성전 그림자",
            "Temple Pattern",
            "エルサレム神殿の型",
            "Pola Bait Suci Yerusalem",
            "แบบอย่างพระวิหารเยรูซาเล็ม",
            "គំរូព្រះវិហារយេរូសាឡឹម"
          ],
          "reference": "히브리서 1-13",
          "references": {
            "ko": "히브리서 1-13",
            "en": "Hebrews 1-13",
            "ja": "ヘブル人への手紙 1-13",
            "ms": "Ibrani 1-13",
            "th": "ฮีบรู 1-13",
            "km": "ហេព្រើរ 1-13"
          },
          "scene": {
            "ko": "성전 그림자+ 위치에서 히브리서 1-13 본문 사건을 확인합니다.",
            "en": "Temple Pattern+: read and answer from Hebrews 1-13.",
            "ja": "神殿の型+の地点で、ヘブル人への手紙 1-13の本文出来事を確認します。",
            "ms": "Di lokasi Pola Bait Suci+, semak peristiwa teks Ibrani 1-13.",
            "th": "ที่ตำแหน่งแบบอย่างพระวิหาร+ ให้ตรวจสอบเหตุการณ์ในฮีบรู 1-13",
            "km": "នៅទីតាំងគំរូព្រះវិហារ+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងហេព្រើរ 1-13។"
          },
          "mission": {
            "ko": "예루살렘 성전 그림자 길에서 히브리서 주요 사건을 다시 확인합니다.",
            "en": "Review the main Hebrews events along Jerusalem Temple Pattern.",
            "ja": "エルサレム神殿の型の道で、ヘブル人への手紙の主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama Ibrani di sepanjang Pola Bait Suci Yerusalem.",
            "th": "ทบทวนเหตุการณ์สำคัญของฮีบรูตามเส้นทางแบบอย่างพระวิหารเยรูซาเล็ม",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃហេព្រើរ តាមផ្លូវគំរូព្រះវិហារយេរូសាឡឹម។"
          }
        },
        {
          "stage_id": "JAS-REVIEW-10",
          "title": {
            "ko": "예루살렘 · 흩어진 지파 복습",
            "en": "Jerusalem · Scattered Tribes Review",
            "ja": "エルサレム · 散らされた部族 復習",
            "ms": "Yerusalem · Suku yang terserak Ulang kaji",
            "th": "เยรูซาเล็ม · เผ่าที่กระจัดกระจาย ทบทวน",
            "km": "យេរូសាឡឹម · កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ រំលឹក"
          },
          "short_title": {
            "ko": "흩어진 지파+",
            "en": "Scattered Tribes+",
            "ja": "散らされた部族+",
            "ms": "Suku yang terserak+",
            "th": "เผ่าที่กระจัดกระจาย+",
            "km": "កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ+"
          },
          "book_title": {
            "ko": "야고보서",
            "en": "James",
            "ja": "ヤコブの手紙",
            "ms": "Yakobus",
            "th": "ยากอบ",
            "km": "យ៉ាកុប"
          },
          "map_query": "Jerusalem James biblical location review",
          "map_region": "jerusalem",
          "map_x": 78,
          "map_y": 71,
          "route_group": "letters",
          "place_names": [
            "예루살렘 · 흩어진 지파",
            "Jerusalem · Scattered Tribes",
            "흩어진 지파",
            "Scattered Tribes",
            "エルサレム · 散らされた部族",
            "Yerusalem · Suku yang terserak",
            "เยรูซาเล็ม · เผ่าที่กระจัดกระจาย",
            "យេរូសាឡឹម · កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ"
          ],
          "reference": "야고보서 1-5",
          "references": {
            "ko": "야고보서 1-5",
            "en": "James 1-5",
            "ja": "ヤコブの手紙 1-5",
            "ms": "Yakobus 1-5",
            "th": "ยากอบ 1-5",
            "km": "យ៉ាកុប 1-5"
          },
          "scene": {
            "ko": "흩어진 지파+ 위치에서 야고보서 1-5 본문 사건을 확인합니다.",
            "en": "Scattered Tribes+: read and answer from James 1-5.",
            "ja": "散らされた部族+の地点で、ヤコブの手紙 1-5の本文出来事を確認します。",
            "ms": "Di lokasi Suku yang terserak+, semak peristiwa teks Yakobus 1-5.",
            "th": "ที่ตำแหน่งเผ่าที่กระจัดกระจาย+ ให้ตรวจสอบเหตุการณ์ในยากอบ 1-5",
            "km": "នៅទីតាំងកុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងយ៉ាកុប 1-5។"
          },
          "mission": {
            "ko": "예루살렘 · 흩어진 지파 길에서 야고보서 주요 사건을 다시 확인합니다.",
            "en": "Review the main James events along Jerusalem · Scattered Tribes.",
            "ja": "エルサレム · 散らされた部族の道で、ヤコブの手紙の主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama Yakobus di sepanjang Yerusalem · Suku yang terserak.",
            "th": "ทบทวนเหตุการณ์สำคัญของยากอบตามเส้นทางเยรูซาเล็ม · เผ่าที่กระจัดกระจาย",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃយ៉ាកុប តាមផ្លូវយេរូសាឡឹម · កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ។"
          }
        }
      ]
    },
    {
      "chapter_id": "NT-PROP-C01",
      "book_id": "REV",
      "section_key": "prophecy",
      "world_id": "W_NT_PROP",
      "order_index": 91,
      "title": {
        "ko": "밧모섬·일곱 교회 → 밧모섬·일곱 교회+",
        "en": "Patmos·Seven Churches → Patmos·Seven Churches+",
        "ja": "パトモス·七つの教会 → パトモス·七つの教会+",
        "ms": "Patmos·Tujuh jemaat → Patmos·Tujuh jemaat+",
        "th": "ปัทมอส·คริสตจักรทั้งเจ็ด → ปัทมอส·คริสตจักรทั้งเจ็ด+",
        "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ → ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+"
      },
      "summary": {
        "ko": "밧모섬·일곱 교회 / 밧모섬·일곱 교회+ / 밧모섬·일곱 교회+ / 밧모섬·일곱 교회+ / 밧모섬·일곱 교회+ 길을 따라 신약 5. 예언서 본문 사건을 풉니다.",
        "en": "Follow Patmos·Seven Churches / Patmos·Seven Churches+ / Patmos·Seven Churches+ / Patmos·Seven Churches+ / Patmos·Seven Churches+ through New Testament 5. Prophecy.",
        "ja": "パトモス·七つの教会 / パトモス·七つの教会+ / パトモス·七つの教会+ / パトモス·七つの教会+ / パトモス·七つの教会+の道をたどり、新約5. 預言書の本文出来事を解きます。",
        "ms": "Ikuti laluan Patmos·Tujuh jemaat / Patmos·Tujuh jemaat+ / Patmos·Tujuh jemaat+ / Patmos·Tujuh jemaat+ / Patmos·Tujuh jemaat+ dan jawab peristiwa teks Perjanjian Baru 5. Nubuat.",
        "th": "ติดตามเส้นทาง ปัทมอส·คริสตจักรทั้งเจ็ด / ปัทมอส·คริสตจักรทั้งเจ็ด+ / ปัทมอส·คริสตจักรทั้งเจ็ด+ / ปัทมอส·คริสตจักรทั้งเจ็ด+ / ปัทมอส·คริสตจักรทั้งเจ็ด+ และตอบเหตุการณ์ในเนื้อหาพันธสัญญาใหม่ 5. คำพยากรณ์",
        "km": "តាមដានផ្លូវ ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ / ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+ / ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+ / ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+ / ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+ ហើយឆ្លើយព្រឹត្តិការណ៍ក្នុងអត្ថបទសញ្ញាថ្មី ៥. ទំនាយ។"
      },
      "stops": [
        {
          "stage_id": "REV-001",
          "title": {
            "ko": "밧모섬 · 소아시아 일곱 교회",
            "en": "Patmos · Seven Churches of Asia",
            "ja": "パトモス · アジアの七つの教会",
            "ms": "Patmos · Tujuh jemaat Asia",
            "th": "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
            "km": "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី"
          },
          "short_title": {
            "ko": "밧모섬·일곱 교회",
            "en": "Patmos·Seven Churches",
            "ja": "パトモス·七つの教会",
            "ms": "Patmos·Tujuh jemaat",
            "th": "ปัทมอส·คริสตจักรทั้งเจ็ด",
            "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ"
          },
          "book_title": {
            "ko": "요한계시록",
            "en": "Revelation",
            "ja": "黙示録",
            "ms": "Wahyu",
            "th": "วิวรณ์",
            "km": "វិវរណៈ"
          },
          "map_query": "Patmos Greece Revelation biblical location",
          "map_region": "patmos",
          "map_x": 52.5,
          "map_y": 43.5,
          "route_group": "prophecy",
          "place_names": [
            "밧모섬 · 소아시아 일곱 교회",
            "Patmos · Seven Churches of Asia",
            "밧모섬·일곱 교회",
            "Patmos·Seven Churches",
            "パトモス · アジアの七つの教会",
            "Patmos · Tujuh jemaat Asia",
            "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
            "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី"
          ],
          "reference": "요한계시록 1-22",
          "references": {
            "ko": "요한계시록 1-22",
            "en": "Revelation 1-22",
            "ja": "黙示録 1-22",
            "ms": "Wahyu 1-22",
            "th": "วิวรณ์ 1-22",
            "km": "វិវរណៈ 1-22"
          },
          "scene": {
            "ko": "밧모섬·일곱 교회 위치에서 요한계시록 1-22 본문 사건을 확인합니다.",
            "en": "Patmos·Seven Churches: read and answer from Revelation 1-22.",
            "ja": "パトモス·七つの教会の地点で、黙示録 1-22の本文出来事を確認します。",
            "ms": "Di lokasi Patmos·Tujuh jemaat, semak peristiwa teks Wahyu 1-22.",
            "th": "ที่ตำแหน่งปัทมอส·คริสตจักรทั้งเจ็ด ให้ตรวจสอบเหตุการณ์ในวิวรณ์ 1-22",
            "km": "នៅទីតាំងប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងវិវរណៈ 1-22។"
          },
          "mission": {
            "ko": "밧모섬 · 소아시아 일곱 교회 여정에서 요한계시록 22장 본문 문제를 풉니다.",
            "en": "Follow Patmos · Seven Churches of Asia and answer Revelation 22 chapters question bank.",
            "ja": "パトモス · アジアの七つの教会の旅で、黙示録22章の問題バンクに答えます。",
            "ms": "Ikuti Patmos · Tujuh jemaat Asia dan jawab bank soalan Wahyu 22 bab.",
            "th": "ติดตามเส้นทางปัทมอส · คริสตจักรทั้งเจ็ดในเอเชียและตอบคลังคำถามจากวิวรณ์ 22 บท",
            "km": "តាមដានដំណើរប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី ហើយឆ្លើយធនាគារសំណួរពីវិវរណៈ 22 ជំពូក។"
          }
        },
        {
          "stage_id": "REV-REVIEW-02",
          "title": {
            "ko": "밧모섬 · 소아시아 일곱 교회 복습",
            "en": "Patmos · Seven Churches of Asia Review",
            "ja": "パトモス · アジアの七つの教会 復習",
            "ms": "Patmos · Tujuh jemaat Asia Ulang kaji",
            "th": "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย ทบทวน",
            "km": "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី រំលឹក"
          },
          "short_title": {
            "ko": "밧모섬·일곱 교회+",
            "en": "Patmos·Seven Churches+",
            "ja": "パトモス·七つの教会+",
            "ms": "Patmos·Tujuh jemaat+",
            "th": "ปัทมอส·คริสตจักรทั้งเจ็ด+",
            "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+"
          },
          "book_title": {
            "ko": "요한계시록",
            "en": "Revelation",
            "ja": "黙示録",
            "ms": "Wahyu",
            "th": "วิวรณ์",
            "km": "វិវរណៈ"
          },
          "map_query": "Patmos Greece Revelation biblical location review",
          "map_region": "patmos",
          "map_x": 52.5,
          "map_y": 43.5,
          "route_group": "prophecy",
          "place_names": [
            "밧모섬 · 소아시아 일곱 교회",
            "Patmos · Seven Churches of Asia",
            "밧모섬·일곱 교회",
            "Patmos·Seven Churches",
            "パトモス · アジアの七つの教会",
            "Patmos · Tujuh jemaat Asia",
            "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
            "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី"
          ],
          "reference": "요한계시록 1-22",
          "references": {
            "ko": "요한계시록 1-22",
            "en": "Revelation 1-22",
            "ja": "黙示録 1-22",
            "ms": "Wahyu 1-22",
            "th": "วิวรณ์ 1-22",
            "km": "វិវរណៈ 1-22"
          },
          "scene": {
            "ko": "밧모섬·일곱 교회+ 위치에서 요한계시록 1-22 본문 사건을 확인합니다.",
            "en": "Patmos·Seven Churches+: read and answer from Revelation 1-22.",
            "ja": "パトモス·七つの教会+の地点で、黙示録 1-22の本文出来事を確認します。",
            "ms": "Di lokasi Patmos·Tujuh jemaat+, semak peristiwa teks Wahyu 1-22.",
            "th": "ที่ตำแหน่งปัทมอส·คริสตจักรทั้งเจ็ด+ ให้ตรวจสอบเหตุการณ์ในวิวรณ์ 1-22",
            "km": "នៅទីតាំងប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងវិវរណៈ 1-22។"
          },
          "mission": {
            "ko": "밧모섬 · 소아시아 일곱 교회 길에서 요한계시록 주요 사건을 다시 확인합니다.",
            "en": "Review the main Revelation events along Patmos · Seven Churches of Asia.",
            "ja": "パトモス · アジアの七つの教会の道で、黙示録の主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama Wahyu di sepanjang Patmos · Tujuh jemaat Asia.",
            "th": "ทบทวนเหตุการณ์สำคัญของวิวรณ์ตามเส้นทางปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃវិវរណៈ តាមផ្លូវប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី។"
          }
        },
        {
          "stage_id": "REV-REVIEW-03",
          "title": {
            "ko": "밧모섬 · 소아시아 일곱 교회 복습",
            "en": "Patmos · Seven Churches of Asia Review",
            "ja": "パトモス · アジアの七つの教会 復習",
            "ms": "Patmos · Tujuh jemaat Asia Ulang kaji",
            "th": "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย ทบทวน",
            "km": "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី រំលឹក"
          },
          "short_title": {
            "ko": "밧모섬·일곱 교회+",
            "en": "Patmos·Seven Churches+",
            "ja": "パトモス·七つの教会+",
            "ms": "Patmos·Tujuh jemaat+",
            "th": "ปัทมอส·คริสตจักรทั้งเจ็ด+",
            "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+"
          },
          "book_title": {
            "ko": "요한계시록",
            "en": "Revelation",
            "ja": "黙示録",
            "ms": "Wahyu",
            "th": "วิวรณ์",
            "km": "វិវរណៈ"
          },
          "map_query": "Patmos Greece Revelation biblical location review",
          "map_region": "patmos",
          "map_x": 52.5,
          "map_y": 43.5,
          "route_group": "prophecy",
          "place_names": [
            "밧모섬 · 소아시아 일곱 교회",
            "Patmos · Seven Churches of Asia",
            "밧모섬·일곱 교회",
            "Patmos·Seven Churches",
            "パトモス · アジアの七つの教会",
            "Patmos · Tujuh jemaat Asia",
            "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
            "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី"
          ],
          "reference": "요한계시록 1-22",
          "references": {
            "ko": "요한계시록 1-22",
            "en": "Revelation 1-22",
            "ja": "黙示録 1-22",
            "ms": "Wahyu 1-22",
            "th": "วิวรณ์ 1-22",
            "km": "វិវរណៈ 1-22"
          },
          "scene": {
            "ko": "밧모섬·일곱 교회+ 위치에서 요한계시록 1-22 본문 사건을 확인합니다.",
            "en": "Patmos·Seven Churches+: read and answer from Revelation 1-22.",
            "ja": "パトモス·七つの教会+の地点で、黙示録 1-22の本文出来事を確認します。",
            "ms": "Di lokasi Patmos·Tujuh jemaat+, semak peristiwa teks Wahyu 1-22.",
            "th": "ที่ตำแหน่งปัทมอส·คริสตจักรทั้งเจ็ด+ ให้ตรวจสอบเหตุการณ์ในวิวรณ์ 1-22",
            "km": "នៅទីតាំងប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងវិវរណៈ 1-22។"
          },
          "mission": {
            "ko": "밧모섬 · 소아시아 일곱 교회 길에서 요한계시록 주요 사건을 다시 확인합니다.",
            "en": "Review the main Revelation events along Patmos · Seven Churches of Asia.",
            "ja": "パトモス · アジアの七つの教会の道で、黙示録の主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama Wahyu di sepanjang Patmos · Tujuh jemaat Asia.",
            "th": "ทบทวนเหตุการณ์สำคัญของวิวรณ์ตามเส้นทางปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃវិវរណៈ តាមផ្លូវប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី។"
          }
        },
        {
          "stage_id": "REV-REVIEW-04",
          "title": {
            "ko": "밧모섬 · 소아시아 일곱 교회 복습",
            "en": "Patmos · Seven Churches of Asia Review",
            "ja": "パトモス · アジアの七つの教会 復習",
            "ms": "Patmos · Tujuh jemaat Asia Ulang kaji",
            "th": "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย ทบทวน",
            "km": "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី រំលឹក"
          },
          "short_title": {
            "ko": "밧모섬·일곱 교회+",
            "en": "Patmos·Seven Churches+",
            "ja": "パトモス·七つの教会+",
            "ms": "Patmos·Tujuh jemaat+",
            "th": "ปัทมอส·คริสตจักรทั้งเจ็ด+",
            "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+"
          },
          "book_title": {
            "ko": "요한계시록",
            "en": "Revelation",
            "ja": "黙示録",
            "ms": "Wahyu",
            "th": "วิวรณ์",
            "km": "វិវរណៈ"
          },
          "map_query": "Patmos Greece Revelation biblical location review",
          "map_region": "patmos",
          "map_x": 52.5,
          "map_y": 43.5,
          "route_group": "prophecy",
          "place_names": [
            "밧모섬 · 소아시아 일곱 교회",
            "Patmos · Seven Churches of Asia",
            "밧모섬·일곱 교회",
            "Patmos·Seven Churches",
            "パトモス · アジアの七つの教会",
            "Patmos · Tujuh jemaat Asia",
            "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
            "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី"
          ],
          "reference": "요한계시록 1-22",
          "references": {
            "ko": "요한계시록 1-22",
            "en": "Revelation 1-22",
            "ja": "黙示録 1-22",
            "ms": "Wahyu 1-22",
            "th": "วิวรณ์ 1-22",
            "km": "វិវរណៈ 1-22"
          },
          "scene": {
            "ko": "밧모섬·일곱 교회+ 위치에서 요한계시록 1-22 본문 사건을 확인합니다.",
            "en": "Patmos·Seven Churches+: read and answer from Revelation 1-22.",
            "ja": "パトモス·七つの教会+の地点で、黙示録 1-22の本文出来事を確認します。",
            "ms": "Di lokasi Patmos·Tujuh jemaat+, semak peristiwa teks Wahyu 1-22.",
            "th": "ที่ตำแหน่งปัทมอส·คริสตจักรทั้งเจ็ด+ ให้ตรวจสอบเหตุการณ์ในวิวรณ์ 1-22",
            "km": "នៅទីតាំងប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងវិវរណៈ 1-22។"
          },
          "mission": {
            "ko": "밧모섬 · 소아시아 일곱 교회 길에서 요한계시록 주요 사건을 다시 확인합니다.",
            "en": "Review the main Revelation events along Patmos · Seven Churches of Asia.",
            "ja": "パトモス · アジアの七つの教会の道で、黙示録の主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama Wahyu di sepanjang Patmos · Tujuh jemaat Asia.",
            "th": "ทบทวนเหตุการณ์สำคัญของวิวรณ์ตามเส้นทางปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃវិវរណៈ តាមផ្លូវប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី។"
          }
        },
        {
          "stage_id": "REV-REVIEW-05",
          "title": {
            "ko": "밧모섬 · 소아시아 일곱 교회 복습",
            "en": "Patmos · Seven Churches of Asia Review",
            "ja": "パトモス · アジアの七つの教会 復習",
            "ms": "Patmos · Tujuh jemaat Asia Ulang kaji",
            "th": "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย ทบทวน",
            "km": "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី រំលឹក"
          },
          "short_title": {
            "ko": "밧모섬·일곱 교회+",
            "en": "Patmos·Seven Churches+",
            "ja": "パトモス·七つの教会+",
            "ms": "Patmos·Tujuh jemaat+",
            "th": "ปัทมอส·คริสตจักรทั้งเจ็ด+",
            "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+"
          },
          "book_title": {
            "ko": "요한계시록",
            "en": "Revelation",
            "ja": "黙示録",
            "ms": "Wahyu",
            "th": "วิวรณ์",
            "km": "វិវរណៈ"
          },
          "map_query": "Patmos Greece Revelation biblical location review",
          "map_region": "patmos",
          "map_x": 52.5,
          "map_y": 43.5,
          "route_group": "prophecy",
          "place_names": [
            "밧모섬 · 소아시아 일곱 교회",
            "Patmos · Seven Churches of Asia",
            "밧모섬·일곱 교회",
            "Patmos·Seven Churches",
            "パトモス · アジアの七つの教会",
            "Patmos · Tujuh jemaat Asia",
            "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
            "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី"
          ],
          "reference": "요한계시록 1-22",
          "references": {
            "ko": "요한계시록 1-22",
            "en": "Revelation 1-22",
            "ja": "黙示録 1-22",
            "ms": "Wahyu 1-22",
            "th": "วิวรณ์ 1-22",
            "km": "វិវរណៈ 1-22"
          },
          "scene": {
            "ko": "밧모섬·일곱 교회+ 위치에서 요한계시록 1-22 본문 사건을 확인합니다.",
            "en": "Patmos·Seven Churches+: read and answer from Revelation 1-22.",
            "ja": "パトモス·七つの教会+の地点で、黙示録 1-22の本文出来事を確認します。",
            "ms": "Di lokasi Patmos·Tujuh jemaat+, semak peristiwa teks Wahyu 1-22.",
            "th": "ที่ตำแหน่งปัทมอส·คริสตจักรทั้งเจ็ด+ ให้ตรวจสอบเหตุการณ์ในวิวรณ์ 1-22",
            "km": "នៅទីតាំងប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+ សូមពិនិត្យព្រឹត្តិការណ៍ក្នុងវិវរណៈ 1-22។"
          },
          "mission": {
            "ko": "밧모섬 · 소아시아 일곱 교회 길에서 요한계시록 주요 사건을 다시 확인합니다.",
            "en": "Review the main Revelation events along Patmos · Seven Churches of Asia.",
            "ja": "パトモス · アジアの七つの教会の道で、黙示録の主な出来事を復習します。",
            "ms": "Ulang kaji peristiwa utama Wahyu di sepanjang Patmos · Tujuh jemaat Asia.",
            "th": "ทบทวนเหตุการณ์สำคัญของวิวรณ์ตามเส้นทางปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
            "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃវិវរណៈ តាមផ្លូវប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី។"
          }
        }
      ]
    }
  ],
  "stages": [
    {
      "stage_id": "GEN-001",
      "world_id": "W_OT_PENT",
      "section_key": "pentateuch",
      "book_id": "GEN",
      "book_order": 1,
      "order_index": 1,
      "title": {
        "ko": "에덴 · 아라랏산 · 바벨",
        "en": "Eden · Mount Ararat · Babel",
        "ja": "エデン · アララト山 · バベル",
        "ms": "Eden · Gunung Ararat · Babel",
        "th": "เอเดน · ภูเขาอารารัต · บาเบล",
        "km": "អេដែន · ភ្នំអារ៉ារ៉ាត់ · បាបិល"
      },
      "short_title": {
        "ko": "에덴·아라랏·바벨",
        "en": "Eden·Ararat·Babel",
        "ja": "エデン·アララト·バベル",
        "ms": "Eden·Ararat·Babel",
        "th": "เอเดน·อารารัต·บาเบล",
        "km": "អេដែន·អារ៉ារ៉ាត់·បាបិល"
      },
      "book_title": {
        "ko": "창세기",
        "en": "Genesis",
        "ja": "創世記",
        "ms": "Kejadian",
        "th": "ปฐมกาล",
        "km": "លោកុប្បត្តិ"
      },
      "bible_range": "창세기 1-50",
      "references": {
        "ko": "창세기 1-50",
        "en": "Genesis 1-50",
        "ja": "創世記 1-50",
        "ms": "Kejadian 1-50",
        "th": "ปฐมกาล 1-50",
        "km": "លោកុប្បត្តិ 1-50"
      },
      "mission": {
        "ko": "에덴 · 아라랏산 · 바벨 여정에서 창세기 50장 본문 문제를 풉니다.",
        "en": "Follow Eden · Mount Ararat · Babel and answer Genesis 50 chapters question bank.",
        "ja": "エデン · アララト山 · バベルの旅で、創世記50章の問題バンクに答えます。",
        "ms": "Ikuti Eden · Gunung Ararat · Babel dan jawab bank soalan Kejadian 50 bab.",
        "th": "ติดตามเส้นทางเอเดน · ภูเขาอารารัต · บาเบลและตอบคลังคำถามจากปฐมกาล 50 บท",
        "km": "តាមដានដំណើរអេដែន · ភ្នំអារ៉ារ៉ាត់ · បាបិល ហើយឆ្លើយធនាគារសំណួរពីលោកុប្បត្តិ 50 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-GEN-001",
      "next_stage_id": "EXO-001",
      "asset_key": "asset.stage.gen",
      "difficulty": "basic",
      "map_query": "Garden of Eden and Ararat biblical route",
      "map_region": "babylon",
      "map_x": 61.7,
      "map_y": 66.5,
      "route_group": "old-testament",
      "place_names": [
        "에덴 · 아라랏산 · 바벨",
        "Eden · Mount Ararat · Babel",
        "에덴·아라랏·바벨",
        "Eden·Ararat·Babel",
        "エデン · アララト山 · バベル",
        "Eden · Gunung Ararat · Babel",
        "เอเดน · ภูเขาอารารัต · บาเบล",
        "អេដែន · ភ្នំអារ៉ារ៉ាត់ · បាបិល"
      ],
      "chapter_question_count": 50
    },
    {
      "stage_id": "EXO-001",
      "world_id": "W_OT_PENT",
      "section_key": "pentateuch",
      "book_id": "EXO",
      "book_order": 2,
      "order_index": 2,
      "title": {
        "ko": "고센 · 홍해 · 시내산",
        "en": "Goshen · Red Sea · Mount Sinai",
        "ja": "ゴシェン · 紅海 · シナイ山",
        "ms": "Gosyen · Laut Merah · Gunung Sinai",
        "th": "โกเชน · ทะเลแดง · ภูเขาซีนาย",
        "km": "កូសែន · សមុទ្រក្រហម · ភ្នំស៊ីណាយ"
      },
      "short_title": {
        "ko": "고센·홍해·시내산",
        "en": "Goshen·Red Sea·Sinai",
        "ja": "ゴシェン·紅海·シナイ",
        "ms": "Gosyen·Laut Merah·Sinai",
        "th": "โกเชน·ทะเลแดง·ซีนาย",
        "km": "កូសែន·សមុទ្រក្រហម·ស៊ីណាយ"
      },
      "book_title": {
        "ko": "출애굽기",
        "en": "Exodus",
        "ja": "出エジプト記",
        "ms": "Keluaran",
        "th": "อพยพ",
        "km": "និក្ខមនំ"
      },
      "bible_range": "출애굽기 1-40",
      "references": {
        "ko": "출애굽기 1-40",
        "en": "Exodus 1-40",
        "ja": "出エジプト記 1-40",
        "ms": "Keluaran 1-40",
        "th": "อพยพ 1-40",
        "km": "និក្ខមនំ 1-40"
      },
      "mission": {
        "ko": "고센 · 홍해 · 시내산 여정에서 출애굽기 40장 본문 문제를 풉니다.",
        "en": "Follow Goshen · Red Sea · Mount Sinai and answer Exodus 40 chapters question bank.",
        "ja": "ゴシェン · 紅海 · シナイ山の旅で、出エジプト記40章の問題バンクに答えます。",
        "ms": "Ikuti Gosyen · Laut Merah · Gunung Sinai dan jawab bank soalan Keluaran 40 bab.",
        "th": "ติดตามเส้นทางโกเชน · ทะเลแดง · ภูเขาซีนายและตอบคลังคำถามจากอพยพ 40 บท",
        "km": "តាមដានដំណើរកូសែន · សមុទ្រក្រហម · ភ្នំស៊ីណាយ ហើយឆ្លើយធនាគារសំណួរពីនិក្ខមនំ 40 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-EXO-001",
      "next_stage_id": "LEV-001",
      "asset_key": "asset.stage.exo",
      "difficulty": "basic",
      "map_query": "Goshen Egypt to Mount Sinai biblical route",
      "map_region": "goshen",
      "map_x": 25.2,
      "map_y": 75.2,
      "route_group": "old-testament",
      "place_names": [
        "고센 · 홍해 · 시내산",
        "Goshen · Red Sea · Mount Sinai",
        "고센·홍해·시내산",
        "Goshen·Red Sea·Sinai",
        "ゴシェン · 紅海 · シナイ山",
        "Gosyen · Laut Merah · Gunung Sinai",
        "โกเชน · ทะเลแดง · ภูเขาซีนาย",
        "កូសែន · សមុទ្រក្រហម · ភ្នំស៊ីណាយ"
      ],
      "chapter_question_count": 42
    },
    {
      "stage_id": "LEV-001",
      "world_id": "W_OT_PENT",
      "section_key": "pentateuch",
      "book_id": "LEV",
      "book_order": 3,
      "order_index": 3,
      "title": {
        "ko": "시내산 회막",
        "en": "The Tent of Meeting at Sinai",
        "ja": "シナイの会見の天幕",
        "ms": "Khemah Pertemuan di Sinai",
        "th": "เต็นท์นัดพบที่ซีนาย",
        "km": "ត្រសាលជំនុំនៅស៊ីណាយ"
      },
      "short_title": {
        "ko": "시내산",
        "en": "Sinai",
        "ja": "シナイ",
        "ms": "Sinai",
        "th": "ซีนาย",
        "km": "ស៊ីណាយ"
      },
      "book_title": {
        "ko": "레위기",
        "en": "Leviticus",
        "ja": "レビ記",
        "ms": "Imamat",
        "th": "เลวีนิติ",
        "km": "លេវីវិន័យ"
      },
      "bible_range": "레위기 1-27",
      "references": {
        "ko": "레위기 1-27",
        "en": "Leviticus 1-27",
        "ja": "レビ記 1-27",
        "ms": "Imamat 1-27",
        "th": "เลวีนิติ 1-27",
        "km": "លេវីវិន័យ 1-27"
      },
      "mission": {
        "ko": "시내산 회막 여정에서 레위기 27장 본문 문제를 풉니다.",
        "en": "Follow The Tent of Meeting at Sinai and answer Leviticus 27 chapters question bank.",
        "ja": "シナイの会見の天幕の旅で、レビ記27章の問題バンクに答えます。",
        "ms": "Ikuti Khemah Pertemuan di Sinai dan jawab bank soalan Imamat 27 bab.",
        "th": "ติดตามเส้นทางเต็นท์นัดพบที่ซีนายและตอบคลังคำถามจากเลวีนิติ 27 บท",
        "km": "តាមដានដំណើរត្រសាលជំនុំនៅស៊ីណាយ ហើយឆ្លើយធនាគារសំណួរពីលេវីវិន័យ 27 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-LEV-001",
      "next_stage_id": "NUM-001",
      "asset_key": "asset.stage.lev",
      "difficulty": "basic",
      "map_query": "Mount Sinai biblical location",
      "map_region": "sinai",
      "map_x": 31.2,
      "map_y": 86.5,
      "route_group": "old-testament",
      "place_names": [
        "시내산 회막",
        "The Tent of Meeting at Sinai",
        "시내산",
        "Sinai",
        "シナイの会見の天幕",
        "Khemah Pertemuan di Sinai",
        "เต็นท์นัดพบที่ซีนาย",
        "ត្រសាលជំនុំនៅស៊ីណាយ"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "NUM-001",
      "world_id": "W_OT_PENT",
      "section_key": "pentateuch",
      "book_id": "NUM",
      "book_order": 4,
      "order_index": 4,
      "title": {
        "ko": "가데스 바네아 · 모압 평지",
        "en": "Kadesh-barnea · Plains of Moab",
        "ja": "カデシュ・バルネア · モアブの平野",
        "ms": "Kadesh-barnea · Dataran Moab",
        "th": "คาเดชบารเนีย · ที่ราบโมอับ",
        "km": "កាដេសបារនេា · វាលទំនាបម៉ូអាប់"
      },
      "short_title": {
        "ko": "가데스·모압",
        "en": "Kadesh·Moab",
        "ja": "カデシュ·モアブ",
        "ms": "Kadesh·Moab",
        "th": "คาเดช·โมอับ",
        "km": "កាដេស·ម៉ូអាប់"
      },
      "book_title": {
        "ko": "민수기",
        "en": "Numbers",
        "ja": "民数記",
        "ms": "Bilangan",
        "th": "กันดารวิถี",
        "km": "ជនគណនា"
      },
      "bible_range": "민수기 1-36",
      "references": {
        "ko": "민수기 1-36",
        "en": "Numbers 1-36",
        "ja": "民数記 1-36",
        "ms": "Bilangan 1-36",
        "th": "กันดารวิถี 1-36",
        "km": "ជនគណនា 1-36"
      },
      "mission": {
        "ko": "가데스 바네아 · 모압 평지 여정에서 민수기 36장 본문 문제를 풉니다.",
        "en": "Follow Kadesh-barnea · Plains of Moab and answer Numbers 36 chapters question bank.",
        "ja": "カデシュ・バルネア · モアブの平野の旅で、民数記36章の問題バンクに答えます。",
        "ms": "Ikuti Kadesh-barnea · Dataran Moab dan jawab bank soalan Bilangan 36 bab.",
        "th": "ติดตามเส้นทางคาเดชบารเนีย · ที่ราบโมอับและตอบคลังคำถามจากกันดารวิถี 36 บท",
        "km": "តាមដានដំណើរកាដេសបារនេា · វាលទំនាបម៉ូអាប់ ហើយឆ្លើយធនាគារសំណួរពីជនគណនា 36 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-NUM-001",
      "next_stage_id": "DEU-001",
      "asset_key": "asset.stage.num",
      "difficulty": "basic",
      "map_query": "Kadesh Barnea wilderness biblical location",
      "map_region": "kadesh",
      "map_x": 34.5,
      "map_y": 76.5,
      "route_group": "old-testament",
      "place_names": [
        "가데스 바네아 · 모압 평지",
        "Kadesh-barnea · Plains of Moab",
        "가데스·모압",
        "Kadesh·Moab",
        "カデシュ・バルネア · モアブの平野",
        "Kadesh-barnea · Dataran Moab",
        "คาเดชบารเนีย · ที่ราบโมอับ",
        "កាដេសបារនេា · វាលទំនាបម៉ូអាប់"
      ],
      "chapter_question_count": 36
    },
    {
      "stage_id": "DEU-001",
      "world_id": "W_OT_PENT",
      "section_key": "pentateuch",
      "book_id": "DEU",
      "book_order": 5,
      "order_index": 5,
      "title": {
        "ko": "느보산 · 모압 평지",
        "en": "Mount Nebo · Plains of Moab",
        "ja": "ネボ山 · モアブの平野",
        "ms": "Gunung Nebo · Dataran Moab",
        "th": "ภูเขาเนโบ · ที่ราบโมอับ",
        "km": "ភ្នំណេបូ · វាលទំនាបម៉ូអាប់"
      },
      "short_title": {
        "ko": "느보산",
        "en": "Mount Nebo",
        "ja": "ネボ山",
        "ms": "Gunung Nebo",
        "th": "ภูเขาเนโบ",
        "km": "ភ្នំណេបូ"
      },
      "book_title": {
        "ko": "신명기",
        "en": "Deuteronomy",
        "ja": "申命記",
        "ms": "Ulangan",
        "th": "เฉลยธรรมบัญญัติ",
        "km": "ចោទិយកថា"
      },
      "bible_range": "신명기 1-34",
      "references": {
        "ko": "신명기 1-34",
        "en": "Deuteronomy 1-34",
        "ja": "申命記 1-34",
        "ms": "Ulangan 1-34",
        "th": "เฉลยธรรมบัญญัติ 1-34",
        "km": "ចោទិយកថា 1-34"
      },
      "mission": {
        "ko": "느보산 · 모압 평지 여정에서 신명기 34장 본문 문제를 풉니다.",
        "en": "Follow Mount Nebo · Plains of Moab and answer Deuteronomy 34 chapters question bank.",
        "ja": "ネボ山 · モアブの平野の旅で、申命記34章の問題バンクに答えます。",
        "ms": "Ikuti Gunung Nebo · Dataran Moab dan jawab bank soalan Ulangan 34 bab.",
        "th": "ติดตามเส้นทางภูเขาเนโบ · ที่ราบโมอับและตอบคลังคำถามจากเฉลยธรรมบัญญัติ 34 บท",
        "km": "តាមដានដំណើរភ្នំណេបូ · វាលទំនាបម៉ូអាប់ ហើយឆ្លើយធនាគារសំណួរពីចោទិយកថា 34 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-DEU-001",
      "next_stage_id": "JOS-001",
      "asset_key": "asset.stage.deu",
      "difficulty": "basic",
      "map_query": "Mount Nebo Jordan biblical location",
      "map_region": "nebo",
      "map_x": 37.6,
      "map_y": 72.4,
      "route_group": "old-testament",
      "place_names": [
        "느보산 · 모압 평지",
        "Mount Nebo · Plains of Moab",
        "느보산",
        "Mount Nebo",
        "ネボ山 · モアブの平野",
        "Gunung Nebo · Dataran Moab",
        "ภูเขาเนโบ · ที่ราบโมอับ",
        "ភ្នំណេបូ · វាលទំនាបម៉ូអាប់"
      ],
      "chapter_question_count": 34
    },
    {
      "stage_id": "JOS-001",
      "world_id": "W_OT_HIST",
      "section_key": "history",
      "book_id": "JOS",
      "book_order": 6,
      "order_index": 6,
      "title": {
        "ko": "요단강 · 여리고",
        "en": "Jordan River · Jericho",
        "ja": "ヨルダン川 · エリコ",
        "ms": "Sungai Yordan · Yerikho",
        "th": "แม่น้ำจอร์แดน · เยรีโค",
        "km": "ទន្លេយ័រដាន់ · យេរីខូ"
      },
      "short_title": {
        "ko": "요단·여리고",
        "en": "Jordan·Jericho",
        "ja": "ヨルダン·エリコ",
        "ms": "Yordan·Yerikho",
        "th": "จอร์แดน·เยรีโค",
        "km": "យ័រដាន់·យេរីខូ"
      },
      "book_title": {
        "ko": "여호수아",
        "en": "Joshua",
        "ja": "ヨシュア記",
        "ms": "Yosua",
        "th": "โยชูวา",
        "km": "យ៉ូស្វេ"
      },
      "bible_range": "여호수아 1-24",
      "references": {
        "ko": "여호수아 1-24",
        "en": "Joshua 1-24",
        "ja": "ヨシュア記 1-24",
        "ms": "Yosua 1-24",
        "th": "โยชูวา 1-24",
        "km": "យ៉ូស្វេ 1-24"
      },
      "mission": {
        "ko": "요단강 · 여리고 여정에서 여호수아 24장 본문 문제를 풉니다.",
        "en": "Follow Jordan River · Jericho and answer Joshua 24 chapters question bank.",
        "ja": "ヨルダン川 · エリコの旅で、ヨシュア記24章の問題バンクに答えます。",
        "ms": "Ikuti Sungai Yordan · Yerikho dan jawab bank soalan Yosua 24 bab.",
        "th": "ติดตามเส้นทางแม่น้ำจอร์แดน · เยรีโคและตอบคลังคำถามจากโยชูวา 24 บท",
        "km": "តាមដានដំណើរទន្លេយ័រដាន់ · យេរីខូ ហើយឆ្លើយធនាគារសំណួរពីយ៉ូស្វេ 24 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-JOS-001",
      "next_stage_id": "JDG-001",
      "asset_key": "asset.stage.jos",
      "difficulty": "basic",
      "map_query": "Jericho archaeological site biblical Joshua",
      "map_region": "canaan",
      "map_x": 37.2,
      "map_y": 69.2,
      "route_group": "old-testament",
      "place_names": [
        "요단강 · 여리고",
        "Jordan River · Jericho",
        "요단·여리고",
        "Jordan·Jericho",
        "ヨルダン川 · エリコ",
        "Sungai Yordan · Yerikho",
        "แม่น้ำจอร์แดน · เยรีโค",
        "ទន្លេយ័រដាន់ · យេរីខូ"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "JDG-001",
      "world_id": "W_OT_HIST",
      "section_key": "history",
      "book_id": "JDG",
      "book_order": 7,
      "order_index": 7,
      "title": {
        "ko": "이스르엘 골짜기 · 가나안 산지",
        "en": "Jezreel Valley · Canaan Highlands",
        "ja": "イズレエルの谷 · カナン山地",
        "ms": "Lembah Yizreel · Tanah tinggi Kanaan",
        "th": "หุบเขายิสเรเอล · ที่ราบสูงคานาอัน",
        "km": "ជ្រលងយីសរេអែល · តំបន់ភ្នំកាណាន"
      },
      "short_title": {
        "ko": "이스르엘",
        "en": "Jezreel",
        "ja": "イズレエル",
        "ms": "Yizreel",
        "th": "ยิสเรเอล",
        "km": "យីសរេអែល"
      },
      "book_title": {
        "ko": "사사기",
        "en": "Judges",
        "ja": "士師記",
        "ms": "Hakim-hakim",
        "th": "ผู้วินิจฉัย",
        "km": "ពួកចៅហ្វាយ"
      },
      "bible_range": "사사기 1-21",
      "references": {
        "ko": "사사기 1-21",
        "en": "Judges 1-21",
        "ja": "士師記 1-21",
        "ms": "Hakim-hakim 1-21",
        "th": "ผู้วินิจฉัย 1-21",
        "km": "ពួកចៅហ្វាយ 1-21"
      },
      "mission": {
        "ko": "이스르엘 골짜기 · 가나안 산지 여정에서 사사기 21장 본문 문제를 풉니다.",
        "en": "Follow Jezreel Valley · Canaan Highlands and answer Judges 21 chapters question bank.",
        "ja": "イズレエルの谷 · カナン山地の旅で、士師記21章の問題バンクに答えます。",
        "ms": "Ikuti Lembah Yizreel · Tanah tinggi Kanaan dan jawab bank soalan Hakim-hakim 21 bab.",
        "th": "ติดตามเส้นทางหุบเขายิสเรเอล · ที่ราบสูงคานาอันและตอบคลังคำถามจากผู้วินิจฉัย 21 บท",
        "km": "តាមដានដំណើរជ្រលងយីសរេអែល · តំបន់ភ្នំកាណាន ហើយឆ្លើយធនាគារសំណួរពីពួកចៅហ្វាយ 21 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-JDG-001",
      "next_stage_id": "RUT-001",
      "asset_key": "asset.stage.jdg",
      "difficulty": "basic",
      "map_query": "Valley of Jezreel Israel biblical Judges",
      "map_region": "canaan",
      "map_x": 36.8,
      "map_y": 67.5,
      "route_group": "old-testament",
      "place_names": [
        "이스르엘 골짜기 · 가나안 산지",
        "Jezreel Valley · Canaan Highlands",
        "이스르엘",
        "Jezreel",
        "イズレエルの谷 · カナン山地",
        "Lembah Yizreel · Tanah tinggi Kanaan",
        "หุบเขายิสเรเอล · ที่ราบสูงคานาอัน",
        "ជ្រលងយីសរេអែល · តំបន់ភ្នំកាណាន"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "RUT-001",
      "world_id": "W_OT_HIST",
      "section_key": "history",
      "book_id": "RUT",
      "book_order": 8,
      "order_index": 8,
      "title": {
        "ko": "모압 · 베들레헴",
        "en": "Moab · Bethlehem",
        "ja": "モアブ · ベツレヘム",
        "ms": "Moab · Betlehem",
        "th": "โมอับ · เบธเลเฮม",
        "km": "ម៉ូអាប់ · បេថ្លេហិម"
      },
      "short_title": {
        "ko": "모압·베들레헴",
        "en": "Moab·Bethlehem",
        "ja": "モアブ·ベツレヘム",
        "ms": "Moab·Betlehem",
        "th": "โมอับ·เบธเลเฮม",
        "km": "ម៉ូអាប់·បេថ្លេហិម"
      },
      "book_title": {
        "ko": "룻기",
        "en": "Ruth",
        "ja": "ルツ記",
        "ms": "Rut",
        "th": "รูธ",
        "km": "នាងរស់"
      },
      "bible_range": "룻기 1-4",
      "references": {
        "ko": "룻기 1-4",
        "en": "Ruth 1-4",
        "ja": "ルツ記 1-4",
        "ms": "Rut 1-4",
        "th": "รูธ 1-4",
        "km": "នាងរស់ 1-4"
      },
      "mission": {
        "ko": "모압 · 베들레헴 여정에서 룻기 4장 본문 문제를 풉니다.",
        "en": "Follow Moab · Bethlehem and answer Ruth 4 chapters question bank.",
        "ja": "モアブ · ベツレヘムの旅で、ルツ記4章の問題バンクに答えます。",
        "ms": "Ikuti Moab · Betlehem dan jawab bank soalan Rut 4 bab.",
        "th": "ติดตามเส้นทางโมอับ · เบธเลเฮมและตอบคลังคำถามจากรูธ 4 บท",
        "km": "តាមដានដំណើរម៉ូអាប់ · បេថ្លេហិម ហើយឆ្លើយធនាគារសំណួរពីនាងរស់ 4 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-RUT-001",
      "next_stage_id": "1SA-001",
      "asset_key": "asset.stage.rut",
      "difficulty": "basic",
      "map_query": "Bethlehem Israel Ruth biblical location",
      "map_region": "bethlehem",
      "map_x": 37.1,
      "map_y": 72.2,
      "route_group": "old-testament",
      "place_names": [
        "모압 · 베들레헴",
        "Moab · Bethlehem",
        "모압·베들레헴",
        "Moab·Bethlehem",
        "モアブ · ベツレヘム",
        "Moab · Betlehem",
        "โมอับ · เบธเลเฮม",
        "ម៉ូអាប់ · បេថ្លេហិម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "1SA-001",
      "world_id": "W_OT_HIST",
      "section_key": "history",
      "book_id": "1SA",
      "book_order": 9,
      "order_index": 9,
      "title": {
        "ko": "실로 · 엘라 골짜기",
        "en": "Shiloh · Valley of Elah",
        "ja": "シロ · エラの谷",
        "ms": "Silo · Lembah Ela",
        "th": "ชิโลห์ · หุบเขาเอลาห์",
        "km": "ស៊ីឡូ · ជ្រលងអេឡា"
      },
      "short_title": {
        "ko": "실로·엘라",
        "en": "Shiloh·Elah",
        "ja": "シロ·エラ",
        "ms": "Silo·Ela",
        "th": "ชิโลห์·เอลาห์",
        "km": "ស៊ីឡូ·អេឡា"
      },
      "book_title": {
        "ko": "사무엘상",
        "en": "1 Samuel",
        "ja": "サムエル記上",
        "ms": "1 Samuel",
        "th": "1 ซามูเอล",
        "km": "១ សាំយូអែល"
      },
      "bible_range": "사무엘상 1-31",
      "references": {
        "ko": "사무엘상 1-31",
        "en": "1 Samuel 1-31",
        "ja": "サムエル記上 1-31",
        "ms": "1 Samuel 1-31",
        "th": "1 ซามูเอล 1-31",
        "km": "១ សាំយូអែល 1-31"
      },
      "mission": {
        "ko": "실로 · 엘라 골짜기 여정에서 사무엘상 31장 본문 문제를 풉니다.",
        "en": "Follow Shiloh · Valley of Elah and answer 1 Samuel 31 chapters question bank.",
        "ja": "シロ · エラの谷の旅で、サムエル記上31章の問題バンクに答えます。",
        "ms": "Ikuti Silo · Lembah Ela dan jawab bank soalan 1 Samuel 31 bab.",
        "th": "ติดตามเส้นทางชิโลห์ · หุบเขาเอลาห์และตอบคลังคำถามจาก1 ซามูเอล 31 บท",
        "km": "តាមដានដំណើរស៊ីឡូ · ជ្រលងអេឡា ហើយឆ្លើយធនាគារសំណួរពី១ សាំយូអែល 31 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-1SA-001",
      "next_stage_id": "2SA-001",
      "asset_key": "asset.stage.1sa",
      "difficulty": "basic",
      "map_query": "Valley of Elah Israel David Goliath",
      "map_region": "canaan",
      "map_x": 36.9,
      "map_y": 72,
      "route_group": "old-testament",
      "place_names": [
        "실로 · 엘라 골짜기",
        "Shiloh · Valley of Elah",
        "실로·엘라",
        "Shiloh·Elah",
        "シロ · エラの谷",
        "Silo · Lembah Ela",
        "ชิโลห์ · หุบเขาเอลาห์",
        "ស៊ីឡូ · ជ្រលងអេឡា"
      ],
      "chapter_question_count": 31
    },
    {
      "stage_id": "2SA-001",
      "world_id": "W_OT_HIST",
      "section_key": "history",
      "book_id": "2SA",
      "book_order": 10,
      "order_index": 10,
      "title": {
        "ko": "헤브론 · 예루살렘",
        "en": "Hebron · Jerusalem",
        "ja": "ヘブロン · エルサレム",
        "ms": "Hebron · Yerusalem",
        "th": "เฮប្រូន · เยรูซาเล็ม",
        "km": "ហេប្រូន · យេរូសាឡឹម"
      },
      "short_title": {
        "ko": "헤브론·예루살렘",
        "en": "Hebron·Jerusalem",
        "ja": "ヘブロン·エルサレム",
        "ms": "Hebron·Yerusalem",
        "th": "เฮប្រូន·เยรูซาเล็ม",
        "km": "ហេប្រូន·យេរូសាឡឹម"
      },
      "book_title": {
        "ko": "사무엘하",
        "en": "2 Samuel",
        "ja": "サムエル記下",
        "ms": "2 Samuel",
        "th": "2 ซามูเอล",
        "km": "២ សាំយូអែល"
      },
      "bible_range": "사무엘하 1-24",
      "references": {
        "ko": "사무엘하 1-24",
        "en": "2 Samuel 1-24",
        "ja": "サムエル記下 1-24",
        "ms": "2 Samuel 1-24",
        "th": "2 ซามูเอล 1-24",
        "km": "២ សាំយូអែល 1-24"
      },
      "mission": {
        "ko": "헤브론 · 예루살렘 여정에서 사무엘하 24장 본문 문제를 풉니다.",
        "en": "Follow Hebron · Jerusalem and answer 2 Samuel 24 chapters question bank.",
        "ja": "ヘブロン · エルサレムの旅で、サムエル記下24章の問題バンクに答えます。",
        "ms": "Ikuti Hebron · Yerusalem dan jawab bank soalan 2 Samuel 24 bab.",
        "th": "ติดตามเส้นทางเฮប្រូន · เยรูซาเล็มและตอบคลังคำถามจาก2 ซามูเอล 24 บท",
        "km": "តាមដានដំណើរហេប្រូន · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពី២ សាំយូអែល 24 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-2SA-001",
      "next_stage_id": "1KI-001",
      "asset_key": "asset.stage.2sa",
      "difficulty": "basic",
      "map_query": "City of David Jerusalem biblical location",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "old-testament",
      "place_names": [
        "헤브론 · 예루살렘",
        "Hebron · Jerusalem",
        "헤브론·예루살렘",
        "Hebron·Jerusalem",
        "ヘブロン · エルサレム",
        "Hebron · Yerusalem",
        "เฮប្រូន · เยรูซาเล็ม",
        "ហេប្រូន · យេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "1KI-001",
      "world_id": "W_OT_HIST",
      "section_key": "history",
      "book_id": "1KI",
      "book_order": 11,
      "order_index": 11,
      "title": {
        "ko": "예루살렘 성전 · 갈멜산",
        "en": "Jerusalem Temple · Mount Carmel",
        "ja": "エルサレム神殿 · カルメル山",
        "ms": "Bait Suci Yerusalem · Gunung Karmel",
        "th": "พระวิหารเยรูซาเล็ม · ภูเขาคารเมล",
        "km": "ព្រះវិហារយេរូសាឡឹម · ភ្នំកាមែល"
      },
      "short_title": {
        "ko": "성전·갈멜산",
        "en": "Temple·Carmel",
        "ja": "神殿·カルメル",
        "ms": "Bait Suci·Karmel",
        "th": "พระวิหาร·คาร์เมล",
        "km": "ព្រះវិហារ·កាមែល"
      },
      "book_title": {
        "ko": "열왕기상",
        "en": "1 Kings",
        "ja": "列王記上",
        "ms": "1 Raja-raja",
        "th": "1 พงศ์กษัตริย์",
        "km": "១ ពង្សាវតារក្សត្រ"
      },
      "bible_range": "열왕기상 1-22",
      "references": {
        "ko": "열왕기상 1-22",
        "en": "1 Kings 1-22",
        "ja": "列王記上 1-22",
        "ms": "1 Raja-raja 1-22",
        "th": "1 พงศ์กษัตริย์ 1-22",
        "km": "១ ពង្សាវតារក្សត្រ 1-22"
      },
      "mission": {
        "ko": "예루살렘 성전 · 갈멜산 여정에서 열왕기상 22장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem Temple · Mount Carmel and answer 1 Kings 22 chapters question bank.",
        "ja": "エルサレム神殿 · カルメル山の旅で、列王記上22章の問題バンクに答えます。",
        "ms": "Ikuti Bait Suci Yerusalem · Gunung Karmel dan jawab bank soalan 1 Raja-raja 22 bab.",
        "th": "ติดตามเส้นทางพระวิหารเยรูซาเล็ม · ภูเขาคารเมลและตอบคลังคำถามจาก1 พงศ์กษัตริย์ 22 บท",
        "km": "តាមដានដំណើរព្រះវិហារយេរូសាឡឹម · ភ្នំកាមែល ហើយឆ្លើយធនាគារសំណួរពី១ ពង្សាវតារក្សត្រ 22 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-1KI-001",
      "next_stage_id": "2KI-001",
      "asset_key": "asset.stage.1ki",
      "difficulty": "basic",
      "map_query": "Jerusalem Temple Mount Solomon biblical location",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "old-testament",
      "place_names": [
        "예루살렘 성전 · 갈멜산",
        "Jerusalem Temple · Mount Carmel",
        "성전·갈멜산",
        "Temple·Carmel",
        "エルサレム神殿 · カルメル山",
        "Bait Suci Yerusalem · Gunung Karmel",
        "พระวิหารเยรูซาเล็ม · ภูเขาคารเมล",
        "ព្រះវិហារយេរូសាឡឹម · ភ្នំកាមែល"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "2KI-001",
      "world_id": "W_OT_HIST",
      "section_key": "history",
      "book_id": "2KI",
      "book_order": 12,
      "order_index": 12,
      "title": {
        "ko": "사마리아 · 예루살렘",
        "en": "Samaria · Jerusalem",
        "ja": "サマリア · エルサレム",
        "ms": "Samaria · Yerusalem",
        "th": "สะมาเรีย · เยรูซาเล็ม",
        "km": "សាម៉ារី · យេរូសាឡឹម"
      },
      "short_title": {
        "ko": "사마리아·예루살렘",
        "en": "Samaria·Jerusalem",
        "ja": "サマリア·エルサレム",
        "ms": "Samaria·Yerusalem",
        "th": "สะมาเรีย·เยรูซาเล็ม",
        "km": "សាម៉ារី·យេរូសាឡឹម"
      },
      "book_title": {
        "ko": "열왕기하",
        "en": "2 Kings",
        "ja": "列王記下",
        "ms": "2 Raja-raja",
        "th": "2 พงศ์กษัตริย์",
        "km": "២ ពង្សាវតារក្សត្រ"
      },
      "bible_range": "열왕기하 1-25",
      "references": {
        "ko": "열왕기하 1-25",
        "en": "2 Kings 1-25",
        "ja": "列王記下 1-25",
        "ms": "2 Raja-raja 1-25",
        "th": "2 พงศ์กษัตริย์ 1-25",
        "km": "២ ពង្សាវតារក្សត្រ 1-25"
      },
      "mission": {
        "ko": "사마리아 · 예루살렘 여정에서 열왕기하 25장 본문 문제를 풉니다.",
        "en": "Follow Samaria · Jerusalem and answer 2 Kings 25 chapters question bank.",
        "ja": "サマリア · エルサレムの旅で、列王記下25章の問題バンクに答えます。",
        "ms": "Ikuti Samaria · Yerusalem dan jawab bank soalan 2 Raja-raja 25 bab.",
        "th": "ติดตามเส้นทางสะมาเรีย · เยรูซาเล็มและตอบคลังคำถามจาก2 พงศ์กษัตริย์ 25 บท",
        "km": "តាមដានដំណើរសាម៉ារី · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពី២ ពង្សាវតារក្សត្រ 25 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-2KI-001",
      "next_stage_id": "1CH-001",
      "asset_key": "asset.stage.2ki",
      "difficulty": "basic",
      "map_query": "Samaria and Jerusalem biblical kings",
      "map_region": "samaria",
      "map_x": 36.5,
      "map_y": 67.3,
      "route_group": "old-testament",
      "place_names": [
        "사마리아 · 예루살렘",
        "Samaria · Jerusalem",
        "사마리아·예루살렘",
        "Samaria·Jerusalem",
        "サマリア · エルサレム",
        "Samaria · Yerusalem",
        "สะมาเรีย · เยรูซาเล็ม",
        "សាម៉ារី · យេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "1CH-001",
      "world_id": "W_OT_HIST",
      "section_key": "history",
      "book_id": "1CH",
      "book_order": 13,
      "order_index": 13,
      "title": {
        "ko": "예루살렘 다윗 성",
        "en": "City of David, Jerusalem",
        "ja": "ダビデの町, エルサレム",
        "ms": "Kota Daud, Yerusalem",
        "th": "นครดาวิด, เยรูซาเล็ม",
        "km": "ទីក្រុងដាវីឌ, យេរូសាឡឹម"
      },
      "short_title": {
        "ko": "다윗 성",
        "en": "City of David",
        "ja": "ダビデの町",
        "ms": "Kota Daud",
        "th": "นครดาวิด",
        "km": "ទីក្រុងដាវីឌ"
      },
      "book_title": {
        "ko": "역대상",
        "en": "1 Chronicles",
        "ja": "歴代誌上",
        "ms": "1 Tawarikh",
        "th": "1 พงศาวดาร",
        "km": "១ របាក្សត្រ"
      },
      "bible_range": "역대상 1-29",
      "references": {
        "ko": "역대상 1-29",
        "en": "1 Chronicles 1-29",
        "ja": "歴代誌上 1-29",
        "ms": "1 Tawarikh 1-29",
        "th": "1 พงศาวดาร 1-29",
        "km": "១ របាក្សត្រ 1-29"
      },
      "mission": {
        "ko": "예루살렘 다윗 성 여정에서 역대상 29장 본문 문제를 풉니다.",
        "en": "Follow City of David, Jerusalem and answer 1 Chronicles 29 chapters question bank.",
        "ja": "ダビデの町, エルサレムの旅で、歴代誌上29章の問題バンクに答えます。",
        "ms": "Ikuti Kota Daud, Yerusalem dan jawab bank soalan 1 Tawarikh 29 bab.",
        "th": "ติดตามเส้นทางนครดาวิด, เยรูซาเล็มและตอบคลังคำถามจาก1 พงศาวดาร 29 บท",
        "km": "តាមដានដំណើរទីក្រុងដាវីឌ, យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពី១ របាក្សត្រ 29 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-1CH-001",
      "next_stage_id": "2CH-001",
      "asset_key": "asset.stage.1ch",
      "difficulty": "basic",
      "map_query": "Jerusalem City of David biblical Chronicles",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "old-testament",
      "place_names": [
        "예루살렘 다윗 성",
        "City of David, Jerusalem",
        "다윗 성",
        "City of David",
        "ダビデの町, エルサレム",
        "Kota Daud, Yerusalem",
        "นครดาวิด, เยรูซาเล็ม",
        "ទីក្រុងដាវីឌ, យេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "2CH-001",
      "world_id": "W_OT_HIST",
      "section_key": "history",
      "book_id": "2CH",
      "book_order": 14,
      "order_index": 14,
      "title": {
        "ko": "예루살렘 성전",
        "en": "Jerusalem Temple",
        "ja": "エルサレム神殿",
        "ms": "Bait Suci Yerusalem",
        "th": "พระวิหารเยรูซาเล็ม",
        "km": "ព្រះវិហារយេរូសាឡឹម"
      },
      "short_title": {
        "ko": "예루살렘 성전",
        "en": "Jerusalem Temple",
        "ja": "エルサレム神殿",
        "ms": "Bait Suci Yerusalem",
        "th": "พระวิหารเยรูซาเล็ม",
        "km": "ព្រះវិហារយេរូសាឡឹម"
      },
      "book_title": {
        "ko": "역대하",
        "en": "2 Chronicles",
        "ja": "歴代誌下",
        "ms": "2 Tawarikh",
        "th": "2 พงศาวดาร",
        "km": "២ របាក្សត្រ"
      },
      "bible_range": "역대하 1-36",
      "references": {
        "ko": "역대하 1-36",
        "en": "2 Chronicles 1-36",
        "ja": "歴代誌下 1-36",
        "ms": "2 Tawarikh 1-36",
        "th": "2 พงศาวดาร 1-36",
        "km": "២ របាក្សត្រ 1-36"
      },
      "mission": {
        "ko": "예루살렘 성전 여정에서 역대하 36장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem Temple and answer 2 Chronicles 36 chapters question bank.",
        "ja": "エルサレム神殿の旅で、歴代誌下36章の問題バンクに答えます。",
        "ms": "Ikuti Bait Suci Yerusalem dan jawab bank soalan 2 Tawarikh 36 bab.",
        "th": "ติดตามเส้นทางพระวิหารเยรูซาเล็มและตอบคลังคำถามจาก2 พงศาวดาร 36 บท",
        "km": "តាមដានដំណើរព្រះវិហារយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពី២ របាក្សត្រ 36 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-2CH-001",
      "next_stage_id": "EZR-001",
      "asset_key": "asset.stage.2ch",
      "difficulty": "basic",
      "map_query": "Jerusalem Temple Mount biblical Chronicles",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "old-testament",
      "place_names": [
        "예루살렘 성전",
        "Jerusalem Temple",
        "예루살렘 성전",
        "Jerusalem Temple",
        "エルサレム神殿",
        "Bait Suci Yerusalem",
        "พระวิหารเยรูซาเล็ม",
        "ព្រះវិហារយេរូសាឡឹម"
      ],
      "chapter_question_count": 36
    },
    {
      "stage_id": "EZR-001",
      "world_id": "W_OT_HIST",
      "section_key": "history",
      "book_id": "EZR",
      "book_order": 15,
      "order_index": 15,
      "title": {
        "ko": "바벨론 · 예루살렘",
        "en": "Babylon · Jerusalem",
        "ja": "バビロン · エルサレム",
        "ms": "Babilon · Yerusalem",
        "th": "บาบิโลน · เยรูซาเล็ม",
        "km": "បាប៊ីឡូន · យេរូសាឡឹម"
      },
      "short_title": {
        "ko": "바벨론·예루살렘",
        "en": "Babylon·Jerusalem",
        "ja": "バビロン·エルサレム",
        "ms": "Babilon·Yerusalem",
        "th": "บาบิโลน·เยรูซาเล็ม",
        "km": "បាប៊ីឡូន·យេរូសាឡឹម"
      },
      "book_title": {
        "ko": "에스라",
        "en": "Ezra",
        "ja": "エズラ記",
        "ms": "Ezra",
        "th": "เอสรา",
        "km": "អែសរ៉ា"
      },
      "bible_range": "에스라 1-10",
      "references": {
        "ko": "에스라 1-10",
        "en": "Ezra 1-10",
        "ja": "エズラ記 1-10",
        "ms": "Ezra 1-10",
        "th": "เอสรา 1-10",
        "km": "អែសរ៉ា 1-10"
      },
      "mission": {
        "ko": "바벨론 · 예루살렘 여정에서 에스라 10장 본문 문제를 풉니다.",
        "en": "Follow Babylon · Jerusalem and answer Ezra 10 chapters question bank.",
        "ja": "バビロン · エルサレムの旅で、エズラ記10章の問題バンクに答えます。",
        "ms": "Ikuti Babilon · Yerusalem dan jawab bank soalan Ezra 10 bab.",
        "th": "ติดตามเส้นทางบาบิโลน · เยรูซาเล็มและตอบคลังคำถามจากเอสรา 10 บท",
        "km": "តាមដានដំណើរបាប៊ីឡូន · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីអែសរ៉ា 10 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-EZR-001",
      "next_stage_id": "NEH-001",
      "asset_key": "asset.stage.ezr",
      "difficulty": "basic",
      "map_query": "Jerusalem Second Temple Ezra biblical location",
      "map_region": "babylon",
      "map_x": 61.7,
      "map_y": 66.5,
      "route_group": "old-testament",
      "place_names": [
        "바벨론 · 예루살렘",
        "Babylon · Jerusalem",
        "바벨론·예루살렘",
        "Babylon·Jerusalem",
        "バビロン · エルサレム",
        "Babilon · Yerusalem",
        "บาบิโลน · เยรูซาเล็ม",
        "បាប៊ីឡូន · យេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "NEH-001",
      "world_id": "W_OT_HIST",
      "section_key": "history",
      "book_id": "NEH",
      "book_order": 16,
      "order_index": 16,
      "title": {
        "ko": "수산궁 · 예루살렘 성벽",
        "en": "Susa Palace · Jerusalem Walls",
        "ja": "スサ宮殿 · エルサレム城壁",
        "ms": "Istana Susann · Tembok Yerusalem",
        "th": "พระราชวังสุสา · กำแพงเยรูซาเล็ม",
        "km": "រាជវាំងស៊ូសា · កំពែងយេរូសាឡឹម"
      },
      "short_title": {
        "ko": "수산·성벽",
        "en": "Susa·Walls",
        "ja": "スサ·城壁",
        "ms": "Susan·Tembok",
        "th": "สุสา·กำแพง",
        "km": "ស៊ូសា·កំពែង"
      },
      "book_title": {
        "ko": "느헤미야",
        "en": "Nehemiah",
        "ja": "ネヘミヤ記",
        "ms": "Nehemia",
        "th": "เนหะมีย์",
        "km": "នេហេមា"
      },
      "bible_range": "느헤미야 1-13",
      "references": {
        "ko": "느헤미야 1-13",
        "en": "Nehemiah 1-13",
        "ja": "ネヘミヤ記 1-13",
        "ms": "Nehemia 1-13",
        "th": "เนหะมีย์ 1-13",
        "km": "នេហេមា 1-13"
      },
      "mission": {
        "ko": "수산궁 · 예루살렘 성벽 여정에서 느헤미야 13장 본문 문제를 풉니다.",
        "en": "Follow Susa Palace · Jerusalem Walls and answer Nehemiah 13 chapters question bank.",
        "ja": "スサ宮殿 · エルサレム城壁の旅で、ネヘミヤ記13章の問題バンクに答えます。",
        "ms": "Ikuti Istana Susann · Tembok Yerusalem dan jawab bank soalan Nehemia 13 bab.",
        "th": "ติดตามเส้นทางพระราชวังสุสา · กำแพงเยรูซาเล็มและตอบคลังคำถามจากเนหะมีย์ 13 บท",
        "km": "តាមដានដំណើររាជវាំងស៊ូសា · កំពែងយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីនេហេមា 13 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-NEH-001",
      "next_stage_id": "EST-001",
      "asset_key": "asset.stage.neh",
      "difficulty": "basic",
      "map_query": "Jerusalem walls Nehemiah biblical location",
      "map_region": "susa",
      "map_x": 78,
      "map_y": 67.2,
      "route_group": "old-testament",
      "place_names": [
        "수산궁 · 예루살렘 성벽",
        "Susa Palace · Jerusalem Walls",
        "수산·성벽",
        "Susa·Walls",
        "スサ宮殿 · エルサレム城壁",
        "Istana Susann · Tembok Yerusalem",
        "พระราชวังสุสา · กำแพงเยรูซาเล็ม",
        "រាជវាំងស៊ូសា · កំពែងយេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "EST-001",
      "world_id": "W_OT_HIST",
      "section_key": "history",
      "book_id": "EST",
      "book_order": 17,
      "order_index": 17,
      "title": {
        "ko": "수산궁",
        "en": "Susa Palace",
        "ja": "スサ宮殿",
        "ms": "Istana Susan",
        "th": "พระราชวังสุสา",
        "km": "រាជវាំងស៊ូសា"
      },
      "short_title": {
        "ko": "수산",
        "en": "Susa",
        "ja": "スサ",
        "ms": "Susan",
        "th": "สุสา",
        "km": "ស៊ូសា"
      },
      "book_title": {
        "ko": "에스더",
        "en": "Esther",
        "ja": "エステル記",
        "ms": "Ester",
        "th": "เอสเธอร์",
        "km": "អេសធើរ"
      },
      "bible_range": "에스더 1-10",
      "references": {
        "ko": "에스더 1-10",
        "en": "Esther 1-10",
        "ja": "エステル記 1-10",
        "ms": "Ester 1-10",
        "th": "เอสเธอร์ 1-10",
        "km": "អេសធើរ 1-10"
      },
      "mission": {
        "ko": "수산궁 여정에서 에스더 10장 본문 문제를 풉니다.",
        "en": "Follow Susa Palace and answer Esther 10 chapters question bank.",
        "ja": "スサ宮殿の旅で、エステル記10章の問題バンクに答えます。",
        "ms": "Ikuti Istana Susan dan jawab bank soalan Ester 10 bab.",
        "th": "ติดตามเส้นทางพระราชวังสุสาและตอบคลังคำถามจากเอสเธอร์ 10 บท",
        "km": "តាមដានដំណើររាជវាំងស៊ូសា ហើយឆ្លើយធនាគារសំណួរពីអេសធើរ 10 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-EST-001",
      "next_stage_id": "JOS-REVIEW-13",
      "asset_key": "asset.stage.est",
      "difficulty": "basic",
      "map_query": "Susa Iran Esther biblical location",
      "map_region": "susa",
      "map_x": 78,
      "map_y": 67.2,
      "route_group": "old-testament",
      "place_names": [
        "수산궁",
        "Susa Palace",
        "수산",
        "Susa",
        "スサ宮殿",
        "Istana Susan",
        "พระราชวังสุสา",
        "រាជវាំងស៊ូសា"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "JOS-REVIEW-13",
      "world_id": "W_OT_HIST",
      "section_key": "history",
      "book_id": "JOS",
      "book_order": 6,
      "order_index": 18,
      "title": {
        "ko": "요단강 · 여리고 복습",
        "en": "Jordan River · Jericho Review",
        "ja": "ヨルダン川 · エリコ 復習",
        "ms": "Sungai Yordan · Yerikho Ulang kaji",
        "th": "แม่น้ำจอร์แดน · เยรีโค ทบทวน",
        "km": "ទន្លេយ័រដាន់ · យេរីខូ រំលឹក"
      },
      "short_title": {
        "ko": "요단·여리고+",
        "en": "Jordan·Jericho+",
        "ja": "ヨルダン·エリコ+",
        "ms": "Yordan·Yerikho+",
        "th": "จอร์แดน·เยรีโค+",
        "km": "យ័រដាន់·យេរីខូ+"
      },
      "book_title": {
        "ko": "여호수아",
        "en": "Joshua",
        "ja": "ヨシュア記",
        "ms": "Yosua",
        "th": "โยชูวา",
        "km": "យ៉ូស្វេ"
      },
      "bible_range": "여호수아 1-24",
      "references": {
        "ko": "여호수아 1-24",
        "en": "Joshua 1-24",
        "ja": "ヨシュア記 1-24",
        "ms": "Yosua 1-24",
        "th": "โยชูวา 1-24",
        "km": "យ៉ូស្វេ 1-24"
      },
      "mission": {
        "ko": "요단강 · 여리고 길에서 여호수아 주요 사건을 다시 확인합니다.",
        "en": "Review the main Joshua events along Jordan River · Jericho.",
        "ja": "ヨルダン川 · エリコの道で、ヨシュア記の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Yosua di sepanjang Sungai Yordan · Yerikho.",
        "th": "ทบทวนเหตุการณ์สำคัญของโยชูวาตามเส้นทางแม่น้ำจอร์แดน · เยรีโค",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃយ៉ូស្វេ តាមផ្លូវទន្លេយ័រដាន់ · យេរីខូ។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-JOS-REVIEW-13",
      "next_stage_id": "JDG-REVIEW-14",
      "asset_key": "asset.stage.jos.review.13",
      "difficulty": "review",
      "map_query": "Jericho archaeological site biblical Joshua review",
      "map_region": "canaan",
      "map_x": 37.2,
      "map_y": 69.2,
      "route_group": "old-testament",
      "place_names": [
        "요단강 · 여리고",
        "Jordan River · Jericho",
        "요단·여리고",
        "Jordan·Jericho",
        "ヨルダン川 · エリコ",
        "Sungai Yordan · Yerikho",
        "แม่น้ำจอร์แดน · เยรีโค",
        "ទន្លេយ័រដាន់ · យេរីខូ"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "JDG-REVIEW-14",
      "world_id": "W_OT_HIST",
      "section_key": "history",
      "book_id": "JDG",
      "book_order": 7,
      "order_index": 19,
      "title": {
        "ko": "이스르엘 골짜기 · 가나안 산지 복습",
        "en": "Jezreel Valley · Canaan Highlands Review",
        "ja": "イズレエルの谷 · カナン山地 復習",
        "ms": "Lembah Yizreel · Tanah tinggi Kanaan Ulang kaji",
        "th": "หุบเขายิสเรเอล · ที่ราบสูงคานาอัน ทบทวน",
        "km": "ជ្រលងយីសរេអែល · តំបន់ភ្នំកាណាន រំលឹក"
      },
      "short_title": {
        "ko": "이스르엘+",
        "en": "Jezreel+",
        "ja": "イズレエル+",
        "ms": "Yizreel+",
        "th": "ยิสเรเอล+",
        "km": "យីសរេអែល+"
      },
      "book_title": {
        "ko": "사사기",
        "en": "Judges",
        "ja": "士師記",
        "ms": "Hakim-hakim",
        "th": "ผู้วินิจฉัย",
        "km": "ពួកចៅហ្វាយ"
      },
      "bible_range": "사사기 1-21",
      "references": {
        "ko": "사사기 1-21",
        "en": "Judges 1-21",
        "ja": "士師記 1-21",
        "ms": "Hakim-hakim 1-21",
        "th": "ผู้วินิจฉัย 1-21",
        "km": "ពួកចៅហ្វាយ 1-21"
      },
      "mission": {
        "ko": "이스르엘 골짜기 · 가나안 산지 길에서 사사기 주요 사건을 다시 확인합니다.",
        "en": "Review the main Judges events along Jezreel Valley · Canaan Highlands.",
        "ja": "イズレエルの谷 · カナン山地の道で、士師記の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Hakim-hakim di sepanjang Lembah Yizreel · Tanah tinggi Kanaan.",
        "th": "ทบทวนเหตุการณ์สำคัญของผู้วินิจฉัยตามเส้นทางหุบเขายิสเรเอล · ที่ราบสูงคานาอัน",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃពួកចៅហ្វាយ តាមផ្លូវជ្រលងយីសរេអែល · តំបន់ភ្នំកាណាន។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-JDG-REVIEW-14",
      "next_stage_id": "RUT-REVIEW-15",
      "asset_key": "asset.stage.jdg.review.14",
      "difficulty": "review",
      "map_query": "Valley of Jezreel Israel biblical Judges review",
      "map_region": "canaan",
      "map_x": 36.8,
      "map_y": 67.5,
      "route_group": "old-testament",
      "place_names": [
        "이스르엘 골짜기 · 가나안 산지",
        "Jezreel Valley · Canaan Highlands",
        "이스르엘",
        "Jezreel",
        "イズレエルの谷 · カナン山地",
        "Lembah Yizreel · Tanah tinggi Kanaan",
        "หุบเขายิสเรเอล · ที่ราบสูงคานาอัน",
        "ជ្រលងយីសរេអែល · តំបន់ភ្នំកាណាន"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "RUT-REVIEW-15",
      "world_id": "W_OT_HIST",
      "section_key": "history",
      "book_id": "RUT",
      "book_order": 8,
      "order_index": 20,
      "title": {
        "ko": "모압 · 베들레헴 복습",
        "en": "Moab · Bethlehem Review",
        "ja": "モアブ · ベツレヘム 復習",
        "ms": "Moab · Betlehem Ulang kaji",
        "th": "โมอับ · เบธเลเฮม ทบทวน",
        "km": "ម៉ូអាប់ · បេថ្លេហិម រំលឹក"
      },
      "short_title": {
        "ko": "모압·베들레헴+",
        "en": "Moab·Bethlehem+",
        "ja": "モアブ·ベツレヘム+",
        "ms": "Moab·Betlehem+",
        "th": "โมอับ·เบธเลเฮม+",
        "km": "ម៉ូអាប់·បេថ្លេហិម+"
      },
      "book_title": {
        "ko": "룻기",
        "en": "Ruth",
        "ja": "ルツ記",
        "ms": "Rut",
        "th": "รูธ",
        "km": "នាងរស់"
      },
      "bible_range": "룻기 1-4",
      "references": {
        "ko": "룻기 1-4",
        "en": "Ruth 1-4",
        "ja": "ルツ記 1-4",
        "ms": "Rut 1-4",
        "th": "รูธ 1-4",
        "km": "នាងរស់ 1-4"
      },
      "mission": {
        "ko": "모압 · 베들레헴 길에서 룻기 주요 사건을 다시 확인합니다.",
        "en": "Review the main Ruth events along Moab · Bethlehem.",
        "ja": "モアブ · ベツレヘムの道で、ルツ記の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Rut di sepanjang Moab · Betlehem.",
        "th": "ทบทวนเหตุการณ์สำคัญของรูธตามเส้นทางโมอับ · เบธเลเฮม",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃនាងរស់ តាមផ្លូវម៉ូអាប់ · បេថ្លេហិម។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-RUT-REVIEW-15",
      "next_stage_id": "JOB-001",
      "asset_key": "asset.stage.rut.review.15",
      "difficulty": "review",
      "map_query": "Bethlehem Israel Ruth biblical location review",
      "map_region": "bethlehem",
      "map_x": 37.1,
      "map_y": 72.2,
      "route_group": "old-testament",
      "place_names": [
        "모압 · 베들레헴",
        "Moab · Bethlehem",
        "모압·베들레헴",
        "Moab·Bethlehem",
        "モアブ · ベツレヘム",
        "Moab · Betlehem",
        "โมอับ · เบธเลเฮม",
        "ម៉ូអាប់ · បេថ្លេហិម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "JOB-001",
      "world_id": "W_OT_WIS",
      "section_key": "wisdom",
      "book_id": "JOB",
      "book_order": 18,
      "order_index": 21,
      "title": {
        "ko": "우스 땅",
        "en": "Land of Uz",
        "ja": "ウツの地",
        "ms": "Tanah Us",
        "th": "แผ่นดินอูส",
        "km": "ស្រុកអ៊ូស"
      },
      "short_title": {
        "ko": "우스",
        "en": "Uz",
        "ja": "ウツ",
        "ms": "Us",
        "th": "อูส",
        "km": "អ៊ូស"
      },
      "book_title": {
        "ko": "욥기",
        "en": "Job",
        "ja": "ヨブ記",
        "ms": "Ayub",
        "th": "โยบ",
        "km": "យ៉ូប"
      },
      "bible_range": "욥기 1-42",
      "references": {
        "ko": "욥기 1-42",
        "en": "Job 1-42",
        "ja": "ヨブ記 1-42",
        "ms": "Ayub 1-42",
        "th": "โยบ 1-42",
        "km": "យ៉ូប 1-42"
      },
      "mission": {
        "ko": "우스 땅 여정에서 욥기 42장 본문 문제를 풉니다.",
        "en": "Follow Land of Uz and answer Job 42 chapters question bank.",
        "ja": "ウツの地の旅で、ヨブ記42章の問題バンクに答えます。",
        "ms": "Ikuti Tanah Us dan jawab bank soalan Ayub 42 bab.",
        "th": "ติดตามเส้นทางแผ่นดินอูสและตอบคลังคำถามจากโยบ 42 บท",
        "km": "តាមដានដំណើរស្រុកអ៊ូស ហើយឆ្លើយធនាគារសំណួរពីយ៉ូប 42 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-JOB-001",
      "next_stage_id": "PSA-001",
      "asset_key": "asset.stage.job",
      "difficulty": "basic",
      "map_query": "Uz Edom biblical Job location",
      "map_region": "edom",
      "map_x": 36.5,
      "map_y": 79.5,
      "route_group": "old-testament",
      "place_names": [
        "우스 땅",
        "Land of Uz",
        "우스",
        "Uz",
        "ウツの地",
        "Tanah Us",
        "แผ่นดินอูส",
        "ស្រុកអ៊ូស"
      ],
      "chapter_question_count": 42
    },
    {
      "stage_id": "PSA-001",
      "world_id": "W_OT_WIS",
      "section_key": "wisdom",
      "book_id": "PSA",
      "book_order": 19,
      "order_index": 22,
      "title": {
        "ko": "시온 · 예루살렘",
        "en": "Zion · Jerusalem",
        "ja": "シオン · エルサレム",
        "ms": "Sion · Yerusalem",
        "th": "ศิโยน · เยรูซาเล็ม",
        "km": "ស៊ីយ៉ូន · យេរូសាឡឹម"
      },
      "short_title": {
        "ko": "시온",
        "en": "Zion",
        "ja": "シオン",
        "ms": "Sion",
        "th": "ศิโยน",
        "km": "ស៊ីយ៉ូន"
      },
      "book_title": {
        "ko": "시편",
        "en": "Psalms",
        "ja": "詩篇",
        "ms": "Mazmur",
        "th": "สดุดี",
        "km": "ទំនុកតម្កើង"
      },
      "bible_range": "시편 1-150",
      "references": {
        "ko": "시편 1-150",
        "en": "Psalms 1-150",
        "ja": "詩篇 1-150",
        "ms": "Mazmur 1-150",
        "th": "สดุดี 1-150",
        "km": "ទំនុកតម្កើង 1-150"
      },
      "mission": {
        "ko": "시온 · 예루살렘 여정에서 시편 150장 본문 문제를 풉니다.",
        "en": "Follow Zion · Jerusalem and answer Psalms 150 chapters question bank.",
        "ja": "シオン · エルサレムの旅で、詩篇150章の問題バンクに答えます。",
        "ms": "Ikuti Sion · Yerusalem dan jawab bank soalan Mazmur 150 bab.",
        "th": "ติดตามเส้นทางศิโยน · เยรูซาเล็มและตอบคลังคำถามจากสดุดี 150 บท",
        "km": "តាមដានដំណើរស៊ីយ៉ូន · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីទំនុកតម្កើង 150 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-PSA-001",
      "next_stage_id": "PRO-001",
      "asset_key": "asset.stage.psa",
      "difficulty": "basic",
      "map_query": "Jerusalem Psalms biblical worship",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "old-testament",
      "place_names": [
        "시온 · 예루살렘",
        "Zion · Jerusalem",
        "시온",
        "Zion",
        "シオン · エルサレム",
        "Sion · Yerusalem",
        "ศิโยน · เยรูซาเล็ม",
        "ស៊ីយ៉ូន · យេរូសាឡឹម"
      ],
      "chapter_question_count": 150
    },
    {
      "stage_id": "PRO-001",
      "world_id": "W_OT_WIS",
      "section_key": "wisdom",
      "book_id": "PRO",
      "book_order": 20,
      "order_index": 23,
      "title": {
        "ko": "예루살렘 왕궁",
        "en": "Royal Court of Jerusalem",
        "ja": "エルサレム王宮",
        "ms": "Istana Diraja Yerusalem",
        "th": "ราชสำนักเยรูซาเล็ม",
        "km": "រាជវាំងយេរូសាឡឹម"
      },
      "short_title": {
        "ko": "예루살렘",
        "en": "Jerusalem",
        "ja": "エルサレム",
        "ms": "Yerusalem",
        "th": "เยรูซาเล็ม",
        "km": "យេរូសាឡឹម"
      },
      "book_title": {
        "ko": "잠언",
        "en": "Proverbs",
        "ja": "箴言",
        "ms": "Amsal",
        "th": "สุภาษิต",
        "km": "សុភាសិត"
      },
      "bible_range": "잠언 1-31",
      "references": {
        "ko": "잠언 1-31",
        "en": "Proverbs 1-31",
        "ja": "箴言 1-31",
        "ms": "Amsal 1-31",
        "th": "สุภาษิต 1-31",
        "km": "សុភាសិត 1-31"
      },
      "mission": {
        "ko": "예루살렘 왕궁 여정에서 잠언 31장 본문 문제를 풉니다.",
        "en": "Follow Royal Court of Jerusalem and answer Proverbs 31 chapters question bank.",
        "ja": "エルサレム王宮の旅で、箴言31章の問題バンクに答えます。",
        "ms": "Ikuti Istana Diraja Yerusalem dan jawab bank soalan Amsal 31 bab.",
        "th": "ติดตามเส้นทางราชสำนักเยรูซาเล็มและตอบคลังคำถามจากสุภาษิต 31 บท",
        "km": "តាមដានដំណើររាជវាំងយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីសុភាសិត 31 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-PRO-001",
      "next_stage_id": "ECC-001",
      "asset_key": "asset.stage.pro",
      "difficulty": "basic",
      "map_query": "Jerusalem Solomon Proverbs biblical location",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "old-testament",
      "place_names": [
        "예루살렘 왕궁",
        "Royal Court of Jerusalem",
        "예루살렘",
        "Jerusalem",
        "エルサレム王宮",
        "Istana Diraja Yerusalem",
        "ราชสำนักเยรูซาเล็ม",
        "រាជវាំងយេរូសាឡឹម"
      ],
      "chapter_question_count": 31
    },
    {
      "stage_id": "ECC-001",
      "world_id": "W_OT_WIS",
      "section_key": "wisdom",
      "book_id": "ECC",
      "book_order": 21,
      "order_index": 24,
      "title": {
        "ko": "예루살렘 집회",
        "en": "Assembly in Jerusalem",
        "ja": "エルサレムの集会",
        "ms": "Perhimpunan di Yerusalem",
        "th": "ที่ชุมนุมในเยรูซาเล็ม",
        "km": "ការជួបជុំនៅយេរូសាឡឹម"
      },
      "short_title": {
        "ko": "예루살렘",
        "en": "Jerusalem",
        "ja": "エルサレム",
        "ms": "Yerusalem",
        "th": "เยรูซาเล็ม",
        "km": "យេរូសាឡឹម"
      },
      "book_title": {
        "ko": "전도서",
        "en": "Ecclesiastes",
        "ja": "伝道者の書",
        "ms": "Pengkhotbah",
        "th": "ปัญญาจารย์",
        "km": "សាស្ដា"
      },
      "bible_range": "전도서 1-12",
      "references": {
        "ko": "전도서 1-12",
        "en": "Ecclesiastes 1-12",
        "ja": "伝道者の書 1-12",
        "ms": "Pengkhotbah 1-12",
        "th": "ปัญญาจารย์ 1-12",
        "km": "សាស្ដា 1-12"
      },
      "mission": {
        "ko": "예루살렘 집회 여정에서 전도서 12장 본문 문제를 풉니다.",
        "en": "Follow Assembly in Jerusalem and answer Ecclesiastes 12 chapters question bank.",
        "ja": "エルサレムの集会の旅で、伝道者の書12章の問題バンクに答えます。",
        "ms": "Ikuti Perhimpunan di Yerusalem dan jawab bank soalan Pengkhotbah 12 bab.",
        "th": "ติดตามเส้นทางที่ชุมนุมในเยรูซาเล็มและตอบคลังคำถามจากปัญญาจารย์ 12 บท",
        "km": "តាមដានដំណើរការជួបជុំនៅយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីសាស្ដា 12 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-ECC-001",
      "next_stage_id": "SNG-001",
      "asset_key": "asset.stage.ecc",
      "difficulty": "basic",
      "map_query": "Jerusalem Ecclesiastes Solomon biblical location",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "old-testament",
      "place_names": [
        "예루살렘 집회",
        "Assembly in Jerusalem",
        "예루살렘",
        "Jerusalem",
        "エルサレムの集会",
        "Perhimpunan di Yerusalem",
        "ที่ชุมนุมในเยรูซาเล็ม",
        "ការជួបជុំនៅយេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "SNG-001",
      "world_id": "W_OT_WIS",
      "section_key": "wisdom",
      "book_id": "SNG",
      "book_order": 22,
      "order_index": 25,
      "title": {
        "ko": "예루살렘 · 레바논",
        "en": "Jerusalem · Lebanon",
        "ja": "エルサレム · レバノン",
        "ms": "Yerusalem · Lebanon",
        "th": "เยรูซาเล็ม · เลบานอน",
        "km": "យេរូសាឡឹម · លីបង់"
      },
      "short_title": {
        "ko": "예루살렘·레바논",
        "en": "Jerusalem·Lebanon",
        "ja": "エルサレム·レバノン",
        "ms": "Yerusalem·Lebanon",
        "th": "เยรูซาเล็ม·เลบานอน",
        "km": "យេរូសាឡឹម·លីបង់"
      },
      "book_title": {
        "ko": "아가",
        "en": "Song of Songs",
        "ja": "雅歌",
        "ms": "Kidung Agung",
        "th": "เพลงซาโลมอน",
        "km": "បទចម្រៀងសាឡូម៉ូន"
      },
      "bible_range": "아가 1-8",
      "references": {
        "ko": "아가 1-8",
        "en": "Song of Songs 1-8",
        "ja": "雅歌 1-8",
        "ms": "Kidung Agung 1-8",
        "th": "เพลงซาโลมอน 1-8",
        "km": "បទចម្រៀងសាឡូម៉ូន 1-8"
      },
      "mission": {
        "ko": "예루살렘 · 레바논 여정에서 아가 8장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem · Lebanon and answer Song of Songs 8 chapters question bank.",
        "ja": "エルサレム · レバノンの旅で、雅歌8章の問題バンクに答えます。",
        "ms": "Ikuti Yerusalem · Lebanon dan jawab bank soalan Kidung Agung 8 bab.",
        "th": "ติดตามเส้นทางเยรูซาเล็ม · เลบานอนและตอบคลังคำถามจากเพลงซาโลมอน 8 บท",
        "km": "តាមដានដំណើរយេរូសាឡឹម · លីបង់ ហើយឆ្លើយធនាគារសំណួរពីបទចម្រៀងសាឡូម៉ូន 8 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-SNG-001",
      "next_stage_id": "ISA-001",
      "asset_key": "asset.stage.sng",
      "difficulty": "basic",
      "map_query": "Jerusalem Song of Songs biblical location",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "old-testament",
      "place_names": [
        "예루살렘 · 레바논",
        "Jerusalem · Lebanon",
        "예루살렘·레바논",
        "Jerusalem·Lebanon",
        "エルサレム · レバノン",
        "Yerusalem · Lebanon",
        "เยรูซาเล็ม · เลบานอน",
        "យេរូសាឡឹម · លីបង់"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "ISA-001",
      "world_id": "W_OT_MAJOR",
      "section_key": "majorProphets",
      "book_id": "ISA",
      "book_order": 23,
      "order_index": 26,
      "title": {
        "ko": "시온 · 예루살렘",
        "en": "Zion · Jerusalem",
        "ja": "シオン · エルサレム",
        "ms": "Sion · Yerusalem",
        "th": "ศิโยน · เยรูซาเล็ม",
        "km": "ស៊ីយ៉ូន · យេរូសាឡឹម"
      },
      "short_title": {
        "ko": "시온",
        "en": "Zion",
        "ja": "シオン",
        "ms": "Sion",
        "th": "ศิโยน",
        "km": "ស៊ីយ៉ូន"
      },
      "book_title": {
        "ko": "이사야",
        "en": "Isaiah",
        "ja": "イザヤ書",
        "ms": "Yesaya",
        "th": "อิสยาห์",
        "km": "អេសាយ"
      },
      "bible_range": "이사야 1-66",
      "references": {
        "ko": "이사야 1-66",
        "en": "Isaiah 1-66",
        "ja": "イザヤ書 1-66",
        "ms": "Yesaya 1-66",
        "th": "อิสยาห์ 1-66",
        "km": "អេសាយ 1-66"
      },
      "mission": {
        "ko": "시온 · 예루살렘 여정에서 이사야 66장 본문 문제를 풉니다.",
        "en": "Follow Zion · Jerusalem and answer Isaiah 66 chapters question bank.",
        "ja": "シオン · エルサレムの旅で、イザヤ書66章の問題バンクに答えます。",
        "ms": "Ikuti Sion · Yerusalem dan jawab bank soalan Yesaya 66 bab.",
        "th": "ติดตามเส้นทางศิโยน · เยรูซาเล็มและตอบคลังคำถามจากอิสยาห์ 66 บท",
        "km": "តាមដានដំណើរស៊ីយ៉ូន · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីអេសាយ 66 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-ISA-001",
      "next_stage_id": "JER-001",
      "asset_key": "asset.stage.isa",
      "difficulty": "basic",
      "map_query": "Jerusalem Isaiah biblical prophet location",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "prophets",
      "place_names": [
        "시온 · 예루살렘",
        "Zion · Jerusalem",
        "시온",
        "Zion",
        "シオン · エルサレム",
        "Sion · Yerusalem",
        "ศิโยน · เยรูซาเล็ม",
        "ស៊ីយ៉ូន · យេរូសាឡឹម"
      ],
      "chapter_question_count": 66
    },
    {
      "stage_id": "JER-001",
      "world_id": "W_OT_MAJOR",
      "section_key": "majorProphets",
      "book_id": "JER",
      "book_order": 24,
      "order_index": 27,
      "title": {
        "ko": "아나돗 · 예루살렘",
        "en": "Anathoth · Jerusalem",
        "ja": "アナトテ · エルサレム",
        "ms": "Anatot · Yerusalem",
        "th": "อานาโธท · เยรูซาเล็ม",
        "km": "អាណាថោត · យេរូសាឡឹម"
      },
      "short_title": {
        "ko": "아나돗·예루살렘",
        "en": "Anathoth·Jerusalem",
        "ja": "アナトテ·エルサレム",
        "ms": "Anatot·Yerusalem",
        "th": "อานาโธท·เยรูซาเล็ม",
        "km": "អាណាថោត·យេរូសាឡឹម"
      },
      "book_title": {
        "ko": "예레미야",
        "en": "Jeremiah",
        "ja": "エレミヤ書",
        "ms": "Yeremia",
        "th": "เยเรมีย์",
        "km": "យេរេមា"
      },
      "bible_range": "예레미야 1-52",
      "references": {
        "ko": "예레미야 1-52",
        "en": "Jeremiah 1-52",
        "ja": "エレミヤ書 1-52",
        "ms": "Yeremia 1-52",
        "th": "เยเรมีย์ 1-52",
        "km": "យេរេមា 1-52"
      },
      "mission": {
        "ko": "아나돗 · 예루살렘 여정에서 예레미야 52장 본문 문제를 풉니다.",
        "en": "Follow Anathoth · Jerusalem and answer Jeremiah 52 chapters question bank.",
        "ja": "アナトテ · エルサレムの旅で、エレミヤ書52章の問題バンクに答えます。",
        "ms": "Ikuti Anatot · Yerusalem dan jawab bank soalan Yeremia 52 bab.",
        "th": "ติดตามเส้นทางอานาโธท · เยรูซาเล็มและตอบคลังคำถามจากเยเรมีย์ 52 บท",
        "km": "តាមដានដំណើរអាណាថោត · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីយេរេមា 52 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-JER-001",
      "next_stage_id": "LAM-001",
      "asset_key": "asset.stage.jer",
      "difficulty": "basic",
      "map_query": "Jerusalem Jeremiah biblical prophet location",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "prophets",
      "place_names": [
        "아나돗 · 예루살렘",
        "Anathoth · Jerusalem",
        "아나돗·예루살렘",
        "Anathoth·Jerusalem",
        "アナトテ · エルサレム",
        "Anatot · Yerusalem",
        "อานาโธท · เยรูซาเล็ม",
        "អាណាថោត · យេរូសាឡឹម"
      ],
      "chapter_question_count": 52
    },
    {
      "stage_id": "LAM-001",
      "world_id": "W_OT_MAJOR",
      "section_key": "majorProphets",
      "book_id": "LAM",
      "book_order": 25,
      "order_index": 28,
      "title": {
        "ko": "예루살렘 폐허",
        "en": "Ruins of Jerusalem",
        "ja": "エルサレムの廃虚",
        "ms": "Reruntuhan Yerusalem",
        "th": "ซากกรุงเยรูซาเล็ม",
        "km": "គំនរបាក់បែកយេរូសាឡឹម"
      },
      "short_title": {
        "ko": "예루살렘 폐허",
        "en": "Jerusalem Ruins",
        "ja": "エルサレムの廃虚",
        "ms": "Reruntuhan Yerusalem",
        "th": "ซากกรุงเยรูซาเล็ม",
        "km": "គំនរបាក់បែកយេរូសាឡឹម"
      },
      "book_title": {
        "ko": "예레미야애가",
        "en": "Lamentations",
        "ja": "哀歌",
        "ms": "Ratapan",
        "th": "เพลงคร่ำครวญ",
        "km": "បរិទេវ"
      },
      "bible_range": "예레미야애가 1-5",
      "references": {
        "ko": "예레미야애가 1-5",
        "en": "Lamentations 1-5",
        "ja": "哀歌 1-5",
        "ms": "Ratapan 1-5",
        "th": "เพลงคร่ำครวญ 1-5",
        "km": "បរិទេវ 1-5"
      },
      "mission": {
        "ko": "예루살렘 폐허 여정에서 예레미야애가 5장 본문 문제를 풉니다.",
        "en": "Follow Ruins of Jerusalem and answer Lamentations 5 chapters question bank.",
        "ja": "エルサレムの廃虚の旅で、哀歌5章の問題バンクに答えます。",
        "ms": "Ikuti Reruntuhan Yerusalem dan jawab bank soalan Ratapan 5 bab.",
        "th": "ติดตามเส้นทางซากกรุงเยรูซาเล็มและตอบคลังคำถามจากเพลงคร่ำครวญ 5 บท",
        "km": "តាមដានដំណើរគំនរបាក់បែកយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីបរិទេវ 5 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-LAM-001",
      "next_stage_id": "EZK-001",
      "asset_key": "asset.stage.lam",
      "difficulty": "basic",
      "map_query": "Jerusalem destruction Lamentations biblical location",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "prophets",
      "place_names": [
        "예루살렘 폐허",
        "Ruins of Jerusalem",
        "예루살렘 폐허",
        "Jerusalem Ruins",
        "エルサレムの廃虚",
        "Reruntuhan Yerusalem",
        "ซากกรุงเยรูซาเล็ม",
        "គំនរបាក់បែកយេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "EZK-001",
      "world_id": "W_OT_MAJOR",
      "section_key": "majorProphets",
      "book_id": "EZK",
      "book_order": 26,
      "order_index": 29,
      "title": {
        "ko": "그발 강가 · 바벨론",
        "en": "Chebar Canal · Babylon",
        "ja": "ケバル川 · バビロン",
        "ms": "Terusan Kebar · Babilon",
        "th": "คลองเคบาร์ · บาบิโลน",
        "km": "ប្រឡាយខេបារ · បាប៊ីឡូន"
      },
      "short_title": {
        "ko": "그발·바벨론",
        "en": "Chebar·Babylon",
        "ja": "ケバル·バビロン",
        "ms": "Kebar·Babilon",
        "th": "เคบาร์·บาบิโลน",
        "km": "ខេបារ·បាប៊ីឡូន"
      },
      "book_title": {
        "ko": "에스겔",
        "en": "Ezekiel",
        "ja": "エゼキエル書",
        "ms": "Yehezkiel",
        "th": "เอเสเคียล",
        "km": "អេសេគាល"
      },
      "bible_range": "에스겔 1-48",
      "references": {
        "ko": "에스겔 1-48",
        "en": "Ezekiel 1-48",
        "ja": "エゼキエル書 1-48",
        "ms": "Yehezkiel 1-48",
        "th": "เอเสเคียล 1-48",
        "km": "អេសេគាល 1-48"
      },
      "mission": {
        "ko": "그발 강가 · 바벨론 여정에서 에스겔 48장 본문 문제를 풉니다.",
        "en": "Follow Chebar Canal · Babylon and answer Ezekiel 48 chapters question bank.",
        "ja": "ケバル川 · バビロンの旅で、エゼキエル書48章の問題バンクに答えます。",
        "ms": "Ikuti Terusan Kebar · Babilon dan jawab bank soalan Yehezkiel 48 bab.",
        "th": "ติดตามเส้นทางคลองเคบาร์ · บาบิโลนและตอบคลังคำถามจากเอเสเคียล 48 บท",
        "km": "តាមដានដំណើរប្រឡាយខេបារ · បាប៊ីឡូន ហើយឆ្លើយធនាគារសំណួរពីអេសេគាល 48 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-EZK-001",
      "next_stage_id": "DAN-001",
      "asset_key": "asset.stage.ezk",
      "difficulty": "basic",
      "map_query": "Chebar canal Babylon Ezekiel biblical location",
      "map_region": "babylon",
      "map_x": 62.5,
      "map_y": 66.2,
      "route_group": "prophets",
      "place_names": [
        "그발 강가 · 바벨론",
        "Chebar Canal · Babylon",
        "그발·바벨론",
        "Chebar·Babylon",
        "ケバル川 · バビロン",
        "Terusan Kebar · Babilon",
        "คลองเคบาร์ · บาบิโลน",
        "ប្រឡាយខេបារ · បាប៊ីឡូន"
      ],
      "chapter_question_count": 48
    },
    {
      "stage_id": "DAN-001",
      "world_id": "W_OT_MAJOR",
      "section_key": "majorProphets",
      "book_id": "DAN",
      "book_order": 27,
      "order_index": 30,
      "title": {
        "ko": "바벨론 · 수산",
        "en": "Babylon · Susa",
        "ja": "バビロン · スサ",
        "ms": "Babilon · Susan",
        "th": "บาบิโลน · สุสา",
        "km": "បាប៊ីឡូន · ស៊ូសា"
      },
      "short_title": {
        "ko": "바벨론·수산",
        "en": "Babylon·Susa",
        "ja": "バビロン·スサ",
        "ms": "Babilon·Susan",
        "th": "บาบิโลน·สุสา",
        "km": "បាប៊ីឡូន·ស៊ូសា"
      },
      "book_title": {
        "ko": "다니엘",
        "en": "Daniel",
        "ja": "ダニエル書",
        "ms": "Daniel",
        "th": "ดาเนียล",
        "km": "ដានីយ៉ែល"
      },
      "bible_range": "다니엘 1-12",
      "references": {
        "ko": "다니엘 1-12",
        "en": "Daniel 1-12",
        "ja": "ダニエル書 1-12",
        "ms": "Daniel 1-12",
        "th": "ดาเนียล 1-12",
        "km": "ដានីយ៉ែល 1-12"
      },
      "mission": {
        "ko": "바벨론 · 수산 여정에서 다니엘 12장 본문 문제를 풉니다.",
        "en": "Follow Babylon · Susa and answer Daniel 12 chapters question bank.",
        "ja": "バビロン · スサの旅で、ダニエル書12章の問題バンクに答えます。",
        "ms": "Ikuti Babilon · Susan dan jawab bank soalan Daniel 12 bab.",
        "th": "ติดตามเส้นทางบาบิโลน · สุสาและตอบคลังคำถามจากดาเนียล 12 บท",
        "km": "តាមដានដំណើរបាប៊ីឡូន · ស៊ូសា ហើយឆ្លើយធនាគារសំណួរពីដានីយ៉ែល 12 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-DAN-001",
      "next_stage_id": "HOS-001",
      "asset_key": "asset.stage.dan",
      "difficulty": "basic",
      "map_query": "Babylon Iraq Daniel biblical location",
      "map_region": "babylon",
      "map_x": 61.7,
      "map_y": 66.5,
      "route_group": "prophets",
      "place_names": [
        "바벨론 · 수산",
        "Babylon · Susa",
        "바벨론·수산",
        "Babylon·Susa",
        "バビロン · スサ",
        "Babilon · Susan",
        "บาบิโลน · สุสา",
        "បាប៊ីឡូន · ស៊ូសា"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "HOS-001",
      "world_id": "W_OT_MINOR",
      "section_key": "minorProphets",
      "book_id": "HOS",
      "book_order": 28,
      "order_index": 31,
      "title": {
        "ko": "사마리아 · 이스르엘",
        "en": "Samaria · Jezreel",
        "ja": "サマリア · イズレエル",
        "ms": "Samaria · Yizreel",
        "th": "สะมาเรีย · ยิสเรเอล",
        "km": "សាម៉ារី · យីសរេអែល"
      },
      "short_title": {
        "ko": "사마리아·이스르엘",
        "en": "Samaria·Jezreel",
        "ja": "サマリア·イズレエル",
        "ms": "Samaria·Yizreel",
        "th": "สะมาเรีย·ยิสเรเอล",
        "km": "សាម៉ារី·យីសរេអែល"
      },
      "book_title": {
        "ko": "호세아",
        "en": "Hosea",
        "ja": "ホセア書",
        "ms": "Hosea",
        "th": "โฮเชยา",
        "km": "ហូសេ"
      },
      "bible_range": "호세아 1-14",
      "references": {
        "ko": "호세아 1-14",
        "en": "Hosea 1-14",
        "ja": "ホセア書 1-14",
        "ms": "Hosea 1-14",
        "th": "โฮเชยา 1-14",
        "km": "ហូសេ 1-14"
      },
      "mission": {
        "ko": "사마리아 · 이스르엘 여정에서 호세아 14장 본문 문제를 풉니다.",
        "en": "Follow Samaria · Jezreel and answer Hosea 14 chapters question bank.",
        "ja": "サマリア · イズレエルの旅で、ホセア書14章の問題バンクに答えます。",
        "ms": "Ikuti Samaria · Yizreel dan jawab bank soalan Hosea 14 bab.",
        "th": "ติดตามเส้นทางสะมาเรีย · ยิสเรเอลและตอบคลังคำถามจากโฮเชยา 14 บท",
        "km": "តាមដានដំណើរសាម៉ារី · យីសរេអែល ហើយឆ្លើយធនាគារសំណួរពីហូសេ 14 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-HOS-001",
      "next_stage_id": "JOL-001",
      "asset_key": "asset.stage.hos",
      "difficulty": "basic",
      "map_query": "Samaria northern kingdom Hosea biblical location",
      "map_region": "samaria",
      "map_x": 36.5,
      "map_y": 67.3,
      "route_group": "prophets",
      "place_names": [
        "사마리아 · 이스르엘",
        "Samaria · Jezreel",
        "사마리아·이스르엘",
        "Samaria·Jezreel",
        "サマリア · イズレエル",
        "Samaria · Yizreel",
        "สะมาเรีย · ยิสเรเอล",
        "សាម៉ារី · យីសរេអែល"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "JOL-001",
      "world_id": "W_OT_MINOR",
      "section_key": "minorProphets",
      "book_id": "JOL",
      "book_order": 29,
      "order_index": 32,
      "title": {
        "ko": "시온 · 예루살렘",
        "en": "Zion · Jerusalem",
        "ja": "シオン · エルサレム",
        "ms": "Sion · Yerusalem",
        "th": "ศิโยน · เยรูซาเล็ม",
        "km": "ស៊ីយ៉ូន · យេរូសាឡឹម"
      },
      "short_title": {
        "ko": "시온",
        "en": "Zion",
        "ja": "シオン",
        "ms": "Sion",
        "th": "ศิโยน",
        "km": "ស៊ីយ៉ូន"
      },
      "book_title": {
        "ko": "요엘",
        "en": "Joel",
        "ja": "ヨエル書",
        "ms": "Yoel",
        "th": "โยเอล",
        "km": "យ៉ូអែល"
      },
      "bible_range": "요엘 1-3",
      "references": {
        "ko": "요엘 1-3",
        "en": "Joel 1-3",
        "ja": "ヨエル書 1-3",
        "ms": "Yoel 1-3",
        "th": "โยเอล 1-3",
        "km": "យ៉ូអែល 1-3"
      },
      "mission": {
        "ko": "시온 · 예루살렘 여정에서 요엘 3장 본문 문제를 풉니다.",
        "en": "Follow Zion · Jerusalem and answer Joel 3 chapters question bank.",
        "ja": "シオン · エルサレムの旅で、ヨエル書3章の問題バンクに答えます。",
        "ms": "Ikuti Sion · Yerusalem dan jawab bank soalan Yoel 3 bab.",
        "th": "ติดตามเส้นทางศิโยน · เยรูซาเล็มและตอบคลังคำถามจากโยเอล 3 บท",
        "km": "តាមដានដំណើរស៊ីយ៉ូន · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីយ៉ូអែល 3 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-JOL-001",
      "next_stage_id": "AMO-001",
      "asset_key": "asset.stage.jol",
      "difficulty": "basic",
      "map_query": "Jerusalem Joel biblical prophet location",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "prophets",
      "place_names": [
        "시온 · 예루살렘",
        "Zion · Jerusalem",
        "시온",
        "Zion",
        "シオン · エルサレム",
        "Sion · Yerusalem",
        "ศิโยน · เยรูซาเล็ม",
        "ស៊ីយ៉ូន · យេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "AMO-001",
      "world_id": "W_OT_MINOR",
      "section_key": "minorProphets",
      "book_id": "AMO",
      "book_order": 30,
      "order_index": 33,
      "title": {
        "ko": "드고아 · 벧엘",
        "en": "Tekoa · Bethel",
        "ja": "テコア · ベテル",
        "ms": "Tekoa · Betel",
        "th": "เทโคอา · เบธเอล",
        "km": "តេកូអា · បេតអែល"
      },
      "short_title": {
        "ko": "드고아·벧엘",
        "en": "Tekoa·Bethel",
        "ja": "テコア·ベテル",
        "ms": "Tekoa·Betel",
        "th": "เทโคอา·เบธเอล",
        "km": "តេកូអា·បេតអែល"
      },
      "book_title": {
        "ko": "아모스",
        "en": "Amos",
        "ja": "アモス書",
        "ms": "Amos",
        "th": "อาโมส",
        "km": "អាម៉ុស"
      },
      "bible_range": "아모스 1-9",
      "references": {
        "ko": "아모스 1-9",
        "en": "Amos 1-9",
        "ja": "アモス書 1-9",
        "ms": "Amos 1-9",
        "th": "อาโมส 1-9",
        "km": "អាម៉ុស 1-9"
      },
      "mission": {
        "ko": "드고아 · 벧엘 여정에서 아모스 9장 본문 문제를 풉니다.",
        "en": "Follow Tekoa · Bethel and answer Amos 9 chapters question bank.",
        "ja": "テコア · ベテルの旅で、アモス書9章の問題バンクに答えます。",
        "ms": "Ikuti Tekoa · Betel dan jawab bank soalan Amos 9 bab.",
        "th": "ติดตามเส้นทางเทโคอา · เบธเอลและตอบคลังคำถามจากอาโมส 9 บท",
        "km": "តាមដានដំណើរតេកូអា · បេតអែល ហើយឆ្លើយធនាគារសំណួរពីអាម៉ុស 9 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-AMO-001",
      "next_stage_id": "OBA-001",
      "asset_key": "asset.stage.amo",
      "difficulty": "basic",
      "map_query": "Tekoa Israel Amos biblical location",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "prophets",
      "place_names": [
        "드고아 · 벧엘",
        "Tekoa · Bethel",
        "드고아·벧엘",
        "Tekoa·Bethel",
        "テコア · ベテル",
        "Tekoa · Betel",
        "เทโคอา · เบธเอล",
        "តេកូអា · បេតអែល"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "OBA-001",
      "world_id": "W_OT_MINOR",
      "section_key": "minorProphets",
      "book_id": "OBA",
      "book_order": 31,
      "order_index": 34,
      "title": {
        "ko": "에돔 산지",
        "en": "Mountains of Edom",
        "ja": "エドム山地",
        "ms": "Pergunungan Edom",
        "th": "ภูเขาเอโดม",
        "km": "តំបន់ភ្នំអេដុម"
      },
      "short_title": {
        "ko": "에돔",
        "en": "Edom",
        "ja": "エドム",
        "ms": "Edom",
        "th": "เอโดม",
        "km": "អេដុម"
      },
      "book_title": {
        "ko": "오바댜",
        "en": "Obadiah",
        "ja": "オバデヤ書",
        "ms": "Obaja",
        "th": "โอบาดีห์",
        "km": "អូបាឌា"
      },
      "bible_range": "오바댜 1",
      "references": {
        "ko": "오바댜 1",
        "en": "Obadiah 1",
        "ja": "オバデヤ書 1",
        "ms": "Obaja 1",
        "th": "โอบาดีห์ 1",
        "km": "អូបាឌា 1"
      },
      "mission": {
        "ko": "에돔 산지 여정에서 오바댜 1장 본문 문제를 풉니다.",
        "en": "Follow Mountains of Edom and answer Obadiah 1 chapters question bank.",
        "ja": "エドム山地の旅で、オバデヤ書1章の問題バンクに答えます。",
        "ms": "Ikuti Pergunungan Edom dan jawab bank soalan Obaja 1 bab.",
        "th": "ติดตามเส้นทางภูเขาเอโดมและตอบคลังคำถามจากโอบาดีห์ 1 บท",
        "km": "តាមដានដំណើរតំបន់ភ្នំអេដុម ហើយឆ្លើយធនាគារសំណួរពីអូបាឌា 1 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-OBA-001",
      "next_stage_id": "JON-001",
      "asset_key": "asset.stage.oba",
      "difficulty": "basic",
      "map_query": "Edom biblical location Obadiah",
      "map_region": "edom",
      "map_x": 36.5,
      "map_y": 79.5,
      "route_group": "prophets",
      "place_names": [
        "에돔 산지",
        "Mountains of Edom",
        "에돔",
        "Edom",
        "エドム山地",
        "Pergunungan Edom",
        "ภูเขาเอโดม",
        "តំបន់ភ្នំអេដុម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "JON-001",
      "world_id": "W_OT_MINOR",
      "section_key": "minorProphets",
      "book_id": "JON",
      "book_order": 32,
      "order_index": 35,
      "title": {
        "ko": "욥바 · 니느웨",
        "en": "Joppa · Nineveh",
        "ja": "ヨッパ · ニネベ",
        "ms": "Yope · Niniwe",
        "th": "ยัฟฟา · นีนะเวห์",
        "km": "យ៉ុបប៉ា · នីនីវេ"
      },
      "short_title": {
        "ko": "욥바·니느웨",
        "en": "Joppa·Nineveh",
        "ja": "ヨッパ·ニネベ",
        "ms": "Yope·Niniwe",
        "th": "ยัฟฟา·นีนะเวห์",
        "km": "យ៉ុបប៉ា·នីនីវេ"
      },
      "book_title": {
        "ko": "요나",
        "en": "Jonah",
        "ja": "ヨナ書",
        "ms": "Yunus",
        "th": "โยนาห์",
        "km": "យ៉ូណា"
      },
      "bible_range": "요나 1-4",
      "references": {
        "ko": "요나 1-4",
        "en": "Jonah 1-4",
        "ja": "ヨナ書 1-4",
        "ms": "Yunus 1-4",
        "th": "โยนาห์ 1-4",
        "km": "យ៉ូណា 1-4"
      },
      "mission": {
        "ko": "욥바 · 니느웨 여정에서 요나 4장 본문 문제를 풉니다.",
        "en": "Follow Joppa · Nineveh and answer Jonah 4 chapters question bank.",
        "ja": "ヨッパ · ニネベの旅で、ヨナ書4章の問題バンクに答えます。",
        "ms": "Ikuti Yope · Niniwe dan jawab bank soalan Yunus 4 bab.",
        "th": "ติดตามเส้นทางยัฟฟา · นีนะเวห์และตอบคลังคำถามจากโยนาห์ 4 บท",
        "km": "តាមដានដំណើរយ៉ុបប៉ា · នីនីវេ ហើយឆ្លើយធនាគារសំណួរពីយ៉ូណា 4 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-JON-001",
      "next_stage_id": "MIC-001",
      "asset_key": "asset.stage.jon",
      "difficulty": "basic",
      "map_query": "Nineveh Iraq Jonah biblical location",
      "map_region": "nineveh",
      "map_x": 60.5,
      "map_y": 39.4,
      "route_group": "prophets",
      "place_names": [
        "욥바 · 니느웨",
        "Joppa · Nineveh",
        "욥바·니느웨",
        "Joppa·Nineveh",
        "ヨッパ · ニネベ",
        "Yope · Niniwe",
        "ยัฟฟา · นีนะเวห์",
        "យ៉ុបប៉ា · នីនីវេ"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "MIC-001",
      "world_id": "W_OT_MINOR",
      "section_key": "minorProphets",
      "book_id": "MIC",
      "book_order": 33,
      "order_index": 36,
      "title": {
        "ko": "모레셋 · 예루살렘",
        "en": "Moresheth · Jerusalem",
        "ja": "モレシェト · エルサレム",
        "ms": "Moresyet · Yerusalem",
        "th": "โมเรเชท · เยรูซาเล็ม",
        "km": "មូរេសែត · យេរូសាឡឹម"
      },
      "short_title": {
        "ko": "모레셋",
        "en": "Moresheth",
        "ja": "モレシェト",
        "ms": "Moresyet",
        "th": "โมเรเชท",
        "km": "មូរេសែត"
      },
      "book_title": {
        "ko": "미가",
        "en": "Micah",
        "ja": "ミカ書",
        "ms": "Mikha",
        "th": "มีคาห์",
        "km": "មីកា"
      },
      "bible_range": "미가 1-7",
      "references": {
        "ko": "미가 1-7",
        "en": "Micah 1-7",
        "ja": "ミカ書 1-7",
        "ms": "Mikha 1-7",
        "th": "มีคาห์ 1-7",
        "km": "មីកា 1-7"
      },
      "mission": {
        "ko": "모레셋 · 예루살렘 여정에서 미가 7장 본문 문제를 풉니다.",
        "en": "Follow Moresheth · Jerusalem and answer Micah 7 chapters question bank.",
        "ja": "モレシェト · エルサレムの旅で、ミカ書7章の問題バンクに答えます。",
        "ms": "Ikuti Moresyet · Yerusalem dan jawab bank soalan Mikha 7 bab.",
        "th": "ติดตามเส้นทางโมเรเชท · เยรูซาเล็มและตอบคลังคำถามจากมีคาห์ 7 บท",
        "km": "តាមដានដំណើរមូរេសែត · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីមីកា 7 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-MIC-001",
      "next_stage_id": "NAM-001",
      "asset_key": "asset.stage.mic",
      "difficulty": "basic",
      "map_query": "Moresheth Gath Micah biblical location",
      "map_region": "canaan",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "prophets",
      "place_names": [
        "모레셋 · 예루살렘",
        "Moresheth · Jerusalem",
        "모레셋",
        "Moresheth",
        "モレシェト · エルサレム",
        "Moresyet · Yerusalem",
        "โมเรเชท · เยรูซาเล็ม",
        "មូរេសែត · យេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "NAM-001",
      "world_id": "W_OT_MINOR",
      "section_key": "minorProphets",
      "book_id": "NAM",
      "book_order": 34,
      "order_index": 37,
      "title": {
        "ko": "니느웨",
        "en": "Nineveh",
        "ja": "ニネベ",
        "ms": "Niniwe",
        "th": "นีนะเวห์",
        "km": "នីនីវេ"
      },
      "short_title": {
        "ko": "니느웨",
        "en": "Nineveh",
        "ja": "ニネベ",
        "ms": "Niniwe",
        "th": "นีนะเวห์",
        "km": "នីនីវេ"
      },
      "book_title": {
        "ko": "나훔",
        "en": "Nahum",
        "ja": "ナホム書",
        "ms": "Nahum",
        "th": "นาฮูม",
        "km": "ណាហ៊ុម"
      },
      "bible_range": "나훔 1-3",
      "references": {
        "ko": "나훔 1-3",
        "en": "Nahum 1-3",
        "ja": "ナホム書 1-3",
        "ms": "Nahum 1-3",
        "th": "นาฮูม 1-3",
        "km": "ណាហ៊ុម 1-3"
      },
      "mission": {
        "ko": "니느웨 여정에서 나훔 3장 본문 문제를 풉니다.",
        "en": "Follow Nineveh and answer Nahum 3 chapters question bank.",
        "ja": "ニネベの旅で、ナホム書3章の問題バンクに答えます。",
        "ms": "Ikuti Niniwe dan jawab bank soalan Nahum 3 bab.",
        "th": "ติดตามเส้นทางนีนะเวห์และตอบคลังคำถามจากนาฮูม 3 บท",
        "km": "តាមដានដំណើរនីនីវេ ហើយឆ្លើយធនាគារសំណួរពីណាហ៊ុម 3 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-NAM-001",
      "next_stage_id": "HAB-001",
      "asset_key": "asset.stage.nam",
      "difficulty": "basic",
      "map_query": "Nineveh Iraq Nahum biblical location",
      "map_region": "nineveh",
      "map_x": 60.5,
      "map_y": 39.4,
      "route_group": "prophets",
      "place_names": [
        "니느웨",
        "Nineveh",
        "니느웨",
        "Nineveh",
        "ニネベ",
        "Niniwe",
        "นีนะเวห์",
        "នីនីវេ"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "HAB-001",
      "world_id": "W_OT_MINOR",
      "section_key": "minorProphets",
      "book_id": "HAB",
      "book_order": 35,
      "order_index": 38,
      "title": {
        "ko": "예루살렘 파수대",
        "en": "Jerusalem Watchpost",
        "ja": "エルサレムの見張り場",
        "ms": "Tempat berjaga Yerusalem",
        "th": "ป้อมยามเยรูซาเล็ม",
        "km": "កន្លែងយាមនៅយេរូសាឡឹម"
      },
      "short_title": {
        "ko": "파수대",
        "en": "Watchpost",
        "ja": "見張り場",
        "ms": "Tempat berjaga",
        "th": "ป้อมยาม",
        "km": "កន្លែងយាម"
      },
      "book_title": {
        "ko": "하박국",
        "en": "Habakkuk",
        "ja": "ハバクク書",
        "ms": "Habakuk",
        "th": "ฮาบากุก",
        "km": "ហាបាគុក"
      },
      "bible_range": "하박국 1-3",
      "references": {
        "ko": "하박국 1-3",
        "en": "Habakkuk 1-3",
        "ja": "ハバクク書 1-3",
        "ms": "Habakuk 1-3",
        "th": "ฮาบากุก 1-3",
        "km": "ហាបាគុក 1-3"
      },
      "mission": {
        "ko": "예루살렘 파수대 여정에서 하박국 3장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem Watchpost and answer Habakkuk 3 chapters question bank.",
        "ja": "エルサレムの見張り場の旅で、ハバクク書3章の問題バンクに答えます。",
        "ms": "Ikuti Tempat berjaga Yerusalem dan jawab bank soalan Habakuk 3 bab.",
        "th": "ติดตามเส้นทางป้อมยามเยรูซาเล็มและตอบคลังคำถามจากฮาบากุก 3 บท",
        "km": "តាមដានដំណើរកន្លែងយាមនៅយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីហាបាគុក 3 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-HAB-001",
      "next_stage_id": "ZEP-001",
      "asset_key": "asset.stage.hab",
      "difficulty": "basic",
      "map_query": "Judah Jerusalem Habakkuk biblical location",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "prophets",
      "place_names": [
        "예루살렘 파수대",
        "Jerusalem Watchpost",
        "파수대",
        "Watchpost",
        "エルサレムの見張り場",
        "Tempat berjaga Yerusalem",
        "ป้อมยามเยรูซาเล็ม",
        "កន្លែងយាមនៅយេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "ZEP-001",
      "world_id": "W_OT_MINOR",
      "section_key": "minorProphets",
      "book_id": "ZEP",
      "book_order": 36,
      "order_index": 39,
      "title": {
        "ko": "예루살렘",
        "en": "Jerusalem",
        "ja": "エルサレム",
        "ms": "Yerusalem",
        "th": "เยรูซาเล็ม",
        "km": "យេរូសាឡឹម"
      },
      "short_title": {
        "ko": "예루살렘",
        "en": "Jerusalem",
        "ja": "エルサレム",
        "ms": "Yerusalem",
        "th": "เยรูซาเล็ม",
        "km": "យេរូសាឡឹម"
      },
      "book_title": {
        "ko": "스바냐",
        "en": "Zephaniah",
        "ja": "ゼパニヤ書",
        "ms": "Zefanya",
        "th": "เศฟันยาห์",
        "km": "សេផានា"
      },
      "bible_range": "스바냐 1-3",
      "references": {
        "ko": "스바냐 1-3",
        "en": "Zephaniah 1-3",
        "ja": "ゼパニヤ書 1-3",
        "ms": "Zefanya 1-3",
        "th": "เศฟันยาห์ 1-3",
        "km": "សេផានា 1-3"
      },
      "mission": {
        "ko": "예루살렘 여정에서 스바냐 3장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem and answer Zephaniah 3 chapters question bank.",
        "ja": "エルサレムの旅で、ゼパニヤ書3章の問題バンクに答えます。",
        "ms": "Ikuti Yerusalem dan jawab bank soalan Zefanya 3 bab.",
        "th": "ติดตามเส้นทางเยรูซาเล็มและตอบคลังคำถามจากเศฟันยาห์ 3 บท",
        "km": "តាមដានដំណើរយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីសេផានា 3 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-ZEP-001",
      "next_stage_id": "HAG-001",
      "asset_key": "asset.stage.zep",
      "difficulty": "basic",
      "map_query": "Jerusalem Zephaniah biblical prophet location",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "prophets",
      "place_names": [
        "예루살렘",
        "Jerusalem",
        "예루살렘",
        "Jerusalem",
        "エルサレム",
        "Yerusalem",
        "เยรูซาเล็ม",
        "យេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "HAG-001",
      "world_id": "W_OT_MINOR",
      "section_key": "minorProphets",
      "book_id": "HAG",
      "book_order": 37,
      "order_index": 40,
      "title": {
        "ko": "예루살렘 성전터",
        "en": "Jerusalem Temple Site",
        "ja": "エルサレム神殿跡",
        "ms": "Tapak Bait Suci Yerusalem",
        "th": "สถานที่พระวิหารเยรูซาเล็ม",
        "km": "ទីតាំងព្រះវិហារយេរូសាឡឹម"
      },
      "short_title": {
        "ko": "성전터",
        "en": "Temple Site",
        "ja": "神殿跡",
        "ms": "Tapak Bait Suci",
        "th": "สถานที่พระวิหาร",
        "km": "ទីតាំងព្រះវិហារ"
      },
      "book_title": {
        "ko": "학개",
        "en": "Haggai",
        "ja": "ハガイ書",
        "ms": "Hagai",
        "th": "ฮักกัย",
        "km": "ហាកាយ"
      },
      "bible_range": "학개 1-2",
      "references": {
        "ko": "학개 1-2",
        "en": "Haggai 1-2",
        "ja": "ハガイ書 1-2",
        "ms": "Hagai 1-2",
        "th": "ฮักกัย 1-2",
        "km": "ហាកាយ 1-2"
      },
      "mission": {
        "ko": "예루살렘 성전터 여정에서 학개 2장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem Temple Site and answer Haggai 2 chapters question bank.",
        "ja": "エルサレム神殿跡の旅で、ハガイ書2章の問題バンクに答えます。",
        "ms": "Ikuti Tapak Bait Suci Yerusalem dan jawab bank soalan Hagai 2 bab.",
        "th": "ติดตามเส้นทางสถานที่พระวิหารเยรูซาเล็มและตอบคลังคำถามจากฮักกัย 2 บท",
        "km": "តាមដានដំណើរទីតាំងព្រះវិហារយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីហាកាយ 2 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-HAG-001",
      "next_stage_id": "ZEC-001",
      "asset_key": "asset.stage.hag",
      "difficulty": "basic",
      "map_query": "Jerusalem Second Temple Haggai biblical location",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "prophets",
      "place_names": [
        "예루살렘 성전터",
        "Jerusalem Temple Site",
        "성전터",
        "Temple Site",
        "エルサレム神殿跡",
        "Tapak Bait Suci Yerusalem",
        "สถานที่พระวิหารเยรูซาเล็ม",
        "ទីតាំងព្រះវិហារយេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "ZEC-001",
      "world_id": "W_OT_MINOR",
      "section_key": "minorProphets",
      "book_id": "ZEC",
      "book_order": 38,
      "order_index": 41,
      "title": {
        "ko": "예루살렘 성전터",
        "en": "Jerusalem Temple Site",
        "ja": "エルサレム神殿跡",
        "ms": "Tapak Bait Suci Yerusalem",
        "th": "สถานที่พระวิหารเยรูซาเล็ม",
        "km": "ទីតាំងព្រះវិហារយេរូសាឡឹម"
      },
      "short_title": {
        "ko": "성전터",
        "en": "Temple Site",
        "ja": "神殿跡",
        "ms": "Tapak Bait Suci",
        "th": "สถานที่พระวิหาร",
        "km": "ទីតាំងព្រះវិហារ"
      },
      "book_title": {
        "ko": "스가랴",
        "en": "Zechariah",
        "ja": "ゼカリヤ書",
        "ms": "Zakharia",
        "th": "เศคาริยาห์",
        "km": "សាការី"
      },
      "bible_range": "스가랴 1-14",
      "references": {
        "ko": "스가랴 1-14",
        "en": "Zechariah 1-14",
        "ja": "ゼカリヤ書 1-14",
        "ms": "Zakharia 1-14",
        "th": "เศคาริยาห์ 1-14",
        "km": "សាការី 1-14"
      },
      "mission": {
        "ko": "예루살렘 성전터 여정에서 스가랴 14장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem Temple Site and answer Zechariah 14 chapters question bank.",
        "ja": "エルサレム神殿跡の旅で、ゼカリヤ書14章の問題バンクに答えます。",
        "ms": "Ikuti Tapak Bait Suci Yerusalem dan jawab bank soalan Zakharia 14 bab.",
        "th": "ติดตามเส้นทางสถานที่พระวิหารเยรูซาเล็มและตอบคลังคำถามจากเศคาริยาห์ 14 บท",
        "km": "តាមដានដំណើរទីតាំងព្រះវិហារយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីសាការី 14 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-ZEC-001",
      "next_stage_id": "MAL-001",
      "asset_key": "asset.stage.zec",
      "difficulty": "basic",
      "map_query": "Jerusalem Zechariah biblical prophet location",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "prophets",
      "place_names": [
        "예루살렘 성전터",
        "Jerusalem Temple Site",
        "성전터",
        "Temple Site",
        "エルサレム神殿跡",
        "Tapak Bait Suci Yerusalem",
        "สถานที่พระวิหารเยรูซาเล็ม",
        "ទីតាំងព្រះវិហារយេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "MAL-001",
      "world_id": "W_OT_MINOR",
      "section_key": "minorProphets",
      "book_id": "MAL",
      "book_order": 39,
      "order_index": 42,
      "title": {
        "ko": "예루살렘 성전",
        "en": "Jerusalem Temple",
        "ja": "エルサレム神殿",
        "ms": "Bait Suci Yerusalem",
        "th": "พระวิหารเยรูซาเล็ม",
        "km": "ព្រះវិហារយេរូសាឡឹម"
      },
      "short_title": {
        "ko": "성전",
        "en": "Temple",
        "ja": "神殿",
        "ms": "Bait Suci",
        "th": "พระวิหาร",
        "km": "ព្រះវិហារ"
      },
      "book_title": {
        "ko": "말라기",
        "en": "Malachi",
        "ja": "マラキ書",
        "ms": "Maleakhi",
        "th": "มาลาคี",
        "km": "ម៉ាឡាគី"
      },
      "bible_range": "말라기 1-4",
      "references": {
        "ko": "말라기 1-4",
        "en": "Malachi 1-4",
        "ja": "マラキ書 1-4",
        "ms": "Maleakhi 1-4",
        "th": "มาลาคี 1-4",
        "km": "ម៉ាឡាគី 1-4"
      },
      "mission": {
        "ko": "예루살렘 성전 여정에서 말라기 4장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem Temple and answer Malachi 4 chapters question bank.",
        "ja": "エルサレム神殿の旅で、マラキ書4章の問題バンクに答えます。",
        "ms": "Ikuti Bait Suci Yerusalem dan jawab bank soalan Maleakhi 4 bab.",
        "th": "ติดตามเส้นทางพระวิหารเยรูซาเล็มและตอบคลังคำถามจากมาลาคี 4 บท",
        "km": "តាមដានដំណើរព្រះវិហារយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីម៉ាឡាគី 4 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-MAL-001",
      "next_stage_id": "HOS-REVIEW-13",
      "asset_key": "asset.stage.mal",
      "difficulty": "basic",
      "map_query": "Jerusalem Second Temple Malachi biblical location",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "prophets",
      "place_names": [
        "예루살렘 성전",
        "Jerusalem Temple",
        "성전",
        "Temple",
        "エルサレム神殿",
        "Bait Suci Yerusalem",
        "พระวิหารเยรูซาเล็ม",
        "ព្រះវិហារយេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "HOS-REVIEW-13",
      "world_id": "W_OT_MINOR",
      "section_key": "minorProphets",
      "book_id": "HOS",
      "book_order": 28,
      "order_index": 43,
      "title": {
        "ko": "사마리아 · 이스르엘 복습",
        "en": "Samaria · Jezreel Review",
        "ja": "サマリア · イズレエル 復習",
        "ms": "Samaria · Yizreel Ulang kaji",
        "th": "สะมาเรีย · ยิสเรเอล ทบทวน",
        "km": "សាម៉ារី · យីសរេអែល រំលឹក"
      },
      "short_title": {
        "ko": "사마리아·이스르엘+",
        "en": "Samaria·Jezreel+",
        "ja": "サマリア·イズレエル+",
        "ms": "Samaria·Yizreel+",
        "th": "สะมาเรีย·ยิสเรเอล+",
        "km": "សាម៉ារី·យីសរេអែល+"
      },
      "book_title": {
        "ko": "호세아",
        "en": "Hosea",
        "ja": "ホセア書",
        "ms": "Hosea",
        "th": "โฮเชยา",
        "km": "ហូសេ"
      },
      "bible_range": "호세아 1-14",
      "references": {
        "ko": "호세아 1-14",
        "en": "Hosea 1-14",
        "ja": "ホセア書 1-14",
        "ms": "Hosea 1-14",
        "th": "โฮเชยา 1-14",
        "km": "ហូសេ 1-14"
      },
      "mission": {
        "ko": "사마리아 · 이스르엘 길에서 호세아 주요 사건을 다시 확인합니다.",
        "en": "Review the main Hosea events along Samaria · Jezreel.",
        "ja": "サマリア · イズレエルの道で、ホセア書の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Hosea di sepanjang Samaria · Yizreel.",
        "th": "ทบทวนเหตุการณ์สำคัญของโฮเชยาตามเส้นทางสะมาเรีย · ยิสเรเอล",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃហូសេ តាមផ្លូវសាម៉ារី · យីសរេអែល។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-HOS-REVIEW-13",
      "next_stage_id": "JOL-REVIEW-14",
      "asset_key": "asset.stage.hos.review.13",
      "difficulty": "review",
      "map_query": "Samaria northern kingdom Hosea biblical location review",
      "map_region": "samaria",
      "map_x": 36.5,
      "map_y": 67.3,
      "route_group": "prophets",
      "place_names": [
        "사마리아 · 이스르엘",
        "Samaria · Jezreel",
        "사마리아·이스르엘",
        "Samaria·Jezreel",
        "サマリア · イズレエル",
        "Samaria · Yizreel",
        "สะมาเรีย · ยิสเรเอล",
        "សាម៉ារី · យីសរេអែល"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "JOL-REVIEW-14",
      "world_id": "W_OT_MINOR",
      "section_key": "minorProphets",
      "book_id": "JOL",
      "book_order": 29,
      "order_index": 44,
      "title": {
        "ko": "시온 · 예루살렘 복습",
        "en": "Zion · Jerusalem Review",
        "ja": "シオン · エルサレム 復習",
        "ms": "Sion · Yerusalem Ulang kaji",
        "th": "ศิโยน · เยรูซาเล็ม ทบทวน",
        "km": "ស៊ីយ៉ូន · យេរូសាឡឹម រំលឹក"
      },
      "short_title": {
        "ko": "시온+",
        "en": "Zion+",
        "ja": "シオン+",
        "ms": "Sion+",
        "th": "ศิโยน+",
        "km": "ស៊ីយ៉ូន+"
      },
      "book_title": {
        "ko": "요엘",
        "en": "Joel",
        "ja": "ヨエル書",
        "ms": "Yoel",
        "th": "โยเอล",
        "km": "យ៉ូអែល"
      },
      "bible_range": "요엘 1-3",
      "references": {
        "ko": "요엘 1-3",
        "en": "Joel 1-3",
        "ja": "ヨエル書 1-3",
        "ms": "Yoel 1-3",
        "th": "โยเอล 1-3",
        "km": "យ៉ូអែល 1-3"
      },
      "mission": {
        "ko": "시온 · 예루살렘 길에서 요엘 주요 사건을 다시 확인합니다.",
        "en": "Review the main Joel events along Zion · Jerusalem.",
        "ja": "シオン · エルサレムの道で、ヨエル書の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Yoel di sepanjang Sion · Yerusalem.",
        "th": "ทบทวนเหตุการณ์สำคัญของโยเอลตามเส้นทางศิโยน · เยรูซาเล็ม",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃយ៉ូអែល តាមផ្លូវស៊ីយ៉ូន · យេរូសាឡឹម។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-JOL-REVIEW-14",
      "next_stage_id": "AMO-REVIEW-15",
      "asset_key": "asset.stage.jol.review.14",
      "difficulty": "review",
      "map_query": "Jerusalem Joel biblical prophet location review",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "prophets",
      "place_names": [
        "시온 · 예루살렘",
        "Zion · Jerusalem",
        "시온",
        "Zion",
        "シオン · エルサレム",
        "Sion · Yerusalem",
        "ศิโยน · เยรูซาเล็ม",
        "ស៊ីយ៉ូន · យេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "AMO-REVIEW-15",
      "world_id": "W_OT_MINOR",
      "section_key": "minorProphets",
      "book_id": "AMO",
      "book_order": 30,
      "order_index": 45,
      "title": {
        "ko": "드고아 · 벧엘 복습",
        "en": "Tekoa · Bethel Review",
        "ja": "テコア · ベテル 復習",
        "ms": "Tekoa · Betel Ulang kaji",
        "th": "เทโคอา · เบธเอล ทบทวน",
        "km": "តេកូអា · បេតអែល រំលឹក"
      },
      "short_title": {
        "ko": "드고아·벧엘+",
        "en": "Tekoa·Bethel+",
        "ja": "テコア·ベテル+",
        "ms": "Tekoa·Betel+",
        "th": "เทโคอา·เบธเอล+",
        "km": "តេកូអា·បេតអែល+"
      },
      "book_title": {
        "ko": "아모스",
        "en": "Amos",
        "ja": "アモス書",
        "ms": "Amos",
        "th": "อาโมส",
        "km": "អាម៉ុស"
      },
      "bible_range": "아모스 1-9",
      "references": {
        "ko": "아모스 1-9",
        "en": "Amos 1-9",
        "ja": "アモス書 1-9",
        "ms": "Amos 1-9",
        "th": "อาโมส 1-9",
        "km": "អាម៉ុស 1-9"
      },
      "mission": {
        "ko": "드고아 · 벧엘 길에서 아모스 주요 사건을 다시 확인합니다.",
        "en": "Review the main Amos events along Tekoa · Bethel.",
        "ja": "テコア · ベテルの道で、アモス書の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Amos di sepanjang Tekoa · Betel.",
        "th": "ทบทวนเหตุการณ์สำคัญของอาโมสตามเส้นทางเทโคอา · เบธเอล",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃអាម៉ុស តាមផ្លូវតេកូអា · បេតអែល។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-AMO-REVIEW-15",
      "next_stage_id": "MAT-001",
      "asset_key": "asset.stage.amo.review.15",
      "difficulty": "review",
      "map_query": "Tekoa Israel Amos biblical location review",
      "map_region": "jerusalem",
      "map_x": 37.2,
      "map_y": 70.2,
      "route_group": "prophets",
      "place_names": [
        "드고아 · 벧엘",
        "Tekoa · Bethel",
        "드고아·벧엘",
        "Tekoa·Bethel",
        "テコア · ベテル",
        "Tekoa · Betel",
        "เทโคอา · เบธเอล",
        "តេកូអា · បេតអែល"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "MAT-001",
      "world_id": "W_NT_GOS",
      "section_key": "gospels",
      "book_id": "MAT",
      "book_order": 40,
      "order_index": 46,
      "title": {
        "ko": "베들레헴 · 갈릴리 · 예루살렘",
        "en": "Bethlehem · Galilee · Jerusalem",
        "ja": "ベツレヘム · ガリラヤ · エルサレム",
        "ms": "Betlehem · Galilea · Yerusalem",
        "th": "เบธเลเฮม · กาลิลี · เยรูซาเล็ม",
        "km": "បេថ្លេហិម · កាលីឡេ · យេរូសាឡឹម"
      },
      "short_title": {
        "ko": "베들레헴·갈릴리",
        "en": "Bethlehem·Galilee",
        "ja": "ベツレヘム·ガリラヤ",
        "ms": "Betlehem·Galilea",
        "th": "เบธเลเฮม·กาลิลี",
        "km": "បេថ្លេហិម·កាលីឡេ"
      },
      "book_title": {
        "ko": "마태복음",
        "en": "Matthew",
        "ja": "マタイの福音書",
        "ms": "Matius",
        "th": "มัทธิว",
        "km": "ម៉ាថាយ"
      },
      "bible_range": "마태복음 1-28",
      "references": {
        "ko": "마태복음 1-28",
        "en": "Matthew 1-28",
        "ja": "マタイの福音書 1-28",
        "ms": "Matius 1-28",
        "th": "มัทธิว 1-28",
        "km": "ម៉ាថាយ 1-28"
      },
      "mission": {
        "ko": "베들레헴 · 갈릴리 · 예루살렘 여정에서 마태복음 28장 본문 문제를 풉니다.",
        "en": "Follow Bethlehem · Galilee · Jerusalem and answer Matthew 28 chapters question bank.",
        "ja": "ベツレヘム · ガリラヤ · エルサレムの旅で、マタイの福音書28章の問題バンクに答えます。",
        "ms": "Ikuti Betlehem · Galilea · Yerusalem dan jawab bank soalan Matius 28 bab.",
        "th": "ติดตามเส้นทางเบธเลเฮม · กาลิลี · เยรูซาเล็มและตอบคลังคำถามจากมัทธิว 28 บท",
        "km": "តាមដានដំណើរបេថ្លេហិម · កាលីឡេ · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីម៉ាថាយ 28 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-MAT-001",
      "next_stage_id": "MRK-001",
      "asset_key": "asset.stage.mat",
      "difficulty": "basic",
      "map_query": "Bethlehem Galilee Jerusalem Jesus biblical route",
      "map_region": "bethlehem",
      "map_x": 47.4,
      "map_y": 70.5,
      "route_group": "new-testament",
      "place_names": [
        "베들레헴 · 갈릴리 · 예루살렘",
        "Bethlehem · Galilee · Jerusalem",
        "베들레헴·갈릴리",
        "Bethlehem·Galilee",
        "ベツレヘム · ガリラヤ · エルサレム",
        "Betlehem · Galilea · Yerusalem",
        "เบธเลเฮม · กาลิลี · เยรูซาเล็ม",
        "បេថ្លេហិម · កាលីឡេ · យេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "MRK-001",
      "world_id": "W_NT_GOS",
      "section_key": "gospels",
      "book_id": "MRK",
      "book_order": 41,
      "order_index": 47,
      "title": {
        "ko": "갈릴리 · 가버나움",
        "en": "Galilee · Capernaum",
        "ja": "ガリラヤ · カペナウム",
        "ms": "Galilea · Kapernaum",
        "th": "กาลิลี · คาเปอรนาอุม",
        "km": "កាលីឡេ · កាពើណិម"
      },
      "short_title": {
        "ko": "갈릴리·가버나움",
        "en": "Galilee·Capernaum",
        "ja": "ガリラヤ·カペナウム",
        "ms": "Galilea·Kapernaum",
        "th": "กาลิลี·คาเปอรนาอุม",
        "km": "កាលីឡេ·កាពើណិម"
      },
      "book_title": {
        "ko": "마가복음",
        "en": "Mark",
        "ja": "マルコの福音書",
        "ms": "Markus",
        "th": "มาระโก",
        "km": "ម៉ាកុស"
      },
      "bible_range": "마가복음 1-16",
      "references": {
        "ko": "마가복음 1-16",
        "en": "Mark 1-16",
        "ja": "マルコの福音書 1-16",
        "ms": "Markus 1-16",
        "th": "มาระโก 1-16",
        "km": "ម៉ាកុស 1-16"
      },
      "mission": {
        "ko": "갈릴리 · 가버나움 여정에서 마가복음 16장 본문 문제를 풉니다.",
        "en": "Follow Galilee · Capernaum and answer Mark 16 chapters question bank.",
        "ja": "ガリラヤ · カペナウムの旅で、マルコの福音書16章の問題バンクに答えます。",
        "ms": "Ikuti Galilea · Kapernaum dan jawab bank soalan Markus 16 bab.",
        "th": "ติดตามเส้นทางกาลิลี · คาเปอรนาอุมและตอบคลังคำถามจากมาระโก 16 บท",
        "km": "តាមដានដំណើរកាលីឡេ · កាពើណិម ហើយឆ្លើយធនាគារសំណួរពីម៉ាកុស 16 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-MRK-001",
      "next_stage_id": "LUK-001",
      "asset_key": "asset.stage.mrk",
      "difficulty": "basic",
      "map_query": "Capernaum Galilee Mark Gospel biblical location",
      "map_region": "galilee",
      "map_x": 51.8,
      "map_y": 37,
      "route_group": "new-testament",
      "place_names": [
        "갈릴리 · 가버나움",
        "Galilee · Capernaum",
        "갈릴리·가버나움",
        "Galilee·Capernaum",
        "ガリラヤ · カペナウム",
        "Galilea · Kapernaum",
        "กาลิลี · คาเปอรนาอุม",
        "កាលីឡេ · កាពើណិម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "LUK-001",
      "world_id": "W_NT_GOS",
      "section_key": "gospels",
      "book_id": "LUK",
      "book_order": 42,
      "order_index": 48,
      "title": {
        "ko": "나사렛 · 베들레헴 · 예루살렘",
        "en": "Nazareth · Bethlehem · Jerusalem",
        "ja": "ナザレ · ベツレヘム · エルサレム",
        "ms": "Nazaret · Betlehem · Yerusalem",
        "th": "นาซาเร็ธ · เบธเลเฮม · เยรูซาเล็ม",
        "km": "ណាសារ៉ែត · បេថ្លេហិម · យេរូសាឡឹម"
      },
      "short_title": {
        "ko": "나사렛·베들레헴",
        "en": "Nazareth·Bethlehem",
        "ja": "ナザレ·ベツレヘム",
        "ms": "Nazaret·Betlehem",
        "th": "นาซาเร็ธ·เบธเลเฮม",
        "km": "ណាសារ៉ែត·បេថ្លេហិម"
      },
      "book_title": {
        "ko": "누가복음",
        "en": "Luke",
        "ja": "ルカの福音書",
        "ms": "Lukas",
        "th": "ลูกา",
        "km": "លូកា"
      },
      "bible_range": "누가복음 1-24",
      "references": {
        "ko": "누가복음 1-24",
        "en": "Luke 1-24",
        "ja": "ルカの福音書 1-24",
        "ms": "Lukas 1-24",
        "th": "ลูกา 1-24",
        "km": "លូកា 1-24"
      },
      "mission": {
        "ko": "나사렛 · 베들레헴 · 예루살렘 여정에서 누가복음 24장 본문 문제를 풉니다.",
        "en": "Follow Nazareth · Bethlehem · Jerusalem and answer Luke 24 chapters question bank.",
        "ja": "ナザレ · ベツレヘム · エルサレムの旅で、ルカの福音書24章の問題バンクに答えます。",
        "ms": "Ikuti Nazaret · Betlehem · Yerusalem dan jawab bank soalan Lukas 24 bab.",
        "th": "ติดตามเส้นทางนาซาเร็ธ · เบธเลเฮม · เยรูซาเล็มและตอบคลังคำถามจากลูกา 24 บท",
        "km": "តាមដានដំណើរណាសារ៉ែត · បេថ្លេហិម · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីលូកា 24 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-LUK-001",
      "next_stage_id": "JHN-001",
      "asset_key": "asset.stage.luk",
      "difficulty": "basic",
      "map_query": "Nazareth Bethlehem Jerusalem Luke biblical route",
      "map_region": "galilee",
      "map_x": 52.2,
      "map_y": 39.2,
      "route_group": "new-testament",
      "place_names": [
        "나사렛 · 베들레헴 · 예루살렘",
        "Nazareth · Bethlehem · Jerusalem",
        "나사렛·베들레헴",
        "Nazareth·Bethlehem",
        "ナザレ · ベツレヘム · エルサレム",
        "Nazaret · Betlehem · Yerusalem",
        "นาซาเร็ธ · เบธเลเฮม · เยรูซาเล็ม",
        "ណាសារ៉ែត · បេថ្លេហិម · យេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "JHN-001",
      "world_id": "W_NT_GOS",
      "section_key": "gospels",
      "book_id": "JHN",
      "book_order": 43,
      "order_index": 49,
      "title": {
        "ko": "갈릴리 · 예루살렘",
        "en": "Galilee · Jerusalem",
        "ja": "ガリラヤ · エルサレム",
        "ms": "Galilea · Yerusalem",
        "th": "กาลิลี · เยรูซาเล็ม",
        "km": "កាលីឡេ · យេរូសាឡឹម"
      },
      "short_title": {
        "ko": "갈릴리·예루살렘",
        "en": "Galilee·Jerusalem",
        "ja": "ガリラヤ·エルサレム",
        "ms": "Galilea·Yerusalem",
        "th": "กาลิลี·เยรูซาเล็ม",
        "km": "កាលីឡេ·យេរូសាឡឹម"
      },
      "book_title": {
        "ko": "요한복음",
        "en": "John",
        "ja": "ヨハネの福音書",
        "ms": "Yohanes",
        "th": "ยอห์น",
        "km": "យ៉ូហាន"
      },
      "bible_range": "요한복음 1-21",
      "references": {
        "ko": "요한복음 1-21",
        "en": "John 1-21",
        "ja": "ヨハネの福音書 1-21",
        "ms": "Yohanes 1-21",
        "th": "ยอห์น 1-21",
        "km": "យ៉ូហាន 1-21"
      },
      "mission": {
        "ko": "갈릴리 · 예루살렘 여정에서 요한복음 21장 본문 문제를 풉니다.",
        "en": "Follow Galilee · Jerusalem and answer John 21 chapters question bank.",
        "ja": "ガリラヤ · エルサレムの旅で、ヨハネの福音書21章の問題バンクに答えます。",
        "ms": "Ikuti Galilea · Yerusalem dan jawab bank soalan Yohanes 21 bab.",
        "th": "ติดตามเส้นทางกาลิลี · เยรูซาเล็มและตอบคลังคำถามจากยอห์น 21 บท",
        "km": "តាមដានដំណើរកាលីឡេ · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីយ៉ូហាន 21 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-JHN-001",
      "next_stage_id": "MAT-REVIEW-05",
      "asset_key": "asset.stage.jhn",
      "difficulty": "basic",
      "map_query": "Jerusalem and Galilee John Gospel biblical route",
      "map_region": "jerusalem",
      "map_x": 47.2,
      "map_y": 69.2,
      "route_group": "new-testament",
      "place_names": [
        "갈릴리 · 예루살렘",
        "Galilee · Jerusalem",
        "갈릴리·예루살렘",
        "Galilee·Jerusalem",
        "ガリラヤ · エルサレム",
        "Galilea · Yerusalem",
        "กาลิลี · เยรูซาเล็ม",
        "កាលីឡេ · យេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "MAT-REVIEW-05",
      "world_id": "W_NT_GOS",
      "section_key": "gospels",
      "book_id": "MAT",
      "book_order": 40,
      "order_index": 50,
      "title": {
        "ko": "베들레헴 · 갈릴리 · 예루살렘 복습",
        "en": "Bethlehem · Galilee · Jerusalem Review",
        "ja": "ベツレヘム · ガリラヤ · エルサレム 復習",
        "ms": "Betlehem · Galilea · Yerusalem Ulang kaji",
        "th": "เบธเลเฮม · กาลิลี · เยรูซาเล็ม ทบทวน",
        "km": "បេថ្លេហិម · កាលីឡេ · យេរូសាឡឹម រំលឹក"
      },
      "short_title": {
        "ko": "베들레헴·갈릴리+",
        "en": "Bethlehem·Galilee+",
        "ja": "ベツレヘム·ガリラヤ+",
        "ms": "Betlehem·Galilea+",
        "th": "เบธเลเฮม·กาลิลี+",
        "km": "បេថ្លេហិម·កាលីឡេ+"
      },
      "book_title": {
        "ko": "마태복음",
        "en": "Matthew",
        "ja": "マタイの福音書",
        "ms": "Matius",
        "th": "มัทธิว",
        "km": "ម៉ាថាយ"
      },
      "bible_range": "마태복음 1-28",
      "references": {
        "ko": "마태복음 1-28",
        "en": "Matthew 1-28",
        "ja": "マタイの福音書 1-28",
        "ms": "Matius 1-28",
        "th": "มัทธิว 1-28",
        "km": "ម៉ាថាយ 1-28"
      },
      "mission": {
        "ko": "베들레헴 · 갈릴리 · 예루살렘 길에서 마태복음 주요 사건을 다시 확인합니다.",
        "en": "Review the main Matthew events along Bethlehem · Galilee · Jerusalem.",
        "ja": "ベツレヘム · ガリラヤ · エルサレムの道で、マタイの福音書の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Matius di sepanjang Betlehem · Galilea · Yerusalem.",
        "th": "ทบทวนเหตุการณ์สำคัญของมัทธิวตามเส้นทางเบธเลเฮม · กาลิลี · เยรูซาเล็ม",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃម៉ាថាយ តាមផ្លូវបេថ្លេហិម · កាលីឡេ · យេរូសាឡឹម។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-MAT-REVIEW-05",
      "next_stage_id": "ACT-001",
      "asset_key": "asset.stage.mat.review.5",
      "difficulty": "review",
      "map_query": "Bethlehem Galilee Jerusalem Jesus biblical route review",
      "map_region": "bethlehem",
      "map_x": 47.4,
      "map_y": 70.5,
      "route_group": "new-testament",
      "place_names": [
        "베들레헴 · 갈릴리 · 예루살렘",
        "Bethlehem · Galilee · Jerusalem",
        "베들레헴·갈릴리",
        "Bethlehem·Galilee",
        "ベツレヘム · ガリラヤ · エルサレム",
        "Betlehem · Galilea · Yerusalem",
        "เบธเลเฮม · กาลิลี · เยรูซาเล็ม",
        "បេថ្លេហិម · កាលីឡេ · យេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "ACT-001",
      "world_id": "W_NT_ACTS",
      "section_key": "acts",
      "book_id": "ACT",
      "book_order": 44,
      "order_index": 51,
      "title": {
        "ko": "예루살렘 · 안디옥 · 로마",
        "en": "Jerusalem · Antioch · Rome",
        "ja": "エルサレム · アンティオキア · ローマ",
        "ms": "Yerusalem · Antiokhia · Roma",
        "th": "เยรูซาเล็ม · อันทิโอก · โรม",
        "km": "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម"
      },
      "short_title": {
        "ko": "예루살렘·안디옥·로마",
        "en": "Jerusalem·Antioch·Rome",
        "ja": "エルサレム·アンティオキア·ローマ",
        "ms": "Yerusalem·Antiokhia·Roma",
        "th": "เยรูซาเล็ม·อันทิโอก·โรม",
        "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម"
      },
      "book_title": {
        "ko": "사도행전",
        "en": "Acts",
        "ja": "使徒の働き",
        "ms": "Kisah Para Rasul",
        "th": "กิจการ",
        "km": "កិច្ចការ"
      },
      "bible_range": "사도행전 1-28",
      "references": {
        "ko": "사도행전 1-28",
        "en": "Acts 1-28",
        "ja": "使徒の働き 1-28",
        "ms": "Kisah Para Rasul 1-28",
        "th": "กิจการ 1-28",
        "km": "កិច្ចការ 1-28"
      },
      "mission": {
        "ko": "예루살렘 · 안디옥 · 로마 여정에서 사도행전 28장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem · Antioch · Rome and answer Acts 28 chapters question bank.",
        "ja": "エルサレム · アンティオキア · ローマの旅で、使徒の働き28章の問題バンクに答えます。",
        "ms": "Ikuti Yerusalem · Antiokhia · Roma dan jawab bank soalan Kisah Para Rasul 28 bab.",
        "th": "ติดตามเส้นทางเยรูซาเล็ม · อันทิโอก · โรมและตอบคลังคำถามจากกิจการ 28 บท",
        "km": "តាមដានដំណើរយេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម ហើយឆ្លើយធនាគារសំណួរពីកិច្ចការ 28 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-ACT-001",
      "next_stage_id": "ACT-REVIEW-02",
      "asset_key": "asset.stage.act",
      "difficulty": "basic",
      "map_query": "Jerusalem Antioch Rome Acts mission route",
      "map_region": "antioch",
      "map_x": 78.5,
      "map_y": 43.5,
      "route_group": "letters",
      "place_names": [
        "예루살렘 · 안디옥 · 로마",
        "Jerusalem · Antioch · Rome",
        "예루살렘·안디옥·로마",
        "Jerusalem·Antioch·Rome",
        "エルサレム · アンティオキア · ローマ",
        "Yerusalem · Antiokhia · Roma",
        "เยรูซาเล็ม · อันทิโอก · โรม",
        "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "ACT-REVIEW-02",
      "world_id": "W_NT_ACTS",
      "section_key": "acts",
      "book_id": "ACT",
      "book_order": 44,
      "order_index": 52,
      "title": {
        "ko": "예루살렘 · 안디옥 · 로마 복습",
        "en": "Jerusalem · Antioch · Rome Review",
        "ja": "エルサレム · アンティオキア · ローマ 復習",
        "ms": "Yerusalem · Antiokhia · Roma Ulang kaji",
        "th": "เยรูซาเล็ม · อันทิโอก · โรม ทบทวน",
        "km": "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម រំលឹក"
      },
      "short_title": {
        "ko": "예루살렘·안디옥·로마+",
        "en": "Jerusalem·Antioch·Rome+",
        "ja": "エルサレム·アンティオキア·ローマ+",
        "ms": "Yerusalem·Antiokhia·Roma+",
        "th": "เยรูซาเล็ม·อันทิโอก·โรม+",
        "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+"
      },
      "book_title": {
        "ko": "사도행전",
        "en": "Acts",
        "ja": "使徒の働き",
        "ms": "Kisah Para Rasul",
        "th": "กิจการ",
        "km": "កិច្ចការ"
      },
      "bible_range": "사도행전 1-28",
      "references": {
        "ko": "사도행전 1-28",
        "en": "Acts 1-28",
        "ja": "使徒の働き 1-28",
        "ms": "Kisah Para Rasul 1-28",
        "th": "กิจการ 1-28",
        "km": "កិច្ចការ 1-28"
      },
      "mission": {
        "ko": "예루살렘 · 안디옥 · 로마 길에서 사도행전 주요 사건을 다시 확인합니다.",
        "en": "Review the main Acts events along Jerusalem · Antioch · Rome.",
        "ja": "エルサレム · アンティオキア · ローマの道で、使徒の働きの主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Kisah Para Rasul di sepanjang Yerusalem · Antiokhia · Roma.",
        "th": "ทบทวนเหตุการณ์สำคัญของกิจการตามเส้นทางเยรูซาเล็ม · อันทิโอก · โรม",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃកិច្ចការ តាមផ្លូវយេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-ACT-REVIEW-02",
      "next_stage_id": "ACT-REVIEW-03",
      "asset_key": "asset.stage.act.review.2",
      "difficulty": "review",
      "map_query": "Jerusalem Antioch Rome Acts mission route review",
      "map_region": "antioch",
      "map_x": 78.5,
      "map_y": 43.5,
      "route_group": "letters",
      "place_names": [
        "예루살렘 · 안디옥 · 로마",
        "Jerusalem · Antioch · Rome",
        "예루살렘·안디옥·로마",
        "Jerusalem·Antioch·Rome",
        "エルサレム · アンティオキア · ローマ",
        "Yerusalem · Antiokhia · Roma",
        "เยรูซาเล็ม · อันทิโอก · โรม",
        "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "ACT-REVIEW-03",
      "world_id": "W_NT_ACTS",
      "section_key": "acts",
      "book_id": "ACT",
      "book_order": 44,
      "order_index": 53,
      "title": {
        "ko": "예루살렘 · 안디옥 · 로마 복습",
        "en": "Jerusalem · Antioch · Rome Review",
        "ja": "エルサレム · アンティオキア · ローマ 復習",
        "ms": "Yerusalem · Antiokhia · Roma Ulang kaji",
        "th": "เยรูซาเล็ม · อันทิโอก · โรม ทบทวน",
        "km": "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម រំលឹក"
      },
      "short_title": {
        "ko": "예루살렘·안디옥·로마+",
        "en": "Jerusalem·Antioch·Rome+",
        "ja": "エルサレム·アンティオキア·ローマ+",
        "ms": "Yerusalem·Antiokhia·Roma+",
        "th": "เยรูซาเล็ม·อันทิโอก·โรม+",
        "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+"
      },
      "book_title": {
        "ko": "사도행전",
        "en": "Acts",
        "ja": "使徒の働き",
        "ms": "Kisah Para Rasul",
        "th": "กิจการ",
        "km": "កិច្ចការ"
      },
      "bible_range": "사도행전 1-28",
      "references": {
        "ko": "사도행전 1-28",
        "en": "Acts 1-28",
        "ja": "使徒の働き 1-28",
        "ms": "Kisah Para Rasul 1-28",
        "th": "กิจการ 1-28",
        "km": "កិច្ចការ 1-28"
      },
      "mission": {
        "ko": "예루살렘 · 안디옥 · 로마 길에서 사도행전 주요 사건을 다시 확인합니다.",
        "en": "Review the main Acts events along Jerusalem · Antioch · Rome.",
        "ja": "エルサレム · アンティオキア · ローマの道で、使徒の働きの主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Kisah Para Rasul di sepanjang Yerusalem · Antiokhia · Roma.",
        "th": "ทบทวนเหตุการณ์สำคัญของกิจการตามเส้นทางเยรูซาเล็ม · อันทิโอก · โรม",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃកិច្ចការ តាមផ្លូវយេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-ACT-REVIEW-03",
      "next_stage_id": "ACT-REVIEW-04",
      "asset_key": "asset.stage.act.review.3",
      "difficulty": "review",
      "map_query": "Jerusalem Antioch Rome Acts mission route review",
      "map_region": "antioch",
      "map_x": 78.5,
      "map_y": 43.5,
      "route_group": "letters",
      "place_names": [
        "예루살렘 · 안디옥 · 로마",
        "Jerusalem · Antioch · Rome",
        "예루살렘·안디옥·로마",
        "Jerusalem·Antioch·Rome",
        "エルサレム · アンティオキア · ローマ",
        "Yerusalem · Antiokhia · Roma",
        "เยรูซาเล็ม · อันทิโอก · โรม",
        "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "ACT-REVIEW-04",
      "world_id": "W_NT_ACTS",
      "section_key": "acts",
      "book_id": "ACT",
      "book_order": 44,
      "order_index": 54,
      "title": {
        "ko": "예루살렘 · 안디옥 · 로마 복습",
        "en": "Jerusalem · Antioch · Rome Review",
        "ja": "エルサレム · アンティオキア · ローマ 復習",
        "ms": "Yerusalem · Antiokhia · Roma Ulang kaji",
        "th": "เยรูซาเล็ม · อันทิโอก · โรม ทบทวน",
        "km": "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម រំលឹក"
      },
      "short_title": {
        "ko": "예루살렘·안디옥·로마+",
        "en": "Jerusalem·Antioch·Rome+",
        "ja": "エルサレム·アンティオキア·ローマ+",
        "ms": "Yerusalem·Antiokhia·Roma+",
        "th": "เยรูซาเล็ม·อันทิโอก·โรม+",
        "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+"
      },
      "book_title": {
        "ko": "사도행전",
        "en": "Acts",
        "ja": "使徒の働き",
        "ms": "Kisah Para Rasul",
        "th": "กิจการ",
        "km": "កិច្ចការ"
      },
      "bible_range": "사도행전 1-28",
      "references": {
        "ko": "사도행전 1-28",
        "en": "Acts 1-28",
        "ja": "使徒の働き 1-28",
        "ms": "Kisah Para Rasul 1-28",
        "th": "กิจการ 1-28",
        "km": "កិច្ចការ 1-28"
      },
      "mission": {
        "ko": "예루살렘 · 안디옥 · 로마 길에서 사도행전 주요 사건을 다시 확인합니다.",
        "en": "Review the main Acts events along Jerusalem · Antioch · Rome.",
        "ja": "エルサレム · アンティオキア · ローマの道で、使徒の働きの主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Kisah Para Rasul di sepanjang Yerusalem · Antiokhia · Roma.",
        "th": "ทบทวนเหตุการณ์สำคัญของกิจการตามเส้นทางเยรูซาเล็ม · อันทิโอก · โรม",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃកិច្ចការ តាមផ្លូវយេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-ACT-REVIEW-04",
      "next_stage_id": "ACT-REVIEW-05",
      "asset_key": "asset.stage.act.review.4",
      "difficulty": "review",
      "map_query": "Jerusalem Antioch Rome Acts mission route review",
      "map_region": "antioch",
      "map_x": 78.5,
      "map_y": 43.5,
      "route_group": "letters",
      "place_names": [
        "예루살렘 · 안디옥 · 로마",
        "Jerusalem · Antioch · Rome",
        "예루살렘·안디옥·로마",
        "Jerusalem·Antioch·Rome",
        "エルサレム · アンティオキア · ローマ",
        "Yerusalem · Antiokhia · Roma",
        "เยรูซาเล็ม · อันทิโอก · โรม",
        "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "ACT-REVIEW-05",
      "world_id": "W_NT_ACTS",
      "section_key": "acts",
      "book_id": "ACT",
      "book_order": 44,
      "order_index": 55,
      "title": {
        "ko": "예루살렘 · 안디옥 · 로마 복습",
        "en": "Jerusalem · Antioch · Rome Review",
        "ja": "エルサレム · アンティオキア · ローマ 復習",
        "ms": "Yerusalem · Antiokhia · Roma Ulang kaji",
        "th": "เยรูซาเล็ม · อันทิโอก · โรม ทบทวน",
        "km": "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម រំលឹក"
      },
      "short_title": {
        "ko": "예루살렘·안디옥·로마+",
        "en": "Jerusalem·Antioch·Rome+",
        "ja": "エルサレム·アンティオキア·ローマ+",
        "ms": "Yerusalem·Antiokhia·Roma+",
        "th": "เยรูซาเล็ม·อันทิโอก·โรม+",
        "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+"
      },
      "book_title": {
        "ko": "사도행전",
        "en": "Acts",
        "ja": "使徒の働き",
        "ms": "Kisah Para Rasul",
        "th": "กิจการ",
        "km": "កិច្ចការ"
      },
      "bible_range": "사도행전 1-28",
      "references": {
        "ko": "사도행전 1-28",
        "en": "Acts 1-28",
        "ja": "使徒の働き 1-28",
        "ms": "Kisah Para Rasul 1-28",
        "th": "กิจการ 1-28",
        "km": "កិច្ចការ 1-28"
      },
      "mission": {
        "ko": "예루살렘 · 안디옥 · 로마 길에서 사도행전 주요 사건을 다시 확인합니다.",
        "en": "Review the main Acts events along Jerusalem · Antioch · Rome.",
        "ja": "エルサレム · アンティオキア · ローマの道で、使徒の働きの主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Kisah Para Rasul di sepanjang Yerusalem · Antiokhia · Roma.",
        "th": "ทบทวนเหตุการณ์สำคัญของกิจการตามเส้นทางเยรูซาเล็ม · อันทิโอก · โรม",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃកិច្ចការ តាមផ្លូវយេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-ACT-REVIEW-05",
      "next_stage_id": "ROM-001",
      "asset_key": "asset.stage.act.review.5",
      "difficulty": "review",
      "map_query": "Jerusalem Antioch Rome Acts mission route review",
      "map_region": "antioch",
      "map_x": 78.5,
      "map_y": 43.5,
      "route_group": "letters",
      "place_names": [
        "예루살렘 · 안디옥 · 로마",
        "Jerusalem · Antioch · Rome",
        "예루살렘·안디옥·로마",
        "Jerusalem·Antioch·Rome",
        "エルサレム · アンティオキア · ローマ",
        "Yerusalem · Antiokhia · Roma",
        "เยรูซาเล็ม · อันทิโอก · โรม",
        "យេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "ROM-001",
      "world_id": "W_NT_PAUL",
      "section_key": "pauline",
      "book_id": "ROM",
      "book_order": 45,
      "order_index": 56,
      "title": {
        "ko": "로마",
        "en": "Rome",
        "ja": "ローマ",
        "ms": "Roma",
        "th": "โรม",
        "km": "រ៉ូម"
      },
      "short_title": {
        "ko": "로마",
        "en": "Rome",
        "ja": "ローマ",
        "ms": "Roma",
        "th": "โรม",
        "km": "រ៉ូម"
      },
      "book_title": {
        "ko": "로마서",
        "en": "Romans",
        "ja": "ローマ人への手紙",
        "ms": "Roma",
        "th": "โรม",
        "km": "រ៉ូម"
      },
      "bible_range": "로마서 1-16",
      "references": {
        "ko": "로마서 1-16",
        "en": "Romans 1-16",
        "ja": "ローマ人への手紙 1-16",
        "ms": "Roma 1-16",
        "th": "โรม 1-16",
        "km": "រ៉ូម 1-16"
      },
      "mission": {
        "ko": "로마 여정에서 로마서 16장 본문 문제를 풉니다.",
        "en": "Follow Rome and answer Romans 16 chapters question bank.",
        "ja": "ローマの旅で、ローマ人への手紙16章の問題バンクに答えます。",
        "ms": "Ikuti Roma dan jawab bank soalan Roma 16 bab.",
        "th": "ติดตามเส้นทางโรมและตอบคลังคำถามจากโรม 16 บท",
        "km": "តាមដានដំណើររ៉ូម ហើយឆ្លើយធនាគារសំណួរពីរ៉ូម 16 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-ROM-001",
      "next_stage_id": "1CO-001",
      "asset_key": "asset.stage.rom",
      "difficulty": "basic",
      "map_query": "Rome Italy Romans biblical letter location",
      "map_region": "rome",
      "map_x": 13.8,
      "map_y": 9.6,
      "route_group": "letters",
      "place_names": [
        "로마",
        "Rome",
        "로마",
        "Rome",
        "ローマ",
        "Roma",
        "โรม",
        "រ៉ូម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "1CO-001",
      "world_id": "W_NT_PAUL",
      "section_key": "pauline",
      "book_id": "1CO",
      "book_order": 46,
      "order_index": 57,
      "title": {
        "ko": "고린도",
        "en": "Corinth",
        "ja": "コリント",
        "ms": "Korintus",
        "th": "โครินธ์",
        "km": "កូរិនថូស"
      },
      "short_title": {
        "ko": "고린도",
        "en": "Corinth",
        "ja": "コリント",
        "ms": "Korintus",
        "th": "โครินธ์",
        "km": "កូរិនថូស"
      },
      "book_title": {
        "ko": "고린도전서",
        "en": "1 Corinthians",
        "ja": "コリント人への手紙第一",
        "ms": "1 Korintus",
        "th": "1 โครินธ์",
        "km": "១ កូរិនថូស"
      },
      "bible_range": "고린도전서 1-16",
      "references": {
        "ko": "고린도전서 1-16",
        "en": "1 Corinthians 1-16",
        "ja": "コリント人への手紙第一 1-16",
        "ms": "1 Korintus 1-16",
        "th": "1 โครินธ์ 1-16",
        "km": "១ កូរិនថូស 1-16"
      },
      "mission": {
        "ko": "고린도 여정에서 고린도전서 16장 본문 문제를 풉니다.",
        "en": "Follow Corinth and answer 1 Corinthians 16 chapters question bank.",
        "ja": "コリントの旅で、コリント人への手紙第一16章の問題バンクに答えます。",
        "ms": "Ikuti Korintus dan jawab bank soalan 1 Korintus 16 bab.",
        "th": "ติดตามเส้นทางโครินธ์และตอบคลังคำถามจาก1 โครินธ์ 16 บท",
        "km": "តាមដានដំណើរកូរិនថូស ហើយឆ្លើយធនាគារសំណួរពី១ កូរិនថូស 16 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-1CO-001",
      "next_stage_id": "2CO-001",
      "asset_key": "asset.stage.1co",
      "difficulty": "basic",
      "map_query": "Corinth Greece biblical location",
      "map_region": "corinth",
      "map_x": 39.1,
      "map_y": 39.2,
      "route_group": "letters",
      "place_names": [
        "고린도",
        "Corinth",
        "고린도",
        "Corinth",
        "コリント",
        "Korintus",
        "โครินธ์",
        "កូរិនថូស"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "2CO-001",
      "world_id": "W_NT_PAUL",
      "section_key": "pauline",
      "book_id": "2CO",
      "book_order": 47,
      "order_index": 58,
      "title": {
        "ko": "고린도 · 마게도냐",
        "en": "Corinth · Macedonia",
        "ja": "コリント · マケドニア",
        "ms": "Korintus · Makedonia",
        "th": "โครินธ์ · มาซิโดเนีย",
        "km": "កូរិនថូស · ម៉ាសេដូនៀ"
      },
      "short_title": {
        "ko": "고린도·마게도냐",
        "en": "Corinth·Macedonia",
        "ja": "コリント·マケドニア",
        "ms": "Korintus·Makedonia",
        "th": "โครินธ์·มาซิโดเนีย",
        "km": "កូរិនថូស·ម៉ាសេដូនៀ"
      },
      "book_title": {
        "ko": "고린도후서",
        "en": "2 Corinthians",
        "ja": "コリント人への手紙第二",
        "ms": "2 Korintus",
        "th": "2 โครินธ์",
        "km": "២ កូរិនថូស"
      },
      "bible_range": "고린도후서 1-13",
      "references": {
        "ko": "고린도후서 1-13",
        "en": "2 Corinthians 1-13",
        "ja": "コリント人への手紙第二 1-13",
        "ms": "2 Korintus 1-13",
        "th": "2 โครินธ์ 1-13",
        "km": "២ កូរិនថូស 1-13"
      },
      "mission": {
        "ko": "고린도 · 마게도냐 여정에서 고린도후서 13장 본문 문제를 풉니다.",
        "en": "Follow Corinth · Macedonia and answer 2 Corinthians 13 chapters question bank.",
        "ja": "コリント · マケドニアの旅で、コリント人への手紙第二13章の問題バンクに答えます。",
        "ms": "Ikuti Korintus · Makedonia dan jawab bank soalan 2 Korintus 13 bab.",
        "th": "ติดตามเส้นทางโครินธ์ · มาซิโดเนียและตอบคลังคำถามจาก2 โครินธ์ 13 บท",
        "km": "តាមដានដំណើរកូរិនថូស · ម៉ាសេដូនៀ ហើយឆ្លើយធនាគារសំណួរពី២ កូរិនថូស 13 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-2CO-001",
      "next_stage_id": "GAL-001",
      "asset_key": "asset.stage.2co",
      "difficulty": "basic",
      "map_query": "Corinth Greece biblical location",
      "map_region": "corinth",
      "map_x": 39.1,
      "map_y": 39.2,
      "route_group": "letters",
      "place_names": [
        "고린도 · 마게도냐",
        "Corinth · Macedonia",
        "고린도·마게도냐",
        "Corinth·Macedonia",
        "コリント · マケドニア",
        "Korintus · Makedonia",
        "โครินธ์ · มาซิโดเนีย",
        "កូរិនថូស · ម៉ាសេដូនៀ"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "GAL-001",
      "world_id": "W_NT_PAUL",
      "section_key": "pauline",
      "book_id": "GAL",
      "book_order": 48,
      "order_index": 59,
      "title": {
        "ko": "갈라디아",
        "en": "Galatia",
        "ja": "ガラテヤ",
        "ms": "Galatia",
        "th": "กาลาเทีย",
        "km": "កាឡាទី"
      },
      "short_title": {
        "ko": "갈라디아",
        "en": "Galatia",
        "ja": "ガラテヤ",
        "ms": "Galatia",
        "th": "กาลาเทีย",
        "km": "កាឡាទី"
      },
      "book_title": {
        "ko": "갈라디아서",
        "en": "Galatians",
        "ja": "ガラテヤ人への手紙",
        "ms": "Galatia",
        "th": "กาลาเทีย",
        "km": "កាឡាទី"
      },
      "bible_range": "갈라디아서 1-6",
      "references": {
        "ko": "갈라디아서 1-6",
        "en": "Galatians 1-6",
        "ja": "ガラテヤ人への手紙 1-6",
        "ms": "Galatia 1-6",
        "th": "กาลาเทีย 1-6",
        "km": "កាឡាទី 1-6"
      },
      "mission": {
        "ko": "갈라디아 여정에서 갈라디아서 6장 본문 문제를 풉니다.",
        "en": "Follow Galatia and answer Galatians 6 chapters question bank.",
        "ja": "ガラテヤの旅で、ガラテヤ人への手紙6章の問題バンクに答えます。",
        "ms": "Ikuti Galatia dan jawab bank soalan Galatia 6 bab.",
        "th": "ติดตามเส้นทางกาลาเทียและตอบคลังคำถามจากกาลาเทีย 6 บท",
        "km": "តាមដានដំណើរកាឡាទី ហើយឆ្លើយធនាគារសំណួរពីកាឡាទី 6 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-GAL-001",
      "next_stage_id": "EPH-001",
      "asset_key": "asset.stage.gal",
      "difficulty": "basic",
      "map_query": "Galatia Asia Minor biblical region",
      "map_region": "asia-minor",
      "map_x": 63.8,
      "map_y": 32.2,
      "route_group": "letters",
      "place_names": [
        "갈라디아",
        "Galatia",
        "갈라디아",
        "Galatia",
        "ガラテヤ",
        "Galatia",
        "กาลาเทีย",
        "កាឡាទី"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "EPH-001",
      "world_id": "W_NT_PAUL",
      "section_key": "pauline",
      "book_id": "EPH",
      "book_order": 49,
      "order_index": 60,
      "title": {
        "ko": "에베소",
        "en": "Ephesus",
        "ja": "エフェソ",
        "ms": "Efesus",
        "th": "เอเฟซัส",
        "km": "អេភេសូរ"
      },
      "short_title": {
        "ko": "에베소",
        "en": "Ephesus",
        "ja": "エフェソ",
        "ms": "Efesus",
        "th": "เอเฟซัส",
        "km": "អេភេសូរ"
      },
      "book_title": {
        "ko": "에베소서",
        "en": "Ephesians",
        "ja": "エペソ人への手紙",
        "ms": "Efesus",
        "th": "เอเฟซัส",
        "km": "អេភេសូរ"
      },
      "bible_range": "에베소서 1-6",
      "references": {
        "ko": "에베소서 1-6",
        "en": "Ephesians 1-6",
        "ja": "エペソ人への手紙 1-6",
        "ms": "Efesus 1-6",
        "th": "เอเฟซัส 1-6",
        "km": "អេភេសូរ 1-6"
      },
      "mission": {
        "ko": "에베소 여정에서 에베소서 6장 본문 문제를 풉니다.",
        "en": "Follow Ephesus and answer Ephesians 6 chapters question bank.",
        "ja": "エフェソの旅で、エペソ人への手紙6章の問題バンクに答えます。",
        "ms": "Ikuti Efesus dan jawab bank soalan Efesus 6 bab.",
        "th": "ติดตามเส้นทางเอเฟซัสและตอบคลังคำถามจากเอเฟซัส 6 บท",
        "km": "តាមដានដំណើរអេភេសូរ ហើយឆ្លើយធនាគារសំណួរពីអេភេសូរ 6 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-EPH-001",
      "next_stage_id": "PHP-001",
      "asset_key": "asset.stage.eph",
      "difficulty": "basic",
      "map_query": "Ephesus Turkey biblical location",
      "map_region": "asia-minor",
      "map_x": 51.5,
      "map_y": 37.8,
      "route_group": "letters",
      "place_names": [
        "에베소",
        "Ephesus",
        "에베소",
        "Ephesus",
        "エフェソ",
        "Efesus",
        "เอเฟซัส",
        "អេភេសូរ"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "PHP-001",
      "world_id": "W_NT_PAUL",
      "section_key": "pauline",
      "book_id": "PHP",
      "book_order": 50,
      "order_index": 61,
      "title": {
        "ko": "빌립보",
        "en": "Philippi",
        "ja": "フィリピ",
        "ms": "Filipi",
        "th": "ฟีลิปปี",
        "km": "ភីលីព"
      },
      "short_title": {
        "ko": "빌립보",
        "en": "Philippi",
        "ja": "フィリピ",
        "ms": "Filipi",
        "th": "ฟีลิปปี",
        "km": "ភីលីព"
      },
      "book_title": {
        "ko": "빌립보서",
        "en": "Philippians",
        "ja": "ピリピ人への手紙",
        "ms": "Filipi",
        "th": "ฟิลิปปี",
        "km": "ភីលីព"
      },
      "bible_range": "빌립보서 1-4",
      "references": {
        "ko": "빌립보서 1-4",
        "en": "Philippians 1-4",
        "ja": "ピリピ人への手紙 1-4",
        "ms": "Filipi 1-4",
        "th": "ฟิลิปปี 1-4",
        "km": "ភីលីព 1-4"
      },
      "mission": {
        "ko": "빌립보 여정에서 빌립보서 4장 본문 문제를 풉니다.",
        "en": "Follow Philippi and answer Philippians 4 chapters question bank.",
        "ja": "フィリピの旅で、ピリピ人への手紙4章の問題バンクに答えます。",
        "ms": "Ikuti Filipi dan jawab bank soalan Filipi 4 bab.",
        "th": "ติดตามเส้นทางฟีลิปปีและตอบคลังคำถามจากฟิลิปปี 4 บท",
        "km": "តាមដានដំណើរភីលីព ហើយឆ្លើយធនាគារសំណួរពីភីលីព 4 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-PHP-001",
      "next_stage_id": "COL-001",
      "asset_key": "asset.stage.php",
      "difficulty": "basic",
      "map_query": "Philippi Greece biblical location",
      "map_region": "macedonia",
      "map_x": 37.4,
      "map_y": 19.2,
      "route_group": "letters",
      "place_names": [
        "빌립보",
        "Philippi",
        "빌립보",
        "Philippi",
        "フィリピ",
        "Filipi",
        "ฟีลิปปี",
        "ភីលីព"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "COL-001",
      "world_id": "W_NT_PAUL",
      "section_key": "pauline",
      "book_id": "COL",
      "book_order": 51,
      "order_index": 62,
      "title": {
        "ko": "골로새",
        "en": "Colossae",
        "ja": "コロサイ",
        "ms": "Kolose",
        "th": "โคโลสี",
        "km": "កូល៉ុស"
      },
      "short_title": {
        "ko": "골로새",
        "en": "Colossae",
        "ja": "コロサイ",
        "ms": "Kolose",
        "th": "โคโลสี",
        "km": "កូល៉ុស"
      },
      "book_title": {
        "ko": "골로새서",
        "en": "Colossians",
        "ja": "コロサイ人への手紙",
        "ms": "Kolose",
        "th": "โคโลสี",
        "km": "កូឡុស"
      },
      "bible_range": "골로새서 1-4",
      "references": {
        "ko": "골로새서 1-4",
        "en": "Colossians 1-4",
        "ja": "コロサイ人への手紙 1-4",
        "ms": "Kolose 1-4",
        "th": "โคโลสี 1-4",
        "km": "កូឡុស 1-4"
      },
      "mission": {
        "ko": "골로새 여정에서 골로새서 4장 본문 문제를 풉니다.",
        "en": "Follow Colossae and answer Colossians 4 chapters question bank.",
        "ja": "コロサイの旅で、コロサイ人への手紙4章の問題バンクに答えます。",
        "ms": "Ikuti Kolose dan jawab bank soalan Kolose 4 bab.",
        "th": "ติดตามเส้นทางโคโลสีและตอบคลังคำถามจากโคโลสี 4 บท",
        "km": "តាមដានដំណើរកូល៉ុស ហើយឆ្លើយធនាគារសំណួរពីកូឡុស 4 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-COL-001",
      "next_stage_id": "1TH-001",
      "asset_key": "asset.stage.col",
      "difficulty": "basic",
      "map_query": "Colossae Turkey biblical location",
      "map_region": "asia-minor",
      "map_x": 59.8,
      "map_y": 39.2,
      "route_group": "letters",
      "place_names": [
        "골로새",
        "Colossae",
        "골로새",
        "Colossae",
        "コロサイ",
        "Kolose",
        "โคโลสี",
        "កូល៉ុស"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "1TH-001",
      "world_id": "W_NT_PAUL",
      "section_key": "pauline",
      "book_id": "1TH",
      "book_order": 52,
      "order_index": 63,
      "title": {
        "ko": "데살로니가",
        "en": "Thessalonica",
        "ja": "テサロニケ",
        "ms": "Tesalonika",
        "th": "เธสะโลนิกา",
        "km": "ថេស្សាឡូនិក"
      },
      "short_title": {
        "ko": "데살로니가",
        "en": "Thessalonica",
        "ja": "テサロニケ",
        "ms": "Tesalonika",
        "th": "เธสะโลนิกา",
        "km": "ថេស្សាឡូនិក"
      },
      "book_title": {
        "ko": "데살로니가전서",
        "en": "1 Thessalonians",
        "ja": "テサロニケ人への手紙第一",
        "ms": "1 Tesalonika",
        "th": "1 เธสะโลนิกา",
        "km": "១ ថែស្សាឡូនីច"
      },
      "bible_range": "데살로니가전서 1-5",
      "references": {
        "ko": "데살로니가전서 1-5",
        "en": "1 Thessalonians 1-5",
        "ja": "テサロニケ人への手紙第一 1-5",
        "ms": "1 Tesalonika 1-5",
        "th": "1 เธสะโลนิกา 1-5",
        "km": "១ ថែស្សាឡូនីច 1-5"
      },
      "mission": {
        "ko": "데살로니가 여정에서 데살로니가전서 5장 본문 문제를 풉니다.",
        "en": "Follow Thessalonica and answer 1 Thessalonians 5 chapters question bank.",
        "ja": "テサロニケの旅で、テサロニケ人への手紙第一5章の問題バンクに答えます。",
        "ms": "Ikuti Tesalonika dan jawab bank soalan 1 Tesalonika 5 bab.",
        "th": "ติดตามเส้นทางเธสะโลนิกาและตอบคลังคำถามจาก1 เธสะโลนิกา 5 บท",
        "km": "តាមដានដំណើរថេស្សាឡូនិក ហើយឆ្លើយធនាគារសំណួរពី១ ថែស្សាឡូនីច 5 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-1TH-001",
      "next_stage_id": "2TH-001",
      "asset_key": "asset.stage.1th",
      "difficulty": "basic",
      "map_query": "Thessalonica Greece biblical location",
      "map_region": "macedonia",
      "map_x": 36.5,
      "map_y": 23.1,
      "route_group": "letters",
      "place_names": [
        "데살로니가",
        "Thessalonica",
        "데살로니가",
        "Thessalonica",
        "テサロニケ",
        "Tesalonika",
        "เธสะโลนิกา",
        "ថេស្សាឡូនិក"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "2TH-001",
      "world_id": "W_NT_PAUL",
      "section_key": "pauline",
      "book_id": "2TH",
      "book_order": 53,
      "order_index": 64,
      "title": {
        "ko": "데살로니가",
        "en": "Thessalonica",
        "ja": "テサロニケ",
        "ms": "Tesalonika",
        "th": "เธสะโลนิกา",
        "km": "ថេស្សាឡូនិក"
      },
      "short_title": {
        "ko": "데살로니가",
        "en": "Thessalonica",
        "ja": "テサロニケ",
        "ms": "Tesalonika",
        "th": "เธสะโลนิกา",
        "km": "ថេស្សាឡូនិក"
      },
      "book_title": {
        "ko": "데살로니가후서",
        "en": "2 Thessalonians",
        "ja": "テサロニケ人への手紙第二",
        "ms": "2 Tesalonika",
        "th": "2 เธสะโลนิกา",
        "km": "២ ថែស្សាឡូនីច"
      },
      "bible_range": "데살로니가후서 1-3",
      "references": {
        "ko": "데살로니가후서 1-3",
        "en": "2 Thessalonians 1-3",
        "ja": "テサロニケ人への手紙第二 1-3",
        "ms": "2 Tesalonika 1-3",
        "th": "2 เธสะโลนิกา 1-3",
        "km": "២ ថែស្សាឡូនីច 1-3"
      },
      "mission": {
        "ko": "데살로니가 여정에서 데살로니가후서 3장 본문 문제를 풉니다.",
        "en": "Follow Thessalonica and answer 2 Thessalonians 3 chapters question bank.",
        "ja": "テサロニケの旅で、テサロニケ人への手紙第二3章の問題バンクに答えます。",
        "ms": "Ikuti Tesalonika dan jawab bank soalan 2 Tesalonika 3 bab.",
        "th": "ติดตามเส้นทางเธสะโลนิกาและตอบคลังคำถามจาก2 เธสะโลนิกา 3 บท",
        "km": "តាមដានដំណើរថេស្សាឡូនិក ហើយឆ្លើយធនាគារសំណួរពី២ ថែស្សាឡូនីច 3 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-2TH-001",
      "next_stage_id": "1TI-001",
      "asset_key": "asset.stage.2th",
      "difficulty": "basic",
      "map_query": "Thessalonica Greece biblical location",
      "map_region": "macedonia",
      "map_x": 36.5,
      "map_y": 23.1,
      "route_group": "letters",
      "place_names": [
        "데살로니가",
        "Thessalonica",
        "데살로니가",
        "Thessalonica",
        "テサロニケ",
        "Tesalonika",
        "เธสะโลนิกา",
        "ថេស្សាឡូនិក"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "1TI-001",
      "world_id": "W_NT_PAUL",
      "section_key": "pauline",
      "book_id": "1TI",
      "book_order": 54,
      "order_index": 65,
      "title": {
        "ko": "에베소",
        "en": "Ephesus",
        "ja": "エフェソ",
        "ms": "Efesus",
        "th": "เอเฟซัส",
        "km": "អេភេសូរ"
      },
      "short_title": {
        "ko": "에베소",
        "en": "Ephesus",
        "ja": "エフェソ",
        "ms": "Efesus",
        "th": "เอเฟซัส",
        "km": "អេភេសូរ"
      },
      "book_title": {
        "ko": "디모데전서",
        "en": "1 Timothy",
        "ja": "テモテへの手紙第一",
        "ms": "1 Timotius",
        "th": "1 ทิโมธี",
        "km": "១ ធីម៉ូថេ"
      },
      "bible_range": "디모데전서 1-6",
      "references": {
        "ko": "디모데전서 1-6",
        "en": "1 Timothy 1-6",
        "ja": "テモテへの手紙第一 1-6",
        "ms": "1 Timotius 1-6",
        "th": "1 ทิโมธี 1-6",
        "km": "១ ធីម៉ូថេ 1-6"
      },
      "mission": {
        "ko": "에베소 여정에서 디모데전서 6장 본문 문제를 풉니다.",
        "en": "Follow Ephesus and answer 1 Timothy 6 chapters question bank.",
        "ja": "エフェソの旅で、テモテへの手紙第一6章の問題バンクに答えます。",
        "ms": "Ikuti Efesus dan jawab bank soalan 1 Timotius 6 bab.",
        "th": "ติดตามเส้นทางเอเฟซัสและตอบคลังคำถามจาก1 ทิโมธี 6 บท",
        "km": "តាមដានដំណើរអេភេសូរ ហើយឆ្លើយធនាគារសំណួរពី១ ធីម៉ូថេ 6 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-1TI-001",
      "next_stage_id": "2TI-001",
      "asset_key": "asset.stage.1ti",
      "difficulty": "basic",
      "map_query": "Ephesus Timothy biblical location",
      "map_region": "asia-minor",
      "map_x": 51.5,
      "map_y": 37.8,
      "route_group": "letters",
      "place_names": [
        "에베소",
        "Ephesus",
        "에베소",
        "Ephesus",
        "エフェソ",
        "Efesus",
        "เอเฟซัส",
        "អេភេសូរ"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "2TI-001",
      "world_id": "W_NT_PAUL",
      "section_key": "pauline",
      "book_id": "2TI",
      "book_order": 55,
      "order_index": 66,
      "title": {
        "ko": "로마 감옥",
        "en": "Prison in Rome",
        "ja": "ローマの獄",
        "ms": "Penjara Roma",
        "th": "คุกในโรม",
        "km": "គុកនៅរ៉ូម"
      },
      "short_title": {
        "ko": "로마 감옥",
        "en": "Rome Prison",
        "ja": "ローマの獄",
        "ms": "Penjara Roma",
        "th": "คุกในโรม",
        "km": "គុកនៅរ៉ូម"
      },
      "book_title": {
        "ko": "디모데후서",
        "en": "2 Timothy",
        "ja": "テモテへの手紙第二",
        "ms": "2 Timotius",
        "th": "2 ทิโมธี",
        "km": "២ ធីម៉ូថេ"
      },
      "bible_range": "디모데후서 1-4",
      "references": {
        "ko": "디모데후서 1-4",
        "en": "2 Timothy 1-4",
        "ja": "テモテへの手紙第二 1-4",
        "ms": "2 Timotius 1-4",
        "th": "2 ทิโมธี 1-4",
        "km": "២ ធីម៉ូថេ 1-4"
      },
      "mission": {
        "ko": "로마 감옥 여정에서 디모데후서 4장 본문 문제를 풉니다.",
        "en": "Follow Prison in Rome and answer 2 Timothy 4 chapters question bank.",
        "ja": "ローマの獄の旅で、テモテへの手紙第二4章の問題バンクに答えます。",
        "ms": "Ikuti Penjara Roma dan jawab bank soalan 2 Timotius 4 bab.",
        "th": "ติดตามเส้นทางคุกในโรมและตอบคลังคำถามจาก2 ทิโมธี 4 บท",
        "km": "តាមដានដំណើរគុកនៅរ៉ូម ហើយឆ្លើយធនាគារសំណួរពី២ ធីម៉ូថេ 4 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-2TI-001",
      "next_stage_id": "TIT-001",
      "asset_key": "asset.stage.2ti",
      "difficulty": "basic",
      "map_query": "Rome Italy Paul Timothy biblical location",
      "map_region": "rome",
      "map_x": 13.8,
      "map_y": 9.6,
      "route_group": "letters",
      "place_names": [
        "로마 감옥",
        "Prison in Rome",
        "로마 감옥",
        "Rome Prison",
        "ローマの獄",
        "Penjara Roma",
        "คุกในโรม",
        "គុកនៅរ៉ូម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "TIT-001",
      "world_id": "W_NT_PAUL",
      "section_key": "pauline",
      "book_id": "TIT",
      "book_order": 56,
      "order_index": 67,
      "title": {
        "ko": "그레데",
        "en": "Crete",
        "ja": "クレタ",
        "ms": "Kreta",
        "th": "เกาะครีต",
        "km": "ក្រេត"
      },
      "short_title": {
        "ko": "그레데",
        "en": "Crete",
        "ja": "クレタ",
        "ms": "Kreta",
        "th": "เกาะครีต",
        "km": "ក្រេត"
      },
      "book_title": {
        "ko": "디도서",
        "en": "Titus",
        "ja": "テトスへの手紙",
        "ms": "Titus",
        "th": "ทิตัส",
        "km": "ទីតុស"
      },
      "bible_range": "디도서 1-3",
      "references": {
        "ko": "디도서 1-3",
        "en": "Titus 1-3",
        "ja": "テトスへの手紙 1-3",
        "ms": "Titus 1-3",
        "th": "ทิตัส 1-3",
        "km": "ទីតុស 1-3"
      },
      "mission": {
        "ko": "그레데 여정에서 디도서 3장 본문 문제를 풉니다.",
        "en": "Follow Crete and answer Titus 3 chapters question bank.",
        "ja": "クレタの旅で、テトスへの手紙3章の問題バンクに答えます。",
        "ms": "Ikuti Kreta dan jawab bank soalan Titus 3 bab.",
        "th": "ติดตามเส้นทางเกาะครีตและตอบคลังคำถามจากทิตัส 3 บท",
        "km": "តាមដានដំណើរក្រេត ហើយឆ្លើយធនាគារសំណួរពីទីតុស 3 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-TIT-001",
      "next_stage_id": "PHM-001",
      "asset_key": "asset.stage.tit",
      "difficulty": "basic",
      "map_query": "Crete Titus biblical location",
      "map_region": "crete",
      "map_x": 43.5,
      "map_y": 56.2,
      "route_group": "letters",
      "place_names": [
        "그레데",
        "Crete",
        "그레데",
        "Crete",
        "クレタ",
        "Kreta",
        "เกาะครีต",
        "ក្រេត"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "PHM-001",
      "world_id": "W_NT_PAUL",
      "section_key": "pauline",
      "book_id": "PHM",
      "book_order": 57,
      "order_index": 68,
      "title": {
        "ko": "골로새",
        "en": "Colossae",
        "ja": "コロサイ",
        "ms": "Kolose",
        "th": "โคโลสี",
        "km": "កូល៉ុស"
      },
      "short_title": {
        "ko": "골로새",
        "en": "Colossae",
        "ja": "コロサイ",
        "ms": "Kolose",
        "th": "โคโลสี",
        "km": "កូល៉ុស"
      },
      "book_title": {
        "ko": "빌레몬서",
        "en": "Philemon",
        "ja": "ピレモンへの手紙",
        "ms": "Filemon",
        "th": "ฟีเลโมน",
        "km": "ភីលេម៉ូន"
      },
      "bible_range": "빌레몬서 1",
      "references": {
        "ko": "빌레몬서 1",
        "en": "Philemon 1",
        "ja": "ピレモンへの手紙 1",
        "ms": "Filemon 1",
        "th": "ฟีเลโมน 1",
        "km": "ភីលេម៉ូន 1"
      },
      "mission": {
        "ko": "골로새 여정에서 빌레몬서 1장 본문 문제를 풉니다.",
        "en": "Follow Colossae and answer Philemon 1 chapters question bank.",
        "ja": "コロサイの旅で、ピレモンへの手紙1章の問題バンクに答えます。",
        "ms": "Ikuti Kolose dan jawab bank soalan Filemon 1 bab.",
        "th": "ติดตามเส้นทางโคโลสีและตอบคลังคำถามจากฟีเลโมน 1 บท",
        "km": "តាមដានដំណើរកូល៉ុស ហើយឆ្លើយធនាគារសំណួរពីភីលេម៉ូន 1 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-PHM-001",
      "next_stage_id": "ROM-REVIEW-14",
      "asset_key": "asset.stage.phm",
      "difficulty": "basic",
      "map_query": "Colossae Philemon biblical location",
      "map_region": "asia-minor",
      "map_x": 59.8,
      "map_y": 39.2,
      "route_group": "letters",
      "place_names": [
        "골로새",
        "Colossae",
        "골로새",
        "Colossae",
        "コロサイ",
        "Kolose",
        "โคโลสี",
        "កូល៉ុស"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "ROM-REVIEW-14",
      "world_id": "W_NT_PAUL",
      "section_key": "pauline",
      "book_id": "ROM",
      "book_order": 45,
      "order_index": 69,
      "title": {
        "ko": "로마 복습",
        "en": "Rome Review",
        "ja": "ローマ 復習",
        "ms": "Roma Ulang kaji",
        "th": "โรม ทบทวน",
        "km": "រ៉ូម រំលឹក"
      },
      "short_title": {
        "ko": "로마+",
        "en": "Rome+",
        "ja": "ローマ+",
        "ms": "Roma+",
        "th": "โรม+",
        "km": "រ៉ូម+"
      },
      "book_title": {
        "ko": "로마서",
        "en": "Romans",
        "ja": "ローマ人への手紙",
        "ms": "Roma",
        "th": "โรม",
        "km": "រ៉ូម"
      },
      "bible_range": "로마서 1-16",
      "references": {
        "ko": "로마서 1-16",
        "en": "Romans 1-16",
        "ja": "ローマ人への手紙 1-16",
        "ms": "Roma 1-16",
        "th": "โรม 1-16",
        "km": "រ៉ូម 1-16"
      },
      "mission": {
        "ko": "로마 길에서 로마서 주요 사건을 다시 확인합니다.",
        "en": "Review the main Romans events along Rome.",
        "ja": "ローマの道で、ローマ人への手紙の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Roma di sepanjang Roma.",
        "th": "ทบทวนเหตุการณ์สำคัญของโรมตามเส้นทางโรม",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃរ៉ូម តាមផ្លូវរ៉ូម។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-ROM-REVIEW-14",
      "next_stage_id": "1CO-REVIEW-15",
      "asset_key": "asset.stage.rom.review.14",
      "difficulty": "review",
      "map_query": "Rome Italy Romans biblical letter location review",
      "map_region": "rome",
      "map_x": 13.8,
      "map_y": 9.6,
      "route_group": "letters",
      "place_names": [
        "로마",
        "Rome",
        "로마",
        "Rome",
        "ローマ",
        "Roma",
        "โรม",
        "រ៉ូម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "1CO-REVIEW-15",
      "world_id": "W_NT_PAUL",
      "section_key": "pauline",
      "book_id": "1CO",
      "book_order": 46,
      "order_index": 70,
      "title": {
        "ko": "고린도 복습",
        "en": "Corinth Review",
        "ja": "コリント 復習",
        "ms": "Korintus Ulang kaji",
        "th": "โครินธ์ ทบทวน",
        "km": "កូរិនថូស រំលឹក"
      },
      "short_title": {
        "ko": "고린도+",
        "en": "Corinth+",
        "ja": "コリント+",
        "ms": "Korintus+",
        "th": "โครินธ์+",
        "km": "កូរិនថូស+"
      },
      "book_title": {
        "ko": "고린도전서",
        "en": "1 Corinthians",
        "ja": "コリント人への手紙第一",
        "ms": "1 Korintus",
        "th": "1 โครินธ์",
        "km": "១ កូរិនថូស"
      },
      "bible_range": "고린도전서 1-16",
      "references": {
        "ko": "고린도전서 1-16",
        "en": "1 Corinthians 1-16",
        "ja": "コリント人への手紙第一 1-16",
        "ms": "1 Korintus 1-16",
        "th": "1 โครินธ์ 1-16",
        "km": "១ កូរិនថូស 1-16"
      },
      "mission": {
        "ko": "고린도 길에서 고린도전서 주요 사건을 다시 확인합니다.",
        "en": "Review the main 1 Corinthians events along Corinth.",
        "ja": "コリントの道で、コリント人への手紙第一の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama 1 Korintus di sepanjang Korintus.",
        "th": "ทบทวนเหตุการณ์สำคัญของ1 โครินธ์ตามเส้นทางโครินธ์",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃ១ កូរិនថូស តាមផ្លូវកូរិនថូស។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-1CO-REVIEW-15",
      "next_stage_id": "HEB-001",
      "asset_key": "asset.stage.1co.review.15",
      "difficulty": "review",
      "map_query": "Corinth Greece biblical location review",
      "map_region": "corinth",
      "map_x": 39.1,
      "map_y": 39.2,
      "route_group": "letters",
      "place_names": [
        "고린도",
        "Corinth",
        "고린도",
        "Corinth",
        "コリント",
        "Korintus",
        "โครินธ์",
        "កូរិនថូស"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "HEB-001",
      "world_id": "W_NT_GEN",
      "section_key": "general",
      "book_id": "HEB",
      "book_order": 58,
      "order_index": 71,
      "title": {
        "ko": "예루살렘 성전 그림자",
        "en": "Jerusalem Temple Pattern",
        "ja": "エルサレム神殿の型",
        "ms": "Pola Bait Suci Yerusalem",
        "th": "แบบอย่างพระวิหารเยรูซาเล็ม",
        "km": "គំរូព្រះវិហារយេរូសាឡឹម"
      },
      "short_title": {
        "ko": "성전 그림자",
        "en": "Temple Pattern",
        "ja": "神殿の型",
        "ms": "Pola Bait Suci",
        "th": "แบบอย่างพระวิหาร",
        "km": "គំរូព្រះវិហារ"
      },
      "book_title": {
        "ko": "히브리서",
        "en": "Hebrews",
        "ja": "ヘブル人への手紙",
        "ms": "Ibrani",
        "th": "ฮีบรู",
        "km": "ហេព្រើរ"
      },
      "bible_range": "히브리서 1-13",
      "references": {
        "ko": "히브리서 1-13",
        "en": "Hebrews 1-13",
        "ja": "ヘブル人への手紙 1-13",
        "ms": "Ibrani 1-13",
        "th": "ฮีบรู 1-13",
        "km": "ហេព្រើរ 1-13"
      },
      "mission": {
        "ko": "예루살렘 성전 그림자 여정에서 히브리서 13장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem Temple Pattern and answer Hebrews 13 chapters question bank.",
        "ja": "エルサレム神殿の型の旅で、ヘブル人への手紙13章の問題バンクに答えます。",
        "ms": "Ikuti Pola Bait Suci Yerusalem dan jawab bank soalan Ibrani 13 bab.",
        "th": "ติดตามเส้นทางแบบอย่างพระวิหารเยรูซาเล็มและตอบคลังคำถามจากฮีบรู 13 บท",
        "km": "តាមដានដំណើរគំរូព្រះវិហារយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីហេព្រើរ 13 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-HEB-001",
      "next_stage_id": "JAS-001",
      "asset_key": "asset.stage.heb",
      "difficulty": "basic",
      "map_query": "Jerusalem Hebrews biblical worship context",
      "map_region": "jerusalem",
      "map_x": 78,
      "map_y": 71,
      "route_group": "letters",
      "place_names": [
        "예루살렘 성전 그림자",
        "Jerusalem Temple Pattern",
        "성전 그림자",
        "Temple Pattern",
        "エルサレム神殿の型",
        "Pola Bait Suci Yerusalem",
        "แบบอย่างพระวิหารเยรูซาเล็ม",
        "គំរូព្រះវិហារយេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "JAS-001",
      "world_id": "W_NT_GEN",
      "section_key": "general",
      "book_id": "JAS",
      "book_order": 59,
      "order_index": 72,
      "title": {
        "ko": "예루살렘 · 흩어진 지파",
        "en": "Jerusalem · Scattered Tribes",
        "ja": "エルサレム · 散らされた部族",
        "ms": "Yerusalem · Suku yang terserak",
        "th": "เยรูซาเล็ม · เผ่าที่กระจัดกระจาย",
        "km": "យេរូសាឡឹម · កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ"
      },
      "short_title": {
        "ko": "흩어진 지파",
        "en": "Scattered Tribes",
        "ja": "散らされた部族",
        "ms": "Suku yang terserak",
        "th": "เผ่าที่กระจัดกระจาย",
        "km": "កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ"
      },
      "book_title": {
        "ko": "야고보서",
        "en": "James",
        "ja": "ヤコブの手紙",
        "ms": "Yakobus",
        "th": "ยากอบ",
        "km": "យ៉ាកុប"
      },
      "bible_range": "야고보서 1-5",
      "references": {
        "ko": "야고보서 1-5",
        "en": "James 1-5",
        "ja": "ヤコブの手紙 1-5",
        "ms": "Yakobus 1-5",
        "th": "ยากอบ 1-5",
        "km": "យ៉ាកុប 1-5"
      },
      "mission": {
        "ko": "예루살렘 · 흩어진 지파 여정에서 야고보서 5장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem · Scattered Tribes and answer James 5 chapters question bank.",
        "ja": "エルサレム · 散らされた部族の旅で、ヤコブの手紙5章の問題バンクに答えます。",
        "ms": "Ikuti Yerusalem · Suku yang terserak dan jawab bank soalan Yakobus 5 bab.",
        "th": "ติดตามเส้นทางเยรูซาเล็ม · เผ่าที่กระจัดกระจายและตอบคลังคำถามจากยากอบ 5 บท",
        "km": "តាមដានដំណើរយេរូសាឡឹម · កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ ហើយឆ្លើយធនាគារសំណួរពីយ៉ាកុប 5 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-JAS-001",
      "next_stage_id": "1PE-001",
      "asset_key": "asset.stage.jas",
      "difficulty": "basic",
      "map_query": "Jerusalem James biblical location",
      "map_region": "jerusalem",
      "map_x": 78,
      "map_y": 71,
      "route_group": "letters",
      "place_names": [
        "예루살렘 · 흩어진 지파",
        "Jerusalem · Scattered Tribes",
        "흩어진 지파",
        "Scattered Tribes",
        "エルサレム · 散らされた部族",
        "Yerusalem · Suku yang terserak",
        "เยรูซาเล็ม · เผ่าที่กระจัดกระจาย",
        "យេរូសាឡឹម · កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "1PE-001",
      "world_id": "W_NT_GEN",
      "section_key": "general",
      "book_id": "1PE",
      "book_order": 60,
      "order_index": 73,
      "title": {
        "ko": "소아시아 흩어진 성도",
        "en": "Scattered Believers in Asia Minor",
        "ja": "小アジアに散らされた信徒",
        "ms": "Orang percaya yang terserak di Asia Kecil",
        "th": "ผู้เชื่อที่กระจัดกระจายในเอเชียน้อย",
        "km": "អ្នកជឿដែលខ្ចាត់ខ្ចាយនៅអាស៊ីតូច"
      },
      "short_title": {
        "ko": "소아시아",
        "en": "Asia Minor",
        "ja": "小アジア",
        "ms": "Asia Kecil",
        "th": "เอเชียน้อย",
        "km": "អាស៊ីតូច"
      },
      "book_title": {
        "ko": "베드로전서",
        "en": "1 Peter",
        "ja": "ペテロの手紙第一",
        "ms": "1 Petrus",
        "th": "1 เปโตร",
        "km": "១ ពេត្រុស"
      },
      "bible_range": "베드로전서 1-5",
      "references": {
        "ko": "베드로전서 1-5",
        "en": "1 Peter 1-5",
        "ja": "ペテロの手紙第一 1-5",
        "ms": "1 Petrus 1-5",
        "th": "1 เปโตร 1-5",
        "km": "១ ពេត្រុស 1-5"
      },
      "mission": {
        "ko": "소아시아 흩어진 성도 여정에서 베드로전서 5장 본문 문제를 풉니다.",
        "en": "Follow Scattered Believers in Asia Minor and answer 1 Peter 5 chapters question bank.",
        "ja": "小アジアに散らされた信徒の旅で、ペテロの手紙第一5章の問題バンクに答えます。",
        "ms": "Ikuti Orang percaya yang terserak di Asia Kecil dan jawab bank soalan 1 Petrus 5 bab.",
        "th": "ติดตามเส้นทางผู้เชื่อที่กระจัดกระจายในเอเชียน้อยและตอบคลังคำถามจาก1 เปโตร 5 บท",
        "km": "តាមដានដំណើរអ្នកជឿដែលខ្ចាត់ខ្ចាយនៅអាស៊ីតូច ហើយឆ្លើយធនាគារសំណួរពី១ ពេត្រុស 5 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-1PE-001",
      "next_stage_id": "2PE-001",
      "asset_key": "asset.stage.1pe",
      "difficulty": "basic",
      "map_query": "Asia Minor 1 Peter biblical recipients",
      "map_region": "asia-minor",
      "map_x": 63.8,
      "map_y": 32.2,
      "route_group": "letters",
      "place_names": [
        "소아시아 흩어진 성도",
        "Scattered Believers in Asia Minor",
        "소아시아",
        "Asia Minor",
        "小アジアに散らされた信徒",
        "Orang percaya yang terserak di Asia Kecil",
        "ผู้เชื่อที่กระจัดกระจายในเอเชียน้อย",
        "អ្នកជឿដែលខ្ចាត់ខ្ចាយនៅអាស៊ីតូច"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "2PE-001",
      "world_id": "W_NT_GEN",
      "section_key": "general",
      "book_id": "2PE",
      "book_order": 61,
      "order_index": 74,
      "title": {
        "ko": "소아시아 교회",
        "en": "Churches in Asia Minor",
        "ja": "小アジアの教会",
        "ms": "Jemaat di Asia Kecil",
        "th": "คริสตจักรในเอเชียน้อย",
        "km": "ពួកជំនុំនៅអាស៊ីតូច"
      },
      "short_title": {
        "ko": "소아시아",
        "en": "Asia Minor",
        "ja": "小アジア",
        "ms": "Asia Kecil",
        "th": "เอเชียน้อย",
        "km": "អាស៊ីតូច"
      },
      "book_title": {
        "ko": "베드로후서",
        "en": "2 Peter",
        "ja": "ペテロの手紙第二",
        "ms": "2 Petrus",
        "th": "2 เปโตร",
        "km": "២ ពេត្រុស"
      },
      "bible_range": "베드로후서 1-3",
      "references": {
        "ko": "베드로후서 1-3",
        "en": "2 Peter 1-3",
        "ja": "ペテロの手紙第二 1-3",
        "ms": "2 Petrus 1-3",
        "th": "2 เปโตร 1-3",
        "km": "២ ពេត្រុស 1-3"
      },
      "mission": {
        "ko": "소아시아 교회 여정에서 베드로후서 3장 본문 문제를 풉니다.",
        "en": "Follow Churches in Asia Minor and answer 2 Peter 3 chapters question bank.",
        "ja": "小アジアの教会の旅で、ペテロの手紙第二3章の問題バンクに答えます。",
        "ms": "Ikuti Jemaat di Asia Kecil dan jawab bank soalan 2 Petrus 3 bab.",
        "th": "ติดตามเส้นทางคริสตจักรในเอเชียน้อยและตอบคลังคำถามจาก2 เปโตร 3 บท",
        "km": "តាមដានដំណើរពួកជំនុំនៅអាស៊ីតូច ហើយឆ្លើយធនាគារសំណួរពី២ ពេត្រុស 3 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-2PE-001",
      "next_stage_id": "1JN-001",
      "asset_key": "asset.stage.2pe",
      "difficulty": "basic",
      "map_query": "Asia Minor 2 Peter biblical recipients",
      "map_region": "asia-minor",
      "map_x": 63.8,
      "map_y": 32.2,
      "route_group": "letters",
      "place_names": [
        "소아시아 교회",
        "Churches in Asia Minor",
        "소아시아",
        "Asia Minor",
        "小アジアの教会",
        "Jemaat di Asia Kecil",
        "คริสตจักรในเอเชียน้อย",
        "ពួកជំនុំនៅអាស៊ីតូច"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "1JN-001",
      "world_id": "W_NT_GEN",
      "section_key": "general",
      "book_id": "1JN",
      "book_order": 62,
      "order_index": 75,
      "title": {
        "ko": "에베소 · 소아시아",
        "en": "Ephesus · Asia Minor",
        "ja": "エフェソ · 小アジア",
        "ms": "Efesus · Asia Kecil",
        "th": "เอเฟซัส · เอเชียน้อย",
        "km": "អេភេសូរ · អាស៊ីតូច"
      },
      "short_title": {
        "ko": "에베소·소아시아",
        "en": "Ephesus·Asia Minor",
        "ja": "エフェソ·小アジア",
        "ms": "Efesus·Asia Kecil",
        "th": "เอเฟซัส·เอเชียน้อย",
        "km": "អេភេសូរ·អាស៊ីតូច"
      },
      "book_title": {
        "ko": "요한일서",
        "en": "1 John",
        "ja": "ヨハネの手紙第一",
        "ms": "1 Yohanes",
        "th": "1 ยอห์น",
        "km": "១ យ៉ូហាន"
      },
      "bible_range": "요한일서 1-5",
      "references": {
        "ko": "요한일서 1-5",
        "en": "1 John 1-5",
        "ja": "ヨハネの手紙第一 1-5",
        "ms": "1 Yohanes 1-5",
        "th": "1 ยอห์น 1-5",
        "km": "១ យ៉ូហាន 1-5"
      },
      "mission": {
        "ko": "에베소 · 소아시아 여정에서 요한일서 5장 본문 문제를 풉니다.",
        "en": "Follow Ephesus · Asia Minor and answer 1 John 5 chapters question bank.",
        "ja": "エフェソ · 小アジアの旅で、ヨハネの手紙第一5章の問題バンクに答えます。",
        "ms": "Ikuti Efesus · Asia Kecil dan jawab bank soalan 1 Yohanes 5 bab.",
        "th": "ติดตามเส้นทางเอเฟซัส · เอเชียน้อยและตอบคลังคำถามจาก1 ยอห์น 5 บท",
        "km": "តាមដានដំណើរអេភេសូរ · អាស៊ីតូច ហើយឆ្លើយធនាគារសំណួរពី១ យ៉ូហាន 5 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-1JN-001",
      "next_stage_id": "2JN-001",
      "asset_key": "asset.stage.1jn",
      "difficulty": "basic",
      "map_query": "Ephesus Asia Minor 1 John biblical tradition",
      "map_region": "asia-minor",
      "map_x": 51.5,
      "map_y": 37.8,
      "route_group": "letters",
      "place_names": [
        "에베소 · 소아시아",
        "Ephesus · Asia Minor",
        "에베소·소아시아",
        "Ephesus·Asia Minor",
        "エフェソ · 小アジア",
        "Efesus · Asia Kecil",
        "เอเฟซัส · เอเชียน้อย",
        "អេភេសូរ · អាស៊ីតូច"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "2JN-001",
      "world_id": "W_NT_GEN",
      "section_key": "general",
      "book_id": "2JN",
      "book_order": 63,
      "order_index": 76,
      "title": {
        "ko": "소아시아 교회",
        "en": "Churches in Asia Minor",
        "ja": "小アジアの教会",
        "ms": "Jemaat di Asia Kecil",
        "th": "คริสตจักรในเอเชียน้อย",
        "km": "ពួកជំនុំនៅអាស៊ីតូច"
      },
      "short_title": {
        "ko": "소아시아",
        "en": "Asia Minor",
        "ja": "小アジア",
        "ms": "Asia Kecil",
        "th": "เอเชียน้อย",
        "km": "អាស៊ីតូច"
      },
      "book_title": {
        "ko": "요한이서",
        "en": "2 John",
        "ja": "ヨハネの手紙第二",
        "ms": "2 Yohanes",
        "th": "2 ยอห์น",
        "km": "២ យ៉ូហាន"
      },
      "bible_range": "요한이서 1",
      "references": {
        "ko": "요한이서 1",
        "en": "2 John 1",
        "ja": "ヨハネの手紙第二 1",
        "ms": "2 Yohanes 1",
        "th": "2 ยอห์น 1",
        "km": "២ យ៉ូហាន 1"
      },
      "mission": {
        "ko": "소아시아 교회 여정에서 요한이서 1장 본문 문제를 풉니다.",
        "en": "Follow Churches in Asia Minor and answer 2 John 1 chapters question bank.",
        "ja": "小アジアの教会の旅で、ヨハネの手紙第二1章の問題バンクに答えます。",
        "ms": "Ikuti Jemaat di Asia Kecil dan jawab bank soalan 2 Yohanes 1 bab.",
        "th": "ติดตามเส้นทางคริสตจักรในเอเชียน้อยและตอบคลังคำถามจาก2 ยอห์น 1 บท",
        "km": "តាមដានដំណើរពួកជំនុំនៅអាស៊ីតូច ហើយឆ្លើយធនាគារសំណួរពី២ យ៉ូហាន 1 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-2JN-001",
      "next_stage_id": "3JN-001",
      "asset_key": "asset.stage.2jn",
      "difficulty": "basic",
      "map_query": "Ephesus Asia Minor 2 John biblical tradition",
      "map_region": "asia-minor",
      "map_x": 51.5,
      "map_y": 37.8,
      "route_group": "letters",
      "place_names": [
        "소아시아 교회",
        "Churches in Asia Minor",
        "소아시아",
        "Asia Minor",
        "小アジアの教会",
        "Jemaat di Asia Kecil",
        "คริสตจักรในเอเชียน้อย",
        "ពួកជំនុំនៅអាស៊ីតូច"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "3JN-001",
      "world_id": "W_NT_GEN",
      "section_key": "general",
      "book_id": "3JN",
      "book_order": 64,
      "order_index": 77,
      "title": {
        "ko": "소아시아 교회",
        "en": "Churches in Asia Minor",
        "ja": "小アジアの教会",
        "ms": "Jemaat di Asia Kecil",
        "th": "คริสตจักรในเอเชียน้อย",
        "km": "ពួកជំនុំនៅអាស៊ីតូច"
      },
      "short_title": {
        "ko": "소아시아",
        "en": "Asia Minor",
        "ja": "小アジア",
        "ms": "Asia Kecil",
        "th": "เอเชียน้อย",
        "km": "អាស៊ីតូច"
      },
      "book_title": {
        "ko": "요한삼서",
        "en": "3 John",
        "ja": "ヨハネの手紙第三",
        "ms": "3 Yohanes",
        "th": "3 ยอห์น",
        "km": "៣ យ៉ូហាន"
      },
      "bible_range": "요한삼서 1",
      "references": {
        "ko": "요한삼서 1",
        "en": "3 John 1",
        "ja": "ヨハネの手紙第三 1",
        "ms": "3 Yohanes 1",
        "th": "3 ยอห์น 1",
        "km": "៣ យ៉ូហាន 1"
      },
      "mission": {
        "ko": "소아시아 교회 여정에서 요한삼서 1장 본문 문제를 풉니다.",
        "en": "Follow Churches in Asia Minor and answer 3 John 1 chapters question bank.",
        "ja": "小アジアの教会の旅で、ヨハネの手紙第三1章の問題バンクに答えます。",
        "ms": "Ikuti Jemaat di Asia Kecil dan jawab bank soalan 3 Yohanes 1 bab.",
        "th": "ติดตามเส้นทางคริสตจักรในเอเชียน้อยและตอบคลังคำถามจาก3 ยอห์น 1 บท",
        "km": "តាមដានដំណើរពួកជំនុំនៅអាស៊ីតូច ហើយឆ្លើយធនាគារសំណួរពី៣ យ៉ូហាន 1 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-3JN-001",
      "next_stage_id": "JUD-001",
      "asset_key": "asset.stage.3jn",
      "difficulty": "basic",
      "map_query": "Ephesus Asia Minor 3 John biblical tradition",
      "map_region": "asia-minor",
      "map_x": 51.5,
      "map_y": 37.8,
      "route_group": "letters",
      "place_names": [
        "소아시아 교회",
        "Churches in Asia Minor",
        "소아시아",
        "Asia Minor",
        "小アジアの教会",
        "Jemaat di Asia Kecil",
        "คริสตจักรในเอเชียน้อย",
        "ពួកជំនុំនៅអាស៊ីតូច"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "JUD-001",
      "world_id": "W_NT_GEN",
      "section_key": "general",
      "book_id": "JUD",
      "book_order": 65,
      "order_index": 78,
      "title": {
        "ko": "예루살렘 형제 공동체",
        "en": "Jerusalem Brotherly Community",
        "ja": "エルサレムの兄弟共同体",
        "ms": "Komuniti saudara Yerusalem",
        "th": "ชุมชนพี่น้องเยรูซาเล็ม",
        "km": "សហគមន៍បងប្អូនយេរូសាឡឹម"
      },
      "short_title": {
        "ko": "예루살렘 공동체",
        "en": "Jerusalem Community",
        "ja": "エルサレム共同体",
        "ms": "Komuniti Yerusalem",
        "th": "ชุมชนเยรูซาเล็ม",
        "km": "សហគមន៍យេរូសាឡឹម"
      },
      "book_title": {
        "ko": "유다서",
        "en": "Jude",
        "ja": "ユダの手紙",
        "ms": "Yudas",
        "th": "ยูดา",
        "km": "យូដាស"
      },
      "bible_range": "유다서 1",
      "references": {
        "ko": "유다서 1",
        "en": "Jude 1",
        "ja": "ユダの手紙 1",
        "ms": "Yudas 1",
        "th": "ยูดา 1",
        "km": "យូដាស 1"
      },
      "mission": {
        "ko": "예루살렘 형제 공동체 여정에서 유다서 1장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem Brotherly Community and answer Jude 1 chapters question bank.",
        "ja": "エルサレムの兄弟共同体の旅で、ユダの手紙1章の問題バンクに答えます。",
        "ms": "Ikuti Komuniti saudara Yerusalem dan jawab bank soalan Yudas 1 bab.",
        "th": "ติดตามเส้นทางชุมชนพี่น้องเยรูซาเล็มและตอบคลังคำถามจากยูดา 1 บท",
        "km": "តាមដានដំណើរសហគមន៍បងប្អូនយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីយូដាស 1 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-JUD-001",
      "next_stage_id": "HEB-REVIEW-09",
      "asset_key": "asset.stage.jud",
      "difficulty": "basic",
      "map_query": "Jerusalem Jude biblical location",
      "map_region": "jerusalem",
      "map_x": 78,
      "map_y": 71,
      "route_group": "letters",
      "place_names": [
        "예루살렘 형제 공동체",
        "Jerusalem Brotherly Community",
        "예루살렘 공동체",
        "Jerusalem Community",
        "エルサレムの兄弟共同体",
        "Komuniti saudara Yerusalem",
        "ชุมชนพี่น้องเยรูซาเล็ม",
        "សហគមន៍បងប្អូនយេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "HEB-REVIEW-09",
      "world_id": "W_NT_GEN",
      "section_key": "general",
      "book_id": "HEB",
      "book_order": 58,
      "order_index": 79,
      "title": {
        "ko": "예루살렘 성전 그림자 복습",
        "en": "Jerusalem Temple Pattern Review",
        "ja": "エルサレム神殿の型 復習",
        "ms": "Pola Bait Suci Yerusalem Ulang kaji",
        "th": "แบบอย่างพระวิหารเยรูซาเล็ม ทบทวน",
        "km": "គំរូព្រះវិហារយេរូសាឡឹម រំលឹក"
      },
      "short_title": {
        "ko": "성전 그림자+",
        "en": "Temple Pattern+",
        "ja": "神殿の型+",
        "ms": "Pola Bait Suci+",
        "th": "แบบอย่างพระวิหาร+",
        "km": "គំរូព្រះវិហារ+"
      },
      "book_title": {
        "ko": "히브리서",
        "en": "Hebrews",
        "ja": "ヘブル人への手紙",
        "ms": "Ibrani",
        "th": "ฮีบรู",
        "km": "ហេព្រើរ"
      },
      "bible_range": "히브리서 1-13",
      "references": {
        "ko": "히브리서 1-13",
        "en": "Hebrews 1-13",
        "ja": "ヘブル人への手紙 1-13",
        "ms": "Ibrani 1-13",
        "th": "ฮีบรู 1-13",
        "km": "ហេព្រើរ 1-13"
      },
      "mission": {
        "ko": "예루살렘 성전 그림자 길에서 히브리서 주요 사건을 다시 확인합니다.",
        "en": "Review the main Hebrews events along Jerusalem Temple Pattern.",
        "ja": "エルサレム神殿の型の道で、ヘブル人への手紙の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Ibrani di sepanjang Pola Bait Suci Yerusalem.",
        "th": "ทบทวนเหตุการณ์สำคัญของฮีบรูตามเส้นทางแบบอย่างพระวิหารเยรูซาเล็ม",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃហេព្រើរ តាមផ្លូវគំរូព្រះវិហារយេរូសាឡឹម។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-HEB-REVIEW-09",
      "next_stage_id": "JAS-REVIEW-10",
      "asset_key": "asset.stage.heb.review.9",
      "difficulty": "review",
      "map_query": "Jerusalem Hebrews biblical worship context review",
      "map_region": "jerusalem",
      "map_x": 78,
      "map_y": 71,
      "route_group": "letters",
      "place_names": [
        "예루살렘 성전 그림자",
        "Jerusalem Temple Pattern",
        "성전 그림자",
        "Temple Pattern",
        "エルサレム神殿の型",
        "Pola Bait Suci Yerusalem",
        "แบบอย่างพระวิหารเยรูซาเล็ม",
        "គំរូព្រះវិហារយេរូសាឡឹម"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "JAS-REVIEW-10",
      "world_id": "W_NT_GEN",
      "section_key": "general",
      "book_id": "JAS",
      "book_order": 59,
      "order_index": 80,
      "title": {
        "ko": "예루살렘 · 흩어진 지파 복습",
        "en": "Jerusalem · Scattered Tribes Review",
        "ja": "エルサレム · 散らされた部族 復習",
        "ms": "Yerusalem · Suku yang terserak Ulang kaji",
        "th": "เยรูซาเล็ม · เผ่าที่กระจัดกระจาย ทบทวน",
        "km": "យេរូសាឡឹម · កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ រំលឹក"
      },
      "short_title": {
        "ko": "흩어진 지파+",
        "en": "Scattered Tribes+",
        "ja": "散らされた部族+",
        "ms": "Suku yang terserak+",
        "th": "เผ่าที่กระจัดกระจาย+",
        "km": "កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ+"
      },
      "book_title": {
        "ko": "야고보서",
        "en": "James",
        "ja": "ヤコブの手紙",
        "ms": "Yakobus",
        "th": "ยากอบ",
        "km": "យ៉ាកុប"
      },
      "bible_range": "야고보서 1-5",
      "references": {
        "ko": "야고보서 1-5",
        "en": "James 1-5",
        "ja": "ヤコブの手紙 1-5",
        "ms": "Yakobus 1-5",
        "th": "ยากอบ 1-5",
        "km": "យ៉ាកុប 1-5"
      },
      "mission": {
        "ko": "예루살렘 · 흩어진 지파 길에서 야고보서 주요 사건을 다시 확인합니다.",
        "en": "Review the main James events along Jerusalem · Scattered Tribes.",
        "ja": "エルサレム · 散らされた部族の道で、ヤコブの手紙の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Yakobus di sepanjang Yerusalem · Suku yang terserak.",
        "th": "ทบทวนเหตุการณ์สำคัญของยากอบตามเส้นทางเยรูซาเล็ม · เผ่าที่กระจัดกระจาย",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃយ៉ាកុប តាមផ្លូវយេរូសាឡឹម · កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-JAS-REVIEW-10",
      "next_stage_id": "REV-001",
      "asset_key": "asset.stage.jas.review.10",
      "difficulty": "review",
      "map_query": "Jerusalem James biblical location review",
      "map_region": "jerusalem",
      "map_x": 78,
      "map_y": 71,
      "route_group": "letters",
      "place_names": [
        "예루살렘 · 흩어진 지파",
        "Jerusalem · Scattered Tribes",
        "흩어진 지파",
        "Scattered Tribes",
        "エルサレム · 散らされた部族",
        "Yerusalem · Suku yang terserak",
        "เยรูซาเล็ม · เผ่าที่กระจัดกระจาย",
        "យេរូសាឡឹម · កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "REV-001",
      "world_id": "W_NT_PROP",
      "section_key": "prophecy",
      "book_id": "REV",
      "book_order": 66,
      "order_index": 81,
      "title": {
        "ko": "밧모섬 · 소아시아 일곱 교회",
        "en": "Patmos · Seven Churches of Asia",
        "ja": "パトモス · アジアの七つの教会",
        "ms": "Patmos · Tujuh jemaat Asia",
        "th": "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
        "km": "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី"
      },
      "short_title": {
        "ko": "밧모섬·일곱 교회",
        "en": "Patmos·Seven Churches",
        "ja": "パトモス·七つの教会",
        "ms": "Patmos·Tujuh jemaat",
        "th": "ปัทมอส·คริสตจักรทั้งเจ็ด",
        "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ"
      },
      "book_title": {
        "ko": "요한계시록",
        "en": "Revelation",
        "ja": "黙示録",
        "ms": "Wahyu",
        "th": "วิวรณ์",
        "km": "វិវរណៈ"
      },
      "bible_range": "요한계시록 1-22",
      "references": {
        "ko": "요한계시록 1-22",
        "en": "Revelation 1-22",
        "ja": "黙示録 1-22",
        "ms": "Wahyu 1-22",
        "th": "วิวรณ์ 1-22",
        "km": "វិវរណៈ 1-22"
      },
      "mission": {
        "ko": "밧모섬 · 소아시아 일곱 교회 여정에서 요한계시록 22장 본문 문제를 풉니다.",
        "en": "Follow Patmos · Seven Churches of Asia and answer Revelation 22 chapters question bank.",
        "ja": "パトモス · アジアの七つの教会の旅で、黙示録22章の問題バンクに答えます。",
        "ms": "Ikuti Patmos · Tujuh jemaat Asia dan jawab bank soalan Wahyu 22 bab.",
        "th": "ติดตามเส้นทางปัทมอส · คริสตจักรทั้งเจ็ดในเอเชียและตอบคลังคำถามจากวิวรณ์ 22 บท",
        "km": "តាមដានដំណើរប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី ហើយឆ្លើយធនាគារសំណួរពីវិវរណៈ 22 ជំពូក។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-REV-001",
      "next_stage_id": "REV-REVIEW-02",
      "asset_key": "asset.stage.rev",
      "difficulty": "basic",
      "map_query": "Patmos Greece Revelation biblical location",
      "map_region": "patmos",
      "map_x": 52.5,
      "map_y": 43.5,
      "route_group": "prophecy",
      "place_names": [
        "밧모섬 · 소아시아 일곱 교회",
        "Patmos · Seven Churches of Asia",
        "밧모섬·일곱 교회",
        "Patmos·Seven Churches",
        "パトモス · アジアの七つの教会",
        "Patmos · Tujuh jemaat Asia",
        "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
        "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "REV-REVIEW-02",
      "world_id": "W_NT_PROP",
      "section_key": "prophecy",
      "book_id": "REV",
      "book_order": 66,
      "order_index": 82,
      "title": {
        "ko": "밧모섬 · 소아시아 일곱 교회 복습",
        "en": "Patmos · Seven Churches of Asia Review",
        "ja": "パトモス · アジアの七つの教会 復習",
        "ms": "Patmos · Tujuh jemaat Asia Ulang kaji",
        "th": "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย ทบทวน",
        "km": "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី រំលឹក"
      },
      "short_title": {
        "ko": "밧모섬·일곱 교회+",
        "en": "Patmos·Seven Churches+",
        "ja": "パトモス·七つの教会+",
        "ms": "Patmos·Tujuh jemaat+",
        "th": "ปัทมอส·คริสตจักรทั้งเจ็ด+",
        "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+"
      },
      "book_title": {
        "ko": "요한계시록",
        "en": "Revelation",
        "ja": "黙示録",
        "ms": "Wahyu",
        "th": "วิวรณ์",
        "km": "វិវរណៈ"
      },
      "bible_range": "요한계시록 1-22",
      "references": {
        "ko": "요한계시록 1-22",
        "en": "Revelation 1-22",
        "ja": "黙示録 1-22",
        "ms": "Wahyu 1-22",
        "th": "วิวรณ์ 1-22",
        "km": "វិវរណៈ 1-22"
      },
      "mission": {
        "ko": "밧모섬 · 소아시아 일곱 교회 길에서 요한계시록 주요 사건을 다시 확인합니다.",
        "en": "Review the main Revelation events along Patmos · Seven Churches of Asia.",
        "ja": "パトモス · アジアの七つの教会の道で、黙示録の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Wahyu di sepanjang Patmos · Tujuh jemaat Asia.",
        "th": "ทบทวนเหตุการณ์สำคัญของวิวรณ์ตามเส้นทางปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃវិវរណៈ តាមផ្លូវប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-REV-REVIEW-02",
      "next_stage_id": "REV-REVIEW-03",
      "asset_key": "asset.stage.rev.review.2",
      "difficulty": "review",
      "map_query": "Patmos Greece Revelation biblical location review",
      "map_region": "patmos",
      "map_x": 52.5,
      "map_y": 43.5,
      "route_group": "prophecy",
      "place_names": [
        "밧모섬 · 소아시아 일곱 교회",
        "Patmos · Seven Churches of Asia",
        "밧모섬·일곱 교회",
        "Patmos·Seven Churches",
        "パトモス · アジアの七つの教会",
        "Patmos · Tujuh jemaat Asia",
        "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
        "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "REV-REVIEW-03",
      "world_id": "W_NT_PROP",
      "section_key": "prophecy",
      "book_id": "REV",
      "book_order": 66,
      "order_index": 83,
      "title": {
        "ko": "밧모섬 · 소아시아 일곱 교회 복습",
        "en": "Patmos · Seven Churches of Asia Review",
        "ja": "パトモス · アジアの七つの教会 復習",
        "ms": "Patmos · Tujuh jemaat Asia Ulang kaji",
        "th": "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย ทบทวน",
        "km": "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី រំលឹក"
      },
      "short_title": {
        "ko": "밧모섬·일곱 교회+",
        "en": "Patmos·Seven Churches+",
        "ja": "パトモス·七つの教会+",
        "ms": "Patmos·Tujuh jemaat+",
        "th": "ปัทมอส·คริสตจักรทั้งเจ็ด+",
        "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+"
      },
      "book_title": {
        "ko": "요한계시록",
        "en": "Revelation",
        "ja": "黙示録",
        "ms": "Wahyu",
        "th": "วิวรณ์",
        "km": "វិវរណៈ"
      },
      "bible_range": "요한계시록 1-22",
      "references": {
        "ko": "요한계시록 1-22",
        "en": "Revelation 1-22",
        "ja": "黙示録 1-22",
        "ms": "Wahyu 1-22",
        "th": "วิวรณ์ 1-22",
        "km": "វិវរណៈ 1-22"
      },
      "mission": {
        "ko": "밧모섬 · 소아시아 일곱 교회 길에서 요한계시록 주요 사건을 다시 확인합니다.",
        "en": "Review the main Revelation events along Patmos · Seven Churches of Asia.",
        "ja": "パトモス · アジアの七つの教会の道で、黙示録の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Wahyu di sepanjang Patmos · Tujuh jemaat Asia.",
        "th": "ทบทวนเหตุการณ์สำคัญของวิวรณ์ตามเส้นทางปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃវិវរណៈ តាមផ្លូវប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-REV-REVIEW-03",
      "next_stage_id": "REV-REVIEW-04",
      "asset_key": "asset.stage.rev.review.3",
      "difficulty": "review",
      "map_query": "Patmos Greece Revelation biblical location review",
      "map_region": "patmos",
      "map_x": 52.5,
      "map_y": 43.5,
      "route_group": "prophecy",
      "place_names": [
        "밧모섬 · 소아시아 일곱 교회",
        "Patmos · Seven Churches of Asia",
        "밧모섬·일곱 교회",
        "Patmos·Seven Churches",
        "パトモス · アジアの七つの教会",
        "Patmos · Tujuh jemaat Asia",
        "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
        "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "REV-REVIEW-04",
      "world_id": "W_NT_PROP",
      "section_key": "prophecy",
      "book_id": "REV",
      "book_order": 66,
      "order_index": 84,
      "title": {
        "ko": "밧모섬 · 소아시아 일곱 교회 복습",
        "en": "Patmos · Seven Churches of Asia Review",
        "ja": "パトモス · アジアの七つの教会 復習",
        "ms": "Patmos · Tujuh jemaat Asia Ulang kaji",
        "th": "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย ทบทวน",
        "km": "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី រំលឹក"
      },
      "short_title": {
        "ko": "밧모섬·일곱 교회+",
        "en": "Patmos·Seven Churches+",
        "ja": "パトモス·七つの教会+",
        "ms": "Patmos·Tujuh jemaat+",
        "th": "ปัทมอส·คริสตจักรทั้งเจ็ด+",
        "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+"
      },
      "book_title": {
        "ko": "요한계시록",
        "en": "Revelation",
        "ja": "黙示録",
        "ms": "Wahyu",
        "th": "วิวรณ์",
        "km": "វិវរណៈ"
      },
      "bible_range": "요한계시록 1-22",
      "references": {
        "ko": "요한계시록 1-22",
        "en": "Revelation 1-22",
        "ja": "黙示録 1-22",
        "ms": "Wahyu 1-22",
        "th": "วิวรณ์ 1-22",
        "km": "វិវរណៈ 1-22"
      },
      "mission": {
        "ko": "밧모섬 · 소아시아 일곱 교회 길에서 요한계시록 주요 사건을 다시 확인합니다.",
        "en": "Review the main Revelation events along Patmos · Seven Churches of Asia.",
        "ja": "パトモス · アジアの七つの教会の道で、黙示録の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Wahyu di sepanjang Patmos · Tujuh jemaat Asia.",
        "th": "ทบทวนเหตุการณ์สำคัญของวิวรณ์ตามเส้นทางปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃវិវរណៈ តាមផ្លូវប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-REV-REVIEW-04",
      "next_stage_id": "REV-REVIEW-05",
      "asset_key": "asset.stage.rev.review.4",
      "difficulty": "review",
      "map_query": "Patmos Greece Revelation biblical location review",
      "map_region": "patmos",
      "map_x": 52.5,
      "map_y": 43.5,
      "route_group": "prophecy",
      "place_names": [
        "밧모섬 · 소아시아 일곱 교회",
        "Patmos · Seven Churches of Asia",
        "밧모섬·일곱 교회",
        "Patmos·Seven Churches",
        "パトモス · アジアの七つの教会",
        "Patmos · Tujuh jemaat Asia",
        "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
        "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី"
      ],
      "chapter_question_count": 30
    },
    {
      "stage_id": "REV-REVIEW-05",
      "world_id": "W_NT_PROP",
      "section_key": "prophecy",
      "book_id": "REV",
      "book_order": 66,
      "order_index": 85,
      "title": {
        "ko": "밧모섬 · 소아시아 일곱 교회 복습",
        "en": "Patmos · Seven Churches of Asia Review",
        "ja": "パトモス · アジアの七つの教会 復習",
        "ms": "Patmos · Tujuh jemaat Asia Ulang kaji",
        "th": "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย ทบทวน",
        "km": "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី រំលឹក"
      },
      "short_title": {
        "ko": "밧모섬·일곱 교회+",
        "en": "Patmos·Seven Churches+",
        "ja": "パトモス·七つの教会+",
        "ms": "Patmos·Tujuh jemaat+",
        "th": "ปัทมอส·คริสตจักรทั้งเจ็ด+",
        "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+"
      },
      "book_title": {
        "ko": "요한계시록",
        "en": "Revelation",
        "ja": "黙示録",
        "ms": "Wahyu",
        "th": "วิวรณ์",
        "km": "វិវរណៈ"
      },
      "bible_range": "요한계시록 1-22",
      "references": {
        "ko": "요한계시록 1-22",
        "en": "Revelation 1-22",
        "ja": "黙示録 1-22",
        "ms": "Wahyu 1-22",
        "th": "วิวรณ์ 1-22",
        "km": "វិវរណៈ 1-22"
      },
      "mission": {
        "ko": "밧모섬 · 소아시아 일곱 교회 길에서 요한계시록 주요 사건을 다시 확인합니다.",
        "en": "Review the main Revelation events along Patmos · Seven Churches of Asia.",
        "ja": "パトモス · アジアの七つの教会の道で、黙示録の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Wahyu di sepanjang Patmos · Tujuh jemaat Asia.",
        "th": "ทบทวนเหตุการณ์สำคัญของวิวรณ์ตามเส้นทางปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃវិវរណៈ តាមផ្លូវប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី។"
      },
      "primary_quiz_types": [
        "multiple_choice"
      ],
      "reward_card_id": "CARD-REV-REVIEW-05",
      "next_stage_id": null,
      "asset_key": "asset.stage.rev.review.5",
      "difficulty": "review",
      "map_query": "Patmos Greece Revelation biblical location review",
      "map_region": "patmos",
      "map_x": 52.5,
      "map_y": 43.5,
      "route_group": "prophecy",
      "place_names": [
        "밧모섬 · 소아시아 일곱 교회",
        "Patmos · Seven Churches of Asia",
        "밧모섬·일곱 교회",
        "Patmos·Seven Churches",
        "パトモス · アジアの七つの教会",
        "Patmos · Tujuh jemaat Asia",
        "ปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
        "ប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី"
      ],
      "chapter_question_count": 30
    }
  ],
  "reward_cards": [
    {
      "card_id": "CARD-GEN-001",
      "world_id": "W_OT_PENT",
      "card_type": "book",
      "asset_key": "asset.card.gen-001",
      "title": {
        "ko": "에덴·아라랏·바벨",
        "en": "Eden·Ararat·Babel",
        "ja": "エデン·アララト·バベル",
        "ms": "Eden·Ararat·Babel",
        "th": "เอเดน·อารารัต·บาเบล",
        "km": "អេដែន·អារ៉ារ៉ាត់·បាបិល"
      },
      "summary": {
        "ko": "에덴 · 아라랏산 · 바벨 여정에서 창세기 50장 본문 문제를 풉니다.",
        "en": "Follow Eden · Mount Ararat · Babel and answer Genesis 50 chapters question bank.",
        "ja": "エデン · アララト山 · バベルの旅で、創世記50章の問題バンクに答えます。",
        "ms": "Ikuti Eden · Gunung Ararat · Babel dan jawab bank soalan Kejadian 50 bab.",
        "th": "ติดตามเส้นทางเอเดน · ภูเขาอารารัต · บาเบลและตอบคลังคำถามจากปฐมกาล 50 บท",
        "km": "តាមដានដំណើរអេដែន · ភ្នំអារ៉ារ៉ាត់ · បាបិល ហើយឆ្លើយធនាគារសំណួរពីលោកុប្បត្តិ 50 ជំពូក។"
      },
      "verse_reference": {
        "ko": "창세기 1-50",
        "en": "Genesis 1-50",
        "ja": "創世記 1-50",
        "ms": "Kejadian 1-50",
        "th": "ปฐมกาล 1-50",
        "km": "លោកុប្បត្តិ 1-50"
      },
      "verse_summary": {
        "ko": "에덴·아라랏·바벨 복습",
        "en": "Eden·Ararat·Babel Review",
        "ja": "エデン·アララト·バベル 復習",
        "ms": "Eden·Ararat·Babel Ulang kaji",
        "th": "เอเดน·อารารัต·บาเบล ทบทวน",
        "km": "អេដែន·អារ៉ារ៉ាត់·បាបិល រំលឹក"
      }
    },
    {
      "card_id": "CARD-EXO-001",
      "world_id": "W_OT_PENT",
      "card_type": "book",
      "asset_key": "asset.card.exo-001",
      "title": {
        "ko": "고센·홍해·시내산",
        "en": "Goshen·Red Sea·Sinai",
        "ja": "ゴシェン·紅海·シナイ",
        "ms": "Gosyen·Laut Merah·Sinai",
        "th": "โกเชน·ทะเลแดง·ซีนาย",
        "km": "កូសែន·សមុទ្រក្រហម·ស៊ីណាយ"
      },
      "summary": {
        "ko": "고센 · 홍해 · 시내산 여정에서 출애굽기 40장 본문 문제를 풉니다.",
        "en": "Follow Goshen · Red Sea · Mount Sinai and answer Exodus 40 chapters question bank.",
        "ja": "ゴシェン · 紅海 · シナイ山の旅で、出エジプト記40章の問題バンクに答えます。",
        "ms": "Ikuti Gosyen · Laut Merah · Gunung Sinai dan jawab bank soalan Keluaran 40 bab.",
        "th": "ติดตามเส้นทางโกเชน · ทะเลแดง · ภูเขาซีนายและตอบคลังคำถามจากอพยพ 40 บท",
        "km": "តាមដានដំណើរកូសែន · សមុទ្រក្រហម · ភ្នំស៊ីណាយ ហើយឆ្លើយធនាគារសំណួរពីនិក្ខមនំ 40 ជំពូក។"
      },
      "verse_reference": {
        "ko": "출애굽기 1-40",
        "en": "Exodus 1-40",
        "ja": "出エジプト記 1-40",
        "ms": "Keluaran 1-40",
        "th": "อพยพ 1-40",
        "km": "និក្ខមនំ 1-40"
      },
      "verse_summary": {
        "ko": "고센·홍해·시내산 복습",
        "en": "Goshen·Red Sea·Sinai Review",
        "ja": "ゴシェン·紅海·シナイ 復習",
        "ms": "Gosyen·Laut Merah·Sinai Ulang kaji",
        "th": "โกเชน·ทะเลแดง·ซีนาย ทบทวน",
        "km": "កូសែន·សមុទ្រក្រហម·ស៊ីណាយ រំលឹក"
      }
    },
    {
      "card_id": "CARD-LEV-001",
      "world_id": "W_OT_PENT",
      "card_type": "book",
      "asset_key": "asset.card.lev-001",
      "title": {
        "ko": "시내산",
        "en": "Sinai",
        "ja": "シナイ",
        "ms": "Sinai",
        "th": "ซีนาย",
        "km": "ស៊ីណាយ"
      },
      "summary": {
        "ko": "시내산 회막 여정에서 레위기 27장 본문 문제를 풉니다.",
        "en": "Follow The Tent of Meeting at Sinai and answer Leviticus 27 chapters question bank.",
        "ja": "シナイの会見の天幕の旅で、レビ記27章の問題バンクに答えます。",
        "ms": "Ikuti Khemah Pertemuan di Sinai dan jawab bank soalan Imamat 27 bab.",
        "th": "ติดตามเส้นทางเต็นท์นัดพบที่ซีนายและตอบคลังคำถามจากเลวีนิติ 27 บท",
        "km": "តាមដានដំណើរត្រសាលជំនុំនៅស៊ីណាយ ហើយឆ្លើយធនាគារសំណួរពីលេវីវិន័យ 27 ជំពូក។"
      },
      "verse_reference": {
        "ko": "레위기 1-27",
        "en": "Leviticus 1-27",
        "ja": "レビ記 1-27",
        "ms": "Imamat 1-27",
        "th": "เลวีนิติ 1-27",
        "km": "លេវីវិន័យ 1-27"
      },
      "verse_summary": {
        "ko": "시내산 복습",
        "en": "Sinai Review",
        "ja": "シナイ 復習",
        "ms": "Sinai Ulang kaji",
        "th": "ซีนาย ทบทวน",
        "km": "ស៊ីណាយ រំលឹក"
      }
    },
    {
      "card_id": "CARD-NUM-001",
      "world_id": "W_OT_PENT",
      "card_type": "book",
      "asset_key": "asset.card.num-001",
      "title": {
        "ko": "가데스·모압",
        "en": "Kadesh·Moab",
        "ja": "カデシュ·モアブ",
        "ms": "Kadesh·Moab",
        "th": "คาเดช·โมอับ",
        "km": "កាដេស·ម៉ូអាប់"
      },
      "summary": {
        "ko": "가데스 바네아 · 모압 평지 여정에서 민수기 36장 본문 문제를 풉니다.",
        "en": "Follow Kadesh-barnea · Plains of Moab and answer Numbers 36 chapters question bank.",
        "ja": "カデシュ・バルネア · モアブの平野の旅で、民数記36章の問題バンクに答えます。",
        "ms": "Ikuti Kadesh-barnea · Dataran Moab dan jawab bank soalan Bilangan 36 bab.",
        "th": "ติดตามเส้นทางคาเดชบารเนีย · ที่ราบโมอับและตอบคลังคำถามจากกันดารวิถี 36 บท",
        "km": "តាមដានដំណើរកាដេសបារនេា · វាលទំនាបម៉ូអាប់ ហើយឆ្លើយធនាគារសំណួរពីជនគណនា 36 ជំពូក។"
      },
      "verse_reference": {
        "ko": "민수기 1-36",
        "en": "Numbers 1-36",
        "ja": "民数記 1-36",
        "ms": "Bilangan 1-36",
        "th": "กันดารวิถี 1-36",
        "km": "ជនគណនា 1-36"
      },
      "verse_summary": {
        "ko": "가데스·모압 복습",
        "en": "Kadesh·Moab Review",
        "ja": "カデシュ·モアブ 復習",
        "ms": "Kadesh·Moab Ulang kaji",
        "th": "คาเดช·โมอับ ทบทวน",
        "km": "កាដេស·ម៉ូអាប់ រំលឹក"
      }
    },
    {
      "card_id": "CARD-DEU-001",
      "world_id": "W_OT_PENT",
      "card_type": "book",
      "asset_key": "asset.card.deu-001",
      "title": {
        "ko": "느보산",
        "en": "Mount Nebo",
        "ja": "ネボ山",
        "ms": "Gunung Nebo",
        "th": "ภูเขาเนโบ",
        "km": "ភ្នំណេបូ"
      },
      "summary": {
        "ko": "느보산 · 모압 평지 여정에서 신명기 34장 본문 문제를 풉니다.",
        "en": "Follow Mount Nebo · Plains of Moab and answer Deuteronomy 34 chapters question bank.",
        "ja": "ネボ山 · モアブの平野の旅で、申命記34章の問題バンクに答えます。",
        "ms": "Ikuti Gunung Nebo · Dataran Moab dan jawab bank soalan Ulangan 34 bab.",
        "th": "ติดตามเส้นทางภูเขาเนโบ · ที่ราบโมอับและตอบคลังคำถามจากเฉลยธรรมบัญญัติ 34 บท",
        "km": "តាមដានដំណើរភ្នំណេបូ · វាលទំនាបម៉ូអាប់ ហើយឆ្លើយធនាគារសំណួរពីចោទិយកថា 34 ជំពូក។"
      },
      "verse_reference": {
        "ko": "신명기 1-34",
        "en": "Deuteronomy 1-34",
        "ja": "申命記 1-34",
        "ms": "Ulangan 1-34",
        "th": "เฉลยธรรมบัญญัติ 1-34",
        "km": "ចោទិយកថា 1-34"
      },
      "verse_summary": {
        "ko": "느보산 복습",
        "en": "Mount Nebo Review",
        "ja": "ネボ山 復習",
        "ms": "Gunung Nebo Ulang kaji",
        "th": "ภูเขาเนโบ ทบทวน",
        "km": "ភ្នំណេបូ រំលឹក"
      }
    },
    {
      "card_id": "CARD-JOS-001",
      "world_id": "W_OT_HIST",
      "card_type": "book",
      "asset_key": "asset.card.jos-001",
      "title": {
        "ko": "요단·여리고",
        "en": "Jordan·Jericho",
        "ja": "ヨルダン·エリコ",
        "ms": "Yordan·Yerikho",
        "th": "จอร์แดน·เยรีโค",
        "km": "យ័រដាន់·យេរីខូ"
      },
      "summary": {
        "ko": "요단강 · 여리고 여정에서 여호수아 24장 본문 문제를 풉니다.",
        "en": "Follow Jordan River · Jericho and answer Joshua 24 chapters question bank.",
        "ja": "ヨルダン川 · エリコの旅で、ヨシュア記24章の問題バンクに答えます。",
        "ms": "Ikuti Sungai Yordan · Yerikho dan jawab bank soalan Yosua 24 bab.",
        "th": "ติดตามเส้นทางแม่น้ำจอร์แดน · เยรีโคและตอบคลังคำถามจากโยชูวา 24 บท",
        "km": "តាមដានដំណើរទន្លេយ័រដាន់ · យេរីខូ ហើយឆ្លើយធនាគារសំណួរពីយ៉ូស្វេ 24 ជំពូក។"
      },
      "verse_reference": {
        "ko": "여호수아 1-24",
        "en": "Joshua 1-24",
        "ja": "ヨシュア記 1-24",
        "ms": "Yosua 1-24",
        "th": "โยชูวา 1-24",
        "km": "យ៉ូស្វេ 1-24"
      },
      "verse_summary": {
        "ko": "요단·여리고 복습",
        "en": "Jordan·Jericho Review",
        "ja": "ヨルダン·エリコ 復習",
        "ms": "Yordan·Yerikho Ulang kaji",
        "th": "จอร์แดน·เยรีโค ทบทวน",
        "km": "យ័រដាន់·យេរីខូ រំលឹក"
      }
    },
    {
      "card_id": "CARD-JDG-001",
      "world_id": "W_OT_HIST",
      "card_type": "book",
      "asset_key": "asset.card.jdg-001",
      "title": {
        "ko": "이스르엘",
        "en": "Jezreel",
        "ja": "イズレエル",
        "ms": "Yizreel",
        "th": "ยิสเรเอล",
        "km": "យីសរេអែល"
      },
      "summary": {
        "ko": "이스르엘 골짜기 · 가나안 산지 여정에서 사사기 21장 본문 문제를 풉니다.",
        "en": "Follow Jezreel Valley · Canaan Highlands and answer Judges 21 chapters question bank.",
        "ja": "イズレエルの谷 · カナン山地の旅で、士師記21章の問題バンクに答えます。",
        "ms": "Ikuti Lembah Yizreel · Tanah tinggi Kanaan dan jawab bank soalan Hakim-hakim 21 bab.",
        "th": "ติดตามเส้นทางหุบเขายิสเรเอล · ที่ราบสูงคานาอันและตอบคลังคำถามจากผู้วินิจฉัย 21 บท",
        "km": "តាមដានដំណើរជ្រលងយីសរេអែល · តំបន់ភ្នំកាណាន ហើយឆ្លើយធនាគារសំណួរពីពួកចៅហ្វាយ 21 ជំពូក។"
      },
      "verse_reference": {
        "ko": "사사기 1-21",
        "en": "Judges 1-21",
        "ja": "士師記 1-21",
        "ms": "Hakim-hakim 1-21",
        "th": "ผู้วินิจฉัย 1-21",
        "km": "ពួកចៅហ្វាយ 1-21"
      },
      "verse_summary": {
        "ko": "이스르엘 복습",
        "en": "Jezreel Review",
        "ja": "イズレエル 復習",
        "ms": "Yizreel Ulang kaji",
        "th": "ยิสเรเอล ทบทวน",
        "km": "យីសរេអែល រំលឹក"
      }
    },
    {
      "card_id": "CARD-RUT-001",
      "world_id": "W_OT_HIST",
      "card_type": "book",
      "asset_key": "asset.card.rut-001",
      "title": {
        "ko": "모압·베들레헴",
        "en": "Moab·Bethlehem",
        "ja": "モアブ·ベツレヘム",
        "ms": "Moab·Betlehem",
        "th": "โมอับ·เบธเลเฮม",
        "km": "ម៉ូអាប់·បេថ្លេហិម"
      },
      "summary": {
        "ko": "모압 · 베들레헴 여정에서 룻기 4장 본문 문제를 풉니다.",
        "en": "Follow Moab · Bethlehem and answer Ruth 4 chapters question bank.",
        "ja": "モアブ · ベツレヘムの旅で、ルツ記4章の問題バンクに答えます。",
        "ms": "Ikuti Moab · Betlehem dan jawab bank soalan Rut 4 bab.",
        "th": "ติดตามเส้นทางโมอับ · เบธเลเฮมและตอบคลังคำถามจากรูธ 4 บท",
        "km": "តាមដានដំណើរម៉ូអាប់ · បេថ្លេហិម ហើយឆ្លើយធនាគារសំណួរពីនាងរស់ 4 ជំពូក។"
      },
      "verse_reference": {
        "ko": "룻기 1-4",
        "en": "Ruth 1-4",
        "ja": "ルツ記 1-4",
        "ms": "Rut 1-4",
        "th": "รูธ 1-4",
        "km": "នាងរស់ 1-4"
      },
      "verse_summary": {
        "ko": "모압·베들레헴 복습",
        "en": "Moab·Bethlehem Review",
        "ja": "モアブ·ベツレヘム 復習",
        "ms": "Moab·Betlehem Ulang kaji",
        "th": "โมอับ·เบธเลเฮม ทบทวน",
        "km": "ម៉ូអាប់·បេថ្លេហិម រំលឹក"
      }
    },
    {
      "card_id": "CARD-1SA-001",
      "world_id": "W_OT_HIST",
      "card_type": "book",
      "asset_key": "asset.card.1sa-001",
      "title": {
        "ko": "실로·엘라",
        "en": "Shiloh·Elah",
        "ja": "シロ·エラ",
        "ms": "Silo·Ela",
        "th": "ชิโลห์·เอลาห์",
        "km": "ស៊ីឡូ·អេឡា"
      },
      "summary": {
        "ko": "실로 · 엘라 골짜기 여정에서 사무엘상 31장 본문 문제를 풉니다.",
        "en": "Follow Shiloh · Valley of Elah and answer 1 Samuel 31 chapters question bank.",
        "ja": "シロ · エラの谷の旅で、サムエル記上31章の問題バンクに答えます。",
        "ms": "Ikuti Silo · Lembah Ela dan jawab bank soalan 1 Samuel 31 bab.",
        "th": "ติดตามเส้นทางชิโลห์ · หุบเขาเอลาห์และตอบคลังคำถามจาก1 ซามูเอล 31 บท",
        "km": "តាមដានដំណើរស៊ីឡូ · ជ្រលងអេឡា ហើយឆ្លើយធនាគារសំណួរពី១ សាំយូអែល 31 ជំពូក។"
      },
      "verse_reference": {
        "ko": "사무엘상 1-31",
        "en": "1 Samuel 1-31",
        "ja": "サムエル記上 1-31",
        "ms": "1 Samuel 1-31",
        "th": "1 ซามูเอล 1-31",
        "km": "១ សាំយូអែល 1-31"
      },
      "verse_summary": {
        "ko": "실로·엘라 복습",
        "en": "Shiloh·Elah Review",
        "ja": "シロ·エラ 復習",
        "ms": "Silo·Ela Ulang kaji",
        "th": "ชิโลห์·เอลาห์ ทบทวน",
        "km": "ស៊ីឡូ·អេឡា រំលឹក"
      }
    },
    {
      "card_id": "CARD-2SA-001",
      "world_id": "W_OT_HIST",
      "card_type": "book",
      "asset_key": "asset.card.2sa-001",
      "title": {
        "ko": "헤브론·예루살렘",
        "en": "Hebron·Jerusalem",
        "ja": "ヘブロン·エルサレム",
        "ms": "Hebron·Yerusalem",
        "th": "เฮប្រូន·เยรูซาเล็ม",
        "km": "ហេប្រូន·យេរូសាឡឹម"
      },
      "summary": {
        "ko": "헤브론 · 예루살렘 여정에서 사무엘하 24장 본문 문제를 풉니다.",
        "en": "Follow Hebron · Jerusalem and answer 2 Samuel 24 chapters question bank.",
        "ja": "ヘブロン · エルサレムの旅で、サムエル記下24章の問題バンクに答えます。",
        "ms": "Ikuti Hebron · Yerusalem dan jawab bank soalan 2 Samuel 24 bab.",
        "th": "ติดตามเส้นทางเฮប្រូន · เยรูซาเล็มและตอบคลังคำถามจาก2 ซามูเอล 24 บท",
        "km": "តាមដានដំណើរហេប្រូន · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពី២ សាំយូអែល 24 ជំពូក។"
      },
      "verse_reference": {
        "ko": "사무엘하 1-24",
        "en": "2 Samuel 1-24",
        "ja": "サムエル記下 1-24",
        "ms": "2 Samuel 1-24",
        "th": "2 ซามูเอล 1-24",
        "km": "២ សាំយូអែល 1-24"
      },
      "verse_summary": {
        "ko": "헤브론·예루살렘 복습",
        "en": "Hebron·Jerusalem Review",
        "ja": "ヘブロン·エルサレム 復習",
        "ms": "Hebron·Yerusalem Ulang kaji",
        "th": "เฮប្រូន·เยรูซาเล็ม ทบทวน",
        "km": "ហេប្រូន·យេរូសាឡឹម រំលឹក"
      }
    },
    {
      "card_id": "CARD-1KI-001",
      "world_id": "W_OT_HIST",
      "card_type": "book",
      "asset_key": "asset.card.1ki-001",
      "title": {
        "ko": "성전·갈멜산",
        "en": "Temple·Carmel",
        "ja": "神殿·カルメル",
        "ms": "Bait Suci·Karmel",
        "th": "พระวิหาร·คาร์เมล",
        "km": "ព្រះវិហារ·កាមែល"
      },
      "summary": {
        "ko": "예루살렘 성전 · 갈멜산 여정에서 열왕기상 22장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem Temple · Mount Carmel and answer 1 Kings 22 chapters question bank.",
        "ja": "エルサレム神殿 · カルメル山の旅で、列王記上22章の問題バンクに答えます。",
        "ms": "Ikuti Bait Suci Yerusalem · Gunung Karmel dan jawab bank soalan 1 Raja-raja 22 bab.",
        "th": "ติดตามเส้นทางพระวิหารเยรูซาเล็ม · ภูเขาคารเมลและตอบคลังคำถามจาก1 พงศ์กษัตริย์ 22 บท",
        "km": "តាមដានដំណើរព្រះវិហារយេរូសាឡឹម · ភ្នំកាមែល ហើយឆ្លើយធនាគារសំណួរពី១ ពង្សាវតារក្សត្រ 22 ជំពូក។"
      },
      "verse_reference": {
        "ko": "열왕기상 1-22",
        "en": "1 Kings 1-22",
        "ja": "列王記上 1-22",
        "ms": "1 Raja-raja 1-22",
        "th": "1 พงศ์กษัตริย์ 1-22",
        "km": "១ ពង្សាវតារក្សត្រ 1-22"
      },
      "verse_summary": {
        "ko": "성전·갈멜산 복습",
        "en": "Temple·Carmel Review",
        "ja": "神殿·カルメル 復習",
        "ms": "Bait Suci·Karmel Ulang kaji",
        "th": "พระวิหาร·คาร์เมล ทบทวน",
        "km": "ព្រះវិហារ·កាមែល រំលឹក"
      }
    },
    {
      "card_id": "CARD-2KI-001",
      "world_id": "W_OT_HIST",
      "card_type": "book",
      "asset_key": "asset.card.2ki-001",
      "title": {
        "ko": "사마리아·예루살렘",
        "en": "Samaria·Jerusalem",
        "ja": "サマリア·エルサレム",
        "ms": "Samaria·Yerusalem",
        "th": "สะมาเรีย·เยรูซาเล็ม",
        "km": "សាម៉ារី·យេរូសាឡឹម"
      },
      "summary": {
        "ko": "사마리아 · 예루살렘 여정에서 열왕기하 25장 본문 문제를 풉니다.",
        "en": "Follow Samaria · Jerusalem and answer 2 Kings 25 chapters question bank.",
        "ja": "サマリア · エルサレムの旅で、列王記下25章の問題バンクに答えます。",
        "ms": "Ikuti Samaria · Yerusalem dan jawab bank soalan 2 Raja-raja 25 bab.",
        "th": "ติดตามเส้นทางสะมาเรีย · เยรูซาเล็มและตอบคลังคำถามจาก2 พงศ์กษัตริย์ 25 บท",
        "km": "តាមដានដំណើរសាម៉ារី · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពី២ ពង្សាវតារក្សត្រ 25 ជំពូក។"
      },
      "verse_reference": {
        "ko": "열왕기하 1-25",
        "en": "2 Kings 1-25",
        "ja": "列王記下 1-25",
        "ms": "2 Raja-raja 1-25",
        "th": "2 พงศ์กษัตริย์ 1-25",
        "km": "២ ពង្សាវតារក្សត្រ 1-25"
      },
      "verse_summary": {
        "ko": "사마리아·예루살렘 복습",
        "en": "Samaria·Jerusalem Review",
        "ja": "サマリア·エルサレム 復習",
        "ms": "Samaria·Yerusalem Ulang kaji",
        "th": "สะมาเรีย·เยรูซาเล็ม ทบทวน",
        "km": "សាម៉ារី·យេរូសាឡឹម រំលឹក"
      }
    },
    {
      "card_id": "CARD-1CH-001",
      "world_id": "W_OT_HIST",
      "card_type": "book",
      "asset_key": "asset.card.1ch-001",
      "title": {
        "ko": "다윗 성",
        "en": "City of David",
        "ja": "ダビデの町",
        "ms": "Kota Daud",
        "th": "นครดาวิด",
        "km": "ទីក្រុងដាវីឌ"
      },
      "summary": {
        "ko": "예루살렘 다윗 성 여정에서 역대상 29장 본문 문제를 풉니다.",
        "en": "Follow City of David, Jerusalem and answer 1 Chronicles 29 chapters question bank.",
        "ja": "ダビデの町, エルサレムの旅で、歴代誌上29章の問題バンクに答えます。",
        "ms": "Ikuti Kota Daud, Yerusalem dan jawab bank soalan 1 Tawarikh 29 bab.",
        "th": "ติดตามเส้นทางนครดาวิด, เยรูซาเล็มและตอบคลังคำถามจาก1 พงศาวดาร 29 บท",
        "km": "តាមដានដំណើរទីក្រុងដាវីឌ, យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពី១ របាក្សត្រ 29 ជំពូក។"
      },
      "verse_reference": {
        "ko": "역대상 1-29",
        "en": "1 Chronicles 1-29",
        "ja": "歴代誌上 1-29",
        "ms": "1 Tawarikh 1-29",
        "th": "1 พงศาวดาร 1-29",
        "km": "១ របាក្សត្រ 1-29"
      },
      "verse_summary": {
        "ko": "다윗 성 복습",
        "en": "City of David Review",
        "ja": "ダビデの町 復習",
        "ms": "Kota Daud Ulang kaji",
        "th": "นครดาวิด ทบทวน",
        "km": "ទីក្រុងដាវីឌ រំលឹក"
      }
    },
    {
      "card_id": "CARD-2CH-001",
      "world_id": "W_OT_HIST",
      "card_type": "book",
      "asset_key": "asset.card.2ch-001",
      "title": {
        "ko": "예루살렘 성전",
        "en": "Jerusalem Temple",
        "ja": "エルサレム神殿",
        "ms": "Bait Suci Yerusalem",
        "th": "พระวิหารเยรูซาเล็ม",
        "km": "ព្រះវិហារយេរូសាឡឹម"
      },
      "summary": {
        "ko": "예루살렘 성전 여정에서 역대하 36장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem Temple and answer 2 Chronicles 36 chapters question bank.",
        "ja": "エルサレム神殿の旅で、歴代誌下36章の問題バンクに答えます。",
        "ms": "Ikuti Bait Suci Yerusalem dan jawab bank soalan 2 Tawarikh 36 bab.",
        "th": "ติดตามเส้นทางพระวิหารเยรูซาเล็มและตอบคลังคำถามจาก2 พงศาวดาร 36 บท",
        "km": "តាមដានដំណើរព្រះវិហារយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពី២ របាក្សត្រ 36 ជំពូក។"
      },
      "verse_reference": {
        "ko": "역대하 1-36",
        "en": "2 Chronicles 1-36",
        "ja": "歴代誌下 1-36",
        "ms": "2 Tawarikh 1-36",
        "th": "2 พงศาวดาร 1-36",
        "km": "២ របាក្សត្រ 1-36"
      },
      "verse_summary": {
        "ko": "예루살렘 성전 복습",
        "en": "Jerusalem Temple Review",
        "ja": "エルサレム神殿 復習",
        "ms": "Bait Suci Yerusalem Ulang kaji",
        "th": "พระวิหารเยรูซาเล็ม ทบทวน",
        "km": "ព្រះវិហារយេរូសាឡឹម រំលឹក"
      }
    },
    {
      "card_id": "CARD-EZR-001",
      "world_id": "W_OT_HIST",
      "card_type": "book",
      "asset_key": "asset.card.ezr-001",
      "title": {
        "ko": "바벨론·예루살렘",
        "en": "Babylon·Jerusalem",
        "ja": "バビロン·エルサレム",
        "ms": "Babilon·Yerusalem",
        "th": "บาบิโลน·เยรูซาเล็ม",
        "km": "បាប៊ីឡូន·យេរូសាឡឹម"
      },
      "summary": {
        "ko": "바벨론 · 예루살렘 여정에서 에스라 10장 본문 문제를 풉니다.",
        "en": "Follow Babylon · Jerusalem and answer Ezra 10 chapters question bank.",
        "ja": "バビロン · エルサレムの旅で、エズラ記10章の問題バンクに答えます。",
        "ms": "Ikuti Babilon · Yerusalem dan jawab bank soalan Ezra 10 bab.",
        "th": "ติดตามเส้นทางบาบิโลน · เยรูซาเล็มและตอบคลังคำถามจากเอสรา 10 บท",
        "km": "តាមដានដំណើរបាប៊ីឡូន · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីអែសរ៉ា 10 ជំពូក។"
      },
      "verse_reference": {
        "ko": "에스라 1-10",
        "en": "Ezra 1-10",
        "ja": "エズラ記 1-10",
        "ms": "Ezra 1-10",
        "th": "เอสรา 1-10",
        "km": "អែសរ៉ា 1-10"
      },
      "verse_summary": {
        "ko": "바벨론·예루살렘 복습",
        "en": "Babylon·Jerusalem Review",
        "ja": "バビロン·エルサレム 復習",
        "ms": "Babilon·Yerusalem Ulang kaji",
        "th": "บาบิโลน·เยรูซาเล็ม ทบทวน",
        "km": "បាប៊ីឡូន·យេរូសាឡឹម រំលឹក"
      }
    },
    {
      "card_id": "CARD-NEH-001",
      "world_id": "W_OT_HIST",
      "card_type": "book",
      "asset_key": "asset.card.neh-001",
      "title": {
        "ko": "수산·성벽",
        "en": "Susa·Walls",
        "ja": "スサ·城壁",
        "ms": "Susan·Tembok",
        "th": "สุสา·กำแพง",
        "km": "ស៊ូសា·កំពែង"
      },
      "summary": {
        "ko": "수산궁 · 예루살렘 성벽 여정에서 느헤미야 13장 본문 문제를 풉니다.",
        "en": "Follow Susa Palace · Jerusalem Walls and answer Nehemiah 13 chapters question bank.",
        "ja": "スサ宮殿 · エルサレム城壁の旅で、ネヘミヤ記13章の問題バンクに答えます。",
        "ms": "Ikuti Istana Susann · Tembok Yerusalem dan jawab bank soalan Nehemia 13 bab.",
        "th": "ติดตามเส้นทางพระราชวังสุสา · กำแพงเยรูซาเล็มและตอบคลังคำถามจากเนหะมีย์ 13 บท",
        "km": "តាមដានដំណើររាជវាំងស៊ូសា · កំពែងយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីនេហេមា 13 ជំពូក។"
      },
      "verse_reference": {
        "ko": "느헤미야 1-13",
        "en": "Nehemiah 1-13",
        "ja": "ネヘミヤ記 1-13",
        "ms": "Nehemia 1-13",
        "th": "เนหะมีย์ 1-13",
        "km": "នេហេមា 1-13"
      },
      "verse_summary": {
        "ko": "수산·성벽 복습",
        "en": "Susa·Walls Review",
        "ja": "スサ·城壁 復習",
        "ms": "Susan·Tembok Ulang kaji",
        "th": "สุสา·กำแพง ทบทวน",
        "km": "ស៊ូសា·កំពែង រំលឹក"
      }
    },
    {
      "card_id": "CARD-EST-001",
      "world_id": "W_OT_HIST",
      "card_type": "book",
      "asset_key": "asset.card.est-001",
      "title": {
        "ko": "수산",
        "en": "Susa",
        "ja": "スサ",
        "ms": "Susan",
        "th": "สุสา",
        "km": "ស៊ូសា"
      },
      "summary": {
        "ko": "수산궁 여정에서 에스더 10장 본문 문제를 풉니다.",
        "en": "Follow Susa Palace and answer Esther 10 chapters question bank.",
        "ja": "スサ宮殿の旅で、エステル記10章の問題バンクに答えます。",
        "ms": "Ikuti Istana Susan dan jawab bank soalan Ester 10 bab.",
        "th": "ติดตามเส้นทางพระราชวังสุสาและตอบคลังคำถามจากเอสเธอร์ 10 บท",
        "km": "តាមដានដំណើររាជវាំងស៊ូសា ហើយឆ្លើយធនាគារសំណួរពីអេសធើរ 10 ជំពូក។"
      },
      "verse_reference": {
        "ko": "에스더 1-10",
        "en": "Esther 1-10",
        "ja": "エステル記 1-10",
        "ms": "Ester 1-10",
        "th": "เอสเธอร์ 1-10",
        "km": "អេសធើរ 1-10"
      },
      "verse_summary": {
        "ko": "수산 복습",
        "en": "Susa Review",
        "ja": "スサ 復習",
        "ms": "Susan Ulang kaji",
        "th": "สุสา ทบทวน",
        "km": "ស៊ូសា រំលឹក"
      }
    },
    {
      "card_id": "CARD-JOS-REVIEW-13",
      "world_id": "W_OT_HIST",
      "card_type": "review",
      "asset_key": "asset.card.jos-review-13",
      "title": {
        "ko": "요단·여리고+",
        "en": "Jordan·Jericho+",
        "ja": "ヨルダン·エリコ+",
        "ms": "Yordan·Yerikho+",
        "th": "จอร์แดน·เยรีโค+",
        "km": "យ័រដាន់·យេរីខូ+"
      },
      "summary": {
        "ko": "요단강 · 여리고 길에서 여호수아 주요 사건을 다시 확인합니다.",
        "en": "Review the main Joshua events along Jordan River · Jericho.",
        "ja": "ヨルダン川 · エリコの道で、ヨシュア記の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Yosua di sepanjang Sungai Yordan · Yerikho.",
        "th": "ทบทวนเหตุการณ์สำคัญของโยชูวาตามเส้นทางแม่น้ำจอร์แดน · เยรีโค",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃយ៉ូស្វេ តាមផ្លូវទន្លេយ័រដាន់ · យេរីខូ។"
      },
      "verse_reference": {
        "ko": "여호수아 1-24",
        "en": "Joshua 1-24",
        "ja": "ヨシュア記 1-24",
        "ms": "Yosua 1-24",
        "th": "โยชูวา 1-24",
        "km": "យ៉ូស្វេ 1-24"
      },
      "verse_summary": {
        "ko": "요단·여리고+ 복습",
        "en": "Jordan·Jericho+ Review",
        "ja": "ヨルダン·エリコ+ 復習",
        "ms": "Yordan·Yerikho+ Ulang kaji",
        "th": "จอร์แดน·เยรีโค+ ทบทวน",
        "km": "យ័រដាន់·យេរីខូ+ រំលឹក"
      }
    },
    {
      "card_id": "CARD-JDG-REVIEW-14",
      "world_id": "W_OT_HIST",
      "card_type": "review",
      "asset_key": "asset.card.jdg-review-14",
      "title": {
        "ko": "이스르엘+",
        "en": "Jezreel+",
        "ja": "イズレエル+",
        "ms": "Yizreel+",
        "th": "ยิสเรเอล+",
        "km": "យីសរេអែល+"
      },
      "summary": {
        "ko": "이스르엘 골짜기 · 가나안 산지 길에서 사사기 주요 사건을 다시 확인합니다.",
        "en": "Review the main Judges events along Jezreel Valley · Canaan Highlands.",
        "ja": "イズレエルの谷 · カナン山地の道で、士師記の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Hakim-hakim di sepanjang Lembah Yizreel · Tanah tinggi Kanaan.",
        "th": "ทบทวนเหตุการณ์สำคัญของผู้วินิจฉัยตามเส้นทางหุบเขายิสเรเอล · ที่ราบสูงคานาอัน",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃពួកចៅហ្វាយ តាមផ្លូវជ្រលងយីសរេអែល · តំបន់ភ្នំកាណាន។"
      },
      "verse_reference": {
        "ko": "사사기 1-21",
        "en": "Judges 1-21",
        "ja": "士師記 1-21",
        "ms": "Hakim-hakim 1-21",
        "th": "ผู้วินิจฉัย 1-21",
        "km": "ពួកចៅហ្វាយ 1-21"
      },
      "verse_summary": {
        "ko": "이스르엘+ 복습",
        "en": "Jezreel+ Review",
        "ja": "イズレエル+ 復習",
        "ms": "Yizreel+ Ulang kaji",
        "th": "ยิสเรเอล+ ทบทวน",
        "km": "យីសរេអែល+ រំលឹក"
      }
    },
    {
      "card_id": "CARD-RUT-REVIEW-15",
      "world_id": "W_OT_HIST",
      "card_type": "review",
      "asset_key": "asset.card.rut-review-15",
      "title": {
        "ko": "모압·베들레헴+",
        "en": "Moab·Bethlehem+",
        "ja": "モアブ·ベツレヘム+",
        "ms": "Moab·Betlehem+",
        "th": "โมอับ·เบธเลเฮม+",
        "km": "ម៉ូអាប់·បេថ្លេហិម+"
      },
      "summary": {
        "ko": "모압 · 베들레헴 길에서 룻기 주요 사건을 다시 확인합니다.",
        "en": "Review the main Ruth events along Moab · Bethlehem.",
        "ja": "モアブ · ベツレヘムの道で、ルツ記の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Rut di sepanjang Moab · Betlehem.",
        "th": "ทบทวนเหตุการณ์สำคัญของรูธตามเส้นทางโมอับ · เบธเลเฮม",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃនាងរស់ តាមផ្លូវម៉ូអាប់ · បេថ្លេហិម។"
      },
      "verse_reference": {
        "ko": "룻기 1-4",
        "en": "Ruth 1-4",
        "ja": "ルツ記 1-4",
        "ms": "Rut 1-4",
        "th": "รูธ 1-4",
        "km": "នាងរស់ 1-4"
      },
      "verse_summary": {
        "ko": "모압·베들레헴+ 복습",
        "en": "Moab·Bethlehem+ Review",
        "ja": "モアブ·ベツレヘム+ 復習",
        "ms": "Moab·Betlehem+ Ulang kaji",
        "th": "โมอับ·เบธเลเฮม+ ทบทวน",
        "km": "ម៉ូអាប់·បេថ្លេហិម+ រំលឹក"
      }
    },
    {
      "card_id": "CARD-JOB-001",
      "world_id": "W_OT_WIS",
      "card_type": "book",
      "asset_key": "asset.card.job-001",
      "title": {
        "ko": "우스",
        "en": "Uz",
        "ja": "ウツ",
        "ms": "Us",
        "th": "อูส",
        "km": "អ៊ូស"
      },
      "summary": {
        "ko": "우스 땅 여정에서 욥기 42장 본문 문제를 풉니다.",
        "en": "Follow Land of Uz and answer Job 42 chapters question bank.",
        "ja": "ウツの地の旅で、ヨブ記42章の問題バンクに答えます。",
        "ms": "Ikuti Tanah Us dan jawab bank soalan Ayub 42 bab.",
        "th": "ติดตามเส้นทางแผ่นดินอูสและตอบคลังคำถามจากโยบ 42 บท",
        "km": "តាមដានដំណើរស្រុកអ៊ូស ហើយឆ្លើយធនាគារសំណួរពីយ៉ូប 42 ជំពូក។"
      },
      "verse_reference": {
        "ko": "욥기 1-42",
        "en": "Job 1-42",
        "ja": "ヨブ記 1-42",
        "ms": "Ayub 1-42",
        "th": "โยบ 1-42",
        "km": "យ៉ូប 1-42"
      },
      "verse_summary": {
        "ko": "우스 복습",
        "en": "Uz Review",
        "ja": "ウツ 復習",
        "ms": "Us Ulang kaji",
        "th": "อูส ทบทวน",
        "km": "អ៊ូស រំលឹក"
      }
    },
    {
      "card_id": "CARD-PSA-001",
      "world_id": "W_OT_WIS",
      "card_type": "book",
      "asset_key": "asset.card.psa-001",
      "title": {
        "ko": "시온",
        "en": "Zion",
        "ja": "シオン",
        "ms": "Sion",
        "th": "ศิโยน",
        "km": "ស៊ីយ៉ូន"
      },
      "summary": {
        "ko": "시온 · 예루살렘 여정에서 시편 150장 본문 문제를 풉니다.",
        "en": "Follow Zion · Jerusalem and answer Psalms 150 chapters question bank.",
        "ja": "シオン · エルサレムの旅で、詩篇150章の問題バンクに答えます。",
        "ms": "Ikuti Sion · Yerusalem dan jawab bank soalan Mazmur 150 bab.",
        "th": "ติดตามเส้นทางศิโยน · เยรูซาเล็มและตอบคลังคำถามจากสดุดี 150 บท",
        "km": "តាមដានដំណើរស៊ីយ៉ូន · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីទំនុកតម្កើង 150 ជំពូក។"
      },
      "verse_reference": {
        "ko": "시편 1-150",
        "en": "Psalms 1-150",
        "ja": "詩篇 1-150",
        "ms": "Mazmur 1-150",
        "th": "สดุดี 1-150",
        "km": "ទំនុកតម្កើង 1-150"
      },
      "verse_summary": {
        "ko": "시온 복습",
        "en": "Zion Review",
        "ja": "シオン 復習",
        "ms": "Sion Ulang kaji",
        "th": "ศิโยน ทบทวน",
        "km": "ស៊ីយ៉ូន រំលឹក"
      }
    },
    {
      "card_id": "CARD-PRO-001",
      "world_id": "W_OT_WIS",
      "card_type": "book",
      "asset_key": "asset.card.pro-001",
      "title": {
        "ko": "예루살렘",
        "en": "Jerusalem",
        "ja": "エルサレム",
        "ms": "Yerusalem",
        "th": "เยรูซาเล็ม",
        "km": "យេរូសាឡឹម"
      },
      "summary": {
        "ko": "예루살렘 왕궁 여정에서 잠언 31장 본문 문제를 풉니다.",
        "en": "Follow Royal Court of Jerusalem and answer Proverbs 31 chapters question bank.",
        "ja": "エルサレム王宮の旅で、箴言31章の問題バンクに答えます。",
        "ms": "Ikuti Istana Diraja Yerusalem dan jawab bank soalan Amsal 31 bab.",
        "th": "ติดตามเส้นทางราชสำนักเยรูซาเล็มและตอบคลังคำถามจากสุภาษิต 31 บท",
        "km": "តាមដានដំណើររាជវាំងយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីសុភាសិត 31 ជំពូក។"
      },
      "verse_reference": {
        "ko": "잠언 1-31",
        "en": "Proverbs 1-31",
        "ja": "箴言 1-31",
        "ms": "Amsal 1-31",
        "th": "สุภาษิต 1-31",
        "km": "សុភាសិត 1-31"
      },
      "verse_summary": {
        "ko": "예루살렘 복습",
        "en": "Jerusalem Review",
        "ja": "エルサレム 復習",
        "ms": "Yerusalem Ulang kaji",
        "th": "เยรูซาเล็ม ทบทวน",
        "km": "យេរូសាឡឹម រំលឹក"
      }
    },
    {
      "card_id": "CARD-ECC-001",
      "world_id": "W_OT_WIS",
      "card_type": "book",
      "asset_key": "asset.card.ecc-001",
      "title": {
        "ko": "예루살렘",
        "en": "Jerusalem",
        "ja": "エルサレム",
        "ms": "Yerusalem",
        "th": "เยรูซาเล็ม",
        "km": "យេរូសាឡឹម"
      },
      "summary": {
        "ko": "예루살렘 집회 여정에서 전도서 12장 본문 문제를 풉니다.",
        "en": "Follow Assembly in Jerusalem and answer Ecclesiastes 12 chapters question bank.",
        "ja": "エルサレムの集会の旅で、伝道者の書12章の問題バンクに答えます。",
        "ms": "Ikuti Perhimpunan di Yerusalem dan jawab bank soalan Pengkhotbah 12 bab.",
        "th": "ติดตามเส้นทางที่ชุมนุมในเยรูซาเล็มและตอบคลังคำถามจากปัญญาจารย์ 12 บท",
        "km": "តាមដានដំណើរការជួបជុំនៅយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីសាស្ដា 12 ជំពូក។"
      },
      "verse_reference": {
        "ko": "전도서 1-12",
        "en": "Ecclesiastes 1-12",
        "ja": "伝道者の書 1-12",
        "ms": "Pengkhotbah 1-12",
        "th": "ปัญญาจารย์ 1-12",
        "km": "សាស្ដា 1-12"
      },
      "verse_summary": {
        "ko": "예루살렘 복습",
        "en": "Jerusalem Review",
        "ja": "エルサレム 復習",
        "ms": "Yerusalem Ulang kaji",
        "th": "เยรูซาเล็ม ทบทวน",
        "km": "យេរូសាឡឹម រំលឹក"
      }
    },
    {
      "card_id": "CARD-SNG-001",
      "world_id": "W_OT_WIS",
      "card_type": "book",
      "asset_key": "asset.card.sng-001",
      "title": {
        "ko": "예루살렘·레바논",
        "en": "Jerusalem·Lebanon",
        "ja": "エルサレム·レバノン",
        "ms": "Yerusalem·Lebanon",
        "th": "เยรูซาเล็ม·เลบานอน",
        "km": "យេរូសាឡឹម·លីបង់"
      },
      "summary": {
        "ko": "예루살렘 · 레바논 여정에서 아가 8장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem · Lebanon and answer Song of Songs 8 chapters question bank.",
        "ja": "エルサレム · レバノンの旅で、雅歌8章の問題バンクに答えます。",
        "ms": "Ikuti Yerusalem · Lebanon dan jawab bank soalan Kidung Agung 8 bab.",
        "th": "ติดตามเส้นทางเยรูซาเล็ม · เลบานอนและตอบคลังคำถามจากเพลงซาโลมอน 8 บท",
        "km": "តាមដានដំណើរយេរូសាឡឹម · លីបង់ ហើយឆ្លើយធនាគារសំណួរពីបទចម្រៀងសាឡូម៉ូន 8 ជំពូក។"
      },
      "verse_reference": {
        "ko": "아가 1-8",
        "en": "Song of Songs 1-8",
        "ja": "雅歌 1-8",
        "ms": "Kidung Agung 1-8",
        "th": "เพลงซาโลมอน 1-8",
        "km": "បទចម្រៀងសាឡូម៉ូន 1-8"
      },
      "verse_summary": {
        "ko": "예루살렘·레바논 복습",
        "en": "Jerusalem·Lebanon Review",
        "ja": "エルサレム·レバノン 復習",
        "ms": "Yerusalem·Lebanon Ulang kaji",
        "th": "เยรูซาเล็ม·เลบานอน ทบทวน",
        "km": "យេរូសាឡឹម·លីបង់ រំលឹក"
      }
    },
    {
      "card_id": "CARD-ISA-001",
      "world_id": "W_OT_MAJOR",
      "card_type": "book",
      "asset_key": "asset.card.isa-001",
      "title": {
        "ko": "시온",
        "en": "Zion",
        "ja": "シオン",
        "ms": "Sion",
        "th": "ศิโยน",
        "km": "ស៊ីយ៉ូន"
      },
      "summary": {
        "ko": "시온 · 예루살렘 여정에서 이사야 66장 본문 문제를 풉니다.",
        "en": "Follow Zion · Jerusalem and answer Isaiah 66 chapters question bank.",
        "ja": "シオン · エルサレムの旅で、イザヤ書66章の問題バンクに答えます。",
        "ms": "Ikuti Sion · Yerusalem dan jawab bank soalan Yesaya 66 bab.",
        "th": "ติดตามเส้นทางศิโยน · เยรูซาเล็มและตอบคลังคำถามจากอิสยาห์ 66 บท",
        "km": "តាមដានដំណើរស៊ីយ៉ូន · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីអេសាយ 66 ជំពូក។"
      },
      "verse_reference": {
        "ko": "이사야 1-66",
        "en": "Isaiah 1-66",
        "ja": "イザヤ書 1-66",
        "ms": "Yesaya 1-66",
        "th": "อิสยาห์ 1-66",
        "km": "អេសាយ 1-66"
      },
      "verse_summary": {
        "ko": "시온 복습",
        "en": "Zion Review",
        "ja": "シオン 復習",
        "ms": "Sion Ulang kaji",
        "th": "ศิโยน ทบทวน",
        "km": "ស៊ីយ៉ូន រំលឹក"
      }
    },
    {
      "card_id": "CARD-JER-001",
      "world_id": "W_OT_MAJOR",
      "card_type": "book",
      "asset_key": "asset.card.jer-001",
      "title": {
        "ko": "아나돗·예루살렘",
        "en": "Anathoth·Jerusalem",
        "ja": "アナトテ·エルサレム",
        "ms": "Anatot·Yerusalem",
        "th": "อานาโธท·เยรูซาเล็ม",
        "km": "អាណាថោត·យេរូសាឡឹម"
      },
      "summary": {
        "ko": "아나돗 · 예루살렘 여정에서 예레미야 52장 본문 문제를 풉니다.",
        "en": "Follow Anathoth · Jerusalem and answer Jeremiah 52 chapters question bank.",
        "ja": "アナトテ · エルサレムの旅で、エレミヤ書52章の問題バンクに答えます。",
        "ms": "Ikuti Anatot · Yerusalem dan jawab bank soalan Yeremia 52 bab.",
        "th": "ติดตามเส้นทางอานาโธท · เยรูซาเล็มและตอบคลังคำถามจากเยเรมีย์ 52 บท",
        "km": "តាមដានដំណើរអាណាថោត · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីយេរេមា 52 ជំពូក។"
      },
      "verse_reference": {
        "ko": "예레미야 1-52",
        "en": "Jeremiah 1-52",
        "ja": "エレミヤ書 1-52",
        "ms": "Yeremia 1-52",
        "th": "เยเรมีย์ 1-52",
        "km": "យេរេមា 1-52"
      },
      "verse_summary": {
        "ko": "아나돗·예루살렘 복습",
        "en": "Anathoth·Jerusalem Review",
        "ja": "アナトテ·エルサレム 復習",
        "ms": "Anatot·Yerusalem Ulang kaji",
        "th": "อานาโธท·เยรูซาเล็ม ทบทวน",
        "km": "អាណាថោត·យេរូសាឡឹម រំលឹក"
      }
    },
    {
      "card_id": "CARD-LAM-001",
      "world_id": "W_OT_MAJOR",
      "card_type": "book",
      "asset_key": "asset.card.lam-001",
      "title": {
        "ko": "예루살렘 폐허",
        "en": "Jerusalem Ruins",
        "ja": "エルサレムの廃虚",
        "ms": "Reruntuhan Yerusalem",
        "th": "ซากกรุงเยรูซาเล็ม",
        "km": "គំនរបាក់បែកយេរូសាឡឹម"
      },
      "summary": {
        "ko": "예루살렘 폐허 여정에서 예레미야애가 5장 본문 문제를 풉니다.",
        "en": "Follow Ruins of Jerusalem and answer Lamentations 5 chapters question bank.",
        "ja": "エルサレムの廃虚の旅で、哀歌5章の問題バンクに答えます。",
        "ms": "Ikuti Reruntuhan Yerusalem dan jawab bank soalan Ratapan 5 bab.",
        "th": "ติดตามเส้นทางซากกรุงเยรูซาเล็มและตอบคลังคำถามจากเพลงคร่ำครวญ 5 บท",
        "km": "តាមដានដំណើរគំនរបាក់បែកយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីបរិទេវ 5 ជំពូក។"
      },
      "verse_reference": {
        "ko": "예레미야애가 1-5",
        "en": "Lamentations 1-5",
        "ja": "哀歌 1-5",
        "ms": "Ratapan 1-5",
        "th": "เพลงคร่ำครวญ 1-5",
        "km": "បរិទេវ 1-5"
      },
      "verse_summary": {
        "ko": "예루살렘 폐허 복습",
        "en": "Jerusalem Ruins Review",
        "ja": "エルサレムの廃虚 復習",
        "ms": "Reruntuhan Yerusalem Ulang kaji",
        "th": "ซากกรุงเยรูซาเล็ม ทบทวน",
        "km": "គំនរបាក់បែកយេរូសាឡឹម រំលឹក"
      }
    },
    {
      "card_id": "CARD-EZK-001",
      "world_id": "W_OT_MAJOR",
      "card_type": "book",
      "asset_key": "asset.card.ezk-001",
      "title": {
        "ko": "그발·바벨론",
        "en": "Chebar·Babylon",
        "ja": "ケバル·バビロン",
        "ms": "Kebar·Babilon",
        "th": "เคบาร์·บาบิโลน",
        "km": "ខេបារ·បាប៊ីឡូន"
      },
      "summary": {
        "ko": "그발 강가 · 바벨론 여정에서 에스겔 48장 본문 문제를 풉니다.",
        "en": "Follow Chebar Canal · Babylon and answer Ezekiel 48 chapters question bank.",
        "ja": "ケバル川 · バビロンの旅で、エゼキエル書48章の問題バンクに答えます。",
        "ms": "Ikuti Terusan Kebar · Babilon dan jawab bank soalan Yehezkiel 48 bab.",
        "th": "ติดตามเส้นทางคลองเคบาร์ · บาบิโลนและตอบคลังคำถามจากเอเสเคียล 48 บท",
        "km": "តាមដានដំណើរប្រឡាយខេបារ · បាប៊ីឡូន ហើយឆ្លើយធនាគារសំណួរពីអេសេគាល 48 ជំពូក។"
      },
      "verse_reference": {
        "ko": "에스겔 1-48",
        "en": "Ezekiel 1-48",
        "ja": "エゼキエル書 1-48",
        "ms": "Yehezkiel 1-48",
        "th": "เอเสเคียล 1-48",
        "km": "អេសេគាល 1-48"
      },
      "verse_summary": {
        "ko": "그발·바벨론 복습",
        "en": "Chebar·Babylon Review",
        "ja": "ケバル·バビロン 復習",
        "ms": "Kebar·Babilon Ulang kaji",
        "th": "เคบาร์·บาบิโลน ทบทวน",
        "km": "ខេបារ·បាប៊ីឡូន រំលឹក"
      }
    },
    {
      "card_id": "CARD-DAN-001",
      "world_id": "W_OT_MAJOR",
      "card_type": "book",
      "asset_key": "asset.card.dan-001",
      "title": {
        "ko": "바벨론·수산",
        "en": "Babylon·Susa",
        "ja": "バビロン·スサ",
        "ms": "Babilon·Susan",
        "th": "บาบิโลน·สุสา",
        "km": "បាប៊ីឡូន·ស៊ូសា"
      },
      "summary": {
        "ko": "바벨론 · 수산 여정에서 다니엘 12장 본문 문제를 풉니다.",
        "en": "Follow Babylon · Susa and answer Daniel 12 chapters question bank.",
        "ja": "バビロン · スサの旅で、ダニエル書12章の問題バンクに答えます。",
        "ms": "Ikuti Babilon · Susan dan jawab bank soalan Daniel 12 bab.",
        "th": "ติดตามเส้นทางบาบิโลน · สุสาและตอบคลังคำถามจากดาเนียล 12 บท",
        "km": "តាមដានដំណើរបាប៊ីឡូន · ស៊ូសា ហើយឆ្លើយធនាគារសំណួរពីដានីយ៉ែល 12 ជំពូក។"
      },
      "verse_reference": {
        "ko": "다니엘 1-12",
        "en": "Daniel 1-12",
        "ja": "ダニエル書 1-12",
        "ms": "Daniel 1-12",
        "th": "ดาเนียล 1-12",
        "km": "ដានីយ៉ែល 1-12"
      },
      "verse_summary": {
        "ko": "바벨론·수산 복습",
        "en": "Babylon·Susa Review",
        "ja": "バビロン·スサ 復習",
        "ms": "Babilon·Susan Ulang kaji",
        "th": "บาบิโลน·สุสา ทบทวน",
        "km": "បាប៊ីឡូន·ស៊ូសា រំលឹក"
      }
    },
    {
      "card_id": "CARD-HOS-001",
      "world_id": "W_OT_MINOR",
      "card_type": "book",
      "asset_key": "asset.card.hos-001",
      "title": {
        "ko": "사마리아·이스르엘",
        "en": "Samaria·Jezreel",
        "ja": "サマリア·イズレエル",
        "ms": "Samaria·Yizreel",
        "th": "สะมาเรีย·ยิสเรเอล",
        "km": "សាម៉ារី·យីសរេអែល"
      },
      "summary": {
        "ko": "사마리아 · 이스르엘 여정에서 호세아 14장 본문 문제를 풉니다.",
        "en": "Follow Samaria · Jezreel and answer Hosea 14 chapters question bank.",
        "ja": "サマリア · イズレエルの旅で、ホセア書14章の問題バンクに答えます。",
        "ms": "Ikuti Samaria · Yizreel dan jawab bank soalan Hosea 14 bab.",
        "th": "ติดตามเส้นทางสะมาเรีย · ยิสเรเอลและตอบคลังคำถามจากโฮเชยา 14 บท",
        "km": "តាមដានដំណើរសាម៉ារី · យីសរេអែល ហើយឆ្លើយធនាគារសំណួរពីហូសេ 14 ជំពូក។"
      },
      "verse_reference": {
        "ko": "호세아 1-14",
        "en": "Hosea 1-14",
        "ja": "ホセア書 1-14",
        "ms": "Hosea 1-14",
        "th": "โฮเชยา 1-14",
        "km": "ហូសេ 1-14"
      },
      "verse_summary": {
        "ko": "사마리아·이스르엘 복습",
        "en": "Samaria·Jezreel Review",
        "ja": "サマリア·イズレエル 復習",
        "ms": "Samaria·Yizreel Ulang kaji",
        "th": "สะมาเรีย·ยิสเรเอล ทบทวน",
        "km": "សាម៉ារី·យីសរេអែល រំលឹក"
      }
    },
    {
      "card_id": "CARD-JOL-001",
      "world_id": "W_OT_MINOR",
      "card_type": "book",
      "asset_key": "asset.card.jol-001",
      "title": {
        "ko": "시온",
        "en": "Zion",
        "ja": "シオン",
        "ms": "Sion",
        "th": "ศิโยน",
        "km": "ស៊ីយ៉ូន"
      },
      "summary": {
        "ko": "시온 · 예루살렘 여정에서 요엘 3장 본문 문제를 풉니다.",
        "en": "Follow Zion · Jerusalem and answer Joel 3 chapters question bank.",
        "ja": "シオン · エルサレムの旅で、ヨエル書3章の問題バンクに答えます。",
        "ms": "Ikuti Sion · Yerusalem dan jawab bank soalan Yoel 3 bab.",
        "th": "ติดตามเส้นทางศิโยน · เยรูซาเล็มและตอบคลังคำถามจากโยเอล 3 บท",
        "km": "តាមដានដំណើរស៊ីយ៉ូន · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីយ៉ូអែល 3 ជំពូក។"
      },
      "verse_reference": {
        "ko": "요엘 1-3",
        "en": "Joel 1-3",
        "ja": "ヨエル書 1-3",
        "ms": "Yoel 1-3",
        "th": "โยเอล 1-3",
        "km": "យ៉ូអែល 1-3"
      },
      "verse_summary": {
        "ko": "시온 복습",
        "en": "Zion Review",
        "ja": "シオン 復習",
        "ms": "Sion Ulang kaji",
        "th": "ศิโยน ทบทวน",
        "km": "ស៊ីយ៉ូន រំលឹក"
      }
    },
    {
      "card_id": "CARD-AMO-001",
      "world_id": "W_OT_MINOR",
      "card_type": "book",
      "asset_key": "asset.card.amo-001",
      "title": {
        "ko": "드고아·벧엘",
        "en": "Tekoa·Bethel",
        "ja": "テコア·ベテル",
        "ms": "Tekoa·Betel",
        "th": "เทโคอา·เบธเอล",
        "km": "តេកូអា·បេតអែល"
      },
      "summary": {
        "ko": "드고아 · 벧엘 여정에서 아모스 9장 본문 문제를 풉니다.",
        "en": "Follow Tekoa · Bethel and answer Amos 9 chapters question bank.",
        "ja": "テコア · ベテルの旅で、アモス書9章の問題バンクに答えます。",
        "ms": "Ikuti Tekoa · Betel dan jawab bank soalan Amos 9 bab.",
        "th": "ติดตามเส้นทางเทโคอา · เบธเอลและตอบคลังคำถามจากอาโมส 9 บท",
        "km": "តាមដានដំណើរតេកូអា · បេតអែល ហើយឆ្លើយធនាគារសំណួរពីអាម៉ុស 9 ជំពូក។"
      },
      "verse_reference": {
        "ko": "아모스 1-9",
        "en": "Amos 1-9",
        "ja": "アモス書 1-9",
        "ms": "Amos 1-9",
        "th": "อาโมส 1-9",
        "km": "អាម៉ុស 1-9"
      },
      "verse_summary": {
        "ko": "드고아·벧엘 복습",
        "en": "Tekoa·Bethel Review",
        "ja": "テコア·ベテル 復習",
        "ms": "Tekoa·Betel Ulang kaji",
        "th": "เทโคอา·เบธเอล ทบทวน",
        "km": "តេកូអា·បេតអែល រំលឹក"
      }
    },
    {
      "card_id": "CARD-OBA-001",
      "world_id": "W_OT_MINOR",
      "card_type": "book",
      "asset_key": "asset.card.oba-001",
      "title": {
        "ko": "에돔",
        "en": "Edom",
        "ja": "エドム",
        "ms": "Edom",
        "th": "เอโดม",
        "km": "អេដុម"
      },
      "summary": {
        "ko": "에돔 산지 여정에서 오바댜 1장 본문 문제를 풉니다.",
        "en": "Follow Mountains of Edom and answer Obadiah 1 chapters question bank.",
        "ja": "エドム山地の旅で、オバデヤ書1章の問題バンクに答えます。",
        "ms": "Ikuti Pergunungan Edom dan jawab bank soalan Obaja 1 bab.",
        "th": "ติดตามเส้นทางภูเขาเอโดมและตอบคลังคำถามจากโอบาดีห์ 1 บท",
        "km": "តាមដានដំណើរតំបន់ភ្នំអេដុម ហើយឆ្លើយធនាគារសំណួរពីអូបាឌា 1 ជំពូក។"
      },
      "verse_reference": {
        "ko": "오바댜 1",
        "en": "Obadiah 1",
        "ja": "オバデヤ書 1",
        "ms": "Obaja 1",
        "th": "โอบาดีห์ 1",
        "km": "អូបាឌា 1"
      },
      "verse_summary": {
        "ko": "에돔 복습",
        "en": "Edom Review",
        "ja": "エドム 復習",
        "ms": "Edom Ulang kaji",
        "th": "เอโดม ทบทวน",
        "km": "អេដុម រំលឹក"
      }
    },
    {
      "card_id": "CARD-JON-001",
      "world_id": "W_OT_MINOR",
      "card_type": "book",
      "asset_key": "asset.card.jon-001",
      "title": {
        "ko": "욥바·니느웨",
        "en": "Joppa·Nineveh",
        "ja": "ヨッパ·ニネベ",
        "ms": "Yope·Niniwe",
        "th": "ยัฟฟา·นีนะเวห์",
        "km": "យ៉ុបប៉ា·នីនីវេ"
      },
      "summary": {
        "ko": "욥바 · 니느웨 여정에서 요나 4장 본문 문제를 풉니다.",
        "en": "Follow Joppa · Nineveh and answer Jonah 4 chapters question bank.",
        "ja": "ヨッパ · ニネベの旅で、ヨナ書4章の問題バンクに答えます。",
        "ms": "Ikuti Yope · Niniwe dan jawab bank soalan Yunus 4 bab.",
        "th": "ติดตามเส้นทางยัฟฟา · นีนะเวห์และตอบคลังคำถามจากโยนาห์ 4 บท",
        "km": "តាមដានដំណើរយ៉ុបប៉ា · នីនីវេ ហើយឆ្លើយធនាគារសំណួរពីយ៉ូណា 4 ជំពូក។"
      },
      "verse_reference": {
        "ko": "요나 1-4",
        "en": "Jonah 1-4",
        "ja": "ヨナ書 1-4",
        "ms": "Yunus 1-4",
        "th": "โยนาห์ 1-4",
        "km": "យ៉ូណា 1-4"
      },
      "verse_summary": {
        "ko": "욥바·니느웨 복습",
        "en": "Joppa·Nineveh Review",
        "ja": "ヨッパ·ニネベ 復習",
        "ms": "Yope·Niniwe Ulang kaji",
        "th": "ยัฟฟา·นีนะเวห์ ทบทวน",
        "km": "យ៉ុបប៉ា·នីនីវេ រំលឹក"
      }
    },
    {
      "card_id": "CARD-MIC-001",
      "world_id": "W_OT_MINOR",
      "card_type": "book",
      "asset_key": "asset.card.mic-001",
      "title": {
        "ko": "모레셋",
        "en": "Moresheth",
        "ja": "モレシェト",
        "ms": "Moresyet",
        "th": "โมเรเชท",
        "km": "មូរេសែត"
      },
      "summary": {
        "ko": "모레셋 · 예루살렘 여정에서 미가 7장 본문 문제를 풉니다.",
        "en": "Follow Moresheth · Jerusalem and answer Micah 7 chapters question bank.",
        "ja": "モレシェト · エルサレムの旅で、ミカ書7章の問題バンクに答えます。",
        "ms": "Ikuti Moresyet · Yerusalem dan jawab bank soalan Mikha 7 bab.",
        "th": "ติดตามเส้นทางโมเรเชท · เยรูซาเล็มและตอบคลังคำถามจากมีคาห์ 7 บท",
        "km": "តាមដានដំណើរមូរេសែត · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីមីកា 7 ជំពូក។"
      },
      "verse_reference": {
        "ko": "미가 1-7",
        "en": "Micah 1-7",
        "ja": "ミカ書 1-7",
        "ms": "Mikha 1-7",
        "th": "มีคาห์ 1-7",
        "km": "មីកា 1-7"
      },
      "verse_summary": {
        "ko": "모레셋 복습",
        "en": "Moresheth Review",
        "ja": "モレシェト 復習",
        "ms": "Moresyet Ulang kaji",
        "th": "โมเรเชท ทบทวน",
        "km": "មូរេសែត រំលឹក"
      }
    },
    {
      "card_id": "CARD-NAM-001",
      "world_id": "W_OT_MINOR",
      "card_type": "book",
      "asset_key": "asset.card.nam-001",
      "title": {
        "ko": "니느웨",
        "en": "Nineveh",
        "ja": "ニネベ",
        "ms": "Niniwe",
        "th": "นีนะเวห์",
        "km": "នីនីវេ"
      },
      "summary": {
        "ko": "니느웨 여정에서 나훔 3장 본문 문제를 풉니다.",
        "en": "Follow Nineveh and answer Nahum 3 chapters question bank.",
        "ja": "ニネベの旅で、ナホム書3章の問題バンクに答えます。",
        "ms": "Ikuti Niniwe dan jawab bank soalan Nahum 3 bab.",
        "th": "ติดตามเส้นทางนีนะเวห์และตอบคลังคำถามจากนาฮูม 3 บท",
        "km": "តាមដានដំណើរនីនីវេ ហើយឆ្លើយធនាគារសំណួរពីណាហ៊ុម 3 ជំពូក។"
      },
      "verse_reference": {
        "ko": "나훔 1-3",
        "en": "Nahum 1-3",
        "ja": "ナホム書 1-3",
        "ms": "Nahum 1-3",
        "th": "นาฮูม 1-3",
        "km": "ណាហ៊ុម 1-3"
      },
      "verse_summary": {
        "ko": "니느웨 복습",
        "en": "Nineveh Review",
        "ja": "ニネベ 復習",
        "ms": "Niniwe Ulang kaji",
        "th": "นีนะเวห์ ทบทวน",
        "km": "នីនីវេ រំលឹក"
      }
    },
    {
      "card_id": "CARD-HAB-001",
      "world_id": "W_OT_MINOR",
      "card_type": "book",
      "asset_key": "asset.card.hab-001",
      "title": {
        "ko": "파수대",
        "en": "Watchpost",
        "ja": "見張り場",
        "ms": "Tempat berjaga",
        "th": "ป้อมยาม",
        "km": "កន្លែងយាម"
      },
      "summary": {
        "ko": "예루살렘 파수대 여정에서 하박국 3장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem Watchpost and answer Habakkuk 3 chapters question bank.",
        "ja": "エルサレムの見張り場の旅で、ハバクク書3章の問題バンクに答えます。",
        "ms": "Ikuti Tempat berjaga Yerusalem dan jawab bank soalan Habakuk 3 bab.",
        "th": "ติดตามเส้นทางป้อมยามเยรูซาเล็มและตอบคลังคำถามจากฮาบากุก 3 บท",
        "km": "តាមដានដំណើរកន្លែងយាមនៅយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីហាបាគុក 3 ជំពូក។"
      },
      "verse_reference": {
        "ko": "하박국 1-3",
        "en": "Habakkuk 1-3",
        "ja": "ハバクク書 1-3",
        "ms": "Habakuk 1-3",
        "th": "ฮาบากุก 1-3",
        "km": "ហាបាគុក 1-3"
      },
      "verse_summary": {
        "ko": "파수대 복습",
        "en": "Watchpost Review",
        "ja": "見張り場 復習",
        "ms": "Tempat berjaga Ulang kaji",
        "th": "ป้อมยาม ทบทวน",
        "km": "កន្លែងយាម រំលឹក"
      }
    },
    {
      "card_id": "CARD-ZEP-001",
      "world_id": "W_OT_MINOR",
      "card_type": "book",
      "asset_key": "asset.card.zep-001",
      "title": {
        "ko": "예루살렘",
        "en": "Jerusalem",
        "ja": "エルサレム",
        "ms": "Yerusalem",
        "th": "เยรูซาเล็ม",
        "km": "យេរូសាឡឹម"
      },
      "summary": {
        "ko": "예루살렘 여정에서 스바냐 3장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem and answer Zephaniah 3 chapters question bank.",
        "ja": "エルサレムの旅で、ゼパニヤ書3章の問題バンクに答えます。",
        "ms": "Ikuti Yerusalem dan jawab bank soalan Zefanya 3 bab.",
        "th": "ติดตามเส้นทางเยรูซาเล็มและตอบคลังคำถามจากเศฟันยาห์ 3 บท",
        "km": "តាមដានដំណើរយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីសេផានា 3 ជំពូក។"
      },
      "verse_reference": {
        "ko": "스바냐 1-3",
        "en": "Zephaniah 1-3",
        "ja": "ゼパニヤ書 1-3",
        "ms": "Zefanya 1-3",
        "th": "เศฟันยาห์ 1-3",
        "km": "សេផានា 1-3"
      },
      "verse_summary": {
        "ko": "예루살렘 복습",
        "en": "Jerusalem Review",
        "ja": "エルサレム 復習",
        "ms": "Yerusalem Ulang kaji",
        "th": "เยรูซาเล็ม ทบทวน",
        "km": "យេរូសាឡឹម រំលឹក"
      }
    },
    {
      "card_id": "CARD-HAG-001",
      "world_id": "W_OT_MINOR",
      "card_type": "book",
      "asset_key": "asset.card.hag-001",
      "title": {
        "ko": "성전터",
        "en": "Temple Site",
        "ja": "神殿跡",
        "ms": "Tapak Bait Suci",
        "th": "สถานที่พระวิหาร",
        "km": "ទីតាំងព្រះវិហារ"
      },
      "summary": {
        "ko": "예루살렘 성전터 여정에서 학개 2장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem Temple Site and answer Haggai 2 chapters question bank.",
        "ja": "エルサレム神殿跡の旅で、ハガイ書2章の問題バンクに答えます。",
        "ms": "Ikuti Tapak Bait Suci Yerusalem dan jawab bank soalan Hagai 2 bab.",
        "th": "ติดตามเส้นทางสถานที่พระวิหารเยรูซาเล็มและตอบคลังคำถามจากฮักกัย 2 บท",
        "km": "តាមដានដំណើរទីតាំងព្រះវិហារយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីហាកាយ 2 ជំពូក។"
      },
      "verse_reference": {
        "ko": "학개 1-2",
        "en": "Haggai 1-2",
        "ja": "ハガイ書 1-2",
        "ms": "Hagai 1-2",
        "th": "ฮักกัย 1-2",
        "km": "ហាកាយ 1-2"
      },
      "verse_summary": {
        "ko": "성전터 복습",
        "en": "Temple Site Review",
        "ja": "神殿跡 復習",
        "ms": "Tapak Bait Suci Ulang kaji",
        "th": "สถานที่พระวิหาร ทบทวน",
        "km": "ទីតាំងព្រះវិហារ រំលឹក"
      }
    },
    {
      "card_id": "CARD-ZEC-001",
      "world_id": "W_OT_MINOR",
      "card_type": "book",
      "asset_key": "asset.card.zec-001",
      "title": {
        "ko": "성전터",
        "en": "Temple Site",
        "ja": "神殿跡",
        "ms": "Tapak Bait Suci",
        "th": "สถานที่พระวิหาร",
        "km": "ទីតាំងព្រះវិហារ"
      },
      "summary": {
        "ko": "예루살렘 성전터 여정에서 스가랴 14장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem Temple Site and answer Zechariah 14 chapters question bank.",
        "ja": "エルサレム神殿跡の旅で、ゼカリヤ書14章の問題バンクに答えます。",
        "ms": "Ikuti Tapak Bait Suci Yerusalem dan jawab bank soalan Zakharia 14 bab.",
        "th": "ติดตามเส้นทางสถานที่พระวิหารเยรูซาเล็มและตอบคลังคำถามจากเศคาริยาห์ 14 บท",
        "km": "តាមដានដំណើរទីតាំងព្រះវិហារយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីសាការី 14 ជំពូក។"
      },
      "verse_reference": {
        "ko": "스가랴 1-14",
        "en": "Zechariah 1-14",
        "ja": "ゼカリヤ書 1-14",
        "ms": "Zakharia 1-14",
        "th": "เศคาริยาห์ 1-14",
        "km": "សាការី 1-14"
      },
      "verse_summary": {
        "ko": "성전터 복습",
        "en": "Temple Site Review",
        "ja": "神殿跡 復習",
        "ms": "Tapak Bait Suci Ulang kaji",
        "th": "สถานที่พระวิหาร ทบทวน",
        "km": "ទីតាំងព្រះវិហារ រំលឹក"
      }
    },
    {
      "card_id": "CARD-MAL-001",
      "world_id": "W_OT_MINOR",
      "card_type": "book",
      "asset_key": "asset.card.mal-001",
      "title": {
        "ko": "성전",
        "en": "Temple",
        "ja": "神殿",
        "ms": "Bait Suci",
        "th": "พระวิหาร",
        "km": "ព្រះវិហារ"
      },
      "summary": {
        "ko": "예루살렘 성전 여정에서 말라기 4장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem Temple and answer Malachi 4 chapters question bank.",
        "ja": "エルサレム神殿の旅で、マラキ書4章の問題バンクに答えます。",
        "ms": "Ikuti Bait Suci Yerusalem dan jawab bank soalan Maleakhi 4 bab.",
        "th": "ติดตามเส้นทางพระวิหารเยรูซาเล็มและตอบคลังคำถามจากมาลาคี 4 บท",
        "km": "តាមដានដំណើរព្រះវិហារយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីម៉ាឡាគី 4 ជំពូក។"
      },
      "verse_reference": {
        "ko": "말라기 1-4",
        "en": "Malachi 1-4",
        "ja": "マラキ書 1-4",
        "ms": "Maleakhi 1-4",
        "th": "มาลาคี 1-4",
        "km": "ម៉ាឡាគី 1-4"
      },
      "verse_summary": {
        "ko": "성전 복습",
        "en": "Temple Review",
        "ja": "神殿 復習",
        "ms": "Bait Suci Ulang kaji",
        "th": "พระวิหาร ทบทวน",
        "km": "ព្រះវិហារ រំលឹក"
      }
    },
    {
      "card_id": "CARD-HOS-REVIEW-13",
      "world_id": "W_OT_MINOR",
      "card_type": "review",
      "asset_key": "asset.card.hos-review-13",
      "title": {
        "ko": "사마리아·이스르엘+",
        "en": "Samaria·Jezreel+",
        "ja": "サマリア·イズレエル+",
        "ms": "Samaria·Yizreel+",
        "th": "สะมาเรีย·ยิสเรเอล+",
        "km": "សាម៉ារី·យីសរេអែល+"
      },
      "summary": {
        "ko": "사마리아 · 이스르엘 길에서 호세아 주요 사건을 다시 확인합니다.",
        "en": "Review the main Hosea events along Samaria · Jezreel.",
        "ja": "サマリア · イズレエルの道で、ホセア書の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Hosea di sepanjang Samaria · Yizreel.",
        "th": "ทบทวนเหตุการณ์สำคัญของโฮเชยาตามเส้นทางสะมาเรีย · ยิสเรเอล",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃហូសេ តាមផ្លូវសាម៉ារី · យីសរេអែល។"
      },
      "verse_reference": {
        "ko": "호세아 1-14",
        "en": "Hosea 1-14",
        "ja": "ホセア書 1-14",
        "ms": "Hosea 1-14",
        "th": "โฮเชยา 1-14",
        "km": "ហូសេ 1-14"
      },
      "verse_summary": {
        "ko": "사마리아·이스르엘+ 복습",
        "en": "Samaria·Jezreel+ Review",
        "ja": "サマリア·イズレエル+ 復習",
        "ms": "Samaria·Yizreel+ Ulang kaji",
        "th": "สะมาเรีย·ยิสเรเอล+ ทบทวน",
        "km": "សាម៉ារី·យីសរេអែល+ រំលឹក"
      }
    },
    {
      "card_id": "CARD-JOL-REVIEW-14",
      "world_id": "W_OT_MINOR",
      "card_type": "review",
      "asset_key": "asset.card.jol-review-14",
      "title": {
        "ko": "시온+",
        "en": "Zion+",
        "ja": "シオン+",
        "ms": "Sion+",
        "th": "ศิโยน+",
        "km": "ស៊ីយ៉ូន+"
      },
      "summary": {
        "ko": "시온 · 예루살렘 길에서 요엘 주요 사건을 다시 확인합니다.",
        "en": "Review the main Joel events along Zion · Jerusalem.",
        "ja": "シオン · エルサレムの道で、ヨエル書の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Yoel di sepanjang Sion · Yerusalem.",
        "th": "ทบทวนเหตุการณ์สำคัญของโยเอลตามเส้นทางศิโยน · เยรูซาเล็ม",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃយ៉ូអែល តាមផ្លូវស៊ីយ៉ូន · យេរូសាឡឹម។"
      },
      "verse_reference": {
        "ko": "요엘 1-3",
        "en": "Joel 1-3",
        "ja": "ヨエル書 1-3",
        "ms": "Yoel 1-3",
        "th": "โยเอล 1-3",
        "km": "យ៉ូអែល 1-3"
      },
      "verse_summary": {
        "ko": "시온+ 복습",
        "en": "Zion+ Review",
        "ja": "シオン+ 復習",
        "ms": "Sion+ Ulang kaji",
        "th": "ศิโยน+ ทบทวน",
        "km": "ស៊ីយ៉ូន+ រំលឹក"
      }
    },
    {
      "card_id": "CARD-AMO-REVIEW-15",
      "world_id": "W_OT_MINOR",
      "card_type": "review",
      "asset_key": "asset.card.amo-review-15",
      "title": {
        "ko": "드고아·벧엘+",
        "en": "Tekoa·Bethel+",
        "ja": "テコア·ベテル+",
        "ms": "Tekoa·Betel+",
        "th": "เทโคอา·เบธเอล+",
        "km": "តេកូអា·បេតអែល+"
      },
      "summary": {
        "ko": "드고아 · 벧엘 길에서 아모스 주요 사건을 다시 확인합니다.",
        "en": "Review the main Amos events along Tekoa · Bethel.",
        "ja": "テコア · ベテルの道で、アモス書の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Amos di sepanjang Tekoa · Betel.",
        "th": "ทบทวนเหตุการณ์สำคัญของอาโมสตามเส้นทางเทโคอา · เบธเอล",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃអាម៉ុស តាមផ្លូវតេកូអា · បេតអែល។"
      },
      "verse_reference": {
        "ko": "아모스 1-9",
        "en": "Amos 1-9",
        "ja": "アモス書 1-9",
        "ms": "Amos 1-9",
        "th": "อาโมส 1-9",
        "km": "អាម៉ុស 1-9"
      },
      "verse_summary": {
        "ko": "드고아·벧엘+ 복습",
        "en": "Tekoa·Bethel+ Review",
        "ja": "テコア·ベテル+ 復習",
        "ms": "Tekoa·Betel+ Ulang kaji",
        "th": "เทโคอา·เบธเอล+ ทบทวน",
        "km": "តេកូអា·បេតអែល+ រំលឹក"
      }
    },
    {
      "card_id": "CARD-MAT-001",
      "world_id": "W_NT_GOS",
      "card_type": "book",
      "asset_key": "asset.card.mat-001",
      "title": {
        "ko": "베들레헴·갈릴리",
        "en": "Bethlehem·Galilee",
        "ja": "ベツレヘム·ガリラヤ",
        "ms": "Betlehem·Galilea",
        "th": "เบธเลเฮม·กาลิลี",
        "km": "បេថ្លេហិម·កាលីឡេ"
      },
      "summary": {
        "ko": "베들레헴 · 갈릴리 · 예루살렘 여정에서 마태복음 28장 본문 문제를 풉니다.",
        "en": "Follow Bethlehem · Galilee · Jerusalem and answer Matthew 28 chapters question bank.",
        "ja": "ベツレヘム · ガリラヤ · エルサレムの旅で、マタイの福音書28章の問題バンクに答えます。",
        "ms": "Ikuti Betlehem · Galilea · Yerusalem dan jawab bank soalan Matius 28 bab.",
        "th": "ติดตามเส้นทางเบธเลเฮม · กาลิลี · เยรูซาเล็มและตอบคลังคำถามจากมัทธิว 28 บท",
        "km": "តាមដានដំណើរបេថ្លេហិម · កាលីឡេ · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីម៉ាថាយ 28 ជំពូក។"
      },
      "verse_reference": {
        "ko": "마태복음 1-28",
        "en": "Matthew 1-28",
        "ja": "マタイの福音書 1-28",
        "ms": "Matius 1-28",
        "th": "มัทธิว 1-28",
        "km": "ម៉ាថាយ 1-28"
      },
      "verse_summary": {
        "ko": "베들레헴·갈릴리 복습",
        "en": "Bethlehem·Galilee Review",
        "ja": "ベツレヘム·ガリラヤ 復習",
        "ms": "Betlehem·Galilea Ulang kaji",
        "th": "เบธเลเฮม·กาลิลี ทบทวน",
        "km": "បេថ្លេហិម·កាលីឡេ រំលឹក"
      }
    },
    {
      "card_id": "CARD-MRK-001",
      "world_id": "W_NT_GOS",
      "card_type": "book",
      "asset_key": "asset.card.mrk-001",
      "title": {
        "ko": "갈릴리·가버나움",
        "en": "Galilee·Capernaum",
        "ja": "ガリラヤ·カペナウム",
        "ms": "Galilea·Kapernaum",
        "th": "กาลิลี·คาเปอรนาอุม",
        "km": "កាលីឡេ·កាពើណិម"
      },
      "summary": {
        "ko": "갈릴리 · 가버나움 여정에서 마가복음 16장 본문 문제를 풉니다.",
        "en": "Follow Galilee · Capernaum and answer Mark 16 chapters question bank.",
        "ja": "ガリラヤ · カペナウムの旅で、マルコの福音書16章の問題バンクに答えます。",
        "ms": "Ikuti Galilea · Kapernaum dan jawab bank soalan Markus 16 bab.",
        "th": "ติดตามเส้นทางกาลิลี · คาเปอรนาอุมและตอบคลังคำถามจากมาระโก 16 บท",
        "km": "តាមដានដំណើរកាលីឡេ · កាពើណិម ហើយឆ្លើយធនាគារសំណួរពីម៉ាកុស 16 ជំពូក។"
      },
      "verse_reference": {
        "ko": "마가복음 1-16",
        "en": "Mark 1-16",
        "ja": "マルコの福音書 1-16",
        "ms": "Markus 1-16",
        "th": "มาระโก 1-16",
        "km": "ម៉ាកុស 1-16"
      },
      "verse_summary": {
        "ko": "갈릴리·가버나움 복습",
        "en": "Galilee·Capernaum Review",
        "ja": "ガリラヤ·カペナウム 復習",
        "ms": "Galilea·Kapernaum Ulang kaji",
        "th": "กาลิลี·คาเปอรนาอุม ทบทวน",
        "km": "កាលីឡេ·កាពើណិម រំលឹក"
      }
    },
    {
      "card_id": "CARD-LUK-001",
      "world_id": "W_NT_GOS",
      "card_type": "book",
      "asset_key": "asset.card.luk-001",
      "title": {
        "ko": "나사렛·베들레헴",
        "en": "Nazareth·Bethlehem",
        "ja": "ナザレ·ベツレヘム",
        "ms": "Nazaret·Betlehem",
        "th": "นาซาเร็ธ·เบธเลเฮม",
        "km": "ណាសារ៉ែត·បេថ្លេហិម"
      },
      "summary": {
        "ko": "나사렛 · 베들레헴 · 예루살렘 여정에서 누가복음 24장 본문 문제를 풉니다.",
        "en": "Follow Nazareth · Bethlehem · Jerusalem and answer Luke 24 chapters question bank.",
        "ja": "ナザレ · ベツレヘム · エルサレムの旅で、ルカの福音書24章の問題バンクに答えます。",
        "ms": "Ikuti Nazaret · Betlehem · Yerusalem dan jawab bank soalan Lukas 24 bab.",
        "th": "ติดตามเส้นทางนาซาเร็ธ · เบธเลเฮม · เยรูซาเล็มและตอบคลังคำถามจากลูกา 24 บท",
        "km": "តាមដានដំណើរណាសារ៉ែត · បេថ្លេហិម · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីលូកា 24 ជំពូក។"
      },
      "verse_reference": {
        "ko": "누가복음 1-24",
        "en": "Luke 1-24",
        "ja": "ルカの福音書 1-24",
        "ms": "Lukas 1-24",
        "th": "ลูกา 1-24",
        "km": "លូកា 1-24"
      },
      "verse_summary": {
        "ko": "나사렛·베들레헴 복습",
        "en": "Nazareth·Bethlehem Review",
        "ja": "ナザレ·ベツレヘム 復習",
        "ms": "Nazaret·Betlehem Ulang kaji",
        "th": "นาซาเร็ธ·เบธเลเฮม ทบทวน",
        "km": "ណាសារ៉ែត·បេថ្លេហិម រំលឹក"
      }
    },
    {
      "card_id": "CARD-JHN-001",
      "world_id": "W_NT_GOS",
      "card_type": "book",
      "asset_key": "asset.card.jhn-001",
      "title": {
        "ko": "갈릴리·예루살렘",
        "en": "Galilee·Jerusalem",
        "ja": "ガリラヤ·エルサレム",
        "ms": "Galilea·Yerusalem",
        "th": "กาลิลี·เยรูซาเล็ม",
        "km": "កាលីឡេ·យេរូសាឡឹម"
      },
      "summary": {
        "ko": "갈릴리 · 예루살렘 여정에서 요한복음 21장 본문 문제를 풉니다.",
        "en": "Follow Galilee · Jerusalem and answer John 21 chapters question bank.",
        "ja": "ガリラヤ · エルサレムの旅で、ヨハネの福音書21章の問題バンクに答えます。",
        "ms": "Ikuti Galilea · Yerusalem dan jawab bank soalan Yohanes 21 bab.",
        "th": "ติดตามเส้นทางกาลิลี · เยรูซาเล็มและตอบคลังคำถามจากยอห์น 21 บท",
        "km": "តាមដានដំណើរកាលីឡេ · យេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីយ៉ូហាន 21 ជំពូក។"
      },
      "verse_reference": {
        "ko": "요한복음 1-21",
        "en": "John 1-21",
        "ja": "ヨハネの福音書 1-21",
        "ms": "Yohanes 1-21",
        "th": "ยอห์น 1-21",
        "km": "យ៉ូហាន 1-21"
      },
      "verse_summary": {
        "ko": "갈릴리·예루살렘 복습",
        "en": "Galilee·Jerusalem Review",
        "ja": "ガリラヤ·エルサレム 復習",
        "ms": "Galilea·Yerusalem Ulang kaji",
        "th": "กาลิลี·เยรูซาเล็ม ทบทวน",
        "km": "កាលីឡេ·យេរូសាឡឹម រំលឹក"
      }
    },
    {
      "card_id": "CARD-MAT-REVIEW-05",
      "world_id": "W_NT_GOS",
      "card_type": "review",
      "asset_key": "asset.card.mat-review-05",
      "title": {
        "ko": "베들레헴·갈릴리+",
        "en": "Bethlehem·Galilee+",
        "ja": "ベツレヘム·ガリラヤ+",
        "ms": "Betlehem·Galilea+",
        "th": "เบธเลเฮม·กาลิลี+",
        "km": "បេថ្លេហិម·កាលីឡេ+"
      },
      "summary": {
        "ko": "베들레헴 · 갈릴리 · 예루살렘 길에서 마태복음 주요 사건을 다시 확인합니다.",
        "en": "Review the main Matthew events along Bethlehem · Galilee · Jerusalem.",
        "ja": "ベツレヘム · ガリラヤ · エルサレムの道で、マタイの福音書の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Matius di sepanjang Betlehem · Galilea · Yerusalem.",
        "th": "ทบทวนเหตุการณ์สำคัญของมัทธิวตามเส้นทางเบธเลเฮม · กาลิลี · เยรูซาเล็ม",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃម៉ាថាយ តាមផ្លូវបេថ្លេហិម · កាលីឡេ · យេរូសាឡឹម។"
      },
      "verse_reference": {
        "ko": "마태복음 1-28",
        "en": "Matthew 1-28",
        "ja": "マタイの福音書 1-28",
        "ms": "Matius 1-28",
        "th": "มัทธิว 1-28",
        "km": "ម៉ាថាយ 1-28"
      },
      "verse_summary": {
        "ko": "베들레헴·갈릴리+ 복습",
        "en": "Bethlehem·Galilee+ Review",
        "ja": "ベツレヘム·ガリラヤ+ 復習",
        "ms": "Betlehem·Galilea+ Ulang kaji",
        "th": "เบธเลเฮม·กาลิลี+ ทบทวน",
        "km": "បេថ្លេហិម·កាលីឡេ+ រំលឹក"
      }
    },
    {
      "card_id": "CARD-ACT-001",
      "world_id": "W_NT_ACTS",
      "card_type": "book",
      "asset_key": "asset.card.act-001",
      "title": {
        "ko": "예루살렘·안디옥·로마",
        "en": "Jerusalem·Antioch·Rome",
        "ja": "エルサレム·アンティオキア·ローマ",
        "ms": "Yerusalem·Antiokhia·Roma",
        "th": "เยรูซาเล็ม·อันทิโอก·โรม",
        "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម"
      },
      "summary": {
        "ko": "예루살렘 · 안디옥 · 로마 여정에서 사도행전 28장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem · Antioch · Rome and answer Acts 28 chapters question bank.",
        "ja": "エルサレム · アンティオキア · ローマの旅で、使徒の働き28章の問題バンクに答えます。",
        "ms": "Ikuti Yerusalem · Antiokhia · Roma dan jawab bank soalan Kisah Para Rasul 28 bab.",
        "th": "ติดตามเส้นทางเยรูซาเล็ม · อันทิโอก · โรมและตอบคลังคำถามจากกิจการ 28 บท",
        "km": "តាមដានដំណើរយេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម ហើយឆ្លើយធនាគារសំណួរពីកិច្ចការ 28 ជំពូក។"
      },
      "verse_reference": {
        "ko": "사도행전 1-28",
        "en": "Acts 1-28",
        "ja": "使徒の働き 1-28",
        "ms": "Kisah Para Rasul 1-28",
        "th": "กิจการ 1-28",
        "km": "កិច្ចការ 1-28"
      },
      "verse_summary": {
        "ko": "예루살렘·안디옥·로마 복습",
        "en": "Jerusalem·Antioch·Rome Review",
        "ja": "エルサレム·アンティオキア·ローマ 復習",
        "ms": "Yerusalem·Antiokhia·Roma Ulang kaji",
        "th": "เยรูซาเล็ม·อันทิโอก·โรม ทบทวน",
        "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម រំលឹក"
      }
    },
    {
      "card_id": "CARD-ACT-REVIEW-02",
      "world_id": "W_NT_ACTS",
      "card_type": "review",
      "asset_key": "asset.card.act-review-02",
      "title": {
        "ko": "예루살렘·안디옥·로마+",
        "en": "Jerusalem·Antioch·Rome+",
        "ja": "エルサレム·アンティオキア·ローマ+",
        "ms": "Yerusalem·Antiokhia·Roma+",
        "th": "เยรูซาเล็ม·อันทิโอก·โรม+",
        "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+"
      },
      "summary": {
        "ko": "예루살렘 · 안디옥 · 로마 길에서 사도행전 주요 사건을 다시 확인합니다.",
        "en": "Review the main Acts events along Jerusalem · Antioch · Rome.",
        "ja": "エルサレム · アンティオキア · ローマの道で、使徒の働きの主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Kisah Para Rasul di sepanjang Yerusalem · Antiokhia · Roma.",
        "th": "ทบทวนเหตุการณ์สำคัญของกิจการตามเส้นทางเยรูซาเล็ม · อันทิโอก · โรม",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃកិច្ចការ តាមផ្លូវយេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម។"
      },
      "verse_reference": {
        "ko": "사도행전 1-28",
        "en": "Acts 1-28",
        "ja": "使徒の働き 1-28",
        "ms": "Kisah Para Rasul 1-28",
        "th": "กิจการ 1-28",
        "km": "កិច្ចការ 1-28"
      },
      "verse_summary": {
        "ko": "예루살렘·안디옥·로마+ 복습",
        "en": "Jerusalem·Antioch·Rome+ Review",
        "ja": "エルサレム·アンティオキア·ローマ+ 復習",
        "ms": "Yerusalem·Antiokhia·Roma+ Ulang kaji",
        "th": "เยรูซาเล็ม·อันทิโอก·โรม+ ทบทวน",
        "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+ រំលឹក"
      }
    },
    {
      "card_id": "CARD-ACT-REVIEW-03",
      "world_id": "W_NT_ACTS",
      "card_type": "review",
      "asset_key": "asset.card.act-review-03",
      "title": {
        "ko": "예루살렘·안디옥·로마+",
        "en": "Jerusalem·Antioch·Rome+",
        "ja": "エルサレム·アンティオキア·ローマ+",
        "ms": "Yerusalem·Antiokhia·Roma+",
        "th": "เยรูซาเล็ม·อันทิโอก·โรม+",
        "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+"
      },
      "summary": {
        "ko": "예루살렘 · 안디옥 · 로마 길에서 사도행전 주요 사건을 다시 확인합니다.",
        "en": "Review the main Acts events along Jerusalem · Antioch · Rome.",
        "ja": "エルサレム · アンティオキア · ローマの道で、使徒の働きの主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Kisah Para Rasul di sepanjang Yerusalem · Antiokhia · Roma.",
        "th": "ทบทวนเหตุการณ์สำคัญของกิจการตามเส้นทางเยรูซาเล็ม · อันทิโอก · โรม",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃកិច្ចការ តាមផ្លូវយេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម។"
      },
      "verse_reference": {
        "ko": "사도행전 1-28",
        "en": "Acts 1-28",
        "ja": "使徒の働き 1-28",
        "ms": "Kisah Para Rasul 1-28",
        "th": "กิจการ 1-28",
        "km": "កិច្ចការ 1-28"
      },
      "verse_summary": {
        "ko": "예루살렘·안디옥·로마+ 복습",
        "en": "Jerusalem·Antioch·Rome+ Review",
        "ja": "エルサレム·アンティオキア·ローマ+ 復習",
        "ms": "Yerusalem·Antiokhia·Roma+ Ulang kaji",
        "th": "เยรูซาเล็ม·อันทิโอก·โรม+ ทบทวน",
        "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+ រំលឹក"
      }
    },
    {
      "card_id": "CARD-ACT-REVIEW-04",
      "world_id": "W_NT_ACTS",
      "card_type": "review",
      "asset_key": "asset.card.act-review-04",
      "title": {
        "ko": "예루살렘·안디옥·로마+",
        "en": "Jerusalem·Antioch·Rome+",
        "ja": "エルサレム·アンティオキア·ローマ+",
        "ms": "Yerusalem·Antiokhia·Roma+",
        "th": "เยรูซาเล็ม·อันทิโอก·โรม+",
        "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+"
      },
      "summary": {
        "ko": "예루살렘 · 안디옥 · 로마 길에서 사도행전 주요 사건을 다시 확인합니다.",
        "en": "Review the main Acts events along Jerusalem · Antioch · Rome.",
        "ja": "エルサレム · アンティオキア · ローマの道で、使徒の働きの主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Kisah Para Rasul di sepanjang Yerusalem · Antiokhia · Roma.",
        "th": "ทบทวนเหตุการณ์สำคัญของกิจการตามเส้นทางเยรูซาเล็ม · อันทิโอก · โรม",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃកិច្ចការ តាមផ្លូវយេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម។"
      },
      "verse_reference": {
        "ko": "사도행전 1-28",
        "en": "Acts 1-28",
        "ja": "使徒の働き 1-28",
        "ms": "Kisah Para Rasul 1-28",
        "th": "กิจการ 1-28",
        "km": "កិច្ចការ 1-28"
      },
      "verse_summary": {
        "ko": "예루살렘·안디옥·로마+ 복습",
        "en": "Jerusalem·Antioch·Rome+ Review",
        "ja": "エルサレム·アンティオキア·ローマ+ 復習",
        "ms": "Yerusalem·Antiokhia·Roma+ Ulang kaji",
        "th": "เยรูซาเล็ม·อันทิโอก·โรม+ ทบทวน",
        "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+ រំលឹក"
      }
    },
    {
      "card_id": "CARD-ACT-REVIEW-05",
      "world_id": "W_NT_ACTS",
      "card_type": "review",
      "asset_key": "asset.card.act-review-05",
      "title": {
        "ko": "예루살렘·안디옥·로마+",
        "en": "Jerusalem·Antioch·Rome+",
        "ja": "エルサレム·アンティオキア·ローマ+",
        "ms": "Yerusalem·Antiokhia·Roma+",
        "th": "เยรูซาเล็ม·อันทิโอก·โรม+",
        "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+"
      },
      "summary": {
        "ko": "예루살렘 · 안디옥 · 로마 길에서 사도행전 주요 사건을 다시 확인합니다.",
        "en": "Review the main Acts events along Jerusalem · Antioch · Rome.",
        "ja": "エルサレム · アンティオキア · ローマの道で、使徒の働きの主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Kisah Para Rasul di sepanjang Yerusalem · Antiokhia · Roma.",
        "th": "ทบทวนเหตุการณ์สำคัญของกิจการตามเส้นทางเยรูซาเล็ม · อันทิโอก · โรม",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃកិច្ចការ តាមផ្លូវយេរូសាឡឹម · អង់ទីយ៉ូក · រ៉ូម។"
      },
      "verse_reference": {
        "ko": "사도행전 1-28",
        "en": "Acts 1-28",
        "ja": "使徒の働き 1-28",
        "ms": "Kisah Para Rasul 1-28",
        "th": "กิจการ 1-28",
        "km": "កិច្ចការ 1-28"
      },
      "verse_summary": {
        "ko": "예루살렘·안디옥·로마+ 복습",
        "en": "Jerusalem·Antioch·Rome+ Review",
        "ja": "エルサレム·アンティオキア·ローマ+ 復習",
        "ms": "Yerusalem·Antiokhia·Roma+ Ulang kaji",
        "th": "เยรูซาเล็ม·อันทิโอก·โรม+ ทบทวน",
        "km": "យេរូសាឡឹម·អង់ទីយ៉ូក·រ៉ូម+ រំលឹក"
      }
    },
    {
      "card_id": "CARD-ROM-001",
      "world_id": "W_NT_PAUL",
      "card_type": "book",
      "asset_key": "asset.card.rom-001",
      "title": {
        "ko": "로마",
        "en": "Rome",
        "ja": "ローマ",
        "ms": "Roma",
        "th": "โรม",
        "km": "រ៉ូម"
      },
      "summary": {
        "ko": "로마 여정에서 로마서 16장 본문 문제를 풉니다.",
        "en": "Follow Rome and answer Romans 16 chapters question bank.",
        "ja": "ローマの旅で、ローマ人への手紙16章の問題バンクに答えます。",
        "ms": "Ikuti Roma dan jawab bank soalan Roma 16 bab.",
        "th": "ติดตามเส้นทางโรมและตอบคลังคำถามจากโรม 16 บท",
        "km": "តាមដានដំណើររ៉ូម ហើយឆ្លើយធនាគារសំណួរពីរ៉ូម 16 ជំពូក។"
      },
      "verse_reference": {
        "ko": "로마서 1-16",
        "en": "Romans 1-16",
        "ja": "ローマ人への手紙 1-16",
        "ms": "Roma 1-16",
        "th": "โรม 1-16",
        "km": "រ៉ូម 1-16"
      },
      "verse_summary": {
        "ko": "로마 복습",
        "en": "Rome Review",
        "ja": "ローマ 復習",
        "ms": "Roma Ulang kaji",
        "th": "โรม ทบทวน",
        "km": "រ៉ូម រំលឹក"
      }
    },
    {
      "card_id": "CARD-1CO-001",
      "world_id": "W_NT_PAUL",
      "card_type": "book",
      "asset_key": "asset.card.1co-001",
      "title": {
        "ko": "고린도",
        "en": "Corinth",
        "ja": "コリント",
        "ms": "Korintus",
        "th": "โครินธ์",
        "km": "កូរិនថូស"
      },
      "summary": {
        "ko": "고린도 여정에서 고린도전서 16장 본문 문제를 풉니다.",
        "en": "Follow Corinth and answer 1 Corinthians 16 chapters question bank.",
        "ja": "コリントの旅で、コリント人への手紙第一16章の問題バンクに答えます。",
        "ms": "Ikuti Korintus dan jawab bank soalan 1 Korintus 16 bab.",
        "th": "ติดตามเส้นทางโครินธ์และตอบคลังคำถามจาก1 โครินธ์ 16 บท",
        "km": "តាមដានដំណើរកូរិនថូស ហើយឆ្លើយធនាគារសំណួរពី១ កូរិនថូស 16 ជំពូក។"
      },
      "verse_reference": {
        "ko": "고린도전서 1-16",
        "en": "1 Corinthians 1-16",
        "ja": "コリント人への手紙第一 1-16",
        "ms": "1 Korintus 1-16",
        "th": "1 โครินธ์ 1-16",
        "km": "១ កូរិនថូស 1-16"
      },
      "verse_summary": {
        "ko": "고린도 복습",
        "en": "Corinth Review",
        "ja": "コリント 復習",
        "ms": "Korintus Ulang kaji",
        "th": "โครินธ์ ทบทวน",
        "km": "កូរិនថូស រំលឹក"
      }
    },
    {
      "card_id": "CARD-2CO-001",
      "world_id": "W_NT_PAUL",
      "card_type": "book",
      "asset_key": "asset.card.2co-001",
      "title": {
        "ko": "고린도·마게도냐",
        "en": "Corinth·Macedonia",
        "ja": "コリント·マケドニア",
        "ms": "Korintus·Makedonia",
        "th": "โครินธ์·มาซิโดเนีย",
        "km": "កូរិនថូស·ម៉ាសេដូនៀ"
      },
      "summary": {
        "ko": "고린도 · 마게도냐 여정에서 고린도후서 13장 본문 문제를 풉니다.",
        "en": "Follow Corinth · Macedonia and answer 2 Corinthians 13 chapters question bank.",
        "ja": "コリント · マケドニアの旅で、コリント人への手紙第二13章の問題バンクに答えます。",
        "ms": "Ikuti Korintus · Makedonia dan jawab bank soalan 2 Korintus 13 bab.",
        "th": "ติดตามเส้นทางโครินธ์ · มาซิโดเนียและตอบคลังคำถามจาก2 โครินธ์ 13 บท",
        "km": "តាមដានដំណើរកូរិនថូស · ម៉ាសេដូនៀ ហើយឆ្លើយធនាគារសំណួរពី២ កូរិនថូស 13 ជំពូក។"
      },
      "verse_reference": {
        "ko": "고린도후서 1-13",
        "en": "2 Corinthians 1-13",
        "ja": "コリント人への手紙第二 1-13",
        "ms": "2 Korintus 1-13",
        "th": "2 โครินธ์ 1-13",
        "km": "២ កូរិនថូស 1-13"
      },
      "verse_summary": {
        "ko": "고린도·마게도냐 복습",
        "en": "Corinth·Macedonia Review",
        "ja": "コリント·マケドニア 復習",
        "ms": "Korintus·Makedonia Ulang kaji",
        "th": "โครินธ์·มาซิโดเนีย ทบทวน",
        "km": "កូរិនថូស·ម៉ាសេដូនៀ រំលឹក"
      }
    },
    {
      "card_id": "CARD-GAL-001",
      "world_id": "W_NT_PAUL",
      "card_type": "book",
      "asset_key": "asset.card.gal-001",
      "title": {
        "ko": "갈라디아",
        "en": "Galatia",
        "ja": "ガラテヤ",
        "ms": "Galatia",
        "th": "กาลาเทีย",
        "km": "កាឡាទី"
      },
      "summary": {
        "ko": "갈라디아 여정에서 갈라디아서 6장 본문 문제를 풉니다.",
        "en": "Follow Galatia and answer Galatians 6 chapters question bank.",
        "ja": "ガラテヤの旅で、ガラテヤ人への手紙6章の問題バンクに答えます。",
        "ms": "Ikuti Galatia dan jawab bank soalan Galatia 6 bab.",
        "th": "ติดตามเส้นทางกาลาเทียและตอบคลังคำถามจากกาลาเทีย 6 บท",
        "km": "តាមដានដំណើរកាឡាទី ហើយឆ្លើយធនាគារសំណួរពីកាឡាទី 6 ជំពូក។"
      },
      "verse_reference": {
        "ko": "갈라디아서 1-6",
        "en": "Galatians 1-6",
        "ja": "ガラテヤ人への手紙 1-6",
        "ms": "Galatia 1-6",
        "th": "กาลาเทีย 1-6",
        "km": "កាឡាទី 1-6"
      },
      "verse_summary": {
        "ko": "갈라디아 복습",
        "en": "Galatia Review",
        "ja": "ガラテヤ 復習",
        "ms": "Galatia Ulang kaji",
        "th": "กาลาเทีย ทบทวน",
        "km": "កាឡាទី រំលឹក"
      }
    },
    {
      "card_id": "CARD-EPH-001",
      "world_id": "W_NT_PAUL",
      "card_type": "book",
      "asset_key": "asset.card.eph-001",
      "title": {
        "ko": "에베소",
        "en": "Ephesus",
        "ja": "エフェソ",
        "ms": "Efesus",
        "th": "เอเฟซัส",
        "km": "អេភេសូរ"
      },
      "summary": {
        "ko": "에베소 여정에서 에베소서 6장 본문 문제를 풉니다.",
        "en": "Follow Ephesus and answer Ephesians 6 chapters question bank.",
        "ja": "エフェソの旅で、エペソ人への手紙6章の問題バンクに答えます。",
        "ms": "Ikuti Efesus dan jawab bank soalan Efesus 6 bab.",
        "th": "ติดตามเส้นทางเอเฟซัสและตอบคลังคำถามจากเอเฟซัส 6 บท",
        "km": "តាមដានដំណើរអេភេសូរ ហើយឆ្លើយធនាគារសំណួរពីអេភេសូរ 6 ជំពូក។"
      },
      "verse_reference": {
        "ko": "에베소서 1-6",
        "en": "Ephesians 1-6",
        "ja": "エペソ人への手紙 1-6",
        "ms": "Efesus 1-6",
        "th": "เอเฟซัส 1-6",
        "km": "អេភេសូរ 1-6"
      },
      "verse_summary": {
        "ko": "에베소 복습",
        "en": "Ephesus Review",
        "ja": "エフェソ 復習",
        "ms": "Efesus Ulang kaji",
        "th": "เอเฟซัส ทบทวน",
        "km": "អេភេសូរ រំលឹក"
      }
    },
    {
      "card_id": "CARD-PHP-001",
      "world_id": "W_NT_PAUL",
      "card_type": "book",
      "asset_key": "asset.card.php-001",
      "title": {
        "ko": "빌립보",
        "en": "Philippi",
        "ja": "フィリピ",
        "ms": "Filipi",
        "th": "ฟีลิปปี",
        "km": "ភីលីព"
      },
      "summary": {
        "ko": "빌립보 여정에서 빌립보서 4장 본문 문제를 풉니다.",
        "en": "Follow Philippi and answer Philippians 4 chapters question bank.",
        "ja": "フィリピの旅で、ピリピ人への手紙4章の問題バンクに答えます。",
        "ms": "Ikuti Filipi dan jawab bank soalan Filipi 4 bab.",
        "th": "ติดตามเส้นทางฟีลิปปีและตอบคลังคำถามจากฟิลิปปี 4 บท",
        "km": "តាមដានដំណើរភីលីព ហើយឆ្លើយធនាគារសំណួរពីភីលីព 4 ជំពូក។"
      },
      "verse_reference": {
        "ko": "빌립보서 1-4",
        "en": "Philippians 1-4",
        "ja": "ピリピ人への手紙 1-4",
        "ms": "Filipi 1-4",
        "th": "ฟิลิปปี 1-4",
        "km": "ភីលីព 1-4"
      },
      "verse_summary": {
        "ko": "빌립보 복습",
        "en": "Philippi Review",
        "ja": "フィリピ 復習",
        "ms": "Filipi Ulang kaji",
        "th": "ฟีลิปปี ทบทวน",
        "km": "ភីលីព រំលឹក"
      }
    },
    {
      "card_id": "CARD-COL-001",
      "world_id": "W_NT_PAUL",
      "card_type": "book",
      "asset_key": "asset.card.col-001",
      "title": {
        "ko": "골로새",
        "en": "Colossae",
        "ja": "コロサイ",
        "ms": "Kolose",
        "th": "โคโลสี",
        "km": "កូល៉ុស"
      },
      "summary": {
        "ko": "골로새 여정에서 골로새서 4장 본문 문제를 풉니다.",
        "en": "Follow Colossae and answer Colossians 4 chapters question bank.",
        "ja": "コロサイの旅で、コロサイ人への手紙4章の問題バンクに答えます。",
        "ms": "Ikuti Kolose dan jawab bank soalan Kolose 4 bab.",
        "th": "ติดตามเส้นทางโคโลสีและตอบคลังคำถามจากโคโลสี 4 บท",
        "km": "តាមដានដំណើរកូល៉ុស ហើយឆ្លើយធនាគារសំណួរពីកូឡុស 4 ជំពូក។"
      },
      "verse_reference": {
        "ko": "골로새서 1-4",
        "en": "Colossians 1-4",
        "ja": "コロサイ人への手紙 1-4",
        "ms": "Kolose 1-4",
        "th": "โคโลสี 1-4",
        "km": "កូឡុស 1-4"
      },
      "verse_summary": {
        "ko": "골로새 복습",
        "en": "Colossae Review",
        "ja": "コロサイ 復習",
        "ms": "Kolose Ulang kaji",
        "th": "โคโลสี ทบทวน",
        "km": "កូល៉ុស រំលឹក"
      }
    },
    {
      "card_id": "CARD-1TH-001",
      "world_id": "W_NT_PAUL",
      "card_type": "book",
      "asset_key": "asset.card.1th-001",
      "title": {
        "ko": "데살로니가",
        "en": "Thessalonica",
        "ja": "テサロニケ",
        "ms": "Tesalonika",
        "th": "เธสะโลนิกา",
        "km": "ថេស្សាឡូនិក"
      },
      "summary": {
        "ko": "데살로니가 여정에서 데살로니가전서 5장 본문 문제를 풉니다.",
        "en": "Follow Thessalonica and answer 1 Thessalonians 5 chapters question bank.",
        "ja": "テサロニケの旅で、テサロニケ人への手紙第一5章の問題バンクに答えます。",
        "ms": "Ikuti Tesalonika dan jawab bank soalan 1 Tesalonika 5 bab.",
        "th": "ติดตามเส้นทางเธสะโลนิกาและตอบคลังคำถามจาก1 เธสะโลนิกา 5 บท",
        "km": "តាមដានដំណើរថេស្សាឡូនិក ហើយឆ្លើយធនាគារសំណួរពី១ ថែស្សាឡូនីច 5 ជំពូក។"
      },
      "verse_reference": {
        "ko": "데살로니가전서 1-5",
        "en": "1 Thessalonians 1-5",
        "ja": "テサロニケ人への手紙第一 1-5",
        "ms": "1 Tesalonika 1-5",
        "th": "1 เธสะโลนิกา 1-5",
        "km": "១ ថែស្សាឡូនីច 1-5"
      },
      "verse_summary": {
        "ko": "데살로니가 복습",
        "en": "Thessalonica Review",
        "ja": "テサロニケ 復習",
        "ms": "Tesalonika Ulang kaji",
        "th": "เธสะโลนิกา ทบทวน",
        "km": "ថេស្សាឡូនិក រំលឹក"
      }
    },
    {
      "card_id": "CARD-2TH-001",
      "world_id": "W_NT_PAUL",
      "card_type": "book",
      "asset_key": "asset.card.2th-001",
      "title": {
        "ko": "데살로니가",
        "en": "Thessalonica",
        "ja": "テサロニケ",
        "ms": "Tesalonika",
        "th": "เธสะโลนิกา",
        "km": "ថេស្សាឡូនិក"
      },
      "summary": {
        "ko": "데살로니가 여정에서 데살로니가후서 3장 본문 문제를 풉니다.",
        "en": "Follow Thessalonica and answer 2 Thessalonians 3 chapters question bank.",
        "ja": "テサロニケの旅で、テサロニケ人への手紙第二3章の問題バンクに答えます。",
        "ms": "Ikuti Tesalonika dan jawab bank soalan 2 Tesalonika 3 bab.",
        "th": "ติดตามเส้นทางเธสะโลนิกาและตอบคลังคำถามจาก2 เธสะโลนิกา 3 บท",
        "km": "តាមដានដំណើរថេស្សាឡូនិក ហើយឆ្លើយធនាគារសំណួរពី២ ថែស្សាឡូនីច 3 ជំពូក។"
      },
      "verse_reference": {
        "ko": "데살로니가후서 1-3",
        "en": "2 Thessalonians 1-3",
        "ja": "テサロニケ人への手紙第二 1-3",
        "ms": "2 Tesalonika 1-3",
        "th": "2 เธสะโลนิกา 1-3",
        "km": "២ ថែស្សាឡូនីច 1-3"
      },
      "verse_summary": {
        "ko": "데살로니가 복습",
        "en": "Thessalonica Review",
        "ja": "テサロニケ 復習",
        "ms": "Tesalonika Ulang kaji",
        "th": "เธสะโลนิกา ทบทวน",
        "km": "ថេស្សាឡូនិក រំលឹក"
      }
    },
    {
      "card_id": "CARD-1TI-001",
      "world_id": "W_NT_PAUL",
      "card_type": "book",
      "asset_key": "asset.card.1ti-001",
      "title": {
        "ko": "에베소",
        "en": "Ephesus",
        "ja": "エフェソ",
        "ms": "Efesus",
        "th": "เอเฟซัส",
        "km": "អេភេសូរ"
      },
      "summary": {
        "ko": "에베소 여정에서 디모데전서 6장 본문 문제를 풉니다.",
        "en": "Follow Ephesus and answer 1 Timothy 6 chapters question bank.",
        "ja": "エフェソの旅で、テモテへの手紙第一6章の問題バンクに答えます。",
        "ms": "Ikuti Efesus dan jawab bank soalan 1 Timotius 6 bab.",
        "th": "ติดตามเส้นทางเอเฟซัสและตอบคลังคำถามจาก1 ทิโมธี 6 บท",
        "km": "តាមដានដំណើរអេភេសូរ ហើយឆ្លើយធនាគារសំណួរពី១ ធីម៉ូថេ 6 ជំពូក។"
      },
      "verse_reference": {
        "ko": "디모데전서 1-6",
        "en": "1 Timothy 1-6",
        "ja": "テモテへの手紙第一 1-6",
        "ms": "1 Timotius 1-6",
        "th": "1 ทิโมธี 1-6",
        "km": "១ ធីម៉ូថេ 1-6"
      },
      "verse_summary": {
        "ko": "에베소 복습",
        "en": "Ephesus Review",
        "ja": "エフェソ 復習",
        "ms": "Efesus Ulang kaji",
        "th": "เอเฟซัส ทบทวน",
        "km": "អេភេសូរ រំលឹក"
      }
    },
    {
      "card_id": "CARD-2TI-001",
      "world_id": "W_NT_PAUL",
      "card_type": "book",
      "asset_key": "asset.card.2ti-001",
      "title": {
        "ko": "로마 감옥",
        "en": "Rome Prison",
        "ja": "ローマの獄",
        "ms": "Penjara Roma",
        "th": "คุกในโรม",
        "km": "គុកនៅរ៉ូម"
      },
      "summary": {
        "ko": "로마 감옥 여정에서 디모데후서 4장 본문 문제를 풉니다.",
        "en": "Follow Prison in Rome and answer 2 Timothy 4 chapters question bank.",
        "ja": "ローマの獄の旅で、テモテへの手紙第二4章の問題バンクに答えます。",
        "ms": "Ikuti Penjara Roma dan jawab bank soalan 2 Timotius 4 bab.",
        "th": "ติดตามเส้นทางคุกในโรมและตอบคลังคำถามจาก2 ทิโมธี 4 บท",
        "km": "តាមដានដំណើរគុកនៅរ៉ូម ហើយឆ្លើយធនាគារសំណួរពី២ ធីម៉ូថេ 4 ជំពូក។"
      },
      "verse_reference": {
        "ko": "디모데후서 1-4",
        "en": "2 Timothy 1-4",
        "ja": "テモテへの手紙第二 1-4",
        "ms": "2 Timotius 1-4",
        "th": "2 ทิโมธี 1-4",
        "km": "២ ធីម៉ូថេ 1-4"
      },
      "verse_summary": {
        "ko": "로마 감옥 복습",
        "en": "Rome Prison Review",
        "ja": "ローマの獄 復習",
        "ms": "Penjara Roma Ulang kaji",
        "th": "คุกในโรม ทบทวน",
        "km": "គុកនៅរ៉ូម រំលឹក"
      }
    },
    {
      "card_id": "CARD-TIT-001",
      "world_id": "W_NT_PAUL",
      "card_type": "book",
      "asset_key": "asset.card.tit-001",
      "title": {
        "ko": "그레데",
        "en": "Crete",
        "ja": "クレタ",
        "ms": "Kreta",
        "th": "เกาะครีต",
        "km": "ក្រេត"
      },
      "summary": {
        "ko": "그레데 여정에서 디도서 3장 본문 문제를 풉니다.",
        "en": "Follow Crete and answer Titus 3 chapters question bank.",
        "ja": "クレタの旅で、テトスへの手紙3章の問題バンクに答えます。",
        "ms": "Ikuti Kreta dan jawab bank soalan Titus 3 bab.",
        "th": "ติดตามเส้นทางเกาะครีตและตอบคลังคำถามจากทิตัส 3 บท",
        "km": "តាមដានដំណើរក្រេត ហើយឆ្លើយធនាគារសំណួរពីទីតុស 3 ជំពូក។"
      },
      "verse_reference": {
        "ko": "디도서 1-3",
        "en": "Titus 1-3",
        "ja": "テトスへの手紙 1-3",
        "ms": "Titus 1-3",
        "th": "ทิตัส 1-3",
        "km": "ទីតុស 1-3"
      },
      "verse_summary": {
        "ko": "그레데 복습",
        "en": "Crete Review",
        "ja": "クレタ 復習",
        "ms": "Kreta Ulang kaji",
        "th": "เกาะครีต ทบทวน",
        "km": "ក្រេត រំលឹក"
      }
    },
    {
      "card_id": "CARD-PHM-001",
      "world_id": "W_NT_PAUL",
      "card_type": "book",
      "asset_key": "asset.card.phm-001",
      "title": {
        "ko": "골로새",
        "en": "Colossae",
        "ja": "コロサイ",
        "ms": "Kolose",
        "th": "โคโลสี",
        "km": "កូល៉ុស"
      },
      "summary": {
        "ko": "골로새 여정에서 빌레몬서 1장 본문 문제를 풉니다.",
        "en": "Follow Colossae and answer Philemon 1 chapters question bank.",
        "ja": "コロサイの旅で、ピレモンへの手紙1章の問題バンクに答えます。",
        "ms": "Ikuti Kolose dan jawab bank soalan Filemon 1 bab.",
        "th": "ติดตามเส้นทางโคโลสีและตอบคลังคำถามจากฟีเลโมน 1 บท",
        "km": "តាមដានដំណើរកូល៉ុស ហើយឆ្លើយធនាគារសំណួរពីភីលេម៉ូន 1 ជំពូក។"
      },
      "verse_reference": {
        "ko": "빌레몬서 1",
        "en": "Philemon 1",
        "ja": "ピレモンへの手紙 1",
        "ms": "Filemon 1",
        "th": "ฟีเลโมน 1",
        "km": "ភីលេម៉ូន 1"
      },
      "verse_summary": {
        "ko": "골로새 복습",
        "en": "Colossae Review",
        "ja": "コロサイ 復習",
        "ms": "Kolose Ulang kaji",
        "th": "โคโลสี ทบทวน",
        "km": "កូល៉ុស រំលឹក"
      }
    },
    {
      "card_id": "CARD-ROM-REVIEW-14",
      "world_id": "W_NT_PAUL",
      "card_type": "review",
      "asset_key": "asset.card.rom-review-14",
      "title": {
        "ko": "로마+",
        "en": "Rome+",
        "ja": "ローマ+",
        "ms": "Roma+",
        "th": "โรม+",
        "km": "រ៉ូម+"
      },
      "summary": {
        "ko": "로마 길에서 로마서 주요 사건을 다시 확인합니다.",
        "en": "Review the main Romans events along Rome.",
        "ja": "ローマの道で、ローマ人への手紙の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Roma di sepanjang Roma.",
        "th": "ทบทวนเหตุการณ์สำคัญของโรมตามเส้นทางโรม",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃរ៉ូម តាមផ្លូវរ៉ូម។"
      },
      "verse_reference": {
        "ko": "로마서 1-16",
        "en": "Romans 1-16",
        "ja": "ローマ人への手紙 1-16",
        "ms": "Roma 1-16",
        "th": "โรม 1-16",
        "km": "រ៉ូម 1-16"
      },
      "verse_summary": {
        "ko": "로마+ 복습",
        "en": "Rome+ Review",
        "ja": "ローマ+ 復習",
        "ms": "Roma+ Ulang kaji",
        "th": "โรม+ ทบทวน",
        "km": "រ៉ូម+ រំលឹក"
      }
    },
    {
      "card_id": "CARD-1CO-REVIEW-15",
      "world_id": "W_NT_PAUL",
      "card_type": "review",
      "asset_key": "asset.card.1co-review-15",
      "title": {
        "ko": "고린도+",
        "en": "Corinth+",
        "ja": "コリント+",
        "ms": "Korintus+",
        "th": "โครินธ์+",
        "km": "កូរិនថូស+"
      },
      "summary": {
        "ko": "고린도 길에서 고린도전서 주요 사건을 다시 확인합니다.",
        "en": "Review the main 1 Corinthians events along Corinth.",
        "ja": "コリントの道で、コリント人への手紙第一の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama 1 Korintus di sepanjang Korintus.",
        "th": "ทบทวนเหตุการณ์สำคัญของ1 โครินธ์ตามเส้นทางโครินธ์",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃ១ កូរិនថូស តាមផ្លូវកូរិនថូស។"
      },
      "verse_reference": {
        "ko": "고린도전서 1-16",
        "en": "1 Corinthians 1-16",
        "ja": "コリント人への手紙第一 1-16",
        "ms": "1 Korintus 1-16",
        "th": "1 โครินธ์ 1-16",
        "km": "១ កូរិនថូស 1-16"
      },
      "verse_summary": {
        "ko": "고린도+ 복습",
        "en": "Corinth+ Review",
        "ja": "コリント+ 復習",
        "ms": "Korintus+ Ulang kaji",
        "th": "โครินธ์+ ทบทวน",
        "km": "កូរិនថូស+ រំលឹក"
      }
    },
    {
      "card_id": "CARD-HEB-001",
      "world_id": "W_NT_GEN",
      "card_type": "book",
      "asset_key": "asset.card.heb-001",
      "title": {
        "ko": "성전 그림자",
        "en": "Temple Pattern",
        "ja": "神殿の型",
        "ms": "Pola Bait Suci",
        "th": "แบบอย่างพระวิหาร",
        "km": "គំរូព្រះវិហារ"
      },
      "summary": {
        "ko": "예루살렘 성전 그림자 여정에서 히브리서 13장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem Temple Pattern and answer Hebrews 13 chapters question bank.",
        "ja": "エルサレム神殿の型の旅で、ヘブル人への手紙13章の問題バンクに答えます。",
        "ms": "Ikuti Pola Bait Suci Yerusalem dan jawab bank soalan Ibrani 13 bab.",
        "th": "ติดตามเส้นทางแบบอย่างพระวิหารเยรูซาเล็มและตอบคลังคำถามจากฮีบรู 13 บท",
        "km": "តាមដានដំណើរគំរូព្រះវិហារយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីហេព្រើរ 13 ជំពូក។"
      },
      "verse_reference": {
        "ko": "히브리서 1-13",
        "en": "Hebrews 1-13",
        "ja": "ヘブル人への手紙 1-13",
        "ms": "Ibrani 1-13",
        "th": "ฮีบรู 1-13",
        "km": "ហេព្រើរ 1-13"
      },
      "verse_summary": {
        "ko": "성전 그림자 복습",
        "en": "Temple Pattern Review",
        "ja": "神殿の型 復習",
        "ms": "Pola Bait Suci Ulang kaji",
        "th": "แบบอย่างพระวิหาร ทบทวน",
        "km": "គំរូព្រះវិហារ រំលឹក"
      }
    },
    {
      "card_id": "CARD-JAS-001",
      "world_id": "W_NT_GEN",
      "card_type": "book",
      "asset_key": "asset.card.jas-001",
      "title": {
        "ko": "흩어진 지파",
        "en": "Scattered Tribes",
        "ja": "散らされた部族",
        "ms": "Suku yang terserak",
        "th": "เผ่าที่กระจัดกระจาย",
        "km": "កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ"
      },
      "summary": {
        "ko": "예루살렘 · 흩어진 지파 여정에서 야고보서 5장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem · Scattered Tribes and answer James 5 chapters question bank.",
        "ja": "エルサレム · 散らされた部族の旅で、ヤコブの手紙5章の問題バンクに答えます。",
        "ms": "Ikuti Yerusalem · Suku yang terserak dan jawab bank soalan Yakobus 5 bab.",
        "th": "ติดตามเส้นทางเยรูซาเล็ม · เผ่าที่กระจัดกระจายและตอบคลังคำถามจากยากอบ 5 บท",
        "km": "តាមដានដំណើរយេរូសាឡឹម · កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ ហើយឆ្លើយធនាគារសំណួរពីយ៉ាកុប 5 ជំពូក។"
      },
      "verse_reference": {
        "ko": "야고보서 1-5",
        "en": "James 1-5",
        "ja": "ヤコブの手紙 1-5",
        "ms": "Yakobus 1-5",
        "th": "ยากอบ 1-5",
        "km": "យ៉ាកុប 1-5"
      },
      "verse_summary": {
        "ko": "흩어진 지파 복습",
        "en": "Scattered Tribes Review",
        "ja": "散らされた部族 復習",
        "ms": "Suku yang terserak Ulang kaji",
        "th": "เผ่าที่กระจัดกระจาย ทบทวน",
        "km": "កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ រំលឹក"
      }
    },
    {
      "card_id": "CARD-1PE-001",
      "world_id": "W_NT_GEN",
      "card_type": "book",
      "asset_key": "asset.card.1pe-001",
      "title": {
        "ko": "소아시아",
        "en": "Asia Minor",
        "ja": "小アジア",
        "ms": "Asia Kecil",
        "th": "เอเชียน้อย",
        "km": "អាស៊ីតូច"
      },
      "summary": {
        "ko": "소아시아 흩어진 성도 여정에서 베드로전서 5장 본문 문제를 풉니다.",
        "en": "Follow Scattered Believers in Asia Minor and answer 1 Peter 5 chapters question bank.",
        "ja": "小アジアに散らされた信徒の旅で、ペテロの手紙第一5章の問題バンクに答えます。",
        "ms": "Ikuti Orang percaya yang terserak di Asia Kecil dan jawab bank soalan 1 Petrus 5 bab.",
        "th": "ติดตามเส้นทางผู้เชื่อที่กระจัดกระจายในเอเชียน้อยและตอบคลังคำถามจาก1 เปโตร 5 บท",
        "km": "តាមដានដំណើរអ្នកជឿដែលខ្ចាត់ខ្ចាយនៅអាស៊ីតូច ហើយឆ្លើយធនាគារសំណួរពី១ ពេត្រុស 5 ជំពូក។"
      },
      "verse_reference": {
        "ko": "베드로전서 1-5",
        "en": "1 Peter 1-5",
        "ja": "ペテロの手紙第一 1-5",
        "ms": "1 Petrus 1-5",
        "th": "1 เปโตร 1-5",
        "km": "១ ពេត្រុស 1-5"
      },
      "verse_summary": {
        "ko": "소아시아 복습",
        "en": "Asia Minor Review",
        "ja": "小アジア 復習",
        "ms": "Asia Kecil Ulang kaji",
        "th": "เอเชียน้อย ทบทวน",
        "km": "អាស៊ីតូច រំលឹក"
      }
    },
    {
      "card_id": "CARD-2PE-001",
      "world_id": "W_NT_GEN",
      "card_type": "book",
      "asset_key": "asset.card.2pe-001",
      "title": {
        "ko": "소아시아",
        "en": "Asia Minor",
        "ja": "小アジア",
        "ms": "Asia Kecil",
        "th": "เอเชียน้อย",
        "km": "អាស៊ីតូច"
      },
      "summary": {
        "ko": "소아시아 교회 여정에서 베드로후서 3장 본문 문제를 풉니다.",
        "en": "Follow Churches in Asia Minor and answer 2 Peter 3 chapters question bank.",
        "ja": "小アジアの教会の旅で、ペテロの手紙第二3章の問題バンクに答えます。",
        "ms": "Ikuti Jemaat di Asia Kecil dan jawab bank soalan 2 Petrus 3 bab.",
        "th": "ติดตามเส้นทางคริสตจักรในเอเชียน้อยและตอบคลังคำถามจาก2 เปโตร 3 บท",
        "km": "តាមដានដំណើរពួកជំនុំនៅអាស៊ីតូច ហើយឆ្លើយធនាគារសំណួរពី២ ពេត្រុស 3 ជំពូក។"
      },
      "verse_reference": {
        "ko": "베드로후서 1-3",
        "en": "2 Peter 1-3",
        "ja": "ペテロの手紙第二 1-3",
        "ms": "2 Petrus 1-3",
        "th": "2 เปโตร 1-3",
        "km": "២ ពេត្រុស 1-3"
      },
      "verse_summary": {
        "ko": "소아시아 복습",
        "en": "Asia Minor Review",
        "ja": "小アジア 復習",
        "ms": "Asia Kecil Ulang kaji",
        "th": "เอเชียน้อย ทบทวน",
        "km": "អាស៊ីតូច រំលឹក"
      }
    },
    {
      "card_id": "CARD-1JN-001",
      "world_id": "W_NT_GEN",
      "card_type": "book",
      "asset_key": "asset.card.1jn-001",
      "title": {
        "ko": "에베소·소아시아",
        "en": "Ephesus·Asia Minor",
        "ja": "エフェソ·小アジア",
        "ms": "Efesus·Asia Kecil",
        "th": "เอเฟซัส·เอเชียน้อย",
        "km": "អេភេសូរ·អាស៊ីតូច"
      },
      "summary": {
        "ko": "에베소 · 소아시아 여정에서 요한일서 5장 본문 문제를 풉니다.",
        "en": "Follow Ephesus · Asia Minor and answer 1 John 5 chapters question bank.",
        "ja": "エフェソ · 小アジアの旅で、ヨハネの手紙第一5章の問題バンクに答えます。",
        "ms": "Ikuti Efesus · Asia Kecil dan jawab bank soalan 1 Yohanes 5 bab.",
        "th": "ติดตามเส้นทางเอเฟซัส · เอเชียน้อยและตอบคลังคำถามจาก1 ยอห์น 5 บท",
        "km": "តាមដានដំណើរអេភេសូរ · អាស៊ីតូច ហើយឆ្លើយធនាគារសំណួរពី១ យ៉ូហាន 5 ជំពូក។"
      },
      "verse_reference": {
        "ko": "요한일서 1-5",
        "en": "1 John 1-5",
        "ja": "ヨハネの手紙第一 1-5",
        "ms": "1 Yohanes 1-5",
        "th": "1 ยอห์น 1-5",
        "km": "១ យ៉ូហាន 1-5"
      },
      "verse_summary": {
        "ko": "에베소·소아시아 복습",
        "en": "Ephesus·Asia Minor Review",
        "ja": "エフェソ·小アジア 復習",
        "ms": "Efesus·Asia Kecil Ulang kaji",
        "th": "เอเฟซัส·เอเชียน้อย ทบทวน",
        "km": "អេភេសូរ·អាស៊ីតូច រំលឹក"
      }
    },
    {
      "card_id": "CARD-2JN-001",
      "world_id": "W_NT_GEN",
      "card_type": "book",
      "asset_key": "asset.card.2jn-001",
      "title": {
        "ko": "소아시아",
        "en": "Asia Minor",
        "ja": "小アジア",
        "ms": "Asia Kecil",
        "th": "เอเชียน้อย",
        "km": "អាស៊ីតូច"
      },
      "summary": {
        "ko": "소아시아 교회 여정에서 요한이서 1장 본문 문제를 풉니다.",
        "en": "Follow Churches in Asia Minor and answer 2 John 1 chapters question bank.",
        "ja": "小アジアの教会の旅で、ヨハネの手紙第二1章の問題バンクに答えます。",
        "ms": "Ikuti Jemaat di Asia Kecil dan jawab bank soalan 2 Yohanes 1 bab.",
        "th": "ติดตามเส้นทางคริสตจักรในเอเชียน้อยและตอบคลังคำถามจาก2 ยอห์น 1 บท",
        "km": "តាមដានដំណើរពួកជំនុំនៅអាស៊ីតូច ហើយឆ្លើយធនាគារសំណួរពី២ យ៉ូហាន 1 ជំពូក។"
      },
      "verse_reference": {
        "ko": "요한이서 1",
        "en": "2 John 1",
        "ja": "ヨハネの手紙第二 1",
        "ms": "2 Yohanes 1",
        "th": "2 ยอห์น 1",
        "km": "២ យ៉ូហាន 1"
      },
      "verse_summary": {
        "ko": "소아시아 복습",
        "en": "Asia Minor Review",
        "ja": "小アジア 復習",
        "ms": "Asia Kecil Ulang kaji",
        "th": "เอเชียน้อย ทบทวน",
        "km": "អាស៊ីតូច រំលឹក"
      }
    },
    {
      "card_id": "CARD-3JN-001",
      "world_id": "W_NT_GEN",
      "card_type": "book",
      "asset_key": "asset.card.3jn-001",
      "title": {
        "ko": "소아시아",
        "en": "Asia Minor",
        "ja": "小アジア",
        "ms": "Asia Kecil",
        "th": "เอเชียน้อย",
        "km": "អាស៊ីតូច"
      },
      "summary": {
        "ko": "소아시아 교회 여정에서 요한삼서 1장 본문 문제를 풉니다.",
        "en": "Follow Churches in Asia Minor and answer 3 John 1 chapters question bank.",
        "ja": "小アジアの教会の旅で、ヨハネの手紙第三1章の問題バンクに答えます。",
        "ms": "Ikuti Jemaat di Asia Kecil dan jawab bank soalan 3 Yohanes 1 bab.",
        "th": "ติดตามเส้นทางคริสตจักรในเอเชียน้อยและตอบคลังคำถามจาก3 ยอห์น 1 บท",
        "km": "តាមដានដំណើរពួកជំនុំនៅអាស៊ីតូច ហើយឆ្លើយធនាគារសំណួរពី៣ យ៉ូហាន 1 ជំពូក។"
      },
      "verse_reference": {
        "ko": "요한삼서 1",
        "en": "3 John 1",
        "ja": "ヨハネの手紙第三 1",
        "ms": "3 Yohanes 1",
        "th": "3 ยอห์น 1",
        "km": "៣ យ៉ូហាន 1"
      },
      "verse_summary": {
        "ko": "소아시아 복습",
        "en": "Asia Minor Review",
        "ja": "小アジア 復習",
        "ms": "Asia Kecil Ulang kaji",
        "th": "เอเชียน้อย ทบทวน",
        "km": "អាស៊ីតូច រំលឹក"
      }
    },
    {
      "card_id": "CARD-JUD-001",
      "world_id": "W_NT_GEN",
      "card_type": "book",
      "asset_key": "asset.card.jud-001",
      "title": {
        "ko": "예루살렘 공동체",
        "en": "Jerusalem Community",
        "ja": "エルサレム共同体",
        "ms": "Komuniti Yerusalem",
        "th": "ชุมชนเยรูซาเล็ม",
        "km": "សហគមន៍យេរូសាឡឹម"
      },
      "summary": {
        "ko": "예루살렘 형제 공동체 여정에서 유다서 1장 본문 문제를 풉니다.",
        "en": "Follow Jerusalem Brotherly Community and answer Jude 1 chapters question bank.",
        "ja": "エルサレムの兄弟共同体の旅で、ユダの手紙1章の問題バンクに答えます。",
        "ms": "Ikuti Komuniti saudara Yerusalem dan jawab bank soalan Yudas 1 bab.",
        "th": "ติดตามเส้นทางชุมชนพี่น้องเยรูซาเล็มและตอบคลังคำถามจากยูดา 1 บท",
        "km": "តាមដានដំណើរសហគមន៍បងប្អូនយេរូសាឡឹម ហើយឆ្លើយធនាគារសំណួរពីយូដាស 1 ជំពូក។"
      },
      "verse_reference": {
        "ko": "유다서 1",
        "en": "Jude 1",
        "ja": "ユダの手紙 1",
        "ms": "Yudas 1",
        "th": "ยูดา 1",
        "km": "យូដាស 1"
      },
      "verse_summary": {
        "ko": "예루살렘 공동체 복습",
        "en": "Jerusalem Community Review",
        "ja": "エルサレム共同体 復習",
        "ms": "Komuniti Yerusalem Ulang kaji",
        "th": "ชุมชนเยรูซาเล็ม ทบทวน",
        "km": "សហគមន៍យេរូសាឡឹម រំលឹក"
      }
    },
    {
      "card_id": "CARD-HEB-REVIEW-09",
      "world_id": "W_NT_GEN",
      "card_type": "review",
      "asset_key": "asset.card.heb-review-09",
      "title": {
        "ko": "성전 그림자+",
        "en": "Temple Pattern+",
        "ja": "神殿の型+",
        "ms": "Pola Bait Suci+",
        "th": "แบบอย่างพระวิหาร+",
        "km": "គំរូព្រះវិហារ+"
      },
      "summary": {
        "ko": "예루살렘 성전 그림자 길에서 히브리서 주요 사건을 다시 확인합니다.",
        "en": "Review the main Hebrews events along Jerusalem Temple Pattern.",
        "ja": "エルサレム神殿の型の道で、ヘブル人への手紙の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Ibrani di sepanjang Pola Bait Suci Yerusalem.",
        "th": "ทบทวนเหตุการณ์สำคัญของฮีบรูตามเส้นทางแบบอย่างพระวิหารเยรูซาเล็ม",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃហេព្រើរ តាមផ្លូវគំរូព្រះវិហារយេរូសាឡឹម។"
      },
      "verse_reference": {
        "ko": "히브리서 1-13",
        "en": "Hebrews 1-13",
        "ja": "ヘブル人への手紙 1-13",
        "ms": "Ibrani 1-13",
        "th": "ฮีบรู 1-13",
        "km": "ហេព្រើរ 1-13"
      },
      "verse_summary": {
        "ko": "성전 그림자+ 복습",
        "en": "Temple Pattern+ Review",
        "ja": "神殿の型+ 復習",
        "ms": "Pola Bait Suci+ Ulang kaji",
        "th": "แบบอย่างพระวิหาร+ ทบทวน",
        "km": "គំរូព្រះវិហារ+ រំលឹក"
      }
    },
    {
      "card_id": "CARD-JAS-REVIEW-10",
      "world_id": "W_NT_GEN",
      "card_type": "review",
      "asset_key": "asset.card.jas-review-10",
      "title": {
        "ko": "흩어진 지파+",
        "en": "Scattered Tribes+",
        "ja": "散らされた部族+",
        "ms": "Suku yang terserak+",
        "th": "เผ่าที่กระจัดกระจาย+",
        "km": "កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ+"
      },
      "summary": {
        "ko": "예루살렘 · 흩어진 지파 길에서 야고보서 주요 사건을 다시 확인합니다.",
        "en": "Review the main James events along Jerusalem · Scattered Tribes.",
        "ja": "エルサレム · 散らされた部族の道で、ヤコブの手紙の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Yakobus di sepanjang Yerusalem · Suku yang terserak.",
        "th": "ทบทวนเหตุการณ์สำคัญของยากอบตามเส้นทางเยรูซาเล็ม · เผ่าที่กระจัดกระจาย",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃយ៉ាកុប តាមផ្លូវយេរូសាឡឹម · កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ។"
      },
      "verse_reference": {
        "ko": "야고보서 1-5",
        "en": "James 1-5",
        "ja": "ヤコブの手紙 1-5",
        "ms": "Yakobus 1-5",
        "th": "ยากอบ 1-5",
        "km": "យ៉ាកុប 1-5"
      },
      "verse_summary": {
        "ko": "흩어진 지파+ 복습",
        "en": "Scattered Tribes+ Review",
        "ja": "散らされた部族+ 復習",
        "ms": "Suku yang terserak+ Ulang kaji",
        "th": "เผ่าที่กระจัดกระจาย+ ทบทวน",
        "km": "កុលសម្ព័ន្ធដែលខ្ចាត់ខ្ចាយ+ រំលឹក"
      }
    },
    {
      "card_id": "CARD-REV-001",
      "world_id": "W_NT_PROP",
      "card_type": "book",
      "asset_key": "asset.card.rev-001",
      "title": {
        "ko": "밧모섬·일곱 교회",
        "en": "Patmos·Seven Churches",
        "ja": "パトモス·七つの教会",
        "ms": "Patmos·Tujuh jemaat",
        "th": "ปัทมอส·คริสตจักรทั้งเจ็ด",
        "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ"
      },
      "summary": {
        "ko": "밧모섬 · 소아시아 일곱 교회 여정에서 요한계시록 22장 본문 문제를 풉니다.",
        "en": "Follow Patmos · Seven Churches of Asia and answer Revelation 22 chapters question bank.",
        "ja": "パトモス · アジアの七つの教会の旅で、黙示録22章の問題バンクに答えます。",
        "ms": "Ikuti Patmos · Tujuh jemaat Asia dan jawab bank soalan Wahyu 22 bab.",
        "th": "ติดตามเส้นทางปัทมอส · คริสตจักรทั้งเจ็ดในเอเชียและตอบคลังคำถามจากวิวรณ์ 22 บท",
        "km": "តាមដានដំណើរប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី ហើយឆ្លើយធនាគារសំណួរពីវិវរណៈ 22 ជំពូក។"
      },
      "verse_reference": {
        "ko": "요한계시록 1-22",
        "en": "Revelation 1-22",
        "ja": "黙示録 1-22",
        "ms": "Wahyu 1-22",
        "th": "วิวรณ์ 1-22",
        "km": "វិវរណៈ 1-22"
      },
      "verse_summary": {
        "ko": "밧모섬·일곱 교회 복습",
        "en": "Patmos·Seven Churches Review",
        "ja": "パトモス·七つの教会 復習",
        "ms": "Patmos·Tujuh jemaat Ulang kaji",
        "th": "ปัทมอส·คริสตจักรทั้งเจ็ด ทบทวน",
        "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ រំលឹក"
      }
    },
    {
      "card_id": "CARD-REV-REVIEW-02",
      "world_id": "W_NT_PROP",
      "card_type": "review",
      "asset_key": "asset.card.rev-review-02",
      "title": {
        "ko": "밧모섬·일곱 교회+",
        "en": "Patmos·Seven Churches+",
        "ja": "パトモス·七つの教会+",
        "ms": "Patmos·Tujuh jemaat+",
        "th": "ปัทมอส·คริสตจักรทั้งเจ็ด+",
        "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+"
      },
      "summary": {
        "ko": "밧모섬 · 소아시아 일곱 교회 길에서 요한계시록 주요 사건을 다시 확인합니다.",
        "en": "Review the main Revelation events along Patmos · Seven Churches of Asia.",
        "ja": "パトモス · アジアの七つの教会の道で、黙示録の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Wahyu di sepanjang Patmos · Tujuh jemaat Asia.",
        "th": "ทบทวนเหตุการณ์สำคัญของวิวรณ์ตามเส้นทางปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃវិវរណៈ តាមផ្លូវប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី។"
      },
      "verse_reference": {
        "ko": "요한계시록 1-22",
        "en": "Revelation 1-22",
        "ja": "黙示録 1-22",
        "ms": "Wahyu 1-22",
        "th": "วิวรณ์ 1-22",
        "km": "វិវរណៈ 1-22"
      },
      "verse_summary": {
        "ko": "밧모섬·일곱 교회+ 복습",
        "en": "Patmos·Seven Churches+ Review",
        "ja": "パトモス·七つの教会+ 復習",
        "ms": "Patmos·Tujuh jemaat+ Ulang kaji",
        "th": "ปัทมอส·คริสตจักรทั้งเจ็ด+ ทบทวน",
        "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+ រំលឹក"
      }
    },
    {
      "card_id": "CARD-REV-REVIEW-03",
      "world_id": "W_NT_PROP",
      "card_type": "review",
      "asset_key": "asset.card.rev-review-03",
      "title": {
        "ko": "밧모섬·일곱 교회+",
        "en": "Patmos·Seven Churches+",
        "ja": "パトモス·七つの教会+",
        "ms": "Patmos·Tujuh jemaat+",
        "th": "ปัทมอส·คริสตจักรทั้งเจ็ด+",
        "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+"
      },
      "summary": {
        "ko": "밧모섬 · 소아시아 일곱 교회 길에서 요한계시록 주요 사건을 다시 확인합니다.",
        "en": "Review the main Revelation events along Patmos · Seven Churches of Asia.",
        "ja": "パトモス · アジアの七つの教会の道で、黙示録の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Wahyu di sepanjang Patmos · Tujuh jemaat Asia.",
        "th": "ทบทวนเหตุการณ์สำคัญของวิวรณ์ตามเส้นทางปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃវិវរណៈ តាមផ្លូវប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី។"
      },
      "verse_reference": {
        "ko": "요한계시록 1-22",
        "en": "Revelation 1-22",
        "ja": "黙示録 1-22",
        "ms": "Wahyu 1-22",
        "th": "วิวรณ์ 1-22",
        "km": "វិវរណៈ 1-22"
      },
      "verse_summary": {
        "ko": "밧모섬·일곱 교회+ 복습",
        "en": "Patmos·Seven Churches+ Review",
        "ja": "パトモス·七つの教会+ 復習",
        "ms": "Patmos·Tujuh jemaat+ Ulang kaji",
        "th": "ปัทมอส·คริสตจักรทั้งเจ็ด+ ทบทวน",
        "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+ រំលឹក"
      }
    },
    {
      "card_id": "CARD-REV-REVIEW-04",
      "world_id": "W_NT_PROP",
      "card_type": "review",
      "asset_key": "asset.card.rev-review-04",
      "title": {
        "ko": "밧모섬·일곱 교회+",
        "en": "Patmos·Seven Churches+",
        "ja": "パトモス·七つの教会+",
        "ms": "Patmos·Tujuh jemaat+",
        "th": "ปัทมอส·คริสตจักรทั้งเจ็ด+",
        "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+"
      },
      "summary": {
        "ko": "밧모섬 · 소아시아 일곱 교회 길에서 요한계시록 주요 사건을 다시 확인합니다.",
        "en": "Review the main Revelation events along Patmos · Seven Churches of Asia.",
        "ja": "パトモス · アジアの七つの教会の道で、黙示録の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Wahyu di sepanjang Patmos · Tujuh jemaat Asia.",
        "th": "ทบทวนเหตุการณ์สำคัญของวิวรณ์ตามเส้นทางปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃវិវរណៈ តាមផ្លូវប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី។"
      },
      "verse_reference": {
        "ko": "요한계시록 1-22",
        "en": "Revelation 1-22",
        "ja": "黙示録 1-22",
        "ms": "Wahyu 1-22",
        "th": "วิวรณ์ 1-22",
        "km": "វិវរណៈ 1-22"
      },
      "verse_summary": {
        "ko": "밧모섬·일곱 교회+ 복습",
        "en": "Patmos·Seven Churches+ Review",
        "ja": "パトモス·七つの教会+ 復習",
        "ms": "Patmos·Tujuh jemaat+ Ulang kaji",
        "th": "ปัทมอส·คริสตจักรทั้งเจ็ด+ ทบทวน",
        "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+ រំលឹក"
      }
    },
    {
      "card_id": "CARD-REV-REVIEW-05",
      "world_id": "W_NT_PROP",
      "card_type": "review",
      "asset_key": "asset.card.rev-review-05",
      "title": {
        "ko": "밧모섬·일곱 교회+",
        "en": "Patmos·Seven Churches+",
        "ja": "パトモス·七つの教会+",
        "ms": "Patmos·Tujuh jemaat+",
        "th": "ปัทมอส·คริสตจักรทั้งเจ็ด+",
        "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+"
      },
      "summary": {
        "ko": "밧모섬 · 소아시아 일곱 교회 길에서 요한계시록 주요 사건을 다시 확인합니다.",
        "en": "Review the main Revelation events along Patmos · Seven Churches of Asia.",
        "ja": "パトモス · アジアの七つの教会の道で、黙示録の主な出来事を復習します。",
        "ms": "Ulang kaji peristiwa utama Wahyu di sepanjang Patmos · Tujuh jemaat Asia.",
        "th": "ทบทวนเหตุการณ์สำคัญของวิวรณ์ตามเส้นทางปัทมอส · คริสตจักรทั้งเจ็ดในเอเชีย",
        "km": "រំលឹកព្រឹត្តិការណ៍សំខាន់ៗនៃវិវរណៈ តាមផ្លូវប៉ាត់ម៉ូស · ពួកជំនុំទាំងប្រាំពីរនៅអាស៊ី។"
      },
      "verse_reference": {
        "ko": "요한계시록 1-22",
        "en": "Revelation 1-22",
        "ja": "黙示録 1-22",
        "ms": "Wahyu 1-22",
        "th": "วิวรณ์ 1-22",
        "km": "វិវរណៈ 1-22"
      },
      "verse_summary": {
        "ko": "밧모섬·일곱 교회+ 복습",
        "en": "Patmos·Seven Churches+ Review",
        "ja": "パトモス·七つの教会+ 復習",
        "ms": "Patmos·Tujuh jemaat+ Ulang kaji",
        "th": "ปัทมอส·คริสตจักรทั้งเจ็ด+ ทบทวน",
        "km": "ប៉ាត់ម៉ូស·ពួកជំនុំទាំងប្រាំពីរ+ រំលឹក"
      }
    }
  ],
  "badges": [
    {
      "badge_id": "BADGE-OT-PENT",
      "stage_id": "DEU-001",
      "title": {
        "ko": "구약 1. 모세오경 완주",
        "en": "Old Testament 1. Pentateuch Finisher",
        "ja": "旧約1. モーセ五書 完走",
        "ms": "Perjanjian Lama 1. Taurat Selesai",
        "th": "พันธสัญญาเดิม 1. โมเสสห้าเล่ม สำเร็จ",
        "km": "សញ្ញាចាស់ ១. បញ្ចកណ្ឌ បញ្ចប់"
      }
    },
    {
      "badge_id": "BADGE-OT-HIST",
      "stage_id": "RUT-REVIEW-15",
      "title": {
        "ko": "구약 2. 역사서 완주",
        "en": "Old Testament 2. Historical Books Finisher",
        "ja": "旧約2. 歴史書 完走",
        "ms": "Perjanjian Lama 2. Kitab Sejarah Selesai",
        "th": "พันธสัญญาเดิม 2. หนังสือประวัติศาสตร์ สำเร็จ",
        "km": "សញ្ញាចាស់ ២. សៀវភៅប្រវត្តិសាស្ត្រ បញ្ចប់"
      }
    },
    {
      "badge_id": "BADGE-OT-WIS",
      "stage_id": "SNG-001",
      "title": {
        "ko": "구약 3. 시가서 완주",
        "en": "Old Testament 3. Wisdom and Poetry Finisher",
        "ja": "旧約3. 知恵と詩 完走",
        "ms": "Perjanjian Lama 3. Hikmat dan Puisi Selesai",
        "th": "พันธสัญญาเดิม 3. ปัญญาและบทกวี สำเร็จ",
        "km": "សញ្ញាចាស់ ៣. ប្រាជ្ញា និងកំណាព្យ បញ្ចប់"
      }
    },
    {
      "badge_id": "BADGE-OT-MAJOR",
      "stage_id": "DAN-001",
      "title": {
        "ko": "구약 4. 대선지서 완주",
        "en": "Old Testament 4. Major Prophets Finisher",
        "ja": "旧約4. 大預言書 完走",
        "ms": "Perjanjian Lama 4. Nabi-nabi Besar Selesai",
        "th": "พันธสัญญาเดิม 4. ผู้เผยพระวจนะใหญ่ สำเร็จ",
        "km": "សញ្ញាចាស់ ៤. ហោរាធំ បញ្ចប់"
      }
    },
    {
      "badge_id": "BADGE-OT-MINOR",
      "stage_id": "AMO-REVIEW-15",
      "title": {
        "ko": "구약 5. 소선지서 완주",
        "en": "Old Testament 5. Minor Prophets Finisher",
        "ja": "旧約5. 小預言書 完走",
        "ms": "Perjanjian Lama 5. Nabi-nabi Kecil Selesai",
        "th": "พันธสัญญาเดิม 5. ผู้เผยพระวจนะเล็ก สำเร็จ",
        "km": "សញ្ញាចាស់ ៥. ហោរាតូច បញ្ចប់"
      }
    },
    {
      "badge_id": "BADGE-NT-GOS",
      "stage_id": "MAT-REVIEW-05",
      "title": {
        "ko": "신약 1. 복음서 완주",
        "en": "New Testament 1. Gospels Finisher",
        "ja": "新約1. 福音書 完走",
        "ms": "Perjanjian Baru 1. Injil Selesai",
        "th": "พันธสัญญาใหม่ 1. พระกิตติคุณ สำเร็จ",
        "km": "សញ្ញាថ្មី ១. ដំណឹងល្អ បញ្ចប់"
      }
    },
    {
      "badge_id": "BADGE-NT-ACTS",
      "stage_id": "ACT-REVIEW-05",
      "title": {
        "ko": "신약 2. 역사서 완주",
        "en": "New Testament 2. History Finisher",
        "ja": "新約2. 歴史書 完走",
        "ms": "Perjanjian Baru 2. Sejarah Selesai",
        "th": "พันธสัญญาใหม่ 2. ประวัติศาสตร์ สำเร็จ",
        "km": "សញ្ញាថ្មី ២. ប្រវត្តិសាស្ត្រ បញ្ចប់"
      }
    },
    {
      "badge_id": "BADGE-NT-PAUL",
      "stage_id": "1CO-REVIEW-15",
      "title": {
        "ko": "신약 3. 바울서신 완주",
        "en": "New Testament 3. Pauline Epistles Finisher",
        "ja": "新約3. パウロ書簡 完走",
        "ms": "Perjanjian Baru 3. Surat Paulus Selesai",
        "th": "พันธสัญญาใหม่ 3. จดหมายของเปาโล สำเร็จ",
        "km": "សញ្ញាថ្មី ៣. សំបុត្ររបស់ប៉ូល បញ្ចប់"
      }
    },
    {
      "badge_id": "BADGE-NT-GEN",
      "stage_id": "JAS-REVIEW-10",
      "title": {
        "ko": "신약 4. 공동서신 완주",
        "en": "New Testament 4. General Epistles Finisher",
        "ja": "新約4. 公同書簡 完走",
        "ms": "Perjanjian Baru 4. Surat Umum Selesai",
        "th": "พันธสัญญาใหม่ 4. จดหมายทั่วไป สำเร็จ",
        "km": "សញ្ញាថ្មី ៤. សំបុត្រទូទៅ បញ្ចប់"
      }
    },
    {
      "badge_id": "BADGE-NT-PROP",
      "stage_id": "REV-REVIEW-05",
      "title": {
        "ko": "신약 5. 예언서 완주",
        "en": "New Testament 5. Prophecy Finisher",
        "ja": "新約5. 預言書 完走",
        "ms": "Perjanjian Baru 5. Nubuat Selesai",
        "th": "พันธสัญญาใหม่ 5. คำพยากรณ์ สำเร็จ",
        "km": "សញ្ញាថ្មី ៥. ទំនាយ បញ្ចប់"
      }
    }
  ],
  "quizzes": []
};

  root.BIBLE_GAME_SEED = seed;

  if (typeof module !== "undefined" && module.exports) {
    module.exports = seed;
  }
})(typeof window !== "undefined" ? window : globalThis);
