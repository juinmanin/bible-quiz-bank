import assert from 'node:assert/strict';import fs from 'node:fs';
const bank=JSON.parse(fs.readFileSync('question-bank/bank.json','utf8')),locales=JSON.parse(fs.readFileSync('question-bank/translations.json','utf8'));
const issues=[];
for(const lang of ['en','ms'])for(const q of bank.questions){
 for(const text of [q.prompt,q.answer,q.explanation,...q.choices]){const translated=locales.strings[lang][text];if(!translated?.trim()||/[가-힣▁⁇♪�]|\[ Gambar|\[ Kotak|= = =|Perancis|lafal ayat|Muhammad/.test(translated))issues.push({id:q.id,lang,text,translation:translated||''});}
 if(lang==='ms')for(const field of ['prompt','explanation'])if(locales.strings.ms[q[field]]===locales.strings.en[q[field]])issues.push({id:q.id,lang,reason:'Malay sentence identical to English',text:q[field]});
 if(q.choices.length){const choices=q.choices.map(s=>locales.strings[lang][s]);if(new Set(choices).size!==choices.length)issues.push({id:q.id,lang,reason:'duplicate translated choices',choices});assert.ok(choices.includes(locales.strings[lang][q.answer]));}
}
for(const b of bank.books)for(const lang of ['ko','en','ms'])assert.ok(locales.books[b.id][lang]);
fs.writeFileSync('question-bank/LOCALE_VALIDATION.json',JSON.stringify({status:issues.length?'FAIL':'PASS',questions:bank.questions.length,languages:['ko','en','ms'],issues,review:'Structural checks; machine translation needs linguistic review'},null,2));
assert.equal(issues.length,0,JSON.stringify(issues.slice(0,8)));console.log('PASS: 2183 questions in three languages, no untranslated Korean, distinct choices, answer alignment');
