import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
const cfg={};vm.runInNewContext(fs.readFileSync(new URL('../reading-bank-config.js',import.meta.url),'utf8'),cfg);
const {url,publishableKey}=cfg.BIBLE_READING_CONFIG;const bank=JSON.parse(fs.readFileSync(new URL('../question-bank/bank.json',import.meta.url),'utf8'));
const headers={apikey:publishableKey,'Content-Type':'application/json'};
const rows=[];
for(let offset=0;offset<bank.questions.length;offset+=500){const r=await fetch(`${url}/rest/v1/bible_questions?select=payload&order=id&offset=${offset}&limit=500`,{headers});assert.ok(r.ok,`read ${r.status}`);rows.push(...await r.json());}
assert.deepEqual(rows.map(r=>r.payload).sort((a,b)=>a.id.localeCompare(b.id)),[...bank.questions].sort((a,b)=>a.id.localeCompare(b.id)));
async function rpc(args){const r=await fetch(`${url}/rest/v1/rpc/bible_quiz_random`,{method:'POST',headers,body:JSON.stringify(args)});assert.ok(r.ok,`rpc ${r.status}`);return r.json();}
const a=await rpc({p_book:'GEN',p_difficulty:'hard',p_origin:'new',p_count:3});assert.equal(a.length,3);assert.ok(a.every(q=>q.book_id==='GEN'&&q.difficulty==='hard'&&q.origin==='new'));
const b=await rpc({p_book:'GEN',p_difficulty:'hard',p_origin:'new',p_count:10,p_exclude:a.map(q=>q.id)});assert.equal(b.length,2);assert.ok(b.every(q=>!a.some(p=>p.id===q.id)));
assert.equal((await rpc({p_book:'GEN',p_theme:'gospels'})).length,0);
const day=await rpc({p_day:1,p_count:50});assert.ok(day.length);assert.ok(day.every(q=>q.mcheyne_days.includes(1)));
const cross=await rpc({p_theme:'ot_nt',p_difficulty:'hard',p_count:50});assert.ok(cross.length);assert.ok(cross.every(q=>q.tags.includes('ot_nt')));
const shuffles=await Promise.all(Array.from({length:3},()=>rpc({p_count:10})));assert.ok(new Set(shuffles.map(s=>s.map(q=>q.id).join(','))).size>1);
const report={status:'PASS',project:'Bible Quiz',project_id:'bhofgavunscaifcepnis',public_rest_rows:rows.length,new_questions:rows.filter(r=>r.payload.origin==='new').length,payloads_match_local:true,rpc:'book/theme/difficulty/day/origin/exclusion/randomness verified',checked_at:new Date().toISOString()};
fs.writeFileSync(new URL('../question-bank/LIVE_VALIDATION.json',import.meta.url),JSON.stringify(report,null,2));console.log(report);
