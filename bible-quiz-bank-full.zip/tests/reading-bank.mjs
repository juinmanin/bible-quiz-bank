import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),bank=require('../question-bank/bank.json'),core=require('../reading-bank-core.js'),counts=require('../question-bank/verse-counts.json');
const q=bank.questions,newQ=q.filter(q=>q.origin==='new');
assert.equal(newQ.length,1056);assert.equal(bank.books.length,66);assert.equal(new Set(q.map(q=>q.id)).size,q.length);
assert.equal(new Set(newQ.map(q=>q.references.map(r=>r.label).join(';')+'|'+q.prompt)).size,newQ.length);
assert.equal(q.filter(q=>q.arithmetic).length,0);
for(const b of bank.books){for(const d of ['easy','medium','hard'])assert.ok(newQ.some(q=>q.book_id===b.id&&q.difficulty===d),`${b.id}/${d}`);assert.equal(newQ.filter(q=>q.book_id===b.id).length,16);}
for(const item of q){assert.ok(item.prompt&&item.answer&&item.explanation);assert.ok(item.references.length);assert.ok(item.mcheyne_days.length,`unmapped: ${item.id}`);for(const r of item.references){assert.ok(counts[r.book_id]?.[r.chapter-1],`chapter ${item.id} ${r.label}`);assert.ok(r.verse_start>0&&r.verse_end>=r.verse_start&&r.verse_end<=counts[r.book_id][r.chapter-1],`verses ${item.id} ${r.label}`);}if(item.choices.length){assert.equal(item.choices.length,4);assert.equal(new Set(item.choices).size,4);assert.equal(item.choices.filter(c=>c===item.answer).length,1);}}
assert.equal(bank.days.length,365);assert.equal(new Set(bank.days.map(d=>d.date)).size,365);
for(const d of bank.days){assert.equal(d.readings.length,4);for(const r of d.readings)assert.ok(r.chapter_start>0&&r.chapter_end<=counts[r.book_id].length);assert.ok(q.some(q=>q.mcheyne_days.includes(d.day)),`empty day ${d.day}`);}
assert.deepEqual(bank.days[0].readings.map(r=>r.book_id),['GEN','MAT','EZR','ACT']);
assert.equal(core.calendarDay(bank,'2028-02-29').date,'02-28');assert.equal(core.calendarDay(bank,'2028-03-01').date,'03-01');
const covered=new Set(bank.days.flatMap(d=>d.readings.flatMap(r=>Array.from({length:r.chapter_end-r.chapter_start+1},(_,i)=>`${r.book_id}:${r.chapter_start+i}`))));assert.equal(covered.size,1189);
for(const f of [{book:'GEN',difficulty:'hard',origin:'new'},{theme:'ot_nt',difficulty:'hard'},{day:1},{book:'PHM',difficulty:'hard'},{theme:'pauline',difficulty:'medium'}]){let a=core.select(bank,f,[],10,()=>.4);assert.ok(a.length);assert.ok(a.every(q=>core.matches(q,f)));assert.equal(new Set(a.map(q=>q.id)).size,a.length);assert.ok(core.select(bank,f,a.map(q=>q.id),10).every(q=>!a.some(p=>p.id===q.id)));}
assert.equal(core.select(bank,{book:'GEN',theme:'gospels'}).length,0);
assert.notDeepEqual(core.shuffle(q.slice(0,20),()=>.1).map(q=>q.id),core.shuffle(q.slice(0,20),()=>.9).map(q=>q.id));
for(const day of bank.days){for(const r of day.readings.filter(r=>r.verse_start)){for(const item of core.select(bank,{day:day.day},[],50)){assert.ok(item.references.some(qr=>day.readings.some(dr=>qr.book_id===dr.book_id&&qr.chapter>=dr.chapter_start&&qr.chapter<=dr.chapter_end&&(!dr.verse_start||qr.verse_start<=dr.verse_end&&qr.verse_end>=dr.verse_start))));}}}
const context={};context.window=context;context.globalThis=context;vm.createContext(context);for(const file of ['questions.js','questions.bible-books.js','genesisGameData.js','bibleChapterQuestionBank.generated.js','reading-bank-core.js','legacy-numeric-limit.js'])vm.runInContext(fs.readFileSync(new URL('../'+file,import.meta.url),'utf8'),context);
const playable=[...context.BIBLE_QUIZ_QUESTIONS,...context.BIBLE_BOOK_QUIZ_QUESTIONS,...context.BIBLE_GAME_SEED.quizzes,...context.BIBLE_CHAPTER_QUESTION_BANK.questions];assert.ok(playable.filter(core.numericPrompt).length<=20);
const report={new_questions:newQ.length,total_questions:q.length,difficulties:bank.metadata.difficulty_counts,books:66,mcheyne_days:365,covered_chapters:covered.size,arithmetic_in_new_bank:0,legacy_numeric_policy:context.BIBLE_NUMERIC_POLICY,checks:'PASS: IDs, uniqueness, verse bounds, 66-book levels, 365-day mapping, partial chapters, leap day, filters, repeat exclusion, shuffle, legacy cap',limitations:'Semantic/theological review is not replaced by these structural checks.'};
fs.writeFileSync(new URL('../question-bank/VALIDATION.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
