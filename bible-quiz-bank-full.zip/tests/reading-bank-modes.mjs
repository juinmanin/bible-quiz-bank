import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),bank=require('../question-bank/bank.json'),core=require('../reading-bank-core.js'),i18n=require('../reading-bank-i18n.js');
for(const format of ['multiple_choice','short_answer','mixed']){
 const selected=core.session(bank,{origin:'new',format},[],20,()=>.37);
 assert.equal(selected.length,20);assert.equal(new Set(selected.map(q=>q.id)).size,20);
 if(format==='multiple_choice')assert.ok(selected.every(q=>core.hasChoices(q)&&q.presentation===format));
 if(format==='short_answer')assert.ok(selected.every(q=>q.presentation===format));
 if(format==='mixed'){assert.equal(selected.filter(q=>q.presentation==='multiple_choice').length,10);assert.equal(selected.filter(q=>q.presentation==='short_answer').length,10);}
 assert.ok(core.session(bank,{origin:'new',format},selected.map(q=>q.id),20).every(q=>!selected.some(p=>p.id===q.id)));
}
assert.equal(core.session(bank,{origin:'new',difficulty:'hard',format:'multiple_choice'}).length,0);
assert.ok(core.session(bank,{origin:'new',difficulty:'hard',format:'mixed'}).every(q=>q.presentation==='short_answer'));
assert.ok(core.session(bank,{origin:'legacy_curated',format:'mixed'},[],10).some(q=>q.presentation==='short_answer'));
const small={questions:bank.questions.filter(q=>q.origin==='new'&&q.book_id==='GEN')};
const mixed=core.session(small,{format:'mixed'},[],50);assert.equal(mixed.length,16);assert.equal(mixed.filter(q=>q.presentation==='multiple_choice').length,1);
assert.ok(!core.hasChoices({answer:'a',choices:['a','a']}));assert.ok(!core.hasChoices({answer:'x',choices:['a','b']}));
for(const l of ['ko','en','ms']){assert.deepEqual(Object.keys(i18n.strings[l]),Object.keys(i18n.strings.ko));assert.ok(Object.values(i18n.strings[l]).every(Boolean));assert.ok(!i18n.text(l,'pool',{count:123}).includes('{count}'));}
console.log('PASS: three formats, balanced mixed sessions, scarce pools, exclusions, all UI locales');
