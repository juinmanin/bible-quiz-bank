(function attachQuestions(root) {
  const questions = [
  {
    "id": "imported-001",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa yang menciptakan langit dan bumi?",
    "choices": [
      "Yesus",
      "Adam",
      "Allah",
      "Musa"
    ],
    "answer": 2,
    "reference": "Genesis 1:1",
    "explanation": "Lihat Genesis 1:1."
  },
  {
    "id": "imported-002",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Allah ciptakan pada hari pertama?",
    "choices": [
      "Manusia",
      "Cahaya",
      "Binatang",
      "Tumbuhan"
    ],
    "answer": 1,
    "reference": "Genesis 1:3-5",
    "explanation": "Lihat Genesis 1:3-5."
  },
  {
    "id": "imported-003",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Berapa hari Allah mengambil untuk menciptakan dunia?",
    "choices": [
      "Tujuh hari",
      "Lima hari",
      "Enam hari",
      "Sepuluh hari"
    ],
    "answer": 2,
    "reference": "Genesis 1:31-2:2",
    "explanation": "Lihat Genesis 1:31-2:2."
  },
  {
    "id": "imported-004",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Allah ciptakan pada hari keenam?",
    "choices": [
      "Tumbuhan",
      "Binatang laut",
      "Manusia",
      "Cahaya"
    ],
    "answer": 2,
    "reference": "Genesis 1:26-31",
    "explanation": "Lihat Genesis 1:26-31."
  },
  {
    "id": "imported-005",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa yang menamakan semua binatang?",
    "choices": [
      "Hawa",
      "Adam",
      "Nuh",
      "Set"
    ],
    "answer": 1,
    "reference": "Genesis 2:19-20",
    "explanation": "Lihat Genesis 2:19-20."
  },
  {
    "id": "imported-006",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Di mana Allah menempatkan Adam setelah menciptakannya?",
    "choices": [
      "Taman Eden",
      "Gunung Sinai",
      "Babel",
      "Kanaan"
    ],
    "answer": 0,
    "reference": "Genesis 2:15",
    "explanation": "Lihat Genesis 2:15."
  },
  {
    "id": "imported-007",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Allah larang Adam makan di Taman Eden?",
    "choices": [
      "Buah anggur",
      "Buah pengetahuan baik dan jahat",
      "Buah apel",
      "Buah delima"
    ],
    "answer": 1,
    "reference": "Genesis 2:16-17",
    "explanation": "Lihat Genesis 2:16-17."
  },
  {
    "id": "imported-008",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa yang diciptakan dari tulang rusuk Adam?",
    "choices": [
      "Hawa",
      "Kain",
      "Abel",
      "Set"
    ],
    "answer": 0,
    "reference": "Genesis 2:21-22",
    "explanation": "Lihat Genesis 2:21-22."
  },
  {
    "id": "imported-009",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa yang menggoda Hawa untuk makan buah terlarang?",
    "choices": [
      "Iblis",
      "Ular",
      "Adam",
      "Kain"
    ],
    "answer": 1,
    "reference": "Genesis 3:1-6",
    "explanation": "Lihat Genesis 3:1-6."
  },
  {
    "id": "imported-010",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa hukuman Allah kepada ular setelah kejatuhan manusia?",
    "choices": [
      "Berjalan dengan kaki",
      "Menjilat debu",
      "Menjadi buta",
      "Kehilangan suara"
    ],
    "answer": 1,
    "reference": "Genesis 3:14",
    "explanation": "Lihat Genesis 3:14."
  },
  {
    "id": "imported-011",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Adam dan Hawa buat setelah makan buah terlarang?",
    "choices": [
      "Bersembunyi dari Allah",
      "Menyalahkan satu sama lain",
      "Berdoa kepada Allah",
      "Meninggalkan taman"
    ],
    "answer": 0,
    "reference": "Genesis 3:8",
    "explanation": "Lihat Genesis 3:8."
  },
  {
    "id": "imported-012",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa anak pertama Adam dan Hawa?",
    "choices": [
      "Kain",
      "Abel",
      "Set",
      "Nuh"
    ],
    "answer": 0,
    "reference": "Genesis 4:1",
    "explanation": "Lihat Genesis 4:1."
  },
  {
    "id": "imported-013",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa pekerjaan Kain?",
    "choices": [
      "Petani",
      "Penggembala",
      "Tukang kayu",
      "Nelayan"
    ],
    "answer": 0,
    "reference": "Genesis 4:2",
    "explanation": "Lihat Genesis 4:2."
  },
  {
    "id": "imported-014",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa pekerjaan Abel?",
    "choices": [
      "Petani",
      "Penggembala",
      "Tukang kayu",
      "Nelayan"
    ],
    "answer": 1,
    "reference": "Genesis 4:2",
    "explanation": "Lihat Genesis 4:2."
  },
  {
    "id": "imported-015",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa yang membunuh Abel?",
    "choices": [
      "Adam",
      "Kain",
      "Set",
      "Nuh"
    ],
    "answer": 1,
    "reference": "Genesis 4:8",
    "explanation": "Lihat Genesis 4:8."
  },
  {
    "id": "imported-016",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa tanda yang Allah berikan kepada Kain setelah dia membunuh Abel?",
    "choices": [
      "Tanda di dahi",
      "Tanda di tangan",
      "Tanda di kaki",
      "Tanda di dada"
    ],
    "answer": 0,
    "reference": "Genesis 4:15",
    "explanation": "Lihat Genesis 4:15."
  },
  {
    "id": "imported-017",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa anak Adam dan Hawa yang menggantikan Abel?",
    "choices": [
      "Kain",
      "Set",
      "Nuh",
      "Lamekh"
    ],
    "answer": 1,
    "reference": "Genesis 4:25",
    "explanation": "Lihat Genesis 4:25."
  },
  {
    "id": "imported-018",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa yang hidup paling lama dalam Kitab Kejadian?",
    "choices": [
      "Metusalah",
      "Nuh",
      "Adam",
      "Lamekh"
    ],
    "answer": 0,
    "reference": "Genesis 5:27",
    "explanation": "Lihat Genesis 5:27."
  },
  {
    "id": "imported-019",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Berapa tahun Metusalah hidup?",
    "choices": [
      "969 tahun",
      "777 tahun",
      "500 tahun",
      "120 tahun"
    ],
    "answer": 0,
    "reference": "Genesis 5:27",
    "explanation": "Lihat Genesis 5:27."
  },
  {
    "id": "imported-020",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa yang \"berjalan bersama Allah\" dan tidak mati tetapi diangkat?",
    "choices": [
      "Henokh",
      "Metusalah",
      "Nuh",
      "Lamekh"
    ],
    "answer": 0,
    "reference": "Genesis 5:24",
    "explanation": "Lihat Genesis 5:24."
  },
  {
    "id": "imported-021",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa bapa kepada Nuh?",
    "choices": [
      "Lamekh",
      "Metusalah",
      "Henokh",
      "Set"
    ],
    "answer": 0,
    "reference": "Genesis 5:28-29",
    "explanation": "Lihat Genesis 5:28-29."
  },
  {
    "id": "imported-022",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Allah perintahkan kepada Nuh untuk membina?",
    "choices": [
      "Bahtera",
      "Kuil",
      "Kota",
      "Taman"
    ],
    "answer": 0,
    "reference": "Genesis 6:14",
    "explanation": "Lihat Genesis 6:14."
  },
  {
    "id": "imported-023",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Berapa lama hujan turun semasa banjir besar?",
    "choices": [
      "40 hari 40 malam",
      "7 hari",
      "100 hari",
      "1 tahun"
    ],
    "answer": 0,
    "reference": "Genesis 7:12",
    "explanation": "Lihat Genesis 7:12."
  },
  {
    "id": "imported-024",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Nuh lepaskan untuk melihat jika air telah surut?",
    "choices": [
      "Burung merpati",
      "Burung gagak",
      "Kedua-duanya",
      "Tidak ada"
    ],
    "answer": 2,
    "reference": "Genesis 8:6-11",
    "explanation": "Lihat Genesis 8:6-11."
  },
  {
    "id": "imported-025",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa tanda perjanjian Allah dengan Nuh setelah banjir?",
    "choices": [
      "Pelangi",
      "Bintang",
      "Matahari",
      "Bulan"
    ],
    "answer": 0,
    "reference": "Genesis 9:12-17",
    "explanation": "Lihat Genesis 9:12-17."
  },
  {
    "id": "imported-026",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa tiga anak Nuh?",
    "choices": [
      "Sem, Ham, Yafet",
      "Kain, Abel, Set",
      "Sem, Ham, Kanaan",
      "Tidak disebutkan"
    ],
    "answer": 0,
    "reference": "Genesis 9:18",
    "explanation": "Lihat Genesis 9:18."
  },
  {
    "id": "imported-027",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Ham lakukan sehingga Nuh mengutuk Kanaan?",
    "choices": [
      "Mencuri",
      "Memukul Nuh",
      "Melihat Nuh telanjang",
      "Menipu"
    ],
    "answer": 2,
    "reference": "Genesis 9:22-25",
    "explanation": "Ham melihat aurat ayahnya dan memberitahu kedua saudaranya; setelah Nuh sadar, ia mengutuk Kanaan. Lihat Genesis 9:22-25."
  },
  {
    "id": "imported-028",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang manusia cuba bina untuk mencapai langit?",
    "choices": [
      "Menara Babel",
      "Taman Eden",
      "Kuil",
      "Bahtera"
    ],
    "answer": 0,
    "reference": "Genesis 11:4",
    "explanation": "Lihat Genesis 11:4."
  },
  {
    "id": "imported-029",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Allah lakukan untuk menghentikan pembinaan Menara Babel?",
    "choices": [
      "Menggantikan pemimpin",
      "Menghancurkan menara",
      "Mengacaukan bahasa",
      "Menghantar banjir"
    ],
    "answer": 2,
    "reference": "Genesis 11:7-9",
    "explanation": "Lihat Genesis 11:7-9."
  },
  {
    "id": "imported-030",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa yang dipanggil Allah untuk meninggalkan tanahnya dan pergi ke Kanaan?",
    "choices": [
      "Abram",
      "Nuh",
      "Lot",
      "Ishak"
    ],
    "answer": 0,
    "reference": "Genesis 12:1",
    "explanation": "Lihat Genesis 12:1."
  },
  {
    "id": "imported-031",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Berapa umur Abram ketika dia meninggalkan Haran?",
    "choices": [
      "75 tahun",
      "50 tahun",
      "100 tahun",
      "120 tahun"
    ],
    "answer": 0,
    "reference": "Genesis 12:4",
    "explanation": "Lihat Genesis 12:4."
  },
  {
    "id": "imported-032",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa isteri Abram?",
    "choices": [
      "Sarai",
      "Hagar",
      "Keturah",
      "Rebekah"
    ],
    "answer": 0,
    "reference": "Genesis 12:5",
    "explanation": "Lihat Genesis 12:5."
  },
  {
    "id": "imported-033",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Ke mana Abram pergi semasa kelaparan di Kanaan?",
    "choices": [
      "Mesir",
      "Babel",
      "Filistia",
      "Haran"
    ],
    "answer": 0,
    "reference": "Genesis 12:10",
    "explanation": "Lihat Genesis 12:10."
  },
  {
    "id": "imported-034",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Abram katakan tentang Sarai kepada Firaun?",
    "choices": [
      "Isterinya",
      "Kakaknya",
      "Anaknya",
      "Ibu mertuanya"
    ],
    "answer": 1,
    "reference": "Genesis 12:13",
    "explanation": "Lihat Genesis 12:13."
  },
  {
    "id": "imported-035",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa anak saudara Abram yang ikut bersamanya?",
    "choices": [
      "Lot",
      "Ishak",
      "Yakub",
      "Esau"
    ],
    "answer": 0,
    "reference": "Genesis 12:5",
    "explanation": "Lihat Genesis 12:5."
  },
  {
    "id": "imported-036",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang menyebabkan Abram dan Lot berpisah?",
    "choices": [
      "Pertengkaran antara gembala",
      "Kelaparan",
      "Perang",
      "Banjir"
    ],
    "answer": 0,
    "reference": "Genesis 13:7",
    "explanation": "Lihat Genesis 13:7."
  },
  {
    "id": "imported-037",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Ke mana Lot memilih untuk tinggal setelah berpisah dengan Abram?",
    "choices": [
      "Sodom dan Gomora",
      "Kanaan",
      "Haran",
      "Mesir"
    ],
    "answer": 0,
    "reference": "Genesis 13:10-12",
    "explanation": "Lihat Genesis 13:10-12."
  },
  {
    "id": "imported-038",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Allah janjikan kepada Abram tentang keturunannya?",
    "choices": [
      "Seperti bintang di langit",
      "Seperti batu",
      "Seperti pohon",
      "Seperti sungai"
    ],
    "answer": 0,
    "reference": "Genesis 15:5",
    "explanation": "Lihat Genesis 15:5."
  },
  {
    "id": "imported-039",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa hamba perempuan Sarai yang diberikan kepada Abram?",
    "choices": [
      "Hagar",
      "Keturah",
      "Bilhah",
      "Zilpa"
    ],
    "answer": 0,
    "reference": "Genesis 16:1",
    "explanation": "Lihat Genesis 16:1."
  },
  {
    "id": "imported-040",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa anak Abram dengan Hagar?",
    "choices": [
      "Ishak",
      "Ismael",
      "Yakub",
      "Esau"
    ],
    "answer": 1,
    "reference": "Genesis 16:15",
    "explanation": "Lihat Genesis 16:15."
  },
  {
    "id": "imported-041",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Berapa umur Abram ketika Ismael dilahirkan?",
    "choices": [
      "86 tahun",
      "75 tahun",
      "100 tahun",
      "120 tahun"
    ],
    "answer": 0,
    "reference": "Genesis 16:16",
    "explanation": "Lihat Genesis 16:16."
  },
  {
    "id": "imported-042",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa nama baru yang Allah berikan kepada Abram?",
    "choices": [
      "Abraham",
      "Abimelekh",
      "Ishak",
      "Yakub"
    ],
    "answer": 0,
    "reference": "Genesis 17:5",
    "explanation": "Lihat Genesis 17:5."
  },
  {
    "id": "imported-043",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa nama baru Sarai setelah perjanjian Allah?",
    "choices": [
      "Sara",
      "Hagar",
      "Keturah",
      "Rebekah"
    ],
    "answer": 0,
    "reference": "Genesis 17:15",
    "explanation": "Lihat Genesis 17:15."
  },
  {
    "id": "imported-044",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa tanda perjanjian yang Allah perintahkan kepada Abraham?",
    "choices": [
      "Sunat",
      "Baptisan",
      "Puasa",
      "Sembahyang"
    ],
    "answer": 0,
    "reference": "Genesis 17:10",
    "explanation": "Lihat Genesis 17:10."
  },
  {
    "id": "imported-045",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa anak yang Allah janjikan kepada Abraham dan Sara?",
    "choices": [
      "Ishak",
      "Ismael",
      "Yakub",
      "Esau"
    ],
    "answer": 0,
    "reference": "Genesis 17:19",
    "explanation": "Lihat Genesis 17:19."
  },
  {
    "id": "imported-046",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Berapa umur Abraham ketika Ishak dilahirkan?",
    "choices": [
      "100 tahun",
      "86 tahun",
      "120 tahun",
      "75 tahun"
    ],
    "answer": 0,
    "reference": "Genesis 21:5",
    "explanation": "Lihat Genesis 21:5."
  },
  {
    "id": "imported-047",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Abraham lakukan dengan Hagar dan Ismael?",
    "choices": [
      "Menyuruh mereka pergi",
      "Mengahwini Hagar",
      "Menghantar mereka ke Mesir",
      "Memberi mereka tanah"
    ],
    "answer": 0,
    "reference": "Genesis 21:14",
    "explanation": "Lihat Genesis 21:14."
  },
  {
    "id": "imported-048",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Allah perintahkan Abraham untuk lakukan dengan Ishak?",
    "choices": [
      "Mengorbankannya",
      "Menghantarnya ke Mesir",
      "Memberinya tanah",
      "Menamakan semula"
    ],
    "answer": 0,
    "reference": "Genesis 22:2",
    "explanation": "Lihat Genesis 22:2."
  },
  {
    "id": "imported-049",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Allah sediakan sebagai ganti Ishak untuk korban?",
    "choices": [
      "Domba",
      "Biri-biri",
      "Kambing",
      "Lembu"
    ],
    "answer": 0,
    "reference": "Genesis 22:13",
    "explanation": "Lihat Genesis 22:13."
  },
  {
    "id": "imported-050",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa isteri Ishak?",
    "choices": [
      "Rebekah",
      "Rakel",
      "Lea",
      "Bilhah"
    ],
    "answer": 0,
    "reference": "Genesis 24:67",
    "explanation": "Lihat Genesis 24:67."
  },
  {
    "id": "imported-051",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa yang diutus Abraham untuk mencari isteri bagi Ishak?",
    "choices": [
      "Eliezer",
      "Lot",
      "Abimelekh",
      "Laban"
    ],
    "answer": 0,
    "reference": "Genesis 24:2-4",
    "explanation": "Lihat Genesis 24:2-4."
  },
  {
    "id": "imported-052",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Di mana Eliezer bertemu dengan Rebekah?",
    "choices": [
      "Sumur",
      "Taman",
      "Pasar",
      "Gunung"
    ],
    "answer": 0,
    "reference": "Genesis 24:13",
    "explanation": "Eliezer berdiri di dekat sumur ketika perempuan-perempuan kota keluar untuk menimba air. Lihat Genesis 24:13."
  },
  {
    "id": "imported-053",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa bapa kepada Rebekah?",
    "choices": [
      "Laban",
      "Betuel",
      "Nahor",
      "Terah"
    ],
    "answer": 1,
    "reference": "Genesis 24:24",
    "explanation": "Lihat Genesis 24:24."
  },
  {
    "id": "imported-054",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Berapa umur Ishak ketika dia berkahwin dengan Rebekah?",
    "choices": [
      "40 tahun",
      "25 tahun",
      "60 tahun",
      "100 tahun"
    ],
    "answer": 0,
    "reference": "Genesis 25:20",
    "explanation": "Lihat Genesis 25:20."
  },
  {
    "id": "imported-055",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa dua anak Ishak dan Rebekah?",
    "choices": [
      "Yakub dan Esau",
      "Ishak dan Ismael",
      "Set dan Kain",
      "Yosua dan Kaleb"
    ],
    "answer": 0,
    "reference": "Genesis 25:24-26",
    "explanation": "Lihat Genesis 25:24-26."
  },
  {
    "id": "imported-056",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Esau jual kepada Yakub untuk semangkuk sup?",
    "choices": [
      "Hak kesulungan",
      "Tanah",
      "Harta",
      "Karunia"
    ],
    "answer": 0,
    "reference": "Genesis 25:29-34",
    "explanation": "Lihat Genesis 25:29-34."
  },
  {
    "id": "imported-057",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa yang lebih tua antara Yakub dan Esau?",
    "choices": [
      "Esau",
      "Yakub",
      "Kedua-duanya kembar",
      "Yakub lebih tua"
    ],
    "answer": 0,
    "reference": "Genesis 25:25-26",
    "explanation": "Lihat Genesis 25:25-26."
  },
  {
    "id": "imported-058",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Yakub gunakan untuk menipu Ishak bagi mendapatkan berkat?",
    "choices": [
      "Kulit kambing",
      "Tanah liat",
      "Bulu domba",
      "Daun"
    ],
    "answer": 0,
    "reference": "Genesis 27:16",
    "explanation": "Lihat Genesis 27:16."
  },
  {
    "id": "imported-059",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa yang membantu Yakub menipu Ishak?",
    "choices": [
      "Rebekah",
      "Laban",
      "Lea",
      "Rakel"
    ],
    "answer": 0,
    "reference": "Genesis 27:6-10",
    "explanation": "Lihat Genesis 27:6-10."
  },
  {
    "id": "imported-060",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Ke mana Yakub melarikan diri setelah menipu Esau?",
    "choices": [
      "Haran",
      "Mesir",
      "Sodom",
      "Kanaan"
    ],
    "answer": 0,
    "reference": "Genesis 27:43",
    "explanation": "Lihat Genesis 27:43."
  },
  {
    "id": "imported-061",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Yakub lihat dalam mimpinya di Betel?",
    "choices": [
      "Tangga ke syurga",
      "Bahtera",
      "Pelangi",
      "Api"
    ],
    "answer": 0,
    "reference": "Genesis 28:12",
    "explanation": "Lihat Genesis 28:12."
  },
  {
    "id": "imported-062",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa yang Yakub jumpai di Haran?",
    "choices": [
      "Laban",
      "Lot",
      "Abimelekh",
      "Eliezer"
    ],
    "answer": 0,
    "reference": "Genesis 29:5",
    "explanation": "Lihat Genesis 29:5."
  },
  {
    "id": "imported-063",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa dua anak perempuan Laban?",
    "choices": [
      "Lea dan Rakel",
      "Hagar dan Keturah",
      "Sara dan Rebekah",
      "Bilhah dan Zilpa"
    ],
    "answer": 0,
    "reference": "Genesis 29:16",
    "explanation": "Lihat Genesis 29:16."
  },
  {
    "id": "imported-064",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Berapa tahun Yakub bekerja untuk berkahwin dengan Rakel?",
    "choices": [
      "7 tahun",
      "14 tahun",
      "3 tahun",
      "20 tahun"
    ],
    "answer": 1,
    "reference": "Genesis 29:20-30",
    "explanation": "Lihat Genesis 29:20-30."
  },
  {
    "id": "imported-065",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa isteri pertama Yakub?",
    "choices": [
      "Lea",
      "Rakel",
      "Bilhah",
      "Zilpa"
    ],
    "answer": 0,
    "reference": "Genesis 29:23",
    "explanation": "Lihat Genesis 29:23."
  },
  {
    "id": "imported-066",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa anak pertama Yakub dengan Lea?",
    "choices": [
      "Ruben",
      "Yusuf",
      "Benyamin",
      "Dan"
    ],
    "answer": 0,
    "reference": "Genesis 29:32",
    "explanation": "Lihat Genesis 29:32."
  },
  {
    "id": "imported-067",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa hamba perempuan Rakel yang diberikan kepada Yakub?",
    "choices": [
      "Bilhah",
      "Zilpa",
      "Hagar",
      "Keturah"
    ],
    "answer": 0,
    "reference": "Genesis 30:3",
    "explanation": "Lihat Genesis 30:3."
  },
  {
    "id": "imported-068",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa anak Yakub dengan Bilhah?",
    "choices": [
      "Dan",
      "Naphtali",
      "Kedua-duanya",
      "Tidak ada"
    ],
    "answer": 2,
    "reference": "Genesis 30:6-8",
    "explanation": "Lihat Genesis 30:6-8."
  },
  {
    "id": "imported-069",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa hamba perempuan Lea yang diberikan kepada Yakub?",
    "choices": [
      "Zilpa",
      "Bilhah",
      "Hagar",
      "Keturah"
    ],
    "answer": 0,
    "reference": "Genesis 30:9",
    "explanation": "Lihat Genesis 30:9."
  },
  {
    "id": "imported-070",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa anak Yakub dengan Zilpa?",
    "choices": [
      "Gad",
      "Asyer",
      "Kedua-duanya",
      "Tidak ada"
    ],
    "answer": 2,
    "reference": "Genesis 30:11-13",
    "explanation": "Lihat Genesis 30:11-13."
  },
  {
    "id": "imported-071",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa anak Yakub yang paling disayangi?",
    "choices": [
      "Yusuf",
      "Benyamin",
      "Ruben",
      "Dan"
    ],
    "answer": 0,
    "reference": "Genesis 37:3",
    "explanation": "Lihat Genesis 37:3."
  },
  {
    "id": "imported-072",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Yakub berikan kepada Yusuf yang menimbulkan iri hati adik-beradiknya?",
    "choices": [
      "Jubah berwarna-warni",
      "Cincin",
      "Domba",
      "Tanah"
    ],
    "answer": 0,
    "reference": "Genesis 37:3",
    "explanation": "Lihat Genesis 37:3."
  },
  {
    "id": "imported-073",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang adik-beradik Yusuf lakukan kepadanya?",
    "choices": [
      "Menjualnya",
      "Membunuhnya",
      "Meninggalkannya di hutan",
      "Memberinya harta"
    ],
    "answer": 0,
    "reference": "Genesis 37:28",
    "explanation": "Lihat Genesis 37:28."
  },
  {
    "id": "imported-074",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Kepada siapa adik-beradik Yusuf menjualnya?",
    "choices": [
      "Orang Mesir",
      "Orang Midian",
      "Orang Filistia",
      "Orang Kanaan"
    ],
    "answer": 1,
    "reference": "Genesis 37:28",
    "explanation": "Lihat Genesis 37:28."
  },
  {
    "id": "imported-075",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Yusuf katakan kepada adik-beradiknya tentang perbuatan mereka?",
    "choices": [
      "Allah menghantar saya",
      "Bunuh saya",
      "Kutuk kamu",
      "Tinggalkan saya"
    ],
    "answer": 0,
    "reference": "Genesis 45:5",
    "explanation": "Lihat Genesis 45:5."
  },
  {
    "id": "imported-076",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Berapa umur Yakub ketika dia pergi ke Mesir untuk bertemu Yusuf?",
    "choices": [
      "130 tahun",
      "100 tahun",
      "75 tahun",
      "40 tahun"
    ],
    "answer": 0,
    "reference": "Genesis 47:9",
    "explanation": "Lihat Genesis 47:9."
  },
  {
    "id": "imported-077",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Siapa dua anak Yusuf yang diberkati oleh Yakub?",
    "choices": [
      "Manasye dan Efraim",
      "Ishak dan Ismael",
      "Dan dan Naphtali",
      "Gad dan Asyer"
    ],
    "answer": 0,
    "reference": "Genesis 48:5",
    "explanation": "Lihat Genesis 48:5."
  },
  {
    "id": "imported-078",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Yakub lakukan terhadap Manasye dan Efraim?",
    "choices": [
      "Menamakan mereka",
      "Mengorbankan mereka",
      "Memberkati mereka",
      "Menghantar mereka ke Kanaan"
    ],
    "answer": 2,
    "reference": "Genesis 48:14-20",
    "explanation": "Lihat Genesis 48:14-20."
  },
  {
    "id": "imported-079",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Berapa umur Yakub ketika dia meninggal?",
    "choices": [
      "147 tahun",
      "130 tahun",
      "100 tahun",
      "75 tahun"
    ],
    "answer": 0,
    "reference": "Genesis 47:28",
    "explanation": "Lihat Genesis 47:28."
  },
  {
    "id": "imported-080",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Di mana Yakub dikebumikan?",
    "choices": [
      "Kanaan",
      "Mesir",
      "Haran",
      "Betel"
    ],
    "answer": 0,
    "reference": "Genesis 49:29-30",
    "explanation": "Lihat Genesis 49:29-30."
  },
  {
    "id": "imported-081",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apa yang Yusuf minta kepada adik-beradiknya sebelum dia meninggal?",
    "choices": [
      "Bawa tulang saya ke Kanaan",
      "Tinggalkan saya di Mesir",
      "Berkati anak saya",
      "Jual harta saya"
    ],
    "answer": 0,
    "reference": "Genesis 50:25",
    "explanation": "Lihat Genesis 50:25."
  },
  {
    "id": "imported-082",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Berapa umur Yusuf ketika dia meninggal?",
    "choices": [
      "110 tahun",
      "130 tahun",
      "147 tahun",
      "75 tahun"
    ],
    "answer": 0,
    "reference": "Genesis 50:26",
    "explanation": "Lihat Genesis 50:26."
  },
  {
    "id": "imported-083",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah maksud pakaian kulit yang Allah buat untuk Adam dan Hawa dalam Kejadian 3:21?",
    "choices": [
      "Fesyen pertama",
      "Dosa mereka ditutup",
      "Yesus Kristus sebagai korban ganti",
      "Suatu hukuman"
    ],
    "answer": 2,
    "reference": "Genesis 3:21",
    "explanation": "Lihat Genesis 3:21."
  },
  {
    "id": "imported-084",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh penciptaan manusia menurut gambar Allah dalam Kejadian 1:26-27?",
    "choices": [
      "Manusia sama dengan Allah",
      "Manusia mempunyai kuasa untuk mencipta",
      "Manusia dicipta untuk memuliakan Allah",
      "Manusia tidak berdosa"
    ],
    "answer": 2,
    "reference": "Genesis 1:26-27",
    "explanation": "Lihat Genesis 1:26-27."
  },
  {
    "id": "imported-085",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Menurut Kejadian 1, apakah tujuan utama Allah menciptakan dunia menurut Westminster Shorter Catechism?",
    "choices": [
      "Untuk keseronokan manusia",
      "Untuk mempamerkan kuasa Allah",
      "Untuk kemuliaan Allah",
      "Untuk menguji manusia"
    ],
    "answer": 2,
    "reference": "Genesis 1:1",
    "explanation": "Lihat Genesis 1:1."
  },
  {
    "id": "imported-086",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh larangan makan buah pengetahuan baik dan jahat dalam Kejadian 2:17?",
    "choices": [
      "Ketaatan kepada Allah",
      "Kepintaran manusia",
      "Kebutuhan untuk berusaha",
      "Kebebasan tanpa batas"
    ],
    "answer": 0,
    "reference": "Genesis 2:17",
    "explanation": "Lihat Genesis 2:17."
  },
  {
    "id": "imported-087",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah akibat dosa Adam menurut Kejadian 3 yang berkaitan dengan Westminster Confession of Faith?",
    "choices": [
      "Kematian rohani dan jasmani",
      "Kehilangan harta",
      "Perang antara manusia",
      "Kerosakan alam sahaja"
    ],
    "answer": 0,
    "reference": "Genesis 3:19",
    "explanation": "Lihat Genesis 3:19."
  },
  {
    "id": "imported-088",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Bagaimana Kejadian 3:15 merujuk kepada Yesus Kristus menurut teologi Reformed?",
    "choices": [
      "Iblis akan menang",
      "Keturunan perempuan akan menghancurkan ular",
      "Manusia akan bertaubat",
      "Allah akan menghukum semua"
    ],
    "answer": 1,
    "reference": "Genesis 3:15",
    "explanation": "Lihat Genesis 3:15."
  },
  {
    "id": "imported-089",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang dilambangkan oleh pohon kehidupan dalam Kejadian 2:9 menurut pandangan Reformed?",
    "choices": [
      "Kehidupan kekal",
      "Harta dunia",
      "Kebijaksanaan",
      "Kebebasan manusia"
    ],
    "answer": 0,
    "reference": "Genesis 2:9",
    "explanation": "Lihat Genesis 2:9."
  },
  {
    "id": "imported-090",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh banjir besar pada zaman Nuh menurut Kejadian 6-9 dalam konteks penghakiman Allah?",
    "choices": [
      "Kasih Allah kepada semua",
      "Keadilan dan murka Allah",
      "Kebutuhan untuk bahtera",
      "Kerosakan alam semata-mata"
    ],
    "answer": 1,
    "reference": "Genesis 6:5-7",
    "explanation": "Lihat Genesis 6:5-7."
  },
  {
    "id": "imported-091",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah perjanjian Allah dengan Nuh selepas banjir dalam Kejadian 9:12-17 menunjukkan?",
    "choices": [
      "Allah melupai manusia",
      "Allah setia pada janji-Nya",
      "Manusia harus membina bahtera lagi",
      "Tiada lagi banjir"
    ],
    "answer": 1,
    "reference": "Genesis 9:12-17",
    "explanation": "Lihat Genesis 9:12-17."
  },
  {
    "id": "imported-092",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh Menara Babel dalam Kejadian 11 berkaitan dengan dosa manusia?",
    "choices": [
      "Kebanggaan dan pemberontakan",
      "Kecerdasan manusia",
      "Keinginan untuk bersatu",
      "Kebutuhan untuk teknologi"
    ],
    "answer": 0,
    "reference": "Genesis 11:4",
    "explanation": "Lihat Genesis 11:4."
  },
  {
    "id": "imported-093",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang dimaksudkan dengan \"keturunan perempuan\" dalam Kejadian 3:15 menurut Westminster Larger Catechism?",
    "choices": [
      "Yesus Kristus",
      "Adam",
      "Hawa",
      "Kain"
    ],
    "answer": 0,
    "reference": "Genesis 3:15",
    "explanation": "Lihat Genesis 3:15."
  },
  {
    "id": "imported-094",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh penciptaan Hawa dari tulang rusuk Adam dalam Kejadian 2:21-22?",
    "choices": [
      "Kesetiaan dalam perkahwinan",
      "Kesaksamaan antara lelaki dan perempuan",
      "Kekuatan lelaki",
      "Kebebasan perempuan"
    ],
    "answer": 1,
    "reference": "Genesis 2:21-22",
    "explanation": "Lihat Genesis 2:21-22."
  },
  {
    "id": "imported-095",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang dimaksudkan dengan \"Allah melihat segala yang dijadikan-Nya baik\" dalam Kejadian 1:31?",
    "choices": [
      "Allah membuat kesilapan",
      "Allah mencipta dunia yang sempurna",
      "Dunia tidak memerlukan manusia",
      "Manusia boleh mengubah ciptaan"
    ],
    "answer": 1,
    "reference": "Genesis 1:31",
    "explanation": "Lihat Genesis 1:31."
  },
  {
    "id": "imported-096",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Bagaimana Kejadian 3 menunjukkan asal usul dosa menurut Westminster Shorter Catechism?",
    "choices": [
      "Dosa bermula dari Allah",
      "Dosa bermula dari Iblis",
      "Dosa bermula dari ketidaktaatan manusia",
      "Dosa tidak wujud"
    ],
    "answer": 2,
    "reference": "Genesis 3:6",
    "explanation": "Lihat Genesis 3:6."
  },
  {
    "id": "imported-097",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh tanda sunat dalam perjanjian Allah dengan Abraham (Kejadian 17)?",
    "choices": [
      "Tanda fizikal sahaja",
      "Tanda perjanjian keselamatan",
      "Tanda kekayaan",
      "Tanda hukuman"
    ],
    "answer": 1,
    "reference": "Genesis 17:10-11",
    "explanation": "Lihat Genesis 17:10-11."
  },
  {
    "id": "imported-098",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pengorbanan Ishak dalam Kejadian 22 menurut teologi Reformed?",
    "choices": [
      "Ketaatan Abraham",
      "Korban Yesus di kayu salib",
      "Kedua-duanya",
      "Tiada makna"
    ],
    "answer": 2,
    "reference": "Genesis 22:1-14",
    "explanation": "Lihat Genesis 22:1-14."
  },
  {
    "id": "imported-099",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang dilambangkan oleh domba yang disediakan Allah sebagai ganti Ishak dalam Kejadian 22:13?",
    "choices": [
      "Yesus sebagai korban ganti",
      "Kekayaan Abraham",
      "Kuasa Allah",
      "Hukuman Allah"
    ],
    "answer": 0,
    "reference": "Genesis 22:13",
    "explanation": "Lihat Genesis 22:13."
  },
  {
    "id": "imported-100",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Bagaimana Kejadian 1:1 berkaitan dengan soalan pertama Westminster Shorter Catechism?",
    "choices": [
      "Manusia dicipta untuk memuliakan Allah",
      "Allah mencipta segalanya",
      "Manusia berdosa",
      "Allah menghukum dunia"
    ],
    "answer": 0,
    "reference": "Genesis 1:1",
    "explanation": "Lihat Genesis 1:1."
  },
  {
    "id": "imported-101",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh perpisahan antara Abram dan Lot dalam Kejadian 13?",
    "choices": [
      "Ketaatan kepada Allah",
      "Konflik kerana dosa",
      "Kebutuhan untuk harta",
      "Kekuatan iman"
    ],
    "answer": 1,
    "reference": "Genesis 13:7-12",
    "explanation": "Lihat Genesis 13:7-12."
  },
  {
    "id": "imported-102",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh perjanjian Allah dengan Abraham dalam Kejadian 15 menurut teologi Reformed?",
    "choices": [
      "Allah setia pada janji-Nya",
      "Manusia harus bekerja keras",
      "Abraham lebih suci",
      "Tiada perjanjian sebenar"
    ],
    "answer": 0,
    "reference": "Genesis 15:18",
    "explanation": "Lihat Genesis 15:18."
  },
  {
    "id": "imported-103",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh kelahiran Ishak dalam Kejadian 21 menurut Westminster Larger Catechism?",
    "choices": [
      "Keajaiban Allah",
      "Kuasa manusia",
      "Ketidaktaatan Sara",
      "Tiada makna"
    ],
    "answer": 0,
    "reference": "Genesis 21:1-3",
    "explanation": "Lihat Genesis 21:1-3."
  },
  {
    "id": "imported-104",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Bagaimana Kejadian 3:19 berkaitan dengan kematian menurut Westminster Confession of Faith?",
    "choices": [
      "Kematian adalah hukuman dosa",
      "Kematian adalah semula jadi",
      "Kematian tiada kaitan dengan dosa",
      "Kematian boleh dielakkan"
    ],
    "answer": 0,
    "reference": "Genesis 3:19",
    "explanation": "Lihat Genesis 3:19."
  },
  {
    "id": "imported-105",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh tangga dalam mimpi Yakub di Betel (Kejadian 28:12)?",
    "choices": [
      "Yesus sebagai pengantara",
      "Kekayaan Yakub",
      "Kuasa malaikat",
      "Tiada makna"
    ],
    "answer": 0,
    "reference": "Genesis 28:12",
    "explanation": "Lihat Genesis 28:12."
  },
  {
    "id": "imported-106",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh hak kesulungan yang Esau jual kepada Yakub dalam Kejadian 25:29-34?",
    "choices": [
      "Esau menghormati Yakub",
      "Esau tidak menghargai berkat rohani",
      "Yakub menipu Esau",
      "Tiada makna"
    ],
    "answer": 1,
    "reference": "Genesis 25:29-34",
    "explanation": "Lihat Genesis 25:29-34."
  },
  {
    "id": "imported-107",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh penipuan Yakub terhadap Ishak dalam Kejadian 27 menurut teologi Reformed?",
    "choices": [
      "Dosa Yakub",
      "Kuasa Allah dalam rancangan-Nya",
      "Kedua-duanya",
      "Tiada dosa"
    ],
    "answer": 2,
    "reference": "Genesis 27:18-29",
    "explanation": "Lihat Genesis 27:18-29."
  },
  {
    "id": "imported-108",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Bagaimana Kejadian 12:1-3 berkaitan dengan perjanjian anugerah menurut Westminster Confession of Faith?",
    "choices": [
      "Allah memilih Abraham untuk berkat semua bangsa",
      "Abraham dipilih kerana kebaikannya",
      "Tiada perjanjian",
      "Allah menghukum Abraham"
    ],
    "answer": 0,
    "reference": "Genesis 12:1-3",
    "explanation": "Lihat Genesis 12:1-3."
  },
  {
    "id": "imported-109",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pelangi dalam Kejadian 9:13 menurut pandangan Reformed?",
    "choices": [
      "Tanda perjanjian Allah",
      "Tanda keindahan alam",
      "Tanda hukuman",
      "Tanda banjir"
    ],
    "answer": 0,
    "reference": "Genesis 9:13",
    "explanation": "Lihat Genesis 9:13."
  },
  {
    "id": "imported-110",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh kejatuhan Adam dan Hawa dalam Kejadian 3 menurut Westminster Shorter Catechism?",
    "choices": [
      "Dosa asal yang mempengaruhi semua manusia",
      "Manusia boleh selamat sendiri",
      "Tiada dosa",
      "Allah tidak adil"
    ],
    "answer": 0,
    "reference": "Genesis 3:6",
    "explanation": "Lihat Genesis 3:6."
  },
  {
    "id": "imported-111",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh penciptaan pada hari ketujuh dalam Kejadian 2:2-3?",
    "choices": [
      "Allah berehat dan menetapkan hari Sabat",
      "Allah berhenti mencipta",
      "Allah mencipta malaikat",
      "Tiada makna"
    ],
    "answer": 0,
    "reference": "Genesis 2:2-3",
    "explanation": "Lihat Genesis 2:2-3."
  },
  {
    "id": "imported-112",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh kutukan kepada Kanaan dalam Kejadian 9:25?",
    "choices": [
      "Akibat dosa Ham",
      "Keadilan Allah",
      "Kedua-duanya",
      "Tiada makna"
    ],
    "answer": 2,
    "reference": "Genesis 9:25",
    "explanation": "Lihat Genesis 9:25."
  },
  {
    "id": "imported-113",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh penolakan Kain oleh Allah dalam Kejadian 4:5?",
    "choices": [
      "Kain tidak memberikan yang terbaik",
      "Kain tidak bertaubat",
      "Kedua-duanya",
      "Tiada sebab"
    ],
    "answer": 2,
    "reference": "Genesis 4:5",
    "explanation": "Lihat Genesis 4:5."
  },
  {
    "id": "imported-114",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh kehidupan Henokh dalam Kejadian 5:24 menurut Westminster Larger Catechism?",
    "choices": [
      "Iman yang menyenangkan Allah",
      "Kehidupan tanpa dosa",
      "Kuasa manusia",
      "Tiada makna"
    ],
    "answer": 0,
    "reference": "Genesis 5:24",
    "explanation": "Lihat Genesis 5:24."
  },
  {
    "id": "imported-115",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian jubah berwarna-warni kepada Yusuf dalam Kejadian 37:3?",
    "choices": [
      "Kasih Yakub kepada Yusuf",
      "Kebanggaan Yusuf",
      "Kedua-duanya",
      "Tiada makna"
    ],
    "answer": 2,
    "reference": "Genesis 37:3",
    "explanation": "Lihat Genesis 37:3."
  },
  {
    "id": "imported-116",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh penjualan Yusuf oleh adik-beradiknya dalam Kejadian 37:28?",
    "choices": [
      "Dosa iri hati",
      "Penyelamatan Allah melalui Yusuf",
      "Kedua-duanya",
      "Tiada dosa"
    ],
    "answer": 2,
    "reference": "Genesis 37:28",
    "explanation": "Lihat Genesis 37:28."
  },
  {
    "id": "imported-117",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh kelaparan di Kanaan dalam Kejadian 12:10?",
    "choices": [
      "Ujian iman Abram",
      "Kekurangan harta",
      "Tiada makna",
      "Hukuman Allah"
    ],
    "answer": 0,
    "reference": "Genesis 12:10",
    "explanation": "Lihat Genesis 12:10."
  },
  {
    "id": "imported-118",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh kelahiran Ismael dalam Kejadian 16 menurut Westminster Confession of Faith?",
    "choices": [
      "Ketidaksabaran manusia",
      "Kuasa Allah",
      "Tiada makna",
      "Hukuman kepada Hagar"
    ],
    "answer": 0,
    "reference": "Genesis 16:15",
    "explanation": "Lihat Genesis 16:15."
  },
  {
    "id": "imported-119",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh perjumpaan Abraham dengan Melkisedek dalam Kejadian 14:18-20?",
    "choices": [
      "Yesus sebagai Imam Besar",
      "Kekayaan Abraham",
      "Kuasa Melkisedek",
      "Tiada makna"
    ],
    "answer": 0,
    "reference": "Genesis 14:18-20",
    "explanation": "Lihat Genesis 14:18-20."
  },
  {
    "id": "imported-120",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Bagaimana Kejadian 1:26-27 berkaitan dengan soalan kedua Westminster Shorter Catechism?",
    "choices": [
      "Allah mencipta manusia menurut gambar-Nya",
      "Manusia berdosa",
      "Allah menghukum manusia",
      "Tiada kaitan"
    ],
    "answer": 0,
    "reference": "Genesis 1:26-27",
    "explanation": "Lihat Genesis 1:26-27."
  },
  {
    "id": "imported-121",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pembunuhan Abel oleh Kain dalam Kejadian 4:8?",
    "choices": [
      "Dosa iri hati",
      "Kekurangan iman",
      "Kedua-duanya",
      "Tiada dosa"
    ],
    "answer": 2,
    "reference": "Genesis 4:8",
    "explanation": "Lihat Genesis 4:8."
  },
  {
    "id": "imported-122",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh tanda pada Kain dalam Kejadian 4:15?",
    "choices": [
      "Belas kasihan Allah",
      "Keadilan Allah",
      "Kedua-duanya",
      "Tiada makna"
    ],
    "answer": 2,
    "reference": "Genesis 4:15",
    "explanation": "Lihat Genesis 4:15."
  },
  {
    "id": "imported-123",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh kehidupan Nuh menurut Kejadian 6:9?",
    "choices": [
      "Iman dan ketaatan kepada Allah",
      "Kekayaan Nuh",
      "Kuasa manusia",
      "Tiada makna"
    ],
    "answer": 0,
    "reference": "Genesis 6:9",
    "explanation": "Lihat Genesis 6:9."
  },
  {
    "id": "imported-124",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh banjir besar dalam Kejadian 7 menurut Westminster Larger Catechism?",
    "choices": [
      "Murka Allah terhadap dosa",
      "Kuasa alam",
      "Tiada makna",
      "Kebaikan manusia"
    ],
    "answer": 0,
    "reference": "Genesis 7:17-23",
    "explanation": "Lihat Genesis 7:17-23."
  },
  {
    "id": "imported-125",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh perjanjian Allah dengan Abraham dalam Kejadian 17 menurut teologi Reformed?",
    "choices": [
      "Perjanjian anugerah",
      "Kuasa manusia",
      "Tiada perjanjian",
      "Hukuman kepada Abraham"
    ],
    "answer": 0,
    "reference": "Genesis 17:7",
    "explanation": "Lihat Genesis 17:7."
  },
  {
    "id": "imported-126",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian nama Abraham dalam Kejadian 17:5?",
    "choices": [
      "Perjanjian baru",
      "Kekayaan Abraham",
      "Tiada makna",
      "Hukuman Allah"
    ],
    "answer": 0,
    "reference": "Genesis 17:5",
    "explanation": "Lihat Genesis 17:5."
  },
  {
    "id": "imported-127",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh ketaatan Abraham dalam Kejadian 22 menurut Westminster Shorter Catechism?",
    "choices": [
      "Iman sejati",
      "Kekayaan Abraham",
      "Kuasa manusia",
      "Tiada makna"
    ],
    "answer": 0,
    "reference": "Genesis 22:1-14",
    "explanation": "Lihat Genesis 22:1-14."
  },
  {
    "id": "imported-128",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh perjalanan Eliezer untuk mencari isteri bagi Ishak dalam Kejadian 24?",
    "choices": [
      "Penyelamatan Allah",
      "Ketaatan Eliezer",
      "Kedua-duanya",
      "Tiada makna"
    ],
    "answer": 2,
    "reference": "Genesis 24:1-67",
    "explanation": "Lihat Genesis 24:1-67."
  },
  {
    "id": "imported-129",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh kelahiran Yakub dan Esau dalam Kejadian 25:24-26?",
    "choices": [
      "Rancangan Allah",
      "Kekayaan Ishak",
      "Tiada makna",
      "Hukuman kepada Rebekah"
    ],
    "answer": 0,
    "reference": "Genesis 25:24-26",
    "explanation": "Lihat Genesis 25:24-26."
  },
  {
    "id": "imported-130",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh perkahwinan Yakub dengan Lea dan Rakel dalam Kejadian 29?",
    "choices": [
      "Rancangan Allah",
      "Dosa Yakub",
      "Kedua-duanya",
      "Tiada makna"
    ],
    "answer": 2,
    "reference": "Genesis 29:23-30",
    "explanation": "Lihat Genesis 29:23-30."
  },
  {
    "id": "imported-131",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh kelahiran Yusuf dalam Kejadian 30:24?",
    "choices": [
      "Keajaiban Allah",
      "Kekayaan Yakub",
      "Tiada makna",
      "Hukuman kepada Rakel"
    ],
    "answer": 0,
    "reference": "Genesis 30:24",
    "explanation": "Lihat Genesis 30:24."
  },
  {
    "id": "imported-132",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh kehidupan Yusuf di Mesir dalam Kejadian 41 menurut Westminster Confession of Faith?",
    "choices": [
      "Penyelamatan Allah",
      "Kekayaan Yusuf",
      "Tiada makna",
      "Hukuman kepada adik-beradiknya"
    ],
    "answer": 0,
    "reference": "Genesis 41:46-57",
    "explanation": "Lihat Genesis 41:46-57."
  },
  {
    "id": "imported-133",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh kematian Yakub dalam Kejadian 49:33?",
    "choices": [
      "Iman kepada janji Allah",
      "Kekayaan Yakub",
      "Tiada makna",
      "Hukuman kepada Yakub"
    ],
    "answer": 0,
    "reference": "Genesis 49:33",
    "explanation": "Lihat Genesis 49:33."
  },
  {
    "id": "imported-134",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh kematian Yusuf dalam Kejadian 50:26?",
    "choices": [
      "Harapan kepada janji Allah",
      "Kekayaan Yusuf",
      "Tiada makna",
      "Hukuman kepada Yusuf"
    ],
    "answer": 0,
    "reference": "Genesis 50:26",
    "explanation": "Lihat Genesis 50:26."
  },
  {
    "id": "imported-135",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh penciptaan manusia pada hari keenam dalam Kejadian 1:26-31 menurut Westminster Larger Catechism?",
    "choices": [
      "Manusia dicipta untuk memuliakan Allah",
      "Manusia lebih mulia daripada Allah",
      "Manusia tidak berdosa",
      "Tiada makna"
    ],
    "answer": 0,
    "reference": "Genesis 1:26-31",
    "explanation": "Lihat Genesis 1:26-31."
  },
  {
    "id": "imported-136",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh peristiwa Sodom dan Gomora dalam Kejadian 19 menurut teologi Reformed?",
    "choices": [
      "Murka Allah terhadap dosa",
      "Kuasa Abraham",
      "Tiada makna",
      "Kebaikan Lot"
    ],
    "answer": 0,
    "reference": "Genesis 19:24-25",
    "explanation": "Lihat Genesis 19:24-25."
  },
  {
    "id": "imported-137",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh perjumpaan Abraham dengan tiga orang asing dalam Kejadian 18?",
    "choices": [
      "Kedatangan Yesus",
      "Kuasa Abraham",
      "Kasih Allah kepada Sodom",
      "Tiada makna"
    ],
    "answer": 0,
    "reference": "Genesis 18:1-2",
    "explanation": "Lihat Genesis 18:1-2."
  },
  {
    "id": "imported-138",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pengusiran Hagar dan Ismael dalam Kejadian 21:14?",
    "choices": [
      "Rancangan Allah",
      "Dosa Sara",
      "Tiada makna",
      "Hukuman kepada Hagar"
    ],
    "answer": 0,
    "reference": "Genesis 21:14",
    "explanation": "Lihat Genesis 21:14."
  },
  {
    "id": "imported-139",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh penamaan Betel oleh Yakub dalam Kejadian 28:19?",
    "choices": [
      "Kehadiran Allah",
      "Kekayaan Yakub",
      "Tiada makna",
      "Hukuman kepada Yakub"
    ],
    "answer": 0,
    "reference": "Genesis 28:19",
    "explanation": "Lihat Genesis 28:19."
  },
  {
    "id": "imported-140",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian berkat Yakub kepada Efraim dan Manasye dalam Kejadian 48?",
    "choices": [
      "Rancangan Allah",
      "Kekayaan Yusuf",
      "Tiada makna",
      "Hukuman kepada Efraim"
    ],
    "answer": 0,
    "reference": "Genesis 48:14-20",
    "explanation": "Lihat Genesis 48:14-20."
  },
  {
    "id": "imported-141",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh perjalanan keluarga Yakub ke Mesir dalam Kejadian 46?",
    "choices": [
      "Penyelamatan Allah",
      "Kekayaan Yakub",
      "Tiada makna",
      "Hukuman kepada Yakub"
    ],
    "answer": 0,
    "reference": "Genesis 46:1-7",
    "explanation": "Lihat Genesis 46:1-7."
  },
  {
    "id": "imported-142",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh peristiwa Kain dan Abel dalam Kejadian 4 menurut Westminster Shorter Catechism?",
    "choices": [
      "Dosa iri hati",
      "Kekurangan iman",
      "Kedua-duanya",
      "Tiada makna"
    ],
    "answer": 2,
    "reference": "Genesis 4:1-8",
    "explanation": "Lihat Genesis 4:1-8."
  },
  {
    "id": "imported-143",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh kehidupan Metusalah dalam Kejadian 5:27?",
    "choices": [
      "Umur panjang sebagai berkat",
      "Kuasa manusia",
      "Tiada makna",
      "Hukuman kepada Metusalah"
    ],
    "answer": 0,
    "reference": "Genesis 5:27",
    "explanation": "Lihat Genesis 5:27."
  },
  {
    "id": "imported-144",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian nama kepada binatang oleh Adam dalam Kejadian 2:19-20?",
    "choices": [
      "Kuasa yang diberikan Allah",
      "Kekayaan Adam",
      "Tiada makna",
      "Hukuman kepada Adam"
    ],
    "answer": 0,
    "reference": "Genesis 2:19-20",
    "explanation": "Lihat Genesis 2:19-20."
  },
  {
    "id": "imported-145",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh peristiwa Menara Babel dalam Kejadian 11 menurut Westminster Larger Catechism?",
    "choices": [
      "Kebanggaan manusia",
      "Kuasa Allah",
      "Kedua-duanya",
      "Tiada makna"
    ],
    "answer": 2,
    "reference": "Genesis 11:1-9",
    "explanation": "Lihat Genesis 11:1-9."
  },
  {
    "id": "imported-146",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh perjanjian Allah dengan Nuh dalam Kejadian 9 menurut Westminster Confession of Faith?",
    "choices": [
      "Allah setia pada janji-Nya",
      "Kuasa Nuh",
      "Tiada makna",
      "Hukuman kepada Nuh"
    ],
    "answer": 0,
    "reference": "Genesis 9:12-17",
    "explanation": "Lihat Genesis 9:12-17."
  },
  {
    "id": "imported-147",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian nama Ishak dalam Kejadian 17:19?",
    "choices": [
      "Harapan kepada janji Allah",
      "Kekayaan Abraham",
      "Tiada makna",
      "Hukuman kepada Sara"
    ],
    "answer": 0,
    "reference": "Genesis 17:19",
    "explanation": "Lihat Genesis 17:19."
  },
  {
    "id": "imported-148",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh peristiwa Abraham dan Abimelekh dalam Kejadian 20?",
    "choices": [
      "Dosa Abraham",
      "Penyelamatan Allah",
      "Kedua-duanya",
      "Tiada makna"
    ],
    "answer": 2,
    "reference": "Genesis 20:1-18",
    "explanation": "Lihat Genesis 20:1-18."
  },
  {
    "id": "imported-149",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian nama kepada Esau dan Yakub dalam Kejadian 25:25-26?",
    "choices": [
      "Rancangan Allah",
      "Kekayaan Ishak",
      "Tiada makna",
      "Hukuman kepada Rebekah"
    ],
    "answer": 0,
    "reference": "Genesis 25:25-26",
    "explanation": "Lihat Genesis 25:25-26."
  },
  {
    "id": "imported-150",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh perjalanan Yakub ke Haran dalam Kejadian 28?",
    "choices": [
      "Penyelamatan Allah",
      "Dosa Yakub",
      "Kedua-duanya",
      "Tiada makna"
    ],
    "answer": 2,
    "reference": "Genesis 28:10-15",
    "explanation": "Lihat Genesis 28:10-15."
  },
  {
    "id": "imported-151",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian nama kepada Ruben dalam Kejadian 29:32?",
    "choices": [
      "Harapan Lea",
      "Kekayaan Yakub",
      "Tiada makna",
      "Hukuman kepada Lea"
    ],
    "answer": 0,
    "reference": "Genesis 29:32",
    "explanation": "Lihat Genesis 29:32."
  },
  {
    "id": "imported-152",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian nama kepada Dan dalam Kejadian 30:6?",
    "choices": [
      "Harapan Bilhah",
      "Kekayaan Yakub",
      "Tiada makna",
      "Hukuman kepada Bilhah"
    ],
    "answer": 0,
    "reference": "Genesis 30:6",
    "explanation": "Lihat Genesis 30:6."
  },
  {
    "id": "imported-153",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian nama kepada Gad dalam Kejadian 30:11?",
    "choices": [
      "Harapan Zilpa",
      "Kekayaan Yakub",
      "Tiada makna",
      "Hukuman kepada Zilpa"
    ],
    "answer": 0,
    "reference": "Genesis 30:11",
    "explanation": "Lihat Genesis 30:11."
  },
  {
    "id": "imported-154",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian nama kepada Yusuf dalam Kejadian 30:24?",
    "choices": [
      "Harapan Rakel",
      "Kekayaan Yakub",
      "Tiada makna",
      "Hukuman kepada Rakel"
    ],
    "answer": 0,
    "reference": "Genesis 30:24",
    "explanation": "Lihat Genesis 30:24."
  },
  {
    "id": "imported-155",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian nama kepada Benyamin dalam Kejadian 35:18?",
    "choices": [
      "Kesedihan Rakel",
      "Kekayaan Yakub",
      "Tiada makna",
      "Hukuman kepada Rakel"
    ],
    "answer": 0,
    "reference": "Genesis 35:18",
    "explanation": "Lihat Genesis 35:18."
  },
  {
    "id": "imported-156",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian berkat Yakub kepada anak-anaknya dalam Kejadian 49?",
    "choices": [
      "Rancangan Allah",
      "Kekayaan Yakub",
      "Tiada makna",
      "Hukuman kepada anak-anaknya"
    ],
    "answer": 0,
    "reference": "Genesis 49:1-28",
    "explanation": "Lihat Genesis 49:1-28."
  },
  {
    "id": "imported-157",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh perjalanan Yusuf ke Mesir dalam Kejadian 39?",
    "choices": [
      "Penyelamatan Allah",
      "Kekayaan Yusuf",
      "Tiada makna",
      "Hukuman kepada Yusuf"
    ],
    "answer": 0,
    "reference": "Genesis 39:1-23",
    "explanation": "Lihat Genesis 39:1-23."
  },
  {
    "id": "imported-158",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian nama kepada Efraim dalam Kejadian 41:52?",
    "choices": [
      "Harapan Yusuf",
      "Kekayaan Yusuf",
      "Tiada makna",
      "Hukuman kepada Yusuf"
    ],
    "answer": 0,
    "reference": "Genesis 41:52",
    "explanation": "Lihat Genesis 41:52."
  },
  {
    "id": "imported-159",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian nama kepada Manasye dalam Kejadian 41:51?",
    "choices": [
      "Harapan Yusuf",
      "Kekayaan Yusuf",
      "Tiada makna",
      "Hukuman kepada Yusuf"
    ],
    "answer": 0,
    "reference": "Genesis 41:51",
    "explanation": "Lihat Genesis 41:51."
  },
  {
    "id": "imported-160",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh perjumpaan Yusuf dengan adik-beradiknya dalam Kejadian 45?",
    "choices": [
      "Penyelamatan Allah",
      "Dosa adik-beradik",
      "Kedua-duanya",
      "Tiada makna"
    ],
    "answer": 2,
    "reference": "Genesis 45:1-15",
    "explanation": "Lihat Genesis 45:1-15."
  },
  {
    "id": "imported-161",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian tanah Gosyen kepada keluarga Yakub dalam Kejadian 47?",
    "choices": [
      "Penyelamatan Allah",
      "Kekayaan Yusuf",
      "Tiada makna",
      "Hukuman kepada Yakub"
    ],
    "answer": 0,
    "reference": "Genesis 47:6",
    "explanation": "Lihat Genesis 47:6."
  },
  {
    "id": "imported-162",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh kematian Abraham dalam Kejadian 25:8?",
    "choices": [
      "Iman kepada janji Allah",
      "Kekayaan Abraham",
      "Tiada makna",
      "Hukuman kepada Abraham"
    ],
    "answer": 0,
    "reference": "Genesis 25:8",
    "explanation": "Lihat Genesis 25:8."
  },
  {
    "id": "imported-163",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh kematian Sara dalam Kejadian 23:2?",
    "choices": [
      "Kesedihan Abraham",
      "Kekayaan Abraham",
      "Tiada makna",
      "Hukuman kepada Sara"
    ],
    "answer": 0,
    "reference": "Genesis 23:2",
    "explanation": "Lihat Genesis 23:2."
  },
  {
    "id": "imported-164",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh kematian Ishak dalam Kejadian 35:29?",
    "choices": [
      "Iman kepada janji Allah",
      "Kekayaan Ishak",
      "Tiada makna",
      "Hukuman kepada Ishak"
    ],
    "answer": 0,
    "reference": "Genesis 35:29",
    "explanation": "Lihat Genesis 35:29."
  },
  {
    "id": "imported-165",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian nama kepada Set dalam Kejadian 4:25?",
    "choices": [
      "Harapan Hawa",
      "Kekayaan Adam",
      "Tiada makna",
      "Hukuman kepada Hawa"
    ],
    "answer": 0,
    "reference": "Genesis 4:25",
    "explanation": "Lihat Genesis 4:25."
  },
  {
    "id": "imported-166",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian nama kepada Nuh dalam Kejadian 5:29?",
    "choices": [
      "Harapan Lamekh",
      "Kekayaan Lamekh",
      "Tiada makna",
      "Hukuman kepada Lamekh"
    ],
    "answer": 0,
    "reference": "Genesis 5:29",
    "explanation": "Lihat Genesis 5:29."
  },
  {
    "id": "imported-167",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian nama kepada Sem dalam Kejadian 9:18?",
    "choices": [
      "Harapan Nuh",
      "Kekayaan Nuh",
      "Tiada makna",
      "Hukuman kepada Sem"
    ],
    "answer": 0,
    "reference": "Genesis 9:18",
    "explanation": "Lihat Genesis 9:18."
  },
  {
    "id": "imported-168",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian nama kepada Ham dalam Kejadian 9:18?",
    "choices": [
      "Harapan Nuh",
      "Kekayaan Nuh",
      "Tiada makna",
      "Hukuman kepada Ham"
    ],
    "answer": 0,
    "reference": "Genesis 9:18",
    "explanation": "Lihat Genesis 9:18."
  },
  {
    "id": "imported-169",
    "category": "Kejadian",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "Apakah yang ditunjukkan oleh pemberian nama kepada Yafet dalam Kejadian 9:18?",
    "choices": [
      "Harapan Nuh",
      "Kekayaan Nuh",
      "Tiada makna",
      "Hukuman kepada Yafet"
    ],
    "answer": 0,
    "reference": "Genesis 9:18",
    "explanation": "Lihat Genesis 9:18."
  },
  {
    "id": "bible-survey-ot-pentateuch-01",
    "category": "구약 1. 모세오경",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "창세기의 시작에서 하나님이 창조하신 것은 무엇입니까?",
    "choices": [
      "하늘과 땅",
      "성전",
      "왕궁",
      "바벨론"
    ],
    "answer": 0,
    "reference": "Genesis 1:1",
    "explanation": "창세기는 하나님이 하늘과 땅을 창조하신 사건으로 시작합니다."
  },
  {
    "id": "bible-survey-ot-pentateuch-02",
    "category": "구약 1. 모세오경",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "하나님이 아브라함에게 약속하신 땅은 어디입니까?",
    "choices": [
      "애굽",
      "가나안",
      "앗수르",
      "로마"
    ],
    "answer": 1,
    "reference": "Genesis 12:1-7",
    "explanation": "하나님은 아브라함에게 가나안 땅을 약속하셨습니다."
  },
  {
    "id": "bible-survey-ot-pentateuch-03",
    "category": "구약 1. 모세오경",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "출애굽기에서 하나님이 이스라엘을 건져 내신 나라는 어디입니까?",
    "choices": [
      "애굽",
      "모압",
      "페르시아",
      "그리스"
    ],
    "answer": 0,
    "reference": "Exodus 12:31-42",
    "explanation": "출애굽기는 하나님이 이스라엘을 애굽에서 구원하신 일을 중심으로 전개됩니다."
  },
  {
    "id": "bible-survey-ot-pentateuch-04",
    "category": "구약 1. 모세오경",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "출애굽 후 하나님이 모세에게 율법을 주신 산은 어디입니까?",
    "choices": [
      "갈멜 산",
      "시내 산",
      "시온 산",
      "느보 산"
    ],
    "answer": 1,
    "reference": "Exodus 19:1-20:21",
    "explanation": "시내 산은 하나님이 모세를 통해 언약과 율법을 주신 장소입니다."
  },
  {
    "id": "bible-survey-ot-pentateuch-05",
    "category": "구약 1. 모세오경",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "레위기의 중심 주제에 가장 가까운 것은 무엇입니까?",
    "choices": [
      "거룩한 예배와 삶",
      "왕국의 멸망",
      "포로 귀환",
      "초대교회 선교"
    ],
    "answer": 0,
    "reference": "Leviticus 19:1-2",
    "explanation": "레위기는 하나님 앞에서 거룩하게 예배하고 살아가는 길을 다룹니다."
  },
  {
    "id": "bible-survey-ot-pentateuch-06",
    "category": "구약 1. 모세오경",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "민수기에서 이스라엘이 주로 지나간 장소는 어디입니까?",
    "choices": [
      "광야",
      "바벨론",
      "로마",
      "니느웨"
    ],
    "answer": 0,
    "reference": "Numbers 10:11-12",
    "explanation": "민수기는 광야 여정 속에서 드러난 믿음과 불순종을 보여 줍니다."
  },
  {
    "id": "bible-survey-ot-pentateuch-07",
    "category": "구약 1. 모세오경",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "가나안 정탐 후 하나님을 신뢰하자고 한 대표 인물은 누구입니까?",
    "choices": [
      "가인과 아벨",
      "여호수아와 갈렙",
      "사울과 다윗",
      "엘리야와 엘리사"
    ],
    "answer": 1,
    "reference": "Numbers 14:6-9",
    "explanation": "여호수아와 갈렙은 하나님이 약속하신 땅을 주실 것을 믿었습니다."
  },
  {
    "id": "bible-survey-ot-pentateuch-08",
    "category": "구약 1. 모세오경",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "신명기에서 모세는 약속의 땅에 들어가기 전 백성에게 무엇을 다시 가르칩니까?",
    "choices": [
      "율법과 언약",
      "성전 건축법",
      "왕의 족보",
      "로마 시민권"
    ],
    "answer": 0,
    "reference": "Deuteronomy 1:1-5",
    "explanation": "신명기는 모세가 다음 세대에게 율법과 언약을 다시 설명하는 책입니다."
  },
  {
    "id": "bible-survey-ot-pentateuch-09",
    "category": "구약 1. 모세오경",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "모세오경의 마지막 책은 무엇입니까?",
    "choices": [
      "창세기",
      "레위기",
      "민수기",
      "신명기"
    ],
    "answer": 3,
    "reference": "Deuteronomy 34:1-12",
    "explanation": "신명기는 모세오경의 마지막 책입니다."
  },
  {
    "id": "bible-survey-ot-pentateuch-10",
    "category": "구약 1. 모세오경",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "모세오경 전체의 흐름을 가장 잘 설명하는 말은 무엇입니까?",
    "choices": [
      "창조, 언약, 출애굽, 율법, 약속의 땅 준비",
      "왕들의 전쟁만 기록",
      "포로 생활만 기록",
      "예수님의 비유만 기록"
    ],
    "answer": 0,
    "reference": "Genesis-Deuteronomy",
    "explanation": "모세오경은 창조에서 시작해 언약, 출애굽, 율법, 약속의 땅 앞 준비로 이어집니다."
  },
  {
    "id": "bible-survey-ot-history-01",
    "category": "구약 2. 역사서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "여호수아서는 어떤 사건 이후의 이야기를 다룹니까?",
    "choices": [
      "출애굽 후 가나안 정착",
      "바벨론 포로 이후 로마 통치",
      "예수님의 탄생",
      "초대교회의 선교"
    ],
    "answer": 0,
    "reference": "Joshua 1:1-9",
    "explanation": "여호수아서는 모세 이후 이스라엘이 가나안에 들어가는 과정을 다룹니다."
  },
  {
    "id": "bible-survey-ot-history-02",
    "category": "구약 2. 역사서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "여리고 성 정복 이야기와 관련된 책은 무엇입니까?",
    "choices": [
      "여호수아",
      "욥기",
      "말라기",
      "로마서"
    ],
    "answer": 0,
    "reference": "Joshua 6:1-27",
    "explanation": "여리고 성 이야기는 여호수아서에 나옵니다."
  },
  {
    "id": "bible-survey-ot-history-03",
    "category": "구약 2. 역사서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "사사기의 반복되는 흐름에 가장 가까운 것은 무엇입니까?",
    "choices": [
      "죄, 압제, 부르짖음, 구원",
      "창조, 안식, 홍수, 언약",
      "탄생, 세례, 십자가, 부활",
      "환상, 인, 나팔, 새 예루살렘"
    ],
    "answer": 0,
    "reference": "Judges 2:11-19",
    "explanation": "사사기는 이스라엘의 반복되는 불순종과 하나님의 구원을 보여 줍니다."
  },
  {
    "id": "bible-survey-ot-history-04",
    "category": "구약 2. 역사서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "룻기의 주요 인물은 누구입니까?",
    "choices": [
      "룻과 나오미",
      "드보라와 바락",
      "에스더와 모르드개",
      "마리아와 마르다"
    ],
    "answer": 0,
    "reference": "Ruth 1:1-18",
    "explanation": "룻기는 룻과 나오미의 이야기와 하나님의 섭리를 보여 줍니다."
  },
  {
    "id": "bible-survey-ot-history-05",
    "category": "구약 2. 역사서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "이스라엘의 첫 왕은 누구입니까?",
    "choices": [
      "사울",
      "다윗",
      "솔로몬",
      "히스기야"
    ],
    "answer": 0,
    "reference": "1 Samuel 10:17-27",
    "explanation": "사무엘상은 사울이 이스라엘의 첫 왕으로 세워지는 일을 기록합니다."
  },
  {
    "id": "bible-survey-ot-history-06",
    "category": "구약 2. 역사서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "예루살렘 성전을 건축한 왕은 누구입니까?",
    "choices": [
      "사울",
      "다윗",
      "솔로몬",
      "요시야"
    ],
    "answer": 2,
    "reference": "1 Kings 6:1-38",
    "explanation": "솔로몬은 예루살렘 성전을 건축했습니다."
  },
  {
    "id": "bible-survey-ot-history-07",
    "category": "구약 2. 역사서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "열왕기에서 북이스라엘과 남유다가 결국 겪은 일은 무엇입니까?",
    "choices": [
      "포로와 멸망",
      "로마 시민권 획득",
      "홍해 도하",
      "초대교회 설립"
    ],
    "answer": 0,
    "reference": "2 Kings 17:1-23; 25:1-21",
    "explanation": "열왕기는 왕국의 분열과 멸망을 보여 줍니다."
  },
  {
    "id": "bible-survey-ot-history-08",
    "category": "구약 2. 역사서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "에스라서와 느헤미야서는 주로 어떤 시대를 다룹니까?",
    "choices": [
      "포로 귀환과 재건",
      "애굽 노예 생활",
      "광야 방랑",
      "예수님의 공생애"
    ],
    "answer": 0,
    "reference": "Ezra 1:1-4; Nehemiah 2:1-20",
    "explanation": "에스라와 느헤미야는 포로 귀환 후 성전과 성벽 재건을 다룹니다."
  },
  {
    "id": "bible-survey-ot-history-09",
    "category": "구약 2. 역사서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "에스더서에서 유다 백성을 구하는 데 쓰임 받은 왕비는 누구입니까?",
    "choices": [
      "에스더",
      "이세벨",
      "드릴라",
      "밧세바"
    ],
    "answer": 0,
    "reference": "Esther 4:13-17",
    "explanation": "에스더는 위기 속에서 유다 백성을 위해 나아갔습니다."
  },
  {
    "id": "bible-survey-ot-history-10",
    "category": "구약 2. 역사서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "구약 역사서의 큰 흐름은 무엇을 보여 줍니까?",
    "choices": [
      "약속의 땅, 왕국, 포로, 귀환",
      "오직 성전 치수",
      "예수님의 비유",
      "바울의 선교 여행만"
    ],
    "answer": 0,
    "reference": "Joshua-Esther",
    "explanation": "역사서는 약속의 땅 정착부터 왕국, 포로, 귀환까지의 흐름을 보여 줍니다."
  },
  {
    "id": "bible-survey-ot-wisdom-01",
    "category": "구약 3. 시가서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "욥기의 중심 질문에 가장 가까운 것은 무엇입니까?",
    "choices": [
      "의인의 고난",
      "성전 건축",
      "왕국 분열",
      "로마 재판"
    ],
    "answer": 0,
    "reference": "Job 1:1-22",
    "explanation": "욥기는 의인의 고난과 하나님 앞에서의 믿음을 깊이 다룹니다."
  },
  {
    "id": "bible-survey-ot-wisdom-02",
    "category": "구약 3. 시가서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "시편은 주로 어떤 성격의 책입니까?",
    "choices": [
      "기도와 찬양의 모음",
      "왕들의 연대기",
      "제사장 명단",
      "선교 여행 기록"
    ],
    "answer": 0,
    "reference": "Psalms",
    "explanation": "시편은 하나님께 드리는 기도, 찬양, 탄식, 감사의 노래를 담고 있습니다."
  },
  {
    "id": "bible-survey-ot-wisdom-03",
    "category": "구약 3. 시가서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "잠언의 중심 주제에 가장 가까운 것은 무엇입니까?",
    "choices": [
      "하나님을 경외하는 지혜",
      "성전 파괴",
      "광야 행군",
      "로마 감옥"
    ],
    "answer": 0,
    "reference": "Proverbs 1:7",
    "explanation": "잠언은 여호와를 경외하는 것이 지혜의 근본임을 가르칩니다."
  },
  {
    "id": "bible-survey-ot-wisdom-04",
    "category": "구약 3. 시가서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "전도서가 반복해서 묻는 인생의 주제는 무엇입니까?",
    "choices": [
      "하나님 없는 삶의 헛됨",
      "가나안 정복 전략",
      "왕들의 전쟁 기록",
      "초대교회 직분"
    ],
    "answer": 0,
    "reference": "Ecclesiastes 1:1-11",
    "explanation": "전도서는 하나님을 떠난 삶의 헛됨과 하나님을 경외하는 삶을 생각하게 합니다."
  },
  {
    "id": "bible-survey-ot-wisdom-05",
    "category": "구약 3. 시가서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "아가서는 주로 어떤 사랑의 언어를 담고 있습니까?",
    "choices": [
      "신랑과 신부의 사랑",
      "왕의 전쟁 명령",
      "포로 귀환 명단",
      "사도의 선교 보고"
    ],
    "answer": 0,
    "reference": "Song of Songs",
    "explanation": "아가서는 사랑의 아름다움을 시적인 언어로 노래합니다."
  },
  {
    "id": "bible-survey-ot-wisdom-06",
    "category": "구약 3. 시가서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "시편 23편에서 하나님은 어떤 분으로 고백됩니까?",
    "choices": [
      "목자",
      "바로",
      "로마 총독",
      "바벨론 왕"
    ],
    "answer": 0,
    "reference": "Psalm 23:1",
    "explanation": "시편 23편은 여호와를 목자로 고백합니다."
  },
  {
    "id": "bible-survey-ot-wisdom-07",
    "category": "구약 3. 시가서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "잠언에서 지혜와 대조되는 태도는 무엇입니까?",
    "choices": [
      "미련함",
      "겸손",
      "회개",
      "순종"
    ],
    "answer": 0,
    "reference": "Proverbs 1:20-33",
    "explanation": "잠언은 지혜로운 길과 미련한 길을 대조합니다."
  },
  {
    "id": "bible-survey-ot-wisdom-08",
    "category": "구약 3. 시가서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "시가서가 신앙생활에 주는 도움은 무엇입니까?",
    "choices": [
      "마음의 기도와 지혜를 배움",
      "왕들의 순서만 외움",
      "지도 경로만 확인",
      "로마 법만 배움"
    ],
    "answer": 0,
    "reference": "Job-Song of Songs",
    "explanation": "시가서는 고난, 찬양, 지혜, 인생, 사랑을 하나님 앞에서 생각하게 합니다."
  },
  {
    "id": "bible-survey-ot-wisdom-09",
    "category": "구약 3. 시가서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "감사와 찬양의 언어가 가장 많이 나타나는 책은 무엇입니까?",
    "choices": [
      "시편",
      "에스라",
      "아모스",
      "갈라디아서"
    ],
    "answer": 0,
    "reference": "Psalms",
    "explanation": "시편에는 감사와 찬양의 고백이 풍성하게 담겨 있습니다."
  },
  {
    "id": "bible-survey-ot-wisdom-10",
    "category": "구약 3. 시가서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "구약 시가서에 포함되지 않는 책은 무엇입니까?",
    "choices": [
      "잠언",
      "시편",
      "전도서",
      "마태복음"
    ],
    "answer": 3,
    "reference": "Job-Song of Songs",
    "explanation": "마태복음은 신약 복음서입니다."
  },
  {
    "id": "bible-survey-ot-major-prophets-01",
    "category": "구약 4. 대선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "이사야서에서 반복해서 드러나는 큰 주제는 무엇입니까?",
    "choices": [
      "거룩하신 하나님과 구원",
      "로마 시민권",
      "초대교회 회의",
      "사사들의 족보"
    ],
    "answer": 0,
    "reference": "Isaiah 6:1-8",
    "explanation": "이사야서는 거룩하신 하나님, 심판, 회복, 구원의 소망을 전합니다."
  },
  {
    "id": "bible-survey-ot-major-prophets-02",
    "category": "구약 4. 대선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "예레미야는 주로 어느 도시의 멸망을 앞두고 말씀을 전했습니까?",
    "choices": [
      "예루살렘",
      "니느웨",
      "로마",
      "아덴"
    ],
    "answer": 0,
    "reference": "Jeremiah 1:1-10; 39:1-10",
    "explanation": "예레미야는 예루살렘의 멸망을 앞두고 회개와 심판의 말씀을 전했습니다."
  },
  {
    "id": "bible-survey-ot-major-prophets-03",
    "category": "구약 4. 대선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "예레미야애가는 어떤 분위기의 책입니까?",
    "choices": [
      "예루살렘 멸망에 대한 애통",
      "성전 완공 축하",
      "로마 선교 보고",
      "왕의 결혼 노래"
    ],
    "answer": 0,
    "reference": "Lamentations 1:1-5",
    "explanation": "예레미야애가는 예루살렘의 비극을 슬퍼하는 애가입니다."
  },
  {
    "id": "bible-survey-ot-major-prophets-04",
    "category": "구약 4. 대선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "에스겔은 주로 어느 상황 속에서 예언했습니까?",
    "choices": [
      "바벨론 포로 생활",
      "애굽 노예 이전",
      "로마 감옥",
      "갈릴리 어부 생활"
    ],
    "answer": 0,
    "reference": "Ezekiel 1:1-3",
    "explanation": "에스겔은 바벨론 포로 중에 하나님의 말씀을 전했습니다."
  },
  {
    "id": "bible-survey-ot-major-prophets-05",
    "category": "구약 4. 대선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "다니엘서의 주요 배경은 어디입니까?",
    "choices": [
      "바벨론과 페르시아",
      "가나안 정복지",
      "로마 원형극장",
      "고린도 교회"
    ],
    "answer": 0,
    "reference": "Daniel 1:1-7",
    "explanation": "다니엘서는 포로로 끌려간 다니엘과 친구들의 믿음을 보여 줍니다."
  },
  {
    "id": "bible-survey-ot-major-prophets-06",
    "category": "구약 4. 대선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "다니엘의 세 친구가 우상에게 절하지 않아 들어간 곳은 어디입니까?",
    "choices": [
      "풀무불",
      "사자 굴",
      "홍해",
      "성막"
    ],
    "answer": 0,
    "reference": "Daniel 3:1-30",
    "explanation": "다니엘의 세 친구는 풀무불 속에서도 하나님께 지켜졌습니다."
  },
  {
    "id": "bible-survey-ot-major-prophets-07",
    "category": "구약 4. 대선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "다니엘이 기도 때문에 던져진 곳은 어디입니까?",
    "choices": [
      "사자 굴",
      "홍해",
      "감람산",
      "갈멜산"
    ],
    "answer": 0,
    "reference": "Daniel 6:1-28",
    "explanation": "다니엘은 기도 때문에 사자 굴에 던져졌지만 하나님이 보호하셨습니다."
  },
  {
    "id": "bible-survey-ot-major-prophets-08",
    "category": "구약 4. 대선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "대선지서가 전하는 공통 메시지에 가까운 것은 무엇입니까?",
    "choices": [
      "죄에 대한 심판과 회복의 소망",
      "성전 재료 목록만",
      "예수님의 열두 제자 명단",
      "바울의 편지 인사말만"
    ],
    "answer": 0,
    "reference": "Isaiah-Daniel",
    "explanation": "대선지서는 심판의 경고와 회복의 약속을 함께 전합니다."
  },
  {
    "id": "bible-survey-ot-major-prophets-09",
    "category": "구약 4. 대선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "새 언약의 약속이 뚜렷하게 나오는 선지서는 무엇입니까?",
    "choices": [
      "예레미야",
      "룻기",
      "요나",
      "빌립보서"
    ],
    "answer": 0,
    "reference": "Jeremiah 31:31-34",
    "explanation": "예레미야는 하나님이 새 언약을 세우실 것을 전했습니다."
  },
  {
    "id": "bible-survey-ot-major-prophets-10",
    "category": "구약 4. 대선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "마른 뼈 환상으로 회복의 소망을 전한 선지자는 누구입니까?",
    "choices": [
      "에스겔",
      "이사야",
      "다니엘",
      "호세아"
    ],
    "answer": 0,
    "reference": "Ezekiel 37:1-14",
    "explanation": "에스겔의 마른 뼈 환상은 하나님의 회복 능력을 보여 줍니다."
  },
  {
    "id": "bible-survey-ot-minor-prophets-01",
    "category": "구약 5. 소선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "호세아서에서 하나님과 이스라엘의 관계는 어떤 이미지로 자주 설명됩니까?",
    "choices": [
      "언약적 사랑",
      "전쟁 계약",
      "상업 거래",
      "로마 재판"
    ],
    "answer": 0,
    "reference": "Hosea 1-3",
    "explanation": "호세아서는 하나님의 신실한 사랑과 이스라엘의 불신실함을 보여 줍니다."
  },
  {
    "id": "bible-survey-ot-minor-prophets-02",
    "category": "구약 5. 소선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "요엘서에서 백성에게 요청되는 태도는 무엇입니까?",
    "choices": [
      "회개하고 하나님께 돌아감",
      "우상에게 절함",
      "애굽으로 도망감",
      "로마에 세금 거부"
    ],
    "answer": 0,
    "reference": "Joel 2:12-17",
    "explanation": "요엘은 마음을 찢고 하나님께 돌아오라고 촉구합니다."
  },
  {
    "id": "bible-survey-ot-minor-prophets-03",
    "category": "구약 5. 소선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "아모스가 강하게 외친 주제는 무엇입니까?",
    "choices": [
      "정의와 공의",
      "왕궁 장식",
      "성전 치수",
      "선박 무역"
    ],
    "answer": 0,
    "reference": "Amos 5:21-24",
    "explanation": "아모스는 형식적 예배보다 정의와 공의를 강조합니다."
  },
  {
    "id": "bible-survey-ot-minor-prophets-04",
    "category": "구약 5. 소선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "요나는 어느 성읍에 가서 말씀을 전하라는 명령을 받았습니까?",
    "choices": [
      "니느웨",
      "예루살렘",
      "베들레헴",
      "로마"
    ],
    "answer": 0,
    "reference": "Jonah 1:1-2",
    "explanation": "요나는 니느웨에 가서 하나님의 말씀을 전하라는 명령을 받았습니다."
  },
  {
    "id": "bible-survey-ot-minor-prophets-05",
    "category": "구약 5. 소선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "미가서에서 하나님이 사람에게 구하시는 삶으로 제시되는 것은 무엇입니까?",
    "choices": [
      "정의, 인자, 겸손",
      "전쟁, 부, 명성",
      "성벽, 말, 병거",
      "금, 은, 향품"
    ],
    "answer": 0,
    "reference": "Micah 6:8",
    "explanation": "미가는 정의를 행하고 인자를 사랑하며 겸손히 하나님과 동행하라고 전합니다."
  },
  {
    "id": "bible-survey-ot-minor-prophets-06",
    "category": "구약 5. 소선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "하박국이 씨름한 질문에 가까운 것은 무엇입니까?",
    "choices": [
      "악인이 형통해 보일 때의 믿음",
      "성전 건축 재료",
      "왕의 혼인 절차",
      "사도의 여행 경로"
    ],
    "answer": 0,
    "reference": "Habakkuk 1:1-4",
    "explanation": "하박국은 악과 고난의 현실 속에서 하나님을 신뢰하는 믿음을 배웁니다."
  },
  {
    "id": "bible-survey-ot-minor-prophets-07",
    "category": "구약 5. 소선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "스가랴와 학개는 주로 어떤 일을 격려했습니까?",
    "choices": [
      "성전 재건",
      "홍해 도하",
      "사사 임명",
      "로마 원정"
    ],
    "answer": 0,
    "reference": "Haggai 1:1-15; Zechariah 1:1-6",
    "explanation": "학개와 스가랴는 포로 귀환 후 성전 재건을 격려했습니다."
  },
  {
    "id": "bible-survey-ot-minor-prophets-08",
    "category": "구약 5. 소선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "말라기서는 구약의 마지막 부분에서 무엇을 촉구합니까?",
    "choices": [
      "언약에 대한 신실함",
      "가나안 정탐",
      "바울의 선교",
      "요한계시록 해석"
    ],
    "answer": 0,
    "reference": "Malachi 3:1-7",
    "explanation": "말라기는 하나님과의 언약에 신실하게 돌아오라고 촉구합니다."
  },
  {
    "id": "bible-survey-ot-minor-prophets-09",
    "category": "구약 5. 소선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "소선지서의 '소'는 무엇을 뜻합니까?",
    "choices": [
      "책의 길이가 비교적 짧음",
      "내용이 덜 중요함",
      "어린 선지자만 기록함",
      "동물 이야기만 기록함"
    ],
    "answer": 0,
    "reference": "Hosea-Malachi",
    "explanation": "소선지서는 내용이 덜 중요하다는 뜻이 아니라 책의 분량이 비교적 짧다는 뜻입니다."
  },
  {
    "id": "bible-survey-ot-minor-prophets-10",
    "category": "구약 5. 소선지서",
    "testament": "old",
    "difficulty": "easy",
    "prompt": "소선지서 전체의 공통 메시지에 가까운 것은 무엇입니까?",
    "choices": [
      "회개, 정의, 심판, 회복",
      "왕의 족보만",
      "성전 도면만",
      "로마 법률만"
    ],
    "answer": 0,
    "reference": "Hosea-Malachi",
    "explanation": "소선지서는 회개와 정의, 심판과 회복의 메시지를 전합니다."
  },
  {
    "id": "bible-survey-nt-gospels-01",
    "category": "신약 1. 복음서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "복음서의 중심 인물은 누구입니까?",
    "choices": [
      "예수 그리스도",
      "모세",
      "다윗",
      "바울"
    ],
    "answer": 0,
    "reference": "Matthew-John",
    "explanation": "복음서는 예수 그리스도의 생애와 가르침, 십자가와 부활을 전합니다."
  },
  {
    "id": "bible-survey-nt-gospels-02",
    "category": "신약 1. 복음서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "예수님이 태어나신 곳으로 알려진 마을은 어디입니까?",
    "choices": [
      "베들레헴",
      "나사렛",
      "가버나움",
      "고린도"
    ],
    "answer": 0,
    "reference": "Matthew 2:1; Luke 2:1-7",
    "explanation": "마태복음과 누가복음은 예수님의 탄생을 베들레헴과 연결해 기록합니다."
  },
  {
    "id": "bible-survey-nt-gospels-03",
    "category": "신약 1. 복음서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "예수님에게 세례를 베푼 사람은 누구입니까?",
    "choices": [
      "세례 요한",
      "베드로",
      "바울",
      "빌라도"
    ],
    "answer": 0,
    "reference": "Matthew 3:13-17",
    "explanation": "세례 요한은 예수님께 세례를 베풀었습니다."
  },
  {
    "id": "bible-survey-nt-gospels-04",
    "category": "신약 1. 복음서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "예수님이 하나님 나라를 설명하실 때 자주 사용하신 방식은 무엇입니까?",
    "choices": [
      "비유",
      "왕의 칙령",
      "군사 명령",
      "무역 계약"
    ],
    "answer": 0,
    "reference": "Matthew 13:1-52",
    "explanation": "예수님은 비유를 통해 하나님 나라를 가르치셨습니다."
  },
  {
    "id": "bible-survey-nt-gospels-05",
    "category": "신약 1. 복음서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "예수님이 십자가에 못 박히신 곳은 어디로 불립니까?",
    "choices": [
      "골고다",
      "시내 산",
      "갈멜 산",
      "아라랏"
    ],
    "answer": 0,
    "reference": "Matthew 27:33",
    "explanation": "복음서는 예수님이 골고다에서 십자가에 못 박히셨다고 기록합니다."
  },
  {
    "id": "bible-survey-nt-gospels-06",
    "category": "신약 1. 복음서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "복음서가 증언하는 예수님의 마지막 승리는 무엇입니까?",
    "choices": [
      "부활",
      "왕궁 건축",
      "바벨론 정복",
      "로마 시민권 획득"
    ],
    "answer": 0,
    "reference": "Matthew 28:1-10",
    "explanation": "복음서는 예수님의 부활을 기쁜 소식의 핵심으로 전합니다."
  },
  {
    "id": "bible-survey-nt-gospels-07",
    "category": "신약 1. 복음서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "요한복음에서 예수님은 자신을 무엇이라고 말씀하십니까?",
    "choices": [
      "길과 진리와 생명",
      "로마 장군",
      "성전 문지기",
      "바벨론 왕"
    ],
    "answer": 0,
    "reference": "John 14:6",
    "explanation": "요한복음은 예수님이 길과 진리와 생명이라고 말씀하신 것을 기록합니다."
  },
  {
    "id": "bible-survey-nt-gospels-08",
    "category": "신약 1. 복음서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "예수님이 제자들에게 모든 민족을 제자로 삼으라고 하신 명령은 무엇이라 불립니까?",
    "choices": [
      "대위임령",
      "십계명",
      "다윗 언약",
      "바벨론 칙령"
    ],
    "answer": 0,
    "reference": "Matthew 28:18-20",
    "explanation": "마태복음 마지막 부분에는 모든 민족을 제자로 삼으라는 명령이 나옵니다."
  },
  {
    "id": "bible-survey-nt-gospels-09",
    "category": "신약 1. 복음서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "마가복음은 예수님의 어떤 모습을 빠르게 보여 주는 편입니까?",
    "choices": [
      "섬기시는 종",
      "포로 왕",
      "성전 건축자",
      "바벨론 학자"
    ],
    "answer": 0,
    "reference": "Mark 10:45",
    "explanation": "마가복음은 섬기고 자기 목숨을 주시는 예수님의 모습을 강조합니다."
  },
  {
    "id": "bible-survey-nt-gospels-10",
    "category": "신약 1. 복음서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "복음서 네 권에 포함되지 않는 책은 무엇입니까?",
    "choices": [
      "마태복음",
      "마가복음",
      "누가복음",
      "사도행전"
    ],
    "answer": 3,
    "reference": "Matthew-John; Acts",
    "explanation": "사도행전은 복음서 다음에 이어지는 신약 역사서입니다."
  },
  {
    "id": "bible-survey-nt-history-01",
    "category": "신약 2. 역사서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "신약의 역사서로 분류되는 책은 무엇입니까?",
    "choices": [
      "사도행전",
      "로마서",
      "히브리서",
      "요한계시록"
    ],
    "answer": 0,
    "reference": "Acts",
    "explanation": "신약 역사서는 사도행전입니다."
  },
  {
    "id": "bible-survey-nt-history-02",
    "category": "신약 2. 역사서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "사도행전은 예수님의 승천 이후 무엇이 확장되는 과정을 보여 줍니까?",
    "choices": [
      "복음과 교회",
      "성전 제사",
      "왕국 세금",
      "바벨론 포로"
    ],
    "answer": 0,
    "reference": "Acts 1:8",
    "explanation": "사도행전은 성령의 능력으로 복음이 확장되는 과정을 보여 줍니다."
  },
  {
    "id": "bible-survey-nt-history-03",
    "category": "신약 2. 역사서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "오순절에 제자들에게 임하신 분은 누구입니까?",
    "choices": [
      "성령",
      "바로",
      "느부갓네살",
      "가이사"
    ],
    "answer": 0,
    "reference": "Acts 2:1-13",
    "explanation": "사도행전 2장은 성령 강림 사건을 기록합니다."
  },
  {
    "id": "bible-survey-nt-history-04",
    "category": "신약 2. 역사서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "초대교회가 처음부터 힘써 전한 중심 소식은 무엇입니까?",
    "choices": [
      "예수님의 죽음과 부활",
      "로마 정치 개혁",
      "성전 장식",
      "상업 규칙"
    ],
    "answer": 0,
    "reference": "Acts 2:22-36",
    "explanation": "사도들은 예수님의 십자가와 부활을 중심으로 복음을 전했습니다."
  },
  {
    "id": "bible-survey-nt-history-05",
    "category": "신약 2. 역사서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "스데반은 어떤 사람으로 기억됩니까?",
    "choices": [
      "첫 순교자",
      "애굽 왕",
      "바벨론 장군",
      "로마 총독"
    ],
    "answer": 0,
    "reference": "Acts 7:54-60",
    "explanation": "스데반은 예수님을 증언하다가 순교한 사람으로 기록됩니다."
  },
  {
    "id": "bible-survey-nt-history-06",
    "category": "신약 2. 역사서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "사울이 예수님을 만난 길은 어디로 가는 길이었습니까?",
    "choices": [
      "다메섹",
      "여리고",
      "베들레헴",
      "니느웨"
    ],
    "answer": 0,
    "reference": "Acts 9:1-19",
    "explanation": "사울은 다메섹으로 가는 길에서 부활하신 예수님을 만났습니다."
  },
  {
    "id": "bible-survey-nt-history-07",
    "category": "신약 2. 역사서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "고넬료 사건은 복음이 누구에게도 열려 있음을 보여 줍니까?",
    "choices": [
      "이방인",
      "제사장만",
      "왕족만",
      "레위인만"
    ],
    "answer": 0,
    "reference": "Acts 10:1-48",
    "explanation": "고넬료 사건은 복음이 이방인에게도 열려 있음을 보여 줍니다."
  },
  {
    "id": "bible-survey-nt-history-08",
    "category": "신약 2. 역사서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "바울과 바나바는 어느 교회에서 선교를 위해 파송됩니까?",
    "choices": [
      "안디옥 교회",
      "고린도 교회",
      "라오디게아 교회",
      "사데 교회"
    ],
    "answer": 0,
    "reference": "Acts 13:1-3",
    "explanation": "안디옥 교회는 바울과 바나바를 선교 사역으로 파송했습니다."
  },
  {
    "id": "bible-survey-nt-history-09",
    "category": "신약 2. 역사서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "사도행전 마지막 부분에서 바울이 도착하는 도시는 어디입니까?",
    "choices": [
      "로마",
      "바벨론",
      "니느웨",
      "수산"
    ],
    "answer": 0,
    "reference": "Acts 28:11-31",
    "explanation": "사도행전은 바울이 로마에서 복음을 전하는 장면으로 마무리됩니다."
  },
  {
    "id": "bible-survey-nt-history-10",
    "category": "신약 2. 역사서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "사도행전의 큰 흐름을 가장 잘 설명하는 말은 무엇입니까?",
    "choices": [
      "예루살렘에서 땅끝으로 복음 확장",
      "가나안 정복만 기록",
      "성전 건축만 기록",
      "왕들의 족보만 기록"
    ],
    "answer": 0,
    "reference": "Acts 1:8",
    "explanation": "사도행전은 예루살렘에서 시작된 복음이 여러 지역으로 확장되는 흐름을 보여 줍니다."
  },
  {
    "id": "bible-survey-nt-pauline-01",
    "category": "신약 3. 바울서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "로마서의 중심 주제에 가까운 것은 무엇입니까?",
    "choices": [
      "복음과 믿음으로 의롭다 하심",
      "성전 건축법",
      "왕들의 전쟁",
      "포로 귀환 명단"
    ],
    "answer": 0,
    "reference": "Romans 1:16-17",
    "explanation": "로마서는 복음과 믿음으로 의롭다 하심을 깊이 설명합니다."
  },
  {
    "id": "bible-survey-nt-pauline-02",
    "category": "신약 3. 바울서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "고린도전서 13장은 어떤 주제로 잘 알려져 있습니까?",
    "choices": [
      "사랑",
      "성벽 재건",
      "홍해 도하",
      "바벨론 제국"
    ],
    "answer": 0,
    "reference": "1 Corinthians 13",
    "explanation": "고린도전서 13장은 사랑의 중요성을 가르칩니다."
  },
  {
    "id": "bible-survey-nt-pauline-03",
    "category": "신약 3. 바울서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "갈라디아서가 강하게 변호하는 진리는 무엇입니까?",
    "choices": [
      "은혜와 믿음의 복음",
      "할례만으로 구원",
      "성전 세금",
      "왕의 혈통"
    ],
    "answer": 0,
    "reference": "Galatians 2:16",
    "explanation": "갈라디아서는 율법의 행위가 아니라 믿음으로 의롭다 하심을 받는 복음을 강조합니다."
  },
  {
    "id": "bible-survey-nt-pauline-04",
    "category": "신약 3. 바울서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "에베소서는 교회를 무엇으로 자주 설명합니까?",
    "choices": [
      "그리스도의 몸",
      "로마 군단",
      "바벨론 시장",
      "애굽 궁전"
    ],
    "answer": 0,
    "reference": "Ephesians 1:22-23",
    "explanation": "에베소서는 교회를 그리스도의 몸으로 설명합니다."
  },
  {
    "id": "bible-survey-nt-pauline-05",
    "category": "신약 3. 바울서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "빌립보서에서 바울이 감옥 중에도 강조하는 태도는 무엇입니까?",
    "choices": [
      "기쁨",
      "복수",
      "두려움",
      "자랑"
    ],
    "answer": 0,
    "reference": "Philippians 4:4",
    "explanation": "빌립보서는 주 안에서 기뻐하라는 권면으로 잘 알려져 있습니다."
  },
  {
    "id": "bible-survey-nt-pauline-06",
    "category": "신약 3. 바울서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "골로새서가 높이는 분은 누구입니까?",
    "choices": [
      "그리스도",
      "가이사",
      "헤롯",
      "바로"
    ],
    "answer": 0,
    "reference": "Colossians 1:15-20",
    "explanation": "골로새서는 그리스도의 충만한 높으심을 강조합니다."
  },
  {
    "id": "bible-survey-nt-pauline-07",
    "category": "신약 3. 바울서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "데살로니가전후서에서 중요한 주제 중 하나는 무엇입니까?",
    "choices": [
      "주님의 다시 오심",
      "가나안 땅 분배",
      "성전 목재",
      "왕의 결혼"
    ],
    "answer": 0,
    "reference": "1 Thessalonians 4:13-18",
    "explanation": "데살로니가 서신은 주님의 재림 소망을 다룹니다."
  },
  {
    "id": "bible-survey-nt-pauline-08",
    "category": "신약 3. 바울서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "디모데전후서와 디도서는 주로 어떤 성격의 편지입니까?",
    "choices": [
      "목회와 교회 질서",
      "전쟁 보고",
      "성전 건축 계약",
      "왕의 족보"
    ],
    "answer": 0,
    "reference": "1 Timothy; 2 Timothy; Titus",
    "explanation": "목회서신은 교회 지도와 바른 가르침을 다룹니다."
  },
  {
    "id": "bible-survey-nt-pauline-09",
    "category": "신약 3. 바울서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "빌레몬서는 어떤 사람을 둘러싼 화해의 편지입니까?",
    "choices": [
      "오네시모",
      "아볼로",
      "고넬료",
      "가말리엘"
    ],
    "answer": 0,
    "reference": "Philemon",
    "explanation": "빌레몬서는 오네시모와 관련된 용서와 화해의 편지입니다."
  },
  {
    "id": "bible-survey-nt-pauline-10",
    "category": "신약 3. 바울서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "바울서신에 포함되지 않는 책은 무엇입니까?",
    "choices": [
      "로마서",
      "갈라디아서",
      "빌립보서",
      "요한계시록"
    ],
    "answer": 3,
    "reference": "Romans-Philemon; Revelation",
    "explanation": "요한계시록은 예언서로 분류됩니다."
  },
  {
    "id": "bible-survey-nt-general-01",
    "category": "신약 4. 공동서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "히브리서가 강조하는 예수님의 사역은 무엇입니까?",
    "choices": [
      "완전한 대제사장",
      "로마 장군",
      "애굽 총리",
      "바벨론 왕"
    ],
    "answer": 0,
    "reference": "Hebrews 4:14-16",
    "explanation": "히브리서는 예수님을 완전한 대제사장으로 제시합니다."
  },
  {
    "id": "bible-survey-nt-general-02",
    "category": "신약 4. 공동서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "야고보서가 강조하는 믿음의 모습은 무엇입니까?",
    "choices": [
      "행함으로 드러나는 믿음",
      "말뿐인 자랑",
      "왕의 권력",
      "성전 장식"
    ],
    "answer": 0,
    "reference": "James 2:14-26",
    "explanation": "야고보서는 참된 믿음이 삶의 열매로 드러남을 가르칩니다."
  },
  {
    "id": "bible-survey-nt-general-03",
    "category": "신약 4. 공동서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "베드로전서는 고난 속 성도에게 무엇을 권면합니까?",
    "choices": [
      "소망과 거룩한 삶",
      "복수와 분노",
      "우상 숭배",
      "로마 숭배"
    ],
    "answer": 0,
    "reference": "1 Peter 1:3-16",
    "explanation": "베드로전서는 고난 중에도 산 소망과 거룩한 삶을 권면합니다."
  },
  {
    "id": "bible-survey-nt-general-04",
    "category": "신약 4. 공동서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "베드로후서가 경계하는 중요한 문제는 무엇입니까?",
    "choices": [
      "거짓 가르침",
      "성전 공사",
      "애굽 탈출",
      "왕의 세금"
    ],
    "answer": 0,
    "reference": "2 Peter 2:1-3",
    "explanation": "베드로후서는 거짓 교사와 거짓 가르침을 경계합니다."
  },
  {
    "id": "bible-survey-nt-general-05",
    "category": "신약 4. 공동서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "요한일서에서 반복적으로 강조되는 것은 무엇입니까?",
    "choices": [
      "사랑과 진리",
      "왕의 전쟁",
      "성전 치수",
      "광야 지도"
    ],
    "answer": 0,
    "reference": "1 John 4:7-12",
    "explanation": "요한일서는 하나님 사랑과 형제 사랑을 강조합니다."
  },
  {
    "id": "bible-survey-nt-general-06",
    "category": "신약 4. 공동서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "요한이서와 요한삼서는 주로 어떤 주제를 다룹니까?",
    "choices": [
      "진리와 사랑, 손대접",
      "성전 건축",
      "사사 시대",
      "왕국 분열"
    ],
    "answer": 0,
    "reference": "2 John; 3 John",
    "explanation": "요한이서와 요한삼서는 진리 안에서 사랑하고 바르게 섬기는 일을 다룹니다."
  },
  {
    "id": "bible-survey-nt-general-07",
    "category": "신약 4. 공동서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "유다서가 권면하는 내용에 가까운 것은 무엇입니까?",
    "choices": [
      "믿음을 위해 힘써 싸움",
      "성전 금그릇 제작",
      "왕궁 세금 징수",
      "애굽 곡식 관리"
    ],
    "answer": 0,
    "reference": "Jude 1:3",
    "explanation": "유다서는 성도에게 단번에 주신 믿음을 위해 힘써 싸우라고 권면합니다."
  },
  {
    "id": "bible-survey-nt-general-08",
    "category": "신약 4. 공동서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "공동서신이 여러 교회와 성도에게 주는 도움은 무엇입니까?",
    "choices": [
      "믿음, 사랑, 인내, 분별",
      "지도 제작",
      "왕의 즉위식",
      "성전 건축 수치"
    ],
    "answer": 0,
    "reference": "Hebrews-Jude",
    "explanation": "공동서신은 성도의 믿음과 삶, 사랑과 분별을 권면합니다."
  },
  {
    "id": "bible-survey-nt-general-09",
    "category": "신약 4. 공동서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "공동서신에 포함되지 않는 책은 무엇입니까?",
    "choices": [
      "야고보서",
      "베드로전서",
      "요한일서",
      "로마서"
    ],
    "answer": 3,
    "reference": "Romans; Hebrews-Jude",
    "explanation": "로마서는 바울서신입니다."
  },
  {
    "id": "bible-survey-nt-general-10",
    "category": "신약 4. 공동서신",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "공동서신의 마지막 책은 무엇입니까?",
    "choices": [
      "유다서",
      "히브리서",
      "야고보서",
      "요한삼서"
    ],
    "answer": 0,
    "reference": "Jude",
    "explanation": "유다서는 공동서신의 마지막 책입니다."
  },
  {
    "id": "bible-survey-nt-prophecy-01",
    "category": "신약 5. 예언서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "신약의 예언서로 분류되는 책은 무엇입니까?",
    "choices": [
      "요한계시록",
      "사도행전",
      "로마서",
      "마가복음"
    ],
    "answer": 0,
    "reference": "Revelation",
    "explanation": "신약의 예언서는 요한계시록입니다."
  },
  {
    "id": "bible-survey-nt-prophecy-02",
    "category": "신약 5. 예언서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "요한계시록은 누구에게 주어진 계시로 시작합니까?",
    "choices": [
      "예수 그리스도",
      "모세",
      "다윗",
      "엘리야"
    ],
    "answer": 0,
    "reference": "Revelation 1:1",
    "explanation": "요한계시록은 예수 그리스도의 계시로 시작합니다."
  },
  {
    "id": "bible-survey-nt-prophecy-03",
    "category": "신약 5. 예언서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "요한계시록 초반에는 몇 교회에 보내는 말씀이 나옵니까?",
    "choices": [
      "일곱 교회",
      "두 교회",
      "열두 교회",
      "한 교회"
    ],
    "answer": 0,
    "reference": "Revelation 2-3",
    "explanation": "요한계시록 2-3장에는 일곱 교회에 보내는 말씀이 나옵니다."
  },
  {
    "id": "bible-survey-nt-prophecy-04",
    "category": "신약 5. 예언서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "요한계시록에서 반복적으로 드러나는 중심 소망은 무엇입니까?",
    "choices": [
      "그리스도의 최종 승리",
      "바벨론의 영원한 승리",
      "로마 황제 숭배",
      "성전 세금 증가"
    ],
    "answer": 0,
    "reference": "Revelation 19-22",
    "explanation": "요한계시록은 그리스도의 승리와 하나님 나라의 완성을 보여 줍니다."
  },
  {
    "id": "bible-survey-nt-prophecy-05",
    "category": "신약 5. 예언서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "요한계시록 마지막 부분에 나오는 새 창조의 표현은 무엇입니까?",
    "choices": [
      "새 하늘과 새 땅",
      "새 애굽과 새 바로",
      "새 바벨론과 새 우상",
      "새 로마와 새 황제"
    ],
    "answer": 0,
    "reference": "Revelation 21:1",
    "explanation": "요한계시록은 새 하늘과 새 땅의 소망을 전합니다."
  },
  {
    "id": "bible-survey-nt-prophecy-06",
    "category": "신약 5. 예언서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "요한계시록에서 눈물을 씻기시는 분은 누구입니까?",
    "choices": [
      "하나님",
      "가이사",
      "헤롯",
      "바로"
    ],
    "answer": 0,
    "reference": "Revelation 21:4",
    "explanation": "요한계시록은 하나님이 자기 백성의 눈물을 씻기실 것을 전합니다."
  },
  {
    "id": "bible-survey-nt-prophecy-07",
    "category": "신약 5. 예언서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "요한계시록은 고난 받는 성도에게 어떤 태도를 격려합니까?",
    "choices": [
      "끝까지 믿음을 지킴",
      "우상과 타협함",
      "복음을 버림",
      "두려움에 숨음"
    ],
    "answer": 0,
    "reference": "Revelation 2:10; 14:12",
    "explanation": "요한계시록은 고난 속에서도 믿음과 인내를 지키라고 격려합니다."
  },
  {
    "id": "bible-survey-nt-prophecy-08",
    "category": "신약 5. 예언서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "요한계시록의 마지막 초청에 가까운 말은 무엇입니까?",
    "choices": [
      "주 예수여 오시옵소서",
      "애굽으로 돌아가자",
      "바벨론을 세우자",
      "성전을 버리자"
    ],
    "answer": 0,
    "reference": "Revelation 22:20",
    "explanation": "요한계시록은 주님의 오심을 기다리는 고백으로 마무리됩니다."
  },
  {
    "id": "bible-survey-nt-prophecy-09",
    "category": "신약 5. 예언서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "요한계시록을 읽을 때 붙들어야 할 중심은 무엇입니까?",
    "choices": [
      "예수 그리스도와 하나님의 승리",
      "상징 자체만",
      "두려움만",
      "날짜 계산만"
    ],
    "answer": 0,
    "reference": "Revelation 1:1-8",
    "explanation": "요한계시록은 상징보다 예수 그리스도와 하나님의 승리를 중심에 두고 읽어야 합니다."
  },
  {
    "id": "bible-survey-nt-prophecy-10",
    "category": "신약 5. 예언서",
    "testament": "new",
    "difficulty": "easy",
    "prompt": "신약 전체의 마지막 책은 무엇입니까?",
    "choices": [
      "요한계시록",
      "유다서",
      "사도행전",
      "요한복음"
    ],
    "answer": 0,
    "reference": "Revelation",
    "explanation": "요한계시록은 신약과 성경 전체의 마지막 책입니다."
  }
];

  if (typeof module !== "undefined" && module.exports) {
    module.exports = questions;
  } else {
    root.BIBLE_QUIZ_QUESTIONS = questions;
  }
})(typeof window !== "undefined" ? window : globalThis);
