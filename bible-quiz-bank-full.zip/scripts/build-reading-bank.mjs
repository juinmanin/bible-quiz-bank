import fs from 'node:fs';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const require=createRequire(import.meta.url);
const legacy=require('../bibleChapterQuestionBank.generated.js');
const dir=path.join(root,'question-bank');
const books=legacy.books.map(b=>({id:b.book_id,name:b.title.ko,english:b.title.en,section:b.section_key,testament:b.testament,chapters:b.chapters,order:b.order_index}));
const byId=Object.fromEntries(books.map(b=>[b.id,b]));
const norm=s=>s.toLowerCase().replace(/[^a-z0-9]/g,'');
const byName=Object.fromEntries(books.map(b=>[norm(b.english),b]));
byName.psalm=byId.PSA;byName['1thes']=byId['1TH'];byName['2thes']=byId['2TH'];
function reference(s){
 const m=s.trim().match(/^(\w+) (\d+):(\d+)(?:-(\d+))?$/);
 if(!m||!byId[m[1]]) throw Error(`Invalid reference: ${s}`);
 const b=byId[m[1]],chapter=+m[2],start=+m[3],end=+(m[4]||m[3]);
 if(chapter<1||chapter>b.chapters||end<start)throw Error(`Invalid bounds: ${s}`);
 return {book_id:b.id,chapter,verse_start:start,verse_end:end,label:`${b.name} ${chapter}:${start}${end!==start?'-'+end:''}`,url:`https://www.biblegateway.com/passage/?search=${encodeURIComponent(`${b.english} ${chapter}:${start}-${end}`)}&version=KRV`};
}
const days=JSON.parse(fs.readFileSync(path.join(dir,'mcheyne-source.json'),'utf8')).data2.map((readings,i)=>{
 const date=new Date(Date.UTC(2025,0,i+1));
 return {day:i+1,date:date.toISOString().slice(5,10),readings:readings.map(s=>{
  const m=s.match(/^(.+?)\s+(\d+)(?:-(\d+))?(?::(\d+)-(\d+))?$/);if(!m)throw Error(`Invalid plan entry ${s}`);
  const b=byName[norm(m[1])];if(!b)throw Error(`Unknown book ${s}`);
  const range=`${m[2]}${m[3]?'-'+m[3]:''}${m[4]?':'+m[4]+'-'+m[5]:''}`;
  return {book_id:b.id,chapter_start:+m[2],chapter_end:+(m[3]||m[2]),verse_start:m[4]?+m[4]:null,verse_end:m[5]?+m[5]:null,label:`${b.name} ${range}${m[4]?'':'장'}`,url:`https://www.biblegateway.com/passage/?search=${encodeURIComponent(`${b.english} ${range}`)}&version=KRV`};
 })};
});
const questions=[];let bookId,unit=0;
const explicitFulfillment=new Set(['ISA-02','ISA-03','ISA-04','MIC-04','ZEC-03','ZEC-04','ZEC-05','MAL-04','MAL-05','PSA-02','PSA-05','DEU-04','2SA-03','HOS-04','JOL-04','AMO-05','MAT-01','LUK-03','ACT-02','HEB-01','HEB-04']);
const explicitTypology=new Set(['EXO-02','NUM-04','JON-05','1CO-03','ROM-03','COL-04','HEB-03','HEB-05','1PE-04','REV-03']);
for(const line of fs.readFileSync(path.join(dir,'reading-units.txt'),'utf8').split(/\r?\n/)){
 if(!line||line.startsWith('#'))continue;
 if(line.startsWith('@')){bookId=line.slice(1);unit=0;continue;}
 const fields=line.split('|');if(fields.length!==7)throw Error(`Invalid unit: ${line}`);
 unit++;const refs=fields[0].split(';').map(reference);const unitId=`${bookId}-${String(unit).padStart(2,'0')}`;
 for(const [i,difficulty] of ['easy','medium','hard'].entries()){
  const connection=i!==2?'observation':explicitFulfillment.has(unitId)?'nt_explicit':explicitTypology.has(unitId)?'nt_typology':'thematic_comparison';
  const explanation=`본문 관찰: ${fields[2]}. 본문 이해: ${fields[4]}. 함께 읽기: ${fields[6]}.`;
  questions.push({id:`new-${unitId}-${difficulty}`,unit_id:unitId,book_id:bookId,difficulty,prompt:fields[1+i*2],answer:fields[2+i*2],choices:[],references:refs,explanation,connection,origin:'new',review_status:'ai_draft',arithmetic:false});
 }
}
const authored=fs.readFileSync(path.join(dir,'authored.tsv'),'utf8').trim().split(/\r?\n/).slice(1);
for(const line of authored){
 const [book_id,difficulty,ref,prompt,answer,w1,w2,w3,explanation,connection]=line.split('\t');
 if(!connection)throw Error(`Invalid authored row ${line}`);
 questions.push({id:`new-${book_id}-comprehension`,unit_id:`${book_id}-comprehension`,book_id,difficulty,prompt,answer,choices:[answer,w1,w2,w3],references:ref.split(';').map(reference),explanation,connection,origin:'new',review_status:'ai_draft',arithmetic:false});
}
const revisions=fs.readFileSync(path.join(dir,'novelty-revisions.tsv'),'utf8').trim().split(/\r?\n/).slice(1);
for(const row of revisions){const [id,prompt,answer]=row.split('\t');const q=questions.find(q=>q.id===id);if(!q||!answer)throw Error(`Bad revision ${id}`);q.prompt=prompt;q.answer=answer;q.explanation=`${answer}. ${q.references.map(r=>r.label).join(' / ')}의 문맥에서 인물의 행동과 말의 뜻을 확인해 보세요.`;}
const uniqueLegacy=[...new Map(legacy.questions.map(q=>[q.prompt.ko.trim(),q])).values()];
const numerical=/몇|얼마|계산|합계|합하면|더하|빼면|총합|곱하|나누면|berapa|how many|how much|subtract|multiply|divide|\d\s*[+×÷=]/i;
let removedNumerical=0;
for(const q of uniqueLegacy){
 if(numerical.test(q.prompt.ko)){removedNumerical++;continue;}
 const b=byId[q.book_id];const r=q.reference.ko.replace(b.name,q.book_id);
 const refs=r.includes(':')?[reference(r)]:[{book_id:b.id,chapter:q.chapter,verse_start:1,verse_end:1,label:q.reference.ko,url:`https://www.biblegateway.com/passage/?search=${encodeURIComponent(q.reference.en)}&version=KRV`}];
 questions.push({id:`legacy-${q.book_id}-${q.chapter}-${q.scripture_fact.slug}`,unit_id:`legacy-${q.book_id}-${q.chapter}`,book_id:q.book_id,difficulty:'easy',prompt:q.prompt.ko,answer:q.choices.find(c=>c.key===q.answer_key).label.ko,choices:q.choices.map(c=>c.label.ko),references:refs,explanation:q.explanation.ko,connection:'observation',origin:'legacy_curated',review_status:'legacy_unreviewed',arithmetic:false});
}
for(const q of questions){
 const b=byId[q.book_id];q.section=b.section;q.book=b.name;q.testament=b.testament;
 q.book_ids=[...new Set(q.references.map(r=>r.book_id))];
 const cross=q.difficulty==='hard'&&q.book_ids.some(id=>byId[id].testament==='old')&&q.book_ids.some(id=>byId[id].testament==='new');
 q.tags=[b.section,...(cross?['ot_nt']:[]),...(['nt_explicit','nt_typology'].includes(q.connection)?['christ_fulfillment']:[])];
 q.mcheyne_days=days.filter(d=>d.readings.some(r=>q.references.some(qr=>qr.book_id===r.book_id&&qr.chapter>=r.chapter_start&&qr.chapter<=r.chapter_end&&(!r.verse_start||(qr.verse_start<=r.verse_end&&qr.verse_end>=r.verse_start))))).map(d=>d.day);
 q.reading_hint='먼저 표시된 본문을 읽고 자신의 말로 답해 보세요. 정답과 표현이 달라도 핵심 뜻이 같으면 됩니다.';
}
questions.sort((a,b)=>byId[a.book_id].order-byId[b.book_id].order||a.id.localeCompare(b.id));
const counts={};for(const q of questions)counts[q.difficulty]=(counts[q.difficulty]||0)+1;
const bank={metadata:{version:'2026-09-13.1',new_questions:questions.filter(q=>q.origin==='new').length,total_questions:questions.length,books:66,arithmetic_questions:0,legacy_duplicate_rows_removed:legacy.questions.length-uniqueLegacy.length,legacy_numerical_questions_excluded:removedNumerical,difficulty_counts:counts,review:'AI 작성·구조 검증; 교단 공식 승인이나 전 문항 신학자 검수를 뜻하지 않음',mcheyne_source:'https://github.com/khornberg/readingplans/blob/master/mcheyne.json',leap_day:'02-29는 02-28 읽기 복습; 03-01부터 정상 날짜 유지'},books,days,questions};
fs.writeFileSync(path.join(dir,'bank.json'),JSON.stringify(bank,null,2)+'\n');
fs.writeFileSync(path.join(root,'readingBank.generated.js'),`globalThis.BIBLE_READING_BANK=${JSON.stringify(bank)};\n`);
fs.writeFileSync(path.join(dir,'new-questions.json'),JSON.stringify(questions.filter(q=>q.origin==='new'),null,2)+'\n');
const md=['# 성경을 읽게 하는 신규 문제 1,056개','', '정답은 본문을 요약한 표현입니다. 신학자 전수 검수 전의 AI 작성 초안입니다.',''];
for(const b of books){md.push(`## ${b.name}`,'');for(const q of questions.filter(q=>q.origin==='new'&&q.book_id===b.id)){md.push(`### ${q.id} · ${{easy:'초급',medium:'중급',hard:'고급'}[q.difficulty]}`,`- 읽기: ${q.references.map(r=>r.label).join(' / ')}`,`- 문제: ${q.prompt}`,`- 답: ${q.answer}`,`- 해설: ${q.explanation}`,'');}}
fs.writeFileSync(path.join(dir,'NEW_QUESTIONS_KO.md'),md.join('\n'));
const literal=v=>`'${String(v).replaceAll("'","''")}'`;
const json=v=>`${literal(JSON.stringify(v))}::jsonb`;
const sql=['BEGIN;'];
sql.push(`insert into public.bible_books(id,name,section,testament,chapters,sort_order) values\n${books.map(b=>`(${literal(b.id)},${literal(b.name)},${literal(b.section)},${literal(b.testament)},${b.chapters},${b.order})`).join(',\n')}\non conflict(id) do update set name=excluded.name,section=excluded.section,testament=excluded.testament,chapters=excluded.chapters,sort_order=excluded.sort_order;`);
sql.push(`insert into public.bible_reading_days(day,calendar_date,readings) values\n${days.map(d=>`(${d.day},${literal(d.date)},${json(d.readings)})`).join(',\n')}\non conflict(day) do update set calendar_date=excluded.calendar_date,readings=excluded.readings;`);
// Deterministic text IDs make reruns idempotent; no generated database IDs are embedded.
const batches=[];
for(let i=0;i<questions.length;i+=100){
 const query=`insert into public.bible_questions(id,book_id,difficulty,origin,tags,mcheyne_days,arithmetic,payload) values\n${questions.slice(i,i+100).map(q=>`(${literal(q.id)},${literal(q.book_id)},${literal(q.difficulty)},${literal(q.origin)},ARRAY[${q.tags.map(literal).join(',')}]::text[],ARRAY[${q.mcheyne_days.join(',')}]::integer[],false,${json(q)})`).join(',\n')}\non conflict(id) do update set book_id=excluded.book_id,difficulty=excluded.difficulty,origin=excluded.origin,tags=excluded.tags,mcheyne_days=excluded.mcheyne_days,arithmetic=excluded.arithmetic,payload=excluded.payload;`;
 sql.push(query);batches.push(query);
}
sql.push('COMMIT;');fs.writeFileSync(path.join(dir,'seed.sql'),sql.join('\n'));
fs.writeFileSync(path.join(dir,'upload-batches.json'),JSON.stringify([sql[1],sql[2],...batches]));
console.log(JSON.stringify(bank.metadata,null,2));
