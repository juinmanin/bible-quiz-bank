"""Build translation drafts using the public Argos English-Malay model.
Run pip install ctranslate2==4.8.2 sentencepiece==0.2.2 requests, then this script.
No credentials, remote inference, or model files are included in the public quiz package.
"""
import json,pathlib,subprocess,sys,zipfile,time,re
import ctranslate2,sentencepiece
ROOT=pathlib.Path(__file__).resolve().parent.parent
partial_ms='--partial-ms' in sys.argv
if not partial_ms:subprocess.run([sys.executable,str(ROOT/'scripts/download-translation-packages.py')],cwd=ROOT,check=True)
data=json.loads((ROOT/'question-bank/translation-jobs.json').read_text(encoding='utf8'))
cache_file=ROOT/'question-bank/translation-cache.json'
cache=json.loads(cache_file.read_text(encoding='utf8')) if cache_file.exists() else {'en':{},'ms':{}}
started=time.time()
for k,v in data['jobs']['en'].items():
 if v and not cache['en'].get(k):cache['en'][k]=v
if any(not cache['en'].get(k) for k in data['jobs']['en']):raise ValueError('Run build-manual-english.mjs first')
for language,pair in [('ms','en_ms')]:
 directory=(ROOT/'artifacts/translation-argos'/pair).resolve();directory.mkdir(exist_ok=True)
 with zipfile.ZipFile(ROOT/'artifacts/translation-argos'/(pair+'.argosmodel')) as z:
  for entry in z.infolist():
   destination=(directory/entry.filename).resolve()
   if not destination.is_relative_to(directory) or (entry.external_attr>>16)&0o170000==0o120000:raise ValueError('Unsafe package entry')
   if not entry.is_dir() and (entry.filename.endswith(('sentencepiece.model','bpe.model','metadata.json','LICENSE')) or '/model/' in entry.filename):
    destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(z.read(entry))
 model=next(directory.rglob('model.bin')).parent
 spfile=next(directory.rglob('sentencepiece.model'),None)
 if not spfile:raise ValueError('Expected a SentencePiece tokenizer')
 sp=sentencepiece.SentencePieceProcessor(model_file=str(spfile))
 translator=ctranslate2.Translator(str(model),device='cpu',compute_type='int8',inter_threads=1,intra_threads=4)
 cache[language].update({k:v for k,v in data['jobs'][language].items() if v})
 pending=[s for s in data['jobs'][language] if not cache[language].get(s) and (not partial_ms or cache['en'].get(s))]
 pending.sort(key=lambda s:len(s if language=='en' else cache['en'][s]))
 for offset in range(0,len(pending),32):
  batch=pending[offset:offset+32];texts=[s if language=='en' else cache['en'][s] for s in batch]
  tokens=[sp.encode(s,out_type=str) for s in texts]
  results=translator.translate_batch(tokens,beam_size=3,max_decoding_length=384,repetition_penalty=1.05)
  for original,result in zip(batch,results):
   value=sp.decode(result.hypotheses[0]).replace('▁',' ').replace('_',' ').replace('♪','').strip()
   if not value:raise ValueError('Empty translation for '+original)
   cache[language][original]=value
  cache_file.write_text(json.dumps(cache,ensure_ascii=False,indent=2),encoding='utf8')
  print(f'{language}: {min(offset+32,len(pending))}/{len(pending)}; elapsed {round(time.time()-started)}s',flush=True)
 del translator
print('TRANSLATION_COMPLETE',flush=True)
