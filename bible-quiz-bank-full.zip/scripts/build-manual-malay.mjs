import fs from 'node:fs';import assert from 'node:assert/strict';
const bank=JSON.parse(fs.readFileSync('question-bank/bank.json','utf8'));
const overrides=JSON.parse(fs.readFileSync('question-bank/translation-overrides.json','utf8'));
const lines=f=>fs.readFileSync('question-bank/'+f,'utf8').replace(/^\uFEFF/,'').trim().split(/\r?\n/);
const seen=new Set();
for(const row of lines('manual-ms-choice.tsv')){
 const [book,prompt,answer,wrong]=row.split('|');const q=bank.questions.find(q=>q.id===`new-${book}-comprehension`);
 assert.ok(q&&!seen.has(book));seen.add(book);overrides.ms[q.prompt]=prompt;overrides.ms[q.answer]=answer;
 const choices=q.choices.filter(c=>c!==q.answer),translated=wrong.split('~');assert.equal(choices.length,translated.length);
 choices.forEach((c,i)=>overrides.ms[c]=translated[i]);
}
assert.equal(seen.size,66);
for(const row of lines('manual-ms-corrections.tsv')){const [ko,ms,extra]=row.split('|');assert.ok(ko&&ms&&!extra);overrides.ms[ko]=ms;}
fs.writeFileSync('question-bank/translation-overrides.json',JSON.stringify(overrides,null,2));
console.log('MALAY_EDITED: 66 complete multiple-choice questions; '+Object.keys(overrides.ms).length+' corrected strings');
