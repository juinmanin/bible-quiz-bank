import requests,pathlib,concurrent.futures,zipfile,time
root=pathlib.Path('artifacts/translation-argos');root.mkdir(parents=True,exist_ok=True)
def download(item):
 name,url=item;target=root/(name+'.argosmodel')
 if not zipfile.is_zipfile(target):
  response=requests.get(url,headers={'Range':'bytes=0-1023'},timeout=30);response.raise_for_status()
  total=int(response.headers['Content-Range'].split('/')[-1]);parts=root/(name+'-parts');parts.mkdir(exist_ok=True)
  print(name,'total',total,flush=True)
  size=1024*1024
  ranges=[(i,min(i+size-1,total-1)) for i in range(0,total,size)]
  def part(bounds):
   a,b=bounds;p=parts/str(a)
   if p.exists() and p.stat().st_size==b-a+1:return p
   for retry in range(2):
    try:
     r=requests.get(url,headers={'Range':f'bytes={a}-{b}'},timeout=45)
     if r.status_code!=206 or len(r.content)!=b-a+1 or r.headers.get('Content-Range')!=f'bytes {a}-{b}/{total}':raise ValueError('Incorrect range')
     p.write_bytes(r.content);print(name,a,'OK',flush=True);return p
    except Exception:
     if retry:raise RuntimeError('Package range download failed') from None
  with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
   # Small groups bound failure handling; finished parts survive an interruption.
   for group in range(0,len(ranges),16):list(pool.map(part,ranges[group:group+16]))
  with target.open('wb') as out:
   for a,b in ranges:out.write((parts/str(a)).read_bytes())
 with zipfile.ZipFile(target) as z:
  if z.testzip():raise ValueError('Package CRC failure')
  print(name,z.namelist()[:25],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(download,[('en_ms','https://argos-net.com/v1/translate-en_ms-1_9.argosmodel')]))
