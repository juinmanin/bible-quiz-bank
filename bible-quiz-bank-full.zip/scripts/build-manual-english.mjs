import fs from 'node:fs';
import assert from 'node:assert/strict';
const read = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const bank = read('question-bank/bank.json');
const jobs = read('question-bank/translation-jobs.json');
const cache = read('question-bank/translation-cache.json');
const questions = new Map(bank.questions.filter(q => q.origin === 'new').map(q => [q.id, q]));
const rows = fs.readFileSync('question-bank/manual-en.tsv', 'utf8').replace(/^\uFEFF/, '').trim().split(/\r?\n/);
const answers = new Map(), translations = new Map(), seen = new Set();
// Shared Korean strings have one canonical translation throughout the application.
function add(source, english) {
  assert.ok(source && english?.trim(), 'Empty translation');
  assert.ok(!/[가-힣▁⁇]/.test(english), 'Invalid English text');
  if (!translations.has(source)) translations.set(source, english.trim());
}
for (const row of rows) {
  const [id, prompt, answer, distractors, extra] = row.split('|');
  const q = questions.get('new-' + id);
  assert.ok(q && !seen.has(q.id) && !extra, 'Invalid or duplicate row: ' + id);
  seen.add(q.id); answers.set(q.id, answer);
  add(q.prompt, prompt); add(q.answer, answer);
  const wrong = q.choices.filter(choice => choice !== q.answer);
  const translatedWrong = distractors ? distractors.split('~') : [];
  assert.equal(translatedWrong.length, wrong.length, 'Choice mismatch: ' + id);
  wrong.forEach((choice, i) => add(choice, translatedWrong[i]));
}
assert.equal(seen.size, questions.size, 'Missing authored English questions');
const explanationGroups = Map.groupBy([...questions.values()], q => q.explanation);
for (const [source, group] of explanationGroups) {
  const points = [...new Set(group.map(q => translations.get(q.answer)))];
  // The English explanation is an answer-focused summary, not a literal translation.
  // References stay in the question's localized reference list, avoiding English book
  // names embedded inside the subsequent Malay explanation.
  add(source, 'Read the listed passages in context. Key points: ' + points.join('; ') + '.');
}
let changed = 0;
for (const [source, english] of Object.entries(jobs.jobs.en)) {
  const value = translations.get(source) || english;
  assert.ok(value, 'Missing English: ' + source);
  if (cache.en[source] !== value) { delete cache.ms[source]; changed++; }
  cache.en[source] = value;
}
fs.writeFileSync('question-bank/translation-cache.json', JSON.stringify(cache, null, 2));
console.log(`ENGLISH_READY: ${seen.size} authored question/answer rows; ${Object.keys(cache.en).length} strings; ${changed} Malay strings invalidated`);
