import fs from 'node:fs';
const jobs=JSON.parse(fs.readFileSync('question-bank/translation-jobs.json','utf8'));
const strings=JSON.parse(fs.readFileSync('question-bank/translation-cache.json','utf8'));
for(const lang of ['en','ms'])for(const key of Object.keys(strings[lang]))strings[lang][key]=strings[lang][key].replace(/[▁_]/g,' ').replace(/♪/g,'').replace(/\s+/g,' ').trim();
const overrides=fs.existsSync('question-bank/translation-overrides.json')?JSON.parse(fs.readFileSync('question-bank/translation-overrides.json','utf8')):{};
for(const lang of ['en','ms']){Object.assign(strings[lang],overrides[lang]);for(const text of Object.keys(jobs.jobs[lang]))if(!strings[lang][text]?.trim())throw Error('Missing '+lang+' translation: '+text);}
const bank=JSON.parse(fs.readFileSync('question-bank/bank.json','utf8'));
for(const [source,group] of Map.groupBy(bank.questions.filter(q=>q.origin==='new'),q=>q.explanation)){
 strings.ms[source]='Baca petikan yang disenaraikan dalam konteksnya. Isi utama: '+[...new Set(group.map(q=>strings.ms[q.answer]))].join('; ')+'.';
}
const data={metadata:{languages:['ko','en','ms'],translation_status:'machine_draft_with_editorial_overrides',model:'Argos en-ms 1.9',model_url:'https://github.com/argosopentech/argospm-index',english_source:'Existing English plus 1056 authored English question/answer rows; answer-focused explanation summaries',malay_source:'Local translation from English',review:'Not a full human linguistic or theological review'},books:jobs.books,strings};
fs.writeFileSync('question-bank/translations.json',JSON.stringify(data,null,2));
fs.writeFileSync('reading-bank-translations.generated.js','globalThis.BIBLE_READING_TRANSLATIONS='+JSON.stringify(data)+';\n');
console.log('LOCALES_BUILT: en/ms '+Object.keys(jobs.jobs.en).length+' strings each');
