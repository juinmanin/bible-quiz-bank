import fs from 'node:fs';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),bank=require('../question-bank/bank.json'),legacy=require('../bibleChapterQuestionBank.generated.js');
const jobs={en:{},ms:{}},existing={};
for(const q of legacy.questions){
 for(const field of ['prompt','explanation'])if(q[field]?.ko&&q[field]?.en)existing[q[field].ko]=q[field].en;
 for(const c of q.choices)existing[c.label.ko]=c.label.en;
}
for(const q of bank.questions)for(const text of [q.prompt,q.answer,q.explanation,...q.choices]){
 jobs.en[text]=existing[text]||null;
 jobs.ms[text]=null;
}
const books=Object.fromEntries(legacy.books.map(b=>[b.book_id,{ko:b.title.ko,en:b.title.en,ms:b.title.ms}]));
fs.writeFileSync('question-bank/translation-jobs.json',JSON.stringify({books,jobs},null,2));
console.log(JSON.stringify({unique_strings:Object.keys(jobs.en).length,existing_english:Object.values(jobs.en).filter(Boolean).length}));
